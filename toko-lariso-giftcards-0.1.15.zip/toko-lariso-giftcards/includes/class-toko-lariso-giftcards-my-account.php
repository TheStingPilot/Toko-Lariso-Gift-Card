<?php
/**
 * My Account giftcard balance checker.
 *
 * @package TokoLarisoGiftcards
 */

defined( 'ABSPATH' ) || exit;

/**
 * Adds a customer-facing balance lookup without exposing full codes.
 */
class Toko_Lariso_Giftcards_My_Account {
	private const ENDPOINT               = 'giftcards';
	private const REWRITE_VERSION_OPTION = 'tokolariso_giftcards_rewrite_version';

	/**
	 * Repository.
	 *
	 * @var Toko_Lariso_Giftcards_Repository
	 */
	private Toko_Lariso_Giftcards_Repository $repository;

	/**
	 * Constructor.
	 *
	 * @param Toko_Lariso_Giftcards_Repository $repository Repository.
	 */
	public function __construct( Toko_Lariso_Giftcards_Repository $repository ) {
		$this->repository = $repository;
	}

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public function init(): void {
		add_action( 'init', array( $this, 'add_endpoint' ) );
		add_action( 'wp_loaded', array( $this, 'maybe_flush_rewrite_rules' ) );
		add_filter( 'query_vars', array( $this, 'add_query_vars' ) );
		add_filter( 'woocommerce_account_menu_items', array( $this, 'add_menu_item' ) );
		add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( $this, 'render_endpoint' ) );
		add_shortcode( 'tokolariso_giftcard_balance', array( $this, 'render_shortcode' ) );
	}

	/**
	 * Registers the My Account endpoint.
	 *
	 * @return void
	 */
	public function add_endpoint(): void {
		add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
	}

	/**
	 * Flushes rewrite rules once per plugin version.
	 *
	 * @return void
	 */
	public function maybe_flush_rewrite_rules(): void {
		if ( get_option( self::REWRITE_VERSION_OPTION ) === TOKO_LARISO_GIFTCARDS_VERSION ) {
			return;
		}

		flush_rewrite_rules( false );
		update_option( self::REWRITE_VERSION_OPTION, TOKO_LARISO_GIFTCARDS_VERSION, false );
	}

	/**
	 * Adds query vars.
	 *
	 * @param string[] $vars Query vars.
	 * @return string[]
	 */
	public function add_query_vars( array $vars ): array {
		$vars[] = self::ENDPOINT;
		return $vars;
	}

	/**
	 * Adds menu item to WooCommerce My Account.
	 *
	 * @param array<string,string> $items Menu items.
	 * @return array<string,string>
	 */
	public function add_menu_item( array $items ): array {
		$updated = array();

		foreach ( $items as $key => $label ) {
			if ( 'customer-logout' === $key ) {
				$updated[ self::ENDPOINT ] = __( 'Giftcards', 'toko-lariso-giftcards' );
			}
			$updated[ $key ] = $label;
		}

		if ( ! isset( $updated[ self::ENDPOINT ] ) ) {
			$updated[ self::ENDPOINT ] = __( 'Giftcards', 'toko-lariso-giftcards' );
		}

		return $updated;
	}

	/**
	 * Renders endpoint content.
	 *
	 * @return void
	 */
	public function render_endpoint(): void {
		echo $this->render_balance_checker(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Shortcode callback.
	 *
	 * @return string
	 */
	public function render_shortcode(): string {
		return $this->render_balance_checker();
	}

	/**
	 * Renders balance checker form and result.
	 *
	 * @return string
	 */
	private function render_balance_checker(): string {
		$result = null;
		$error  = '';
		$code   = '';

		if ( isset( $_POST['tokolariso_giftcard_balance_action'] ) ) {
			$nonce = isset( $_POST['tokolariso_giftcard_balance_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['tokolariso_giftcard_balance_nonce'] ) ) : '';
			$code  = isset( $_POST['tokolariso_giftcard_balance_code'] ) ? sanitize_text_field( wp_unslash( $_POST['tokolariso_giftcard_balance_code'] ) ) : '';

			if ( ! wp_verify_nonce( $nonce, 'tokolariso_giftcard_balance' ) ) {
				$error = __( 'Security check failed. Please try again.', 'toko-lariso-giftcards' );
			} elseif ( '' === trim( $code ) ) {
				$error = __( 'Please enter a giftcard code.', 'toko-lariso-giftcards' );
			} else {
				$result = $this->lookup_card( $code );
				if ( ! $result ) {
					$error = __( 'Giftcard code was not found or cannot be checked.', 'toko-lariso-giftcards' );
				}
			}
		}

		ob_start();
		?>
		<div class="tokolariso-giftcard-balance-checker">
			<h3><?php esc_html_e( 'Check giftcard balance', 'toko-lariso-giftcards' ); ?></h3>
			<form method="post" class="tokolariso-giftcard-balance-form">
				<?php wp_nonce_field( 'tokolariso_giftcard_balance', 'tokolariso_giftcard_balance_nonce' ); ?>
				<input type="hidden" name="tokolariso_giftcard_balance_action" value="check" />
				<p class="form-row form-row-wide">
					<label for="tokolariso-giftcard-balance-code"><?php esc_html_e( 'Giftcard code', 'toko-lariso-giftcards' ); ?></label>
					<input
						type="text"
						id="tokolariso-giftcard-balance-code"
						name="tokolariso_giftcard_balance_code"
						value="<?php echo esc_attr( $code ); ?>"
						autocomplete="off"
					/>
				</p>
				<p>
					<button type="submit" class="button wp-element-button"><?php esc_html_e( 'Check balance', 'toko-lariso-giftcards' ); ?></button>
				</p>
			</form>

			<?php if ( $error ) : ?>
				<div class="woocommerce-error" role="alert"><?php echo esc_html( $error ); ?></div>
			<?php endif; ?>

			<?php if ( is_array( $result ) ) : ?>
				<table class="shop_table shop_table_responsive tokolariso-giftcard-balance-result">
					<tbody>
						<tr>
							<th><?php esc_html_e( 'Code', 'toko-lariso-giftcards' ); ?></th>
							<td><?php echo esc_html( (string) $result['code_mask'] ); ?></td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Current balance', 'toko-lariso-giftcards' ); ?></th>
							<td><?php echo wp_kses_post( wc_price( (float) $result['current_balance'], array( 'currency' => (string) $result['currency'] ) ) ); ?></td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Status', 'toko-lariso-giftcards' ); ?></th>
							<td><?php echo esc_html( $this->status_label( (string) $result['status'] ) ); ?></td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Expiry date', 'toko-lariso-giftcards' ); ?></th>
							<td><?php echo esc_html( $this->format_expiry( $result['expires_at'] ?? null ) ); ?></td>
						</tr>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Looks up a giftcard for customer display.
	 *
	 * @param string $code Giftcard code.
	 * @return array<string,mixed>|null
	 */
	private function lookup_card( string $code ): ?array {
		$card = $this->repository->get_by_code( $code );
		if ( ! $card ) {
			return null;
		}

		if ( $this->repository->is_expired_by_date( $card ) ) {
			$this->repository->expire( (int) $card['id'] );
			$card = $this->repository->get_by_id( (int) $card['id'] );
		}

		return $card;
	}

	/**
	 * Formats a giftcard status for customers.
	 *
	 * @param string $status Status.
	 * @return string
	 */
	private function status_label( string $status ): string {
		return match ( $status ) {
			'active' => __( 'Active', 'toko-lariso-giftcards' ),
			'used' => __( 'Used', 'toko-lariso-giftcards' ),
			'expired' => __( 'Expired', 'toko-lariso-giftcards' ),
			'blocked' => __( 'Blocked', 'toko-lariso-giftcards' ),
			default => __( 'Unknown', 'toko-lariso-giftcards' ),
		};
	}

	/**
	 * Formats expiry for customer display.
	 *
	 * @param mixed $expires_at Expiry date.
	 * @return string
	 */
	private function format_expiry( mixed $expires_at ): string {
		if ( empty( $expires_at ) ) {
			return __( 'No expiry date', 'toko-lariso-giftcards' );
		}

		$timestamp = strtotime( (string) $expires_at );
		if ( ! $timestamp ) {
			return __( 'No expiry date', 'toko-lariso-giftcards' );
		}

		return wp_date( get_option( 'date_format' ), $timestamp );
	}
}
