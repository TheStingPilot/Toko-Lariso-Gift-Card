<?php
    defined( 'ABSPATH' ) || exit;
    class WALLREGI_Product_Wxgiftcard extends WC_Product_Simple {
        /**
         * Return the product type
         * @return string
         */
        public function get_type() {
            return 'wxgiftcard';
        }

        public function add_to_cart_url(){
            return get_permalink( $this->get_id() );;
        }

        public function add_to_cart_text(){
            $wallregi_settings = get_option( 'wallregi_settings', [] );
            $wallregi_defaults = [
                'shop_giftcard_button' => 'View Giftcard',
            ];
            $wallregi_settings = wp_parse_args( $wallregi_settings, $wallregi_defaults );

            return esc_html( $wallregi_settings['shop_giftcard_button'] );
        }

        public function supports( $feature ) {
            if('ajax_add_to_cart' === $feature){
                return false;
            } else {
                // phpcs:ignore
                return apply_filters( 'wallregi_woocommerce_product_supports', in_array( $feature, $this->supports, true ), $feature, $this );
            }
        }

        public function is_purchasable() {
            return true;
        }
       
        public function is_sold_individually() {
            return true;
        }
    }


