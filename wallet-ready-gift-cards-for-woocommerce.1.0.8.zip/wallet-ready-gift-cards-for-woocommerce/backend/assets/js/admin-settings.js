/**
 * Unified settings hub: in-page tabs + AJAX save (no full reload).
 */
(function () {
    var cfg = typeof wallregiAdminSettings !== 'undefined' ? wallregiAdminSettings : null;
    if (!cfg || !cfg.hubTabKeys || !cfg.hubTabKeys.length) {
        return;
    }

    function showToast(message, isError) {
        var el = document.getElementById('wallregi-admin-settings-toast');
        if (!el) {
            el = document.createElement('div');
            el.id = 'wallregi-admin-settings-toast';
            el.className = 'wallregi-admin-settings-toast';
            el.setAttribute('role', 'status');
            document.body.appendChild(el);
        }
        el.textContent = message;
        el.classList.toggle('is-error', !!isError);
        el.classList.add('is-visible');
        clearTimeout(showToast._t);
        showToast._t = setTimeout(function () {
            el.classList.remove('is-visible');
        }, 3800);
    }

    function restoreAlwaysVisibleHubPanels(tabKey) {
        if (tabKey !== 'wallregi_email' && tabKey !== 'wallregi_wallet') {
            return;
        }
        var hubPanel = document.querySelector(
            '.wallregi-settings-hub-panel[data-settings-tab="' + tabKey + '"]'
        );
        if (!hubPanel) {
            return;
        }
        hubPanel.querySelectorAll('.wodg_panels').forEach(function (p) {
            p.style.display = 'block';
        });
        if (tabKey === 'wallregi_wallet') {
            var providerSelect = document.getElementById('wallregi_wallet_provider');
            if (providerSelect) {
                providerSelect.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }
    }

    function showPanel(tabKey) {
        var hubEl = document.getElementById('wallregi-settings-hub');
        if (!hubEl) {
            return;
        }
        document.querySelectorAll('.wallregi-settings-hub-panel').forEach(function (panel) {
            var match = panel.getAttribute('data-settings-tab') === tabKey;
            panel.style.display = match ? 'block' : 'none';
            panel.hidden = !match;
        });
        document.querySelectorAll('.wallregi-settings-hub__tab').forEach(function (btn) {
            var on = btn.getAttribute('data-wallregi-hub-tab') === tabKey;
            btn.classList.toggle('is-active', on);
            btn.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        hubEl.setAttribute('data-active-tab', tabKey);
        restoreAlwaysVisibleHubPanels(tabKey);
    }

    /**
     * @param {string} tabKey
     * @param {string|null} sidebarHref Full URL from sidebar link (keeps fresh nonce), or null when switching inner tabs.
     */
    window.wallregiSettingsHubActivateTab = function (tabKey, sidebarHref) {
        if (cfg.hubTabKeys.indexOf(tabKey) === -1) {
            return;
        }
        if (sidebarHref) {
            window.history.replaceState({}, '', sidebarHref);
        } else {
            var u = new URL(window.location.href);
            u.searchParams.set('tab', tabKey);
            window.history.replaceState({}, '', u.toString());
        }
        showPanel(tabKey);
    };

    function bindHubTabs() {
        document.querySelectorAll('.wallregi-settings-hub__tab').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var key = btn.getAttribute('data-wallregi-hub-tab');
                if (key) {
                    window.wallregiSettingsHubActivateTab(key, null);
                }
            });
        });
    }

    function bindSidebarDeepLinks() {
        document.addEventListener(
            'click',
            function (e) {
                var a = e.target.closest('.wallregi_panel_submenu a.item-link[data-tab]');
                if (!a) {
                    return;
                }
                var tab = a.getAttribute('data-tab');
                if (!tab || cfg.hubTabKeys.indexOf(tab) === -1) {
                    return;
                }
                if (!document.getElementById('wallregi-settings-hub')) {
                    return;
                }
                e.preventDefault();
                var href = a.getAttribute('href');
                window.wallregiSettingsHubActivateTab(tab, href || null);
            },
            true
        );
    }

    function saveForm(form) {
        if (form.dataset.wallregiSaving === '1') {
            return;
        }
        form.dataset.wallregiSaving = '1';
        var tab = form.getAttribute('data-settings-tab');
        var btns = form.querySelectorAll('[name="wallregi_save_settings"]');
        btns.forEach(function (b) {
            b.disabled = true;
            b.setAttribute('aria-busy', 'true');
            b.classList.add('wallregi-is-saving');
            if (!b.querySelector('.wallregi-save-spinner')) {
                var sp = document.createElement('span');
                sp.className = 'wallregi-save-spinner';
                sp.setAttribute('aria-hidden', 'true');
                b.insertBefore(sp, b.firstChild);
            }
        });

        if (window.tinymce) {
            if (typeof window.tinymce.triggerSave === 'function') {
                window.tinymce.triggerSave();
            } else if (window.tinymce.get('wallregi_email_body')) {
                window.tinymce.get('wallregi_email_body').save();
            }
        }

        if (tab === 'wallregi_wallet' && window.jQuery) {
            var $templateSel = window.jQuery('#wallregi_wallet_global_template_uid');
            if ($templateSel.length) {
                var $opt = $templateSel.find('option:selected');
                window.jQuery('#wallregi_wallet_global_template_name').val(
                    $opt.attr('data-template-name') || $opt.text() || ''
                );
                window.jQuery('#wallregi_wallet_global_template_id').val($opt.attr('data-template-id') || 0);
            }
        }

        var fd = new FormData(form);
        fd.append('action', 'wallregi_admin_save_settings');
        fd.append('nonce', cfg.nonce);
        fd.append('settings_tab', tab);

        fetch(cfg.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: fd,
        })
            .then(function (res) {
                if (!res.ok) {
                    throw new Error('bad_status');
                }
                return res.json();
            })
            .then(function (json) {
                if (!json.success) {
                    var msg =
                        json.data && json.data.message ? json.data.message : cfg.strings.saveFailed;
                    showToast(msg, true);
                } else {
                    showToast(
                        json.data && json.data.message ? json.data.message : cfg.strings.saved,
                        false
                    );
                }
            })
            .catch(function () {
                showToast(cfg.strings.network, true);
            })
            .finally(function () {
                form.dataset.wallregiSaving = '0';
                btns.forEach(function (b) {
                    b.disabled = false;
                    b.removeAttribute('aria-busy');
                    b.classList.remove('wallregi-is-saving');
                    var sp = b.querySelector('.wallregi-save-spinner');
                    if (sp) {
                        sp.remove();
                    }
                });
            });
    }

    function bindForms() {
        document.querySelectorAll('form.wallregi-settings-hub-form').forEach(function (form) {
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                saveForm(form);
            });
        });
    }

    function renderWalletStatus(container, data) {
        if (!container) {
            return;
        }
        container.innerHTML = '';
        if (!data || !data.message) {
            return;
        }
        var wrap = document.createElement('div');
        wrap.className = 'notice notice-success inline wallregi-wallet-status__inner';
        var p1 = document.createElement('p');
        var strong = document.createElement('strong');
        strong.textContent = data.message;
        p1.appendChild(strong);
        wrap.appendChild(p1);
        if (data.expiry_label) {
            var p2 = document.createElement('p');
            p2.className = 'description';
            p2.style.margin = '0.35em 0 0';
            var cap = data.expiry_caption || '';
            p2.textContent = cap ? cap + ': ' + data.expiry_label : data.expiry_label;
            wrap.appendChild(p2);
        }
        if (data.expiry_utc) {
            var p3 = document.createElement('p');
            p3.className = 'description';
            p3.style.margin = '0.35em 0 0';
            p3.textContent = (cfg.strings.walletExpiryUtcPrefix || '') + data.expiry_utc;
            wrap.appendChild(p3);
        }
        container.appendChild(wrap);
    }

    function bindWalletConnect() {
        var btn = document.getElementById('wallregi_wallet_connect_btn');
        var input = document.getElementById('wallregi_epass_api_key');
        var statusEl = document.getElementById('wallregi-wallet-status');
        if (!btn || !input || !cfg.strings) {
            return;
        }
        btn.addEventListener('click', function () {
            var key = (input.value || '').trim();
            var masked = input.getAttribute('data-wallregi-masked') === '1';
            if (!key && masked) {
                showToast(cfg.strings.walletEnterKey, true);
                return;
            }
            if (!key) {
                showToast(cfg.strings.walletEnterKey, true);
                return;
            }
            if (btn.dataset.wallregiConnecting === '1') {
                return;
            }
            btn.dataset.wallregiConnecting = '1';
            btn.disabled = true;
            btn.setAttribute('aria-busy', 'true');
            var prevLabel = btn.textContent;
            btn.textContent = cfg.strings.walletConnecting || prevLabel;

            var fd = new FormData();
            fd.append('action', 'wallregi_wallet_epass_connect');
            fd.append('nonce', cfg.nonce);
            fd.append('api_key', key);

            fetch(cfg.ajaxUrl, {
                method: 'POST',
                credentials: 'same-origin',
                body: fd,
            })
                .then(function (res) {
                    if (!res.ok) {
                        throw new Error('bad_status');
                    }
                    return res.json();
                })
                .then(function (json) {
                    if (!json.success) {
                        var msg =
                            json.data && json.data.message ? json.data.message : cfg.strings.saveFailed;
                        showToast(msg, true);
                        return;
                    }
                    var d = json.data || {};
                    showToast(d.message || cfg.strings.saved, false);
                    input.value = '';
                    input.placeholder = '****';
                    input.setAttribute('data-wallregi-masked', '1');
                    renderWalletStatus(statusEl, d);
                })
                .catch(function () {
                    showToast(cfg.strings.network, true);
                })
                .finally(function () {
                    btn.dataset.wallregiConnecting = '0';
                    btn.disabled = false;
                    btn.removeAttribute('aria-busy');
                    btn.textContent = prevLabel;
                });
        });
    }

    function bindWalletProviderToggle() {
        var select = document.getElementById('wallregi_wallet_provider');
        if (!select) {
            return;
        }

        function panelStyle(show) {
            return show ? '' : 'none';
        }

        function syncWalletProviderPanels() {
            var value = select.value || 'none';

            document.querySelectorAll('[data-wallet-provider-panel]').forEach(function (panel) {
                var match = panel.getAttribute('data-wallet-provider-panel') === value;
                panel.style.display = panelStyle(match);
            });

            document.querySelectorAll('[data-wallet-provider-hint="gtw-settings"]').forEach(function (hint) {
                hint.style.display = panelStyle(value === 'gifttowallet');
            });
        }

        select.addEventListener('change', syncWalletProviderPanels);
        syncWalletProviderPanels();
    }

    document.addEventListener('DOMContentLoaded', function () {
        if (!document.getElementById('wallregi-settings-hub')) {
            return;
        }
        bindHubTabs();
        bindSidebarDeepLinks();
        bindForms();
        bindWalletConnect();
        bindWalletProviderToggle();
        var active = document.getElementById('wallregi-settings-hub').getAttribute('data-active-tab');
        if (active && cfg.hubTabKeys.indexOf(active) !== -1) {
            showPanel(active);
        }
    });
})();
