(function ($) {
	'use strict';

	var cfg = window.wallregiAdminOrderGiftcard;
	if (!cfg) {
		return;
	}

	function getOrderId($wrap) {
		var id = parseInt($wrap.data('order-id'), 10);
		if (id > 0) {
			return id;
		}
		if (typeof woocommerce_admin_meta_boxes !== 'undefined' && woocommerce_admin_meta_boxes.order_id) {
			return parseInt(woocommerce_admin_meta_boxes.order_id, 10);
		}
		return 0;
	}

	function showMsg($wrap, text, type) {
		type = type || 'info';
		var cls = 'notice-info';
		if (type === 'error') {
			cls = 'notice-error';
		} else if (type === 'success') {
			cls = 'notice-success';
		}
		$wrap.find('.wallregi-admin-order-giftcard-msg').html(
			'<div class="notice ' + cls + ' inline"><p>' + $('<div>').text(text).html() + '</p></div>'
		);
	}

	function post(action, data, $wrap) {
		data.action = action;
		data.nonce = cfg.nonce;
		return $.post(cfg.ajaxUrl, data)
			.done(function (res) {
				if (!res || !res.success) {
					var err =
						res && res.data && res.data.message
							? String(res.data.message)
							: 'Request failed.';
					showMsg($wrap, err, 'error');
					return;
				}
				showMsg($wrap, res.data && res.data.message ? String(res.data.message) : cfg.strings.reloadHint, 'success');
				if (res.data && res.data.reload) {
					window.setTimeout(function () {
						window.location.reload();
					}, 600);
				}
			})
			.fail(function () {
				showMsg($wrap, 'Network error.', 'error');
			});
	}

	$(document).on('click', '.wallregi-admin-order-apply-giftcard', function () {
		var $wrap = $(this).closest('.wallregi-admin-order-giftcard-wrap');
		if (!$wrap.length || $wrap.data('editable') !== 1 && $wrap.data('editable') !== '1') {
			return;
		}
		var code = $.trim($wrap.find('.wallregi-admin-order-giftcard-code').val());
		if (!code) {
			window.alert(cfg.strings.codeRequired);
			return;
		}
		var orderId = getOrderId($wrap);
		if (!orderId) {
			return;
		}
		var payload = {
			order_id: orderId,
			giftcard_code: code,
		};
		if (cfg.buyerUi) {
			var amt = $.trim($wrap.find('.wallregi-admin-order-giftcard-amount').val());
			if (amt !== '') {
				payload.redeem_amount = amt;
			}
		}
		showMsg($wrap, cfg.strings.working, 'info');
		post('wallregi_admin_order_apply_giftcard', payload, $wrap);
	});

	$(document).on('click', '.wallregi-admin-order-remove-giftcard', function () {
		var $wrap = $(this).closest('.wallregi-admin-order-giftcard-wrap');
		var code = $(this).data('code') || '';
		var orderId = getOrderId($wrap);
		if (!orderId || !code) {
			return;
		}
		if (!window.confirm('Remove gift card ' + code + ' from this order and restore its balance?')) {
			return;
		}
		showMsg($wrap, cfg.strings.working, 'info');
		post(
			'wallregi_admin_order_remove_giftcard',
			{
				order_id: orderId,
				giftcard_code: code,
			},
			$wrap
		);
	});
})(jQuery);
