document.addEventListener('DOMContentLoaded', function () {

    // Show new gift card form if 'tab=new_giftcard' is present in URL
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('tab') === 'new_giftcard') {
        document.getElementById('wallregi_new_giftcard_form').style.display = 'block';
    }
    

    // Initialize modal and close button elements
    const modal = document.getElementById('wallregi_modal');
    const timeClose = document.getElementById('timeClose');
    const trashIcons = document.querySelectorAll('span.dashicons-trash');

    // Buttons inside the modal
    const noButton = document.getElementById('btnSelectNo');
    const yesButton = document.getElementById('btnSelectYesDelete');

    // Get all notification boxes
    const showNotices = document.querySelectorAll(".wallregi_giftcard_notice");


    

    // Handle notices and dismiss buttons
    showNotices.forEach(item => {
        const noticeMgs = item.querySelector("p");
        const dismissButton = item.querySelector(".notice-dismiss");

        // Hide notice initially
        item.style.display = "none";

        if (dismissButton) {
            dismissButton.addEventListener("click", function () {
                item.style.display = "none";
            });
        }
    });

    let selectedRow = null;
    let selectedId = null;  

    // Prefer the gift card list form so clicks are handled even when another `.wallregi_card_body` appears first in the DOM.
    const cardBody = document.getElementById('wallregi_giftcard_filter_form') || document.querySelector('.wallregi_card_body');

    if (cardBody) {
        cardBody.addEventListener('click', function (event) {
            const issueBtn = event.target.closest('.wallregi-epass-issue-missing-pass');
            if (issueBtn) {
                event.preventDefault();
                event.stopPropagation();
                const gid = issueBtn.getAttribute('data-giftcard-id');
                if (!gid || issueBtn.disabled) {
                    return;
                }
                if (typeof wallregi_dashboard_obj === 'undefined' || !wallregi_dashboard_obj.ajaxurl || !wallregi_dashboard_obj.nonce) {
                    window.alert('Dashboard script configuration is missing. Reload the page and try again.');
                    return;
                }
                const strings = wallregi_dashboard_obj.strings ? wallregi_dashboard_obj.strings : {};
                issueBtn.disabled = true;
                const origHtml = issueBtn.innerHTML;
                issueBtn.setAttribute('aria-busy', 'true');
                issueBtn.innerHTML = '<span class="dashicons dashicons-update" aria-hidden="true"></span>';
                fetch(wallregi_dashboard_obj.ajaxurl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'wallregi_epass_issue_missing_pass',
                        wallreginonce: wallregi_dashboard_obj.nonce,
                        giftcard_id: gid,
                    }).toString(),
                })
                    .then(function (response) {
                        return response.json();
                    })
                    .then(function (data) {
                        issueBtn.disabled = false;
                        issueBtn.removeAttribute('aria-busy');
                        if (data.success && data.data && data.data.wallet_html) {
                            issueBtn.insertAdjacentHTML('afterend', data.data.wallet_html);
                            issueBtn.remove();
                            const firstNotice = document.querySelector('.wallregi_giftcard_notice');
                            if (firstNotice) {
                                const noticeMgs = firstNotice.querySelector('p');
                                firstNotice.style.display = 'block';
                                if (noticeMgs) {
                                    noticeMgs.textContent = strings.epassIssueDone || '';
                                }
                            }
                        } else {
                            issueBtn.innerHTML = origHtml;
                            const msg = (data.data && data.data.message) ? data.data.message : (strings.epassIssueFailed || '');
                            const firstNotice = document.querySelector('.wallregi_giftcard_notice');
                            if (firstNotice) {
                                const noticeMgs = firstNotice.querySelector('p');
                                firstNotice.style.display = 'block';
                                if (noticeMgs) {
                                    noticeMgs.textContent = msg;
                                }
                            } else if (msg) {
                                window.alert(msg);
                            }
                        }
                    })
                    .catch(function () {
                        issueBtn.disabled = false;
                        issueBtn.removeAttribute('aria-busy');
                        issueBtn.innerHTML = origHtml;
                        const msg = strings.epassIssueNetwork || '';
                        const firstNotice = document.querySelector('.wallregi_giftcard_notice');
                        if (firstNotice) {
                            const noticeMgs = firstNotice.querySelector('p');
                            firstNotice.style.display = 'block';
                            if (noticeMgs) {
                                noticeMgs.textContent = msg;
                            }
                        }
                    });
                return;
            }

            const trashIcon = event.target.closest('span.dashicons-trash');
            if (trashIcon) {
                modal.classList.add('active');

                // Get the closest row (`tr`) and extract the ID
                selectedRow = trashIcon.closest('tr');
                selectedId = selectedRow?.id?.replace('post-', ''); // Extract only the numeric ID
            }
        });
    }


    // Close modal when clicking the close icon
    if (timeClose) {
        timeClose.addEventListener('click', function () {
            modal.classList.remove('active');
        });
    }

    // Close modal when clicking outside of it
    if (modal) {
        modal.addEventListener('click', function (event) {
            if (event.target === modal) {
                modal.classList.remove('active');
            }
        });
    }

    // "No" button - Close modal without deleting
    if (noButton) {
        noButton.addEventListener('click', function () {
            modal.classList.remove('active');
        });
    }

    // "Yes Delete" button - Send AJAX request to delete item
    if (yesButton) {
        // Use proper event listener syntax and handle dynamic elements
        function handleDelete() {
            if (!selectedId) {
                return;
            }
    
            const giftcard_number = selectedRow?.querySelector('.giftcard_code')?.textContent;
            const order_id = selectedRow?.querySelector('.column-order a')?.textContent;
            const receipent_email = selectedRow?.querySelector('.wallregi_recipient')?.textContent;
            const cardBody = document.querySelector('.wallregi_card_body');
    
            const dataObj = {
                action: 'wallregi_delete_giftcard',
                wallreginonce: wallregi_dashboard_obj.nonce,
                giftcard_id: selectedId, 
                giftcard_number,
                order_id,
                receipent_email,
            };
    
            const loadingSpinner = document.createElement("span");
            loadingSpinner.classList.add("loading-spinner");
            yesButton.prepend(loadingSpinner);
            yesButton.disabled = true;
    
            fetch(wallregi_dashboard_obj.ajaxurl, {  
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                body: new URLSearchParams(dataObj).toString(),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    selectedRow.remove();
                    const firstNotice = document.querySelector(".wallregi_giftcard_notice");
                    if (firstNotice) {
                        const noticeMgs = firstNotice.querySelector("p");
                        firstNotice.style.display = "block";
                        noticeMgs.innerHTML = `<span style="color: red;">[${giftcard_number}] </span> ${data.data.message}`;
                    }
    
                    const updatedTableRow = cardBody.querySelectorAll('tbody > tr');
                    if (updatedTableRow.length === 0 && data.data.gift_wrap) {
                        cardBody.innerHTML = data.data.gift_wrap;
                    }
                } else {
                    console.error("Failed to delete:", data.data.message);
                }
                modal.classList.remove('active');
                // Reset selection after deletion
                selectedId = null;
                selectedRow = null;
            })
            .catch(error => {
                console.error("Error deleting:", error);
                modal.classList.remove('active');
            })
            .finally(() => {
                loadingSpinner.remove();
                yesButton.disabled = false;
            });
        }
    
        // Remove existing listener before adding new one to prevent duplicates
        yesButton.removeEventListener('click', handleDelete);
        yesButton.addEventListener('click', handleDelete);

        // Add this at the document level instead of button-specific
        document.addEventListener('click', function(e) {
            if (e.target.closest('#yesButton')) {
                handleDelete();
            }
        });
    }


    // Gift card search functionality
    const searchInput = document.getElementById('wallregi_search_query');
    const table = document.getElementById('wallregi_giftcard_table');
    const rows = table?.querySelectorAll('#wallregi_table_list tr');

    // Filter table rows based on search query
    searchInput?.addEventListener('input', function () {
        const searchTerm = searchInput.value.toLowerCase().trim();

        rows.forEach(row => {
            let matchText = '';

            const codeEl = row.querySelector('.column-code');
            const orderEl = row.querySelector('.column-order');
            const balanceEl = row.querySelector('.column-balance');
            const expireEl = row.querySelector('.column-expiration');
            const emailEl = row.querySelector('.column-recipient');
            const statusEl = row.querySelector('.column-status');

            const code = codeEl ? codeEl.textContent.toLowerCase().trim() : '';
            const orderKey = orderEl ? orderEl.textContent.toLowerCase().trim() : '';
            const balance = balanceEl ? balanceEl.textContent.toLowerCase().trim() : '';
            const expiry = expireEl ? expireEl.textContent.toLowerCase().trim() : '';
            const email = emailEl ? emailEl.textContent.toLowerCase().trim() : '';
            const status = statusEl ? statusEl.textContent.toLowerCase().trim() : '';

            matchText = code + ' ' + orderKey + ' ' + balance + ' ' + expiry + ' ' + email + ' ' + status;

            // Show/hide row based on match
            row.style.display = matchText.includes(searchTerm) ? '' : 'none';
        });
    });

});


// Filters gift card table rows by selected status from dropdown
function wallregiFilterByStatus(status, event) {
    event.preventDefault();

    const table = document.querySelector('#wallregi_giftcard_table');
    const rows = table?.querySelectorAll('#wallregi_table_list tr');

    if (!table || !rows) return;

    rows.forEach(row => {
        // Assuming the status is in a <td> with class "column-status"
        const statusCell = row.querySelector('.column-status');
        const rowStatus = statusCell?.textContent.trim().toLowerCase();

        // Show all if "all" is selected
        if (status === 'all') {
            row.style.display = '';
            return;
        }

        // Match row status
        row.style.display = rowStatus === status ? '' : 'none';
    });
    
}

// Create or Edit Giftcard form switcher 
const switcher = document.getElementById("wallregi_update_gc_form_switch");
const optionShowHide = document.getElementById("wallregi_user_form_wrapper");

if (switcher) {
    switcher.addEventListener("click", function () {
        optionShowHide.style.display = this.checked ? "block" : "none";
    });
} 

const copyTextToClipboard = async (element) => {
    const copyText = element.previousElementSibling.textContent;
    const toastMsg = element.parentElement.nextElementSibling;
    
    if (!copyText) {
        console.error('No text to copy');
        return;
    }
    
    try {
        await navigator.clipboard.writeText(copyText);
    } catch {
        // Fallback for older browsers
        const ta = document.createElement('textarea');
        ta.value = copyText;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
    }
    
    toastMsg?.classList.add('show');
    setTimeout(() => toastMsg?.classList.remove('show'), 1000);
};


/**
* Switcher Option Applying Here.
*/
function wallregiToggleContent(checkbox) {
    const parent = checkbox.closest('.wallregi_options');
    
    var optionShowHide = parent.querySelector('.option_showhide');
    
    if (checkbox.checked) {
        optionShowHide.style.display = 'block'; // Show the section
    } else {
        optionShowHide.style.display = 'none'; // Hide the section
    }
}



/**
* Gift card product backgroud styles
*/
function wallregiToggleBackgroundOptions() {
    var backgroundSelect = document.getElementById('wallregi_background_style');
    if (!backgroundSelect) {
        return;
    }
    var backgroundStyle = backgroundSelect.value;
    
    // Get option containers
    var solidOptions = document.getElementById('solid_color_options');
    var imageOptions = document.getElementById('image_background_options');
    var gradientOptions = document.getElementById('gradient_options');
    
    // Hide all options by default
    if (solidOptions) solidOptions.style.display = 'none';
    if (imageOptions) imageOptions.style.display = 'none';
    if (gradientOptions) gradientOptions.style.display = 'none';
    
    // Show the relevant option based on the selected background style
    if (backgroundStyle === 'solid' && solidOptions) {
        solidOptions.style.display = 'block';
    } else if (backgroundStyle === 'image' && imageOptions) {
        imageOptions.style.display = 'block';
    } else if (backgroundStyle === 'gradient' && gradientOptions) {
        gradientOptions.style.display = 'block';
    }
}

/**
* Gift card product backgroud image upload or choose image from media library
*/
jQuery(document).ready(function ($) {
    var mediaUploader;

    $('#upload_bg_image_btn').on('click', function (e) {
        e.preventDefault();

        if (mediaUploader) {
            mediaUploader.open();
            return;
        }

        mediaUploader = wp.media({
            title: 'Select Background Image',
            button: {
                text: 'Use this image'
            },
            multiple: false
        });

        mediaUploader.on('select', function () {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            $('#wallregi_bg_image').val(attachment.url);
            $('#wallregi_bg_image_preview').attr('src', attachment.url).show();
            $('#remove_bg_image_btn').show();
        });

        mediaUploader.open();
    });

    // Button click event to remove the background image
    $('#remove_bg_image_btn').on('click', function (e) {
        e.preventDefault();
        $('#wallregi_bg_image').val(''); 
        $('#wallregi_bg_image_preview').hide(); 
        $(this).hide(); 
        $('#wallregi_bg_image_url_display').text(''); 
    });
});


/**
 * Initializes gift card bulk actions including:
 * - Select/Deselect all checkboxes functionality
 * - Bulk delete operation via AJAX
 */

function wallregiInitializeGiftCardBulkActions() {
    const filterForm        = document.querySelector('#wallregi_giftcard_filter_form');
    if ( !filterForm ) return;

    const selectAllCheckbox = filterForm.querySelector('#wallregi_cb_select_all');
    const bulkActionSelect  = filterForm.querySelector('select[name="wallregi_bulk_action_option"]');
    const bulkActionSubmit  = filterForm.querySelector('#wallregi_doaction');
    // const nonceField        = filterForm.querySelector('input[name="wallregi_bulk_delete_nonce"]');

    // Initialize modal and close button elements
    const confirmationModal = document.querySelector('#wallregi_modal');
    if (!confirmationModal) return;

    // Buttons inside the modal
    const modalCloseButton = confirmationModal.querySelector('#timeClose');
    const cancelDeleteButton = confirmationModal.querySelector('#btnSelectNo');
    const confirmDeleteButton = confirmationModal.querySelector('#btnSelectYesDelete');


    const ajaxUrl   = wallregi_dashboard_obj.ajaxurl;
    const ajaxNonce = wallregi_dashboard_obj.nonce;

    // Get all notification boxes
    const showNotices = document.querySelectorAll(".wallregi_giftcard_notice");


    // === Notice boxes handling ===

    // Hide notices initially and handle dismiss buttons
    showNotices.forEach(item => {
        const dismissButton = item.querySelector(".notice-dismiss");

        // Hide notice initially
        item.style.display = "none";

        if (dismissButton) {
            dismissButton.addEventListener("click", function () {
                item.style.display = "none";
            });
        }
    });


    // 1) Select/Deselect all
    selectAllCheckbox.addEventListener('change', function () {
        const boxes = filterForm.querySelectorAll('input[name="wallregi_giftcard_ids[]"]');
        boxes.forEach(cb => cb.checked = this.checked);
    });



    // 3) Actual submit handler (AJAX delete)
    filterForm.addEventListener("submit", function (event) {
        event.preventDefault();

        // re-collect checked IDs
        const checkedItems = Array.from(
            filterForm.querySelectorAll('input[name="wallregi_giftcard_ids[]"]:checked')
        );

        // If none checked, alert and stop
        if (checkedItems.length === 0) {
            alert("Please select at least one gift card to delete.");
            return;
        }
        if (bulkActionSelect.value !== 'wallregi_delete') {
            alert('Please select "Delete" from the bulk actions dropdown.');
            return;
        }

     
        const ids = checkedItems.map(cb => cb.value);

        if (ids.length === 0) return;
        if (!confirm(`Are you sure you want to delete ${ids.length} gift card(s)? This cannot be undone.`)) {
            return;
        }

        // Show the modal
        if ( confirmationModal ) {
            confirmationModal.classList.add('active');
        }

        modalCloseButton.addEventListener('click', () => {
            confirmationModal.classList.remove('active');
        });

        cancelDeleteButton.addEventListener('click', () => {
            confirmationModal.classList.remove('active');
        });

   


        // build AJAX request
        const data = new FormData();
        data.append('action',       'wallregi_bulk_delete_giftcards');
        data.append('giftcard_ids', JSON.stringify(ids));
        data.append('wallreginonce', ajaxNonce);

        // Disable button & show spinner
        bulkActionSubmit.disabled = true;
        bulkActionSubmit.value    = 'Deleting…';

        confirmDeleteButton.addEventListener('click', () => {

            const loadingSpinner = document.createElement("span");
            loadingSpinner.classList.add("loading-spinner");
            confirmDeleteButton.prepend(loadingSpinner);
            confirmDeleteButton.disabled = true;
            
            fetch(ajaxUrl, {
                method:      'POST',
                credentials: 'same-origin',
                body:        data
            })
            .then(response => response.json())
            .then(data  => {
            
                bulkActionSubmit.disabled = false;
                bulkActionSubmit.value    = 'Apply';


                if (data.success) {

                    // Remove rows from the table:
                    ids.forEach(id => {
                        const tableRow = document.querySelector(`#post-${id}`);
                        if (tableRow) tableRow.remove();
                    });

                    confirmationModal.classList.remove('active');
                    location.reload();

                } else {
                    alert(data.data.message || 'Something went wrong.');
                }
                
            })
            .catch(() => {
                alert('Network error, please try again.');
            })
            .finally(()=>{
                loadingSpinner.remove();
                confirmDeleteButton.disabled = false;
            })
        });




        
    });
}

wallregiInitializeGiftCardBulkActions();


// Dashboard 'section' toggler
function wallregiSectionToggleHandler(header) {
    const wrapper = header.closest('.wallregi_section_panel');
    const panel = wrapper.querySelector('.wodg_panels');
    const icon = header.querySelector('.dashicons');

    const scope =
        header.closest('.wallregi-settings-hub-panel') ||
        header.closest('.wallregi_card') ||
        document;

    const isOpen = panel.style.display === 'block';

    // Collapse sections only within the same settings card (not other hub tabs).
    scope.querySelectorAll('.wallregi_section_panel .wodg_panels').forEach(function (p) {
        p.style.display = 'none';
    });
    scope.querySelectorAll('.wallregi_switcher_icon .dashicons').forEach(function (i) {
        i.classList.remove('rotate');
    });

    // Toggle current section
    if (!isOpen) {
        panel.style.display = 'block';
        icon.classList.add('rotate');
    }
}


// Download PDF 
function wallregiDownloadPDF(element, event) {
    event.preventDefault();

    const giftcode = element.getAttribute('data-giftcode');
    if (!giftcode) {
        alert('Gift code not found.');
        return;
    }

    const url = wallregi_dashboard_obj.ajaxurl 
        + '?action=wallregi_generate_pdf'
        + '&giftcode=' + encodeURIComponent(giftcode)
        + '&wallreginonce=' + encodeURIComponent(wallregi_dashboard_obj.nonce);

    open(url, '_self'); 
}


// ============================================================
// WP Media Library picker — used by image_upload field type
// ============================================================
document.querySelectorAll('.wallregi-media-upload-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
        var targetId = this.getAttribute('data-target');
        if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
            return;
        }
        var frame = wp.media({
            title: wallregi_dashboard_obj.strings && wallregi_dashboard_obj.strings.select_image
                ? wallregi_dashboard_obj.strings.select_image
                : 'Select or Upload Image',
            button: {
                text: wallregi_dashboard_obj.strings && wallregi_dashboard_obj.strings.use_image
                    ? wallregi_dashboard_obj.strings.use_image
                    : 'Use this image'
            },
            multiple: false,
            library: { type: 'image' }
        });
        frame.on('select', function () {
            var attachment = frame.state().get('selection').first().toJSON();
            var hiddenInput = document.getElementById(targetId);
            var preview     = document.getElementById(targetId + '_preview');
            var removeBtn   = document.querySelector('.wallregi-media-remove-btn[data-target="' + targetId + '"]');
            if (hiddenInput) { hiddenInput.value = attachment.url; }
            if (preview)     { preview.src = attachment.url; preview.style.display = 'block'; }
            if (removeBtn)   { removeBtn.style.display = 'block'; }
        });
        frame.open();
    });
});

// Remove image handler
document.querySelectorAll('.wallregi-media-remove-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
        var targetId    = this.getAttribute('data-target');
        var hiddenInput = document.getElementById(targetId);
        var preview     = document.getElementById(targetId + '_preview');
        if (hiddenInput) { hiddenInput.value = ''; }
        if (preview)     { preview.src = ''; preview.style.display = 'none'; }
        this.style.display = 'none';
    });
});


// ============================================================
// Conditional field visibility — data-depends-on support
// Hides .panel_rows that carry data-depends-on="checkboxId"
// when the referenced checkbox is unchecked, and shows them
// when it is checked.
// ============================================================
function wallregiToggleDependentRows(checkboxId) {
    var checkbox   = document.getElementById(checkboxId);
    if (!checkbox) { return; }
    var dependents = document.querySelectorAll('[data-depends-on="' + checkboxId + '"]');
    function toggle() {
        dependents.forEach(function (row) {
            row.style.display = checkbox.checked ? '' : 'none';
        });
    }
    toggle(); // apply on page load
    checkbox.addEventListener('change', toggle);
}

// Initialise for logo, date, and custom pdf layout checkboxes
wallregiToggleDependentRows('wallregi_show_card_logo');
wallregiToggleDependentRows('wallregi_show_card_date');
wallregiToggleDependentRows('wallregi_enable_custom_pdf_layout');

var wallregiCheckedDeps = {};
document.querySelectorAll('[data-depends-on]').forEach(function (el) {
    var dep = el.getAttribute('data-depends-on');
    if (dep && !wallregiCheckedDeps[dep]) {
        wallregiCheckedDeps[dep] = true;
        wallregiToggleDependentRows(dep);
    }
});
