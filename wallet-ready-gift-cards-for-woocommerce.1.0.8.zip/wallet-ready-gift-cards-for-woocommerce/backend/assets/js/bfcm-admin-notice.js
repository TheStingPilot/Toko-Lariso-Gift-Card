/**
 * Gift Rocket BFCM Admin Notice Handler
 */
jQuery(document).ready(function ($) {
    'use strict';

    $(document).on('click', '.giftrocket-campaign-notice .notice-dismiss', function () {
        var $notice = $(this).closest('.giftrocket-campaign-notice');

        if (typeof GiftRocketNotice !== 'undefined' && GiftRocketNotice.ajax_url) {
            $.ajax({
                url: GiftRocketNotice.ajax_url,
                type: 'POST',
                data: {
                    action: 'giftrocket_dismiss_notice',
                    dismiss_action: 'later',
                    nonce: GiftRocketNotice.nonce
                }
            });
        }

        $notice.fadeTo(100, 0, function () {
            $notice.slideUp(100, function () {
                $notice.remove();
            });
        });
    });
});
