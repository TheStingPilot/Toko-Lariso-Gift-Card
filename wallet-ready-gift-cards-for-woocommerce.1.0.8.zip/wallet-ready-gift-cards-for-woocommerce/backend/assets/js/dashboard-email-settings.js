(function () {
    /**
     * Copy text to clipboard with fallback for non-HTTPS / HTTP environments.
     */
    function copyToClipboard(text) {
        text = (text || '').trim();
        if (!text) {
            return Promise.reject(new Error('Empty text'));
        }

        // Try modern Clipboard API if supported and in a secure context
        if (navigator.clipboard && window.isSecureContext) {
            return navigator.clipboard.writeText(text).catch(function () {
                return fallbackCopy(text);
            });
        }
        return fallbackCopy(text);
    }

    /**
     * Fallback copy using textarea + execCommand('copy') for HTTP/local environments.
     */
    function fallbackCopy(text) {
        return new Promise(function (resolve, reject) {
            try {
                var textArea = document.createElement('textarea');
                textArea.value = text;
                textArea.setAttribute('readonly', '');
                textArea.style.position = 'fixed';
                textArea.style.top = '0';
                textArea.style.left = '0';
                textArea.style.width = '2em';
                textArea.style.height = '2em';
                textArea.style.padding = '0';
                textArea.style.border = 'none';
                textArea.style.outline = 'none';
                textArea.style.boxShadow = 'none';
                textArea.style.background = 'transparent';
                textArea.style.opacity = '0.01';
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                textArea.setSelectionRange(0, text.length);

                var successful = false;
                try {
                    successful = document.execCommand('copy');
                } catch (err) {
                    successful = false;
                }
                document.body.removeChild(textArea);

                if (successful) {
                    resolve();
                } else {
                    reject(new Error('execCommand copy failed'));
                }
            } catch (err) {
                reject(err);
            }
        });
    }

    // Fixed-position viewport toast element
    var toast = null;
    function getToastElement() {
        if (!toast) {
            toast = document.getElementById('wallregi-toast');
            if (!toast) {
                toast = document.createElement('div');
                toast.id = 'wallregi-toast';
                toast.style.position = 'fixed';
                toast.style.bottom = '24px';
                toast.style.right = '24px';
                toast.style.padding = '12px 22px';
                toast.style.backgroundColor = '#7d60a9';
                toast.style.color = '#fff';
                toast.style.borderRadius = '6px';
                toast.style.fontSize = '14px';
                toast.style.fontWeight = '500';
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(10px)';
                toast.style.transition = 'opacity 0.25s ease, transform 0.25s ease';
                toast.style.zIndex = '999999';
                toast.style.pointerEvents = 'none';
                toast.style.boxShadow = '0 4px 16px rgba(0,0,0,0.25)';
                document.body.appendChild(toast);
            }
        }
        return toast;
    }

    var toastTimer = null;
    function wallregiShowToast(message) {
        var el = getToastElement();
        if (!el) return;
        el.textContent = message;
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
            el.style.opacity = '0';
            el.style.transform = 'translateY(10px)';
        }, 2400);
    }

    // Delegated click listener for all placeholder tags
    document.addEventListener('click', function (e) {
        var tag = e.target.closest('.wallregi-placeholder-tag');
        if (!tag) return;

        var text = (tag.getAttribute('data-placeholder') || tag.textContent || '').trim();
        if (!text) return;

        copyToClipboard(text).then(function () {
            var copyMessage = (typeof wallregi_dashboard_obj !== 'undefined' && wallregi_dashboard_obj.strings && wallregi_dashboard_obj.strings.placeholderCopied)
                ? wallregi_dashboard_obj.strings.placeholderCopied.replace('%s', text)
                : 'Placeholder copied: ' + text;
            wallregiShowToast(copyMessage);

            // Visual indicator on tag itself
            tag.classList.add('wallregi-tag-copied');
            setTimeout(function () {
                tag.classList.remove('wallregi-tag-copied');
            }, 1000);
        }).catch(function () {
            wallregiShowToast('Copied: ' + text);
        });
    });

    // Delegated dragstart listener for all placeholder tags
    document.addEventListener('dragstart', function (e) {
        var tag = e.target.closest('.wallregi-placeholder-tag');
        if (!tag) return;

        var text = (tag.getAttribute('data-placeholder') || tag.textContent || '').trim();
        if (e.dataTransfer) {
            e.dataTransfer.setData('text/plain', text);
        }
    });

    // Drag-and-drop targets setup
    function setupDropTargets() {
        var subjectInput = document.getElementById('wallregi_email_subject');
        var headingInput = document.getElementById('wallregi_email_heading');
        var textareaFallback = document.querySelector('textarea[name="wallregi_email_body"]');

        function wallregiHandleDrop(input, e) {
            e.preventDefault();
            var dropText = e.dataTransfer ? e.dataTransfer.getData('text/plain') : '';
            if (!dropText) return;

            if (input === 'tinymce' && typeof tinymce !== 'undefined') {
                var editor = tinymce.get('wallregi_email_body');
                if (editor) {
                    editor.execCommand('mceInsertContent', false, dropText);
                }
            } else if (input && input.selectionStart !== undefined) {
                var cursorPos = input.selectionStart;
                var textBefore = input.value.substring(0, cursorPos);
                var textAfter = input.value.substring(cursorPos);
                input.value = textBefore + dropText + textAfter;
            }
        }

        [subjectInput, headingInput, textareaFallback].forEach(function (input) {
            if (!input) return;
            input.addEventListener('dragover', function (e) {
                e.preventDefault();
            });
            input.addEventListener('drop', function (e) {
                wallregiHandleDrop(input, e);
            });
        });

        if (typeof tinymce !== 'undefined') {
            var attempts = 0;
            var tinymceInterval = setInterval(function () {
                attempts++;
                var editor = tinymce.get('wallregi_email_body');
                if (editor && editor.initialized) {
                    var editorDoc = editor.getDoc();
                    if (editorDoc) {
                        editorDoc.addEventListener('dragover', function (e) {
                            e.preventDefault();
                        });
                        editorDoc.addEventListener('drop', function (e) {
                            wallregiHandleDrop('tinymce', e);
                        });
                    }
                    clearInterval(tinymceInterval);
                }
                if (attempts > 30) {
                    clearInterval(tinymceInterval);
                }
            }, 500);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupDropTargets);
    } else {
        setupDropTargets();
    }
})();
