
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.querySelector(".wallregi_panel_sidebar");
    if (!sidebar) return;

    const menuItems = sidebar.querySelectorAll(".menu-item");
    const collapseBtn = sidebar.querySelector(".collapse-item .item-link");

    // Get current tab from URL
    const urlParams = new URLSearchParams(window.location.search);
    let currentTab = urlParams.get('tab');
    if (!currentTab || currentTab === '') {
        currentTab = 'wallregi_dashboard';
    }

    // Restore sidebar collapsed state
    if (localStorage.getItem("sidebarCollapsed") === "true") {
        sidebar.classList.add("collapsed");
        if (collapseBtn) {
            const icon = collapseBtn.querySelector('.dashicons');
            if (icon) icon.style.transform = "rotate(180deg)";
        }
    }

    // Set active states based on URL parameter
    function wallregiSetActiveStates() {
        // Clear all active states
        menuItems.forEach(item => {
            item.classList.remove('active-item');
            const submenu = item.querySelector('.wallregi_panel_submenu');
            if (submenu) {
                submenu.style.maxHeight = "0px";
                submenu.classList.remove('open');
                submenu.querySelectorAll('.submenu-item').forEach(subItem => {
                    subItem.classList.remove('active-submenu-item');
                });
            }
        });

        // Set active item based on current tab
        let activeItemFound = false;

        // First check top-level items
        menuItems.forEach(item => {
            if (item.dataset.tab === currentTab) {
                item.classList.add('active-item');
                activeItemFound = true;
            }
        });

        // Then check submenu items if not found in top-level
        if (!activeItemFound) {
            menuItems.forEach(item => {
                const submenu = item.querySelector('.wallregi_panel_submenu');
                if (submenu) {
                    const submenuItems = submenu.querySelectorAll('.submenu-item');
                    submenuItems.forEach(subItem => {
                        const link = subItem.querySelector('.item-link');
                        if (link && link.dataset.tab === currentTab) {
                            item.classList.add('active-item');
                            submenu.style.maxHeight = (submenu.scrollHeight + 20) + "px";
                            submenu.classList.add('open');
                            subItem.classList.add('active-submenu-item');
                            activeItemFound = true;
                        }
                    });
                }
            });
        }

        // If still no active item found, default to dashboard
        if (!activeItemFound) {
            currentTab = 'wallregi_dashboard';
            const dashboardItem = document.querySelector('.menu-item[data-tab="wallregi_dashboard"]');
            if (dashboardItem) {
                dashboardItem.classList.add('active-item');
            }
        }
    }

    // Set initial active states
    wallregiSetActiveStates();

    // Handle menu clicks
    menuItems.forEach(menuItem => {
        const menuLink = menuItem.querySelector('.item-link');
        const submenu = menuItem.querySelector('.wallregi_panel_submenu');

        menuLink.addEventListener('click', function (e) {
            // If it's the main Gift Cards menu item (dashboard)
            if (this.getAttribute('href').includes('tab=wallregi_dashboard')) {
                currentTab = 'wallregi_dashboard';
                wallregiSetActiveStates();
                return true; // Allow normal navigation
            }

            // Handle submenu toggle
            if (submenu) {
                e.preventDefault();

                // Close other open submenus
                document.querySelectorAll('.wallregi_panel_submenu').forEach(sm => {
                    if (sm !== submenu) {
                        sm.style.maxHeight = "0px";
                        sm.classList.remove('open');
                    }
                });

                // Toggle current submenu
                const isOpen = submenu.classList.contains('open');
                submenu.style.maxHeight = isOpen ? "0px" : (submenu.scrollHeight + 20) + "px";
                submenu.classList.toggle('open');

                return false;
            }

            return true;
        });

        // Handle submenu item clicks
        if (submenu) {
            const submenuLinks = submenu.querySelectorAll('.item-link');
            submenuLinks.forEach(link => {
                link.addEventListener('click', function () {
                    currentTab = this.dataset.tab;
                    wallregiSetActiveStates();
                    return true; // Allow normal navigation
                });
            });
        }
    });

    // Handle sidebar collapse
    if (collapseBtn) {
        collapseBtn.addEventListener('click', function (e) {
            e.preventDefault();
            const icon = this.querySelector('.dashicons');
            sidebar.classList.toggle('collapsed');
            if (icon) {
                icon.style.transform = sidebar.classList.contains('collapsed') ?
                    'rotate(180deg)' : 'rotate(0deg)';
            }
            localStorage.setItem("sidebarCollapsed", sidebar.classList.contains('collapsed'));
        });
    }
});



jQuery(function ($) {
    const container = $('.wallregi-price-fields');

    $('.add_custom_price_row').on('click', function (e) {
        e.preventDefault();
        container.show();

        container.append(
            '<div class=\"wallregi-price-input\">' +
            '<input type=\"number\" step=\"any\" min=\"{$global_min}\" max=\"{$global_max}\" name=\"wallregi_custom_prices[]\" value=\"\" class=\"small-price-input\" /> ' +
            '<button type=\"button\" class=\"button remove_custom_price_row\">×</button>' +
            '</div>'
        );
    });

    $(document).on('click', '.remove_custom_price_row', function (e) {
        e.preventDefault();
        $(this).closest('.wallregi-price-input').remove();

        if (container.children('.wallregi-price-input').length === 0) {
            container.hide();
        }
    });

    if (container.children('.wallregi-price-input').length > 0) {
        container.show();
    }
});

jQuery(function ($) {
    const productType = $('#product-type').val();
    if (productType === 'wxgiftcard') {
        $('#wallet-ready-gift-cards-for-woocommerce-admin-product-settings').show();
    } else {
        $('#wallet-ready-gift-cards-for-woocommerce-admin-product-settings').hide();
    }

    $('#product-type').on('change', function () {
        const productType = $(this).val();
        if (productType === 'wxgiftcard') {
            $('#wallet-ready-gift-cards-for-woocommerce-admin-product-settings').show();
        } else {
            $('#wallet-ready-gift-cards-for-woocommerce-admin-product-settings').hide();
        }
    });
    const container = $('.wallregi-price-fields');
    const variationCheckbox = $('#wallregi_enable_variation_price');
    const regularPriceRow = $('._regular_price_field');
    const salePriceRow = $('._sale_price_field');
    const customPriceWrapper = $('.wallregi_custom_price_contents');


    function toggleCustomPriceFields() {
        if (variationCheckbox.is(':checked')) {
            container.show();
            regularPriceRow.hide();
            //salePriceRow.hide();
            customPriceWrapper.show();

        } else {
            regularPriceRow.show();
            //salePriceRow.show();
            customPriceWrapper.hide();

        }
    }

    // Initial call
    toggleCustomPriceFields();

    // On checkbox change
    variationCheckbox.on('change', function () {
        toggleCustomPriceFields();
    });



    // Remove price row
    $(document).on('click', '.remove_custom_price_row', function (e) {
        e.preventDefault();
        $(this).closest('.wallregi-price-input').remove();
        if (container.children('.wallregi-price-input').length === 0) {
            container.hide();
        }
    });

    if (container.children('.wallregi-price-input').length > 0) {
        container.show();
    }
});

jQuery(document).ready(function ($) {

    // Toggle custom expiry wrapper
    function toggleExpiryDateWrapper() {
        var checkbox = document.getElementById('wallregi_enable_custom_expiry_date');
        var wrapper = document.querySelector('.wallregi_expiry_date_wrapper');
        if (checkbox && wrapper) {
            wrapper.style.display = checkbox.checked ? 'block' : 'none';
        }
    }

    // Uncheck the custom expiry checkbox when a select option is changed
    $('#wallregi_expiry_date').on('change', function () {
        if (this.value !== '') {
            $('#wallregi_enable_custom_expiry_date').prop('checked', false).trigger('change');
            toggleExpiryDateWrapper();
        }
    });

    // Run on load
    toggleExpiryDateWrapper();

    // Bind checkbox change
    $('#wallregi_enable_custom_expiry_date').on('change', function () {
        toggleExpiryDateWrapper();
    });

    // Clear Manual Expiry Date button
    $('#clear_manual_expiry_date').on('click', function () {
        $('#wallregi_manual_expiry_date').val('');
    });

});

jQuery(document).ready(function ($) {
    const productType = $('#product-type').val();
    if (productType === 'wxgiftcard') {
        $('#postimagediv,#woocommerce-product-images').append('<div class=\"wxgiftcard-image-size-hints\">🖼️ Recommended Gift Card PDF Image Size: 923×400 px</div>');
        $('.product_data_tabs .general_options').addClass('active').show();
        $('.product_data_tabs .marketplace-suggestions_options').removeClass('active');
        $('.options_group.pricing').removeClass('hidden').show();
        $('#_virtual').parent().show();
        $('#general_product_data').show();
        $('#_virtual').attr('checked', true);
        $('.woocommerce_options_panel').not('#general_product_data').hide();
        $('.form-field._sale_price_field').hide();
    }

    $('body').on('woocommerce-product-type-change', function (e, type) {

        if (type === 'wxgiftcard') {
            $('#postimagediv,#woocommerce-product-images').append('<div class=\"wxgiftcard-image-size-hints\">🖼️ Recommended Gift Card PDF Image Size: 923×400 px</div>');
            $('.product_data_tabs .general_options').addClass('active').show();
            $('.product_data_tabs .marketplace-suggestions_options').removeClass('active');
            $('.options_group.pricing').removeClass('hidden').show();
            $('#_virtual').parent().show();
            $('#general_product_data').show();
            $('#_virtual').attr('checked', true);
            $('.woocommerce_options_panel').not('#general_product_data').hide();
            $('.form-field._sale_price_field').hide();
        } else {
            $('#postimagediv .wxgiftcard-image-size-hints,#woocommerce-product-images .wxgiftcard-image-size-hints').remove();
            $('.form-field._sale_price_field').show();
        }
    });
});