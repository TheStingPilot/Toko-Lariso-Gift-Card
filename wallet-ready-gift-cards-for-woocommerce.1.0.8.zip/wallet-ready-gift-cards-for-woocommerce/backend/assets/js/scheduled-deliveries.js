document.addEventListener('DOMContentLoaded', function () {
    const wrap = document.getElementById('wallregi_scheduled_deliveries_wrap');
    if (!wrap || typeof wallregi_scheduled_deliveries_obj === 'undefined') {
        return;
    }

    const config = wallregi_scheduled_deliveries_obj;
    const strings = config.strings || {};

    function handleResend(event, action, buttonSelector, stringsKey) {
        const button = event.target.closest(buttonSelector);
        if (!button || button.disabled) {
            return false;
        }

        event.preventDefault();

        const giftcardId = button.getAttribute('data-giftcard-id');
        const giftcardCode = button.getAttribute('data-giftcard-code') || '';
        const confirmTemplate = strings[stringsKey + 'Confirm'] || 'Re-send now?';
        const confirmMessage = confirmTemplate.replace('%s', giftcardCode);

        if (!window.confirm(confirmMessage)) {
            return true;
        }

        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
        const originalLabel = button.textContent;
        button.textContent = strings[stringsKey + 'Working'] || 'Sending…';

        fetch(config.ajaxurl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: action,
                wallreginonce: config.nonce,
                giftcard_id: giftcardId,
            }).toString(),
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                const row = button.closest('tr');
                if (data.success && row) {
                    const statusCell = row.querySelector(stringsKey === 'resendEmail' ? '.column-email-status' : '.column-sms-status');
                    const sentAtCell = row.querySelector('.wallregi-sent-at-value');
                    if (statusCell && data.data && data.data.status_badge_html) {
                        statusCell.innerHTML = data.data.status_badge_html;
                    }
                    if (sentAtCell && data.data && data.data.sent_at_display) {
                        sentAtCell.textContent = data.data.sent_at_display;
                    }
                    window.alert(data.data && data.data.message ? data.data.message : (strings[stringsKey + 'Success'] || 'Sent.'));
                } else {
                    const message = data.data && data.data.message
                        ? data.data.message
                        : (strings[stringsKey + 'Failed'] || 'Could not send.');
                    window.alert(message);
                }
            })
            .catch(function () {
                window.alert(strings[stringsKey + 'Network'] || strings.resendNetwork || 'Network error. Please try again.');
            })
            .finally(function () {
                button.disabled = false;
                button.removeAttribute('aria-busy');
                button.textContent = originalLabel;
            });

        return true;
    }

    wrap.addEventListener('click', function (event) {
        if (handleResend(event, 'wallregi_resend_giftcard_email', '.wallregi-resend-giftcard-email', 'resendEmail')) {
            return;
        }
        handleResend(event, 'wallregi_resend_giftcard_sms', '.wallregi-resend-giftcard-sms', 'resendSms');
    });
});
