/**
 * Gift Cards admin → Google/Apple Wallet: global pass template + field mapping + stripe image.
 */
(function ($) {
	'use strict';

	function postAjax(action, data) {
		return $.post(
			wallregiGlobalWalletEpass.ajaxUrl,
			$.extend(
				{
					action: action,
					nonce: wallregiGlobalWalletEpass.nonce,
				},
				data || {}
			)
		);
	}

	function esc(s) {
		return $('<div></div>').text(String(s == null ? '' : s)).html();
	}

	function fieldOptionsHtml(fields, notMappedLabel) {
		var html = '<option value="">' + esc(notMappedLabel) + '</option>';
		if (!fields || !fields.length) {
			return html;
		}
		fields.forEach(function (f) {
			var uid = f.uid ? String(f.uid) : '';
			var name = f.field_name ? String(f.field_name) : uid;
			var ft = f.field_type ? ' (' + String(f.field_type) + ')' : '';
			html += '<option value="' + esc(uid) + '">' + esc(name + ft) + '</option>';
		});
		return html;
	}

	function renderMappingRows(fields, mapping) {
		var $rows = $('#wallregi_wallet_global_mapping_rows');
		$rows.empty();
		var notMapped = wallregiGlobalWalletEpass.strings.notMapped;
		var opts = fieldOptionsHtml(fields, notMapped);

		wallregiGlobalWalletEpass.giftElements.forEach(function (el) {
			var val = mapping && mapping[el.slug] ? String(mapping[el.slug]) : '';
			var $p = $('<p class="form-field wallregi-epass-map-row"></p>');
			$p.append($('<label></label>').text(el.label));
			var $sel = $('<select class="wallregi-epass-map-select" style="max-width:28rem;"></select>');
			$sel.attr('name', 'wallregi_global_epass_mapping[' + el.slug + ']');
			$sel.html(opts);
			$sel.val(val);
			$p.append($sel);
			$rows.append($p);
		});
	}

	function setSnapshot(fields) {
		$('#wallregi_wallet_global_pass_fields_json').val(JSON.stringify(fields || []));
	}

	function syncTemplateMetaFromSelection() {
		var $opt = $('#wallregi_wallet_global_template_uid option:selected');
		var name = $opt.attr('data-template-name') || $opt.text() || '';
		var id = $opt.attr('data-template-id') || 0;
		$('#wallregi_wallet_global_template_name').val(name);
		$('#wallregi_wallet_global_template_id').val(id);
	}

	function loadPassFields(templateUid, mappingPreserve) {
		var $st = $('.wallregi-wallet-global-template-status');
		$st.text(wallregiGlobalWalletEpass.strings.loadingFields);
		return postAjax('wallregi_wallet_epass_global_get_pass_fields', { template_uid: templateUid })
			.done(function (res) {
				if (!res || !res.success) {
					var msg =
						res && res.data && res.data.message
							? res.data.message
							: wallregiGlobalWalletEpass.strings.loadFailed;
					$st.text(msg);
					return;
				}
				var fields = res.data && res.data.passFields ? res.data.passFields : [];
				setSnapshot(fields);
				$('#wallregi_wallet_global_mapping_wrap').show();
				renderMappingRows(fields, mappingPreserve || {});
				$st.text('');
			})
			.fail(function () {
				$st.text(wallregiGlobalWalletEpass.strings.loadFailed);
			});
	}

	function bindStripePicker() {
		var $btn = $('#wallregi_wallet_global_stripe_pick');
		var $inp = $('#wallregi_wallet_global_stripe_image_url');
		if (!$btn.length || !$inp.length) {
			return;
		}
		$btn.on('click', function (e) {
			e.preventDefault();
			if (typeof wp === 'undefined' || !wp.media) {
				return;
			}
			var frame = wp.media({
				title: wallregiGlobalWalletEpass.strings.stripeFrameTitle,
				library: { type: 'image' },
				button: { text: wallregiGlobalWalletEpass.strings.stripeUse },
				multiple: false,
			});
			frame.on('select', function () {
				var att = frame.state().get('selection').first().toJSON();
				var url = att.url || (att.sizes && att.sizes.full && att.sizes.full.url) || '';
				$inp.val(url);
			});
			frame.open();
		});
	}

	function fillTemplatesAndInit() {
		var $root = $('#wallregi-wallet-global-pass-config');
		if (!$root.length || typeof wallregiGlobalWalletEpass === 'undefined') {
			return;
		}

		var $st = $('.wallregi-wallet-global-template-status');
		var $sel = $('#wallregi_wallet_global_template_uid');
		var savedUid = wallregiGlobalWalletEpass.savedConfig.template_uid || '';
		var savedMap = wallregiGlobalWalletEpass.savedConfig.mapping || {};
		var savedFields = wallregiGlobalWalletEpass.savedConfig.pass_fields || [];

		var $stripeIn = $('#wallregi_wallet_global_stripe_image_url');
		if ($stripeIn.length && wallregiGlobalWalletEpass.savedConfig.stripe_url) {
			$stripeIn.val(wallregiGlobalWalletEpass.savedConfig.stripe_url);
		}

		bindStripePicker();

		$st.text(wallregiGlobalWalletEpass.strings.loadingTemplates);

		postAjax('wallregi_wallet_epass_global_get_templates')
			.done(function (res) {
				if (!res || !res.success) {
					var msg =
						res && res.data && res.data.message
							? res.data.message
							: wallregiGlobalWalletEpass.strings.loadFailed;
					$st.text(msg);
					return;
				}

				var templates = res.data && res.data.templates ? res.data.templates : [];
				var preserveUid = $sel.val() || savedUid;

				$sel.empty();
				$sel.append(
					$('<option value=""></option>').text(wallregiGlobalWalletEpass.strings.selectTemplate)
				);

				templates.forEach(function (t) {
					var uid = t.uid ? String(t.uid) : '';
					var name = t.name ? String(t.name) : uid;
					var id = t.id != null ? t.id : 0;
					var $opt = $('<option></option>').val(uid).text(name);
					$opt.attr('data-template-name', name);
					$opt.attr('data-template-id', id);
					$sel.append($opt);
				});

				if (preserveUid) {
					var hasOpt = false;
					$sel.find('option').each(function () {
						if (this.value === preserveUid) {
							hasOpt = true;
							return false;
						}
					});
					if (hasOpt) {
						$sel.val(preserveUid);
					} else {
						var sn = wallregiGlobalWalletEpass.savedConfig.template_name || preserveUid;
						var sid = wallregiGlobalWalletEpass.savedConfig.template_id || 0;
						var $fallback = $('<option></option>')
							.val(preserveUid)
							.text(sn)
							.attr('data-template-name', sn)
							.attr('data-template-id', sid);
						$sel.append($fallback);
						$sel.val(preserveUid);
					}
				}

				syncTemplateMetaFromSelection();

				var uidNow = $sel.val();
				if (uidNow) {
					if (savedFields.length && uidNow === savedUid) {
						setSnapshot(savedFields);
						$('#wallregi_wallet_global_mapping_wrap').show();
						renderMappingRows(savedFields, savedMap);
						$st.text('');
					} else {
						loadPassFields(uidNow, savedUid === uidNow ? savedMap : {});
					}
				} else {
					$('#wallregi_wallet_global_mapping_wrap').hide();
					setSnapshot([]);
					$st.text('');
				}
			})
			.fail(function () {
				$st.text(wallregiGlobalWalletEpass.strings.loadFailed);
			});

		$sel.on('change', function () {
			syncTemplateMetaFromSelection();
			var uid = $(this).val();
			if (!uid) {
				$('#wallregi_wallet_global_mapping_wrap').hide();
				$('#wallregi_wallet_global_mapping_rows').empty();
				setSnapshot([]);
				return;
			}
			loadPassFields(uid, {});
		});
	}

	$(fillTemplatesAndInit);
})(jQuery);
