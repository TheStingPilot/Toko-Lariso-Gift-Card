/**
 * Product admin: ePasscard template list + pass field mapping.
 */
(function ($) {
	'use strict';

	function postAjax(action, data) {
		return $.post(
			wallregiEpassProduct.ajaxUrl,
			$.extend(
				{
					action: action,
					nonce: wallregiEpassProduct.nonce,
				},
				data || {}
			)
		);
	}

	function esc(s) {
		return $('<div></div>').text(String(s == null ? '' : s)).html();
	}

	function fieldOptionsHtml(fields, notMappedLabel) {
		var html = '<option value="">' + esc(notMappedLabel) + '</option>';
		if (!fields || !fields.length) {
			return html;
		}
		fields.forEach(function (f) {
			var uid = f.uid ? String(f.uid) : '';
			var name = f.field_name ? String(f.field_name) : uid;
			var ft = f.field_type ? ' (' + String(f.field_type) + ')' : '';
			html += '<option value="' + esc(uid) + '">' + esc(name + ft) + '</option>';
		});
		return html;
	}

	function renderMappingRows(fields, mapping) {
		var $rows = $('#wallregi_epass_mapping_rows');
		$rows.empty();
		var notMapped = wallregiEpassProduct.strings.notMapped;
		var opts = fieldOptionsHtml(fields, notMapped);

		wallregiEpassProduct.giftElements.forEach(function (el) {
			var val = mapping && mapping[el.slug] ? String(mapping[el.slug]) : '';
			var $p = $('<p class="form-field wallregi-epass-map-row"></p>');
			$p.append($('<label></label>').text(el.label));
			var $sel = $('<select class="wallregi-epass-map-select" style="max-width:28rem;"></select>');
			$sel.attr('name', 'wallregi_epass_mapping[' + el.slug + ']');
			$sel.html(opts);
			$sel.val(val);
			$p.append($sel);
			$rows.append($p);
		});
	}

	function setSnapshot(fields) {
		$('#wallregi_epass_pass_fields_json').val(JSON.stringify(fields || []));
	}

	function syncTemplateMetaFromSelection() {
		var $opt = $('#wallregi_epass_template_uid option:selected');
		var name = $opt.attr('data-template-name') || $opt.text() || '';
		var id = $opt.attr('data-template-id') || 0;
		$('#wallregi_epass_template_name').val(name);
		$('#wallregi_epass_template_id').val(id);
	}

	function loadPassFields(templateUid, mappingPreserve) {
		var $st = $('.wallregi-epass-template-status');
		$st.text(wallregiEpassProduct.strings.loadingFields);
		return postAjax('wallregi_wallet_epass_get_pass_fields', { template_uid: templateUid })
			.done(function (res) {
				if (!res || !res.success) {
					var msg =
						res && res.data && res.data.message
							? res.data.message
							: wallregiEpassProduct.strings.loadFailed;
					$st.text(msg);
					return;
				}
				var fields = res.data && res.data.passFields ? res.data.passFields : [];
				setSnapshot(fields);
				$('#wallregi_epass_mapping_wrap').show();
				renderMappingRows(fields, mappingPreserve || {});
				$st.text('');
			})
			.fail(function () {
				$st.text(wallregiEpassProduct.strings.loadFailed);
			});
	}

	function fillTemplatesAndInit() {
		var $root = $('#wallregi-epass-pass-config');
		if (!$root.length || typeof wallregiEpassProduct === 'undefined') {
			return;
		}

		var $st = $('.wallregi-epass-template-status');
		var $sel = $('#wallregi_epass_template_uid');
		var savedUid = wallregiEpassProduct.savedConfig.template_uid || '';
		var savedMap = wallregiEpassProduct.savedConfig.mapping || {};
		var savedFields = wallregiEpassProduct.savedConfig.pass_fields || [];

		$st.text(wallregiEpassProduct.strings.loadingTemplates);

		postAjax('wallregi_wallet_epass_get_templates')
			.done(function (res) {
				if (!res || !res.success) {
					var msg =
						res && res.data && res.data.message
							? res.data.message
							: wallregiEpassProduct.strings.loadFailed;
					$st.text(msg);
					return;
				}

				var templates = res.data && res.data.templates ? res.data.templates : [];
				var preserveUid = $sel.val() || savedUid;

				$sel.empty();
				$sel.append(
					$('<option value=""></option>').text(wallregiEpassProduct.strings.selectTemplate)
				);

				templates.forEach(function (t) {
					var uid = t.uid ? String(t.uid) : '';
					var name = t.name ? String(t.name) : uid;
					var id = t.id != null ? t.id : 0;
					var $opt = $('<option></option>').val(uid).text(name);
					$opt.attr('data-template-name', name);
					$opt.attr('data-template-id', id);
					$sel.append($opt);
				});

				if (preserveUid) {
					var hasOpt = false;
					$sel.find('option').each(function () {
						if (this.value === preserveUid) {
							hasOpt = true;
							return false;
						}
					});
					if (hasOpt) {
						$sel.val(preserveUid);
					} else {
						var sn = wallregiEpassProduct.savedConfig.template_name || preserveUid;
						var sid = wallregiEpassProduct.savedConfig.template_id || 0;
						var $fallback = $('<option></option>')
							.val(preserveUid)
							.text(sn)
							.attr('data-template-name', sn)
							.attr('data-template-id', sid);
						$sel.append($fallback);
						$sel.val(preserveUid);
					}
				}

				syncTemplateMetaFromSelection();

				var uidNow = $sel.val();
				if (uidNow) {
					if (savedFields.length && uidNow === savedUid) {
						setSnapshot(savedFields);
						$('#wallregi_epass_mapping_wrap').show();
						renderMappingRows(savedFields, savedMap);
						$st.text('');
					} else {
						loadPassFields(uidNow, savedUid === uidNow ? savedMap : {});
					}
				} else {
					$('#wallregi_epass_mapping_wrap').hide();
					setSnapshot([]);
					$st.text('');
				}
			})
			.fail(function () {
				$st.text(wallregiEpassProduct.strings.loadFailed);
			});

		$sel.on('change', function () {
			syncTemplateMetaFromSelection();
			var uid = $(this).val();
			if (!uid) {
				$('#wallregi_epass_mapping_wrap').hide();
				$('#wallregi_epass_mapping_rows').empty();
				setSnapshot([]);
				return;
			}
			loadPassFields(uid, {});
		});
	}

	$(fillTemplatesAndInit);
})(jQuery);
