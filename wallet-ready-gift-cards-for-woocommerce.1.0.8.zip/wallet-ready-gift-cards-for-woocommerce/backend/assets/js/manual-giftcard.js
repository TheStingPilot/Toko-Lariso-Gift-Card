
// flatpickr JS 
jQuery(document).ready(function ($) {
    let preferredPicker;

    // Destroy and init expiry date picker
    $(".wallregi_expiry_date").each(function () {
        if (this._flatpickr) {
            this._flatpickr.destroy();
        }
    });
    const expiryPicker = $(".wallregi_expiry_date").flatpickr({
        dateFormat: "Y-m-d",
        minDate: new Date(), // default: disable past dates
    });

    // Destroy and init preferred date/time picker
    $(".preferred_date_time").each(function () {
        if (this._flatpickr) {
            this._flatpickr.destroy();
        }
    });

    preferredPicker = $(".preferred_date_time").flatpickr({
        enableTime: true,
        dateFormat: "Y-m-d H:i",
        minDate: new Date(), 
        defaultHour: new Date().getHours(),
        defaultMinute: new Date().getMinutes(),

        onReady: function (selectedDates, dateStr, instance) {
            const now = new Date();
            if (selectedDates.length > 0) {
                const selected = selectedDates[0];
                if (
                    selected.getFullYear() === now.getFullYear() &&
                    selected.getMonth() === now.getMonth() &&
                    selected.getDate() === now.getDate()
                ) {
                    instance.set("minTime", now.getHours() + ":" + now.getMinutes());
                } else {
                    instance.set("minTime", "00:00");
                }
            }
        },

        onChange: function (selectedDates, dateStr, instance) {
            const now = new Date();
            const selected = selectedDates[0];
            if (selected) {
                // Update expiry picker min date to be at least the preferred date
                expiryPicker.set("minDate", selected);

                if (
                    selected.getFullYear() === now.getFullYear() &&
                    selected.getMonth() === now.getMonth() &&
                    selected.getDate() === now.getDate()
                ) {
                    // Today → disable past times
                    instance.set("minTime", now.getHours() + ":" + now.getMinutes());
                } else {
                    // Future date → allow full day
                    instance.set("minTime", "00:00");
                }
            }
        }
    });



    var frame;

    $('.wallregi-media-upload-button').on('click', function (e) {
        e.preventDefault();
        const button = $(this);
        const targetInputId = button.data('target');
        const targetInput = button.closest('.wallregi_input_wrapper').find('#' + targetInputId);
        const previewContainer = button.nextAll('.wallregi_show_pdf_thumbnail');

        if (frame) {
            frame.open();
            return;
        }

        frame = wp.media({
            title: 'Select or Upload Image',
            button: {
                text: 'Use this image'
            },
            multiple: false
        });

        
        frame.on('select', function() {
            // Get media attachment details from the frame state
            const attachment = frame.state().get('selection').first().toJSON();

            // Set the image URL to the hidden input
            targetInput.val(attachment.url);

            // Show the preview + remove button
            previewContainer.html(
                '<img src="' + attachment.url + '" alt="PDF Thumbnail" />' +
                '<span class="remove_image dashicons dashicons-no-alt" style="cursor: pointer;"></span>'
            );
            // Make sure preview container is visible
            previewContainer.show();  // <-- add this line

        });

        // Finally, open the modal on click
        frame.open();
    });

    // Button click event to remove the thumbnail
    $(document).on('click', '.remove_image', function(e) {
        e.preventDefault();
        const container = $(this).closest('.wallregi_input_wrapper');
        container.find('input[type="hidden"]').val('');
        container.find('.wallregi_show_pdf_thumbnail').empty().hide();  // Hide after clearing
    });
});


/**
 * Normalizes WordPress admin-ajax JSON: { success, data } where data may be an object or JSON string.
 *
 * @param {object} json Full response object from response.json().
 * @returns {object}
 */
function wallregiNormalizeWpAjaxPayload(json) {
    if (!json || json.data === undefined || json.data === null) {
        return {};
    }
    let p = json.data;
    if (typeof p === 'string') {
        try {
            p = JSON.parse(p);
        } catch (e) {
            return {};
        }
    }
    return p && typeof p === 'object' ? p : {};
}

/**
 * Final gift card code from the full AJAX response (checks json.data, not only a loose "data" binding).
 *
 * @param {object} json Full wp_send_json_* response { success, data }.
 * @param {string} fallback Client-side value (typed code).
 * @returns {string}
 */
function wallregiExtractSavedGiftcardCode(json, fallback) {
    const layers = [];
    if (json && typeof json === 'object') {
        layers.push(json);
        const inner = wallregiNormalizeWpAjaxPayload(json);
        if (inner && Object.keys(inner).length) {
            layers.push(inner);
        }
    }
    for (let i = 0; i < layers.length; i++) {
        const d = layers[i];
        if (!d || typeof d !== 'object') {
            continue;
        }
        const sn = d.saved_giftcard_number;
        if (sn != null && String(sn).trim() !== '') {
            return String(sn).trim();
        }
        const gd = d.giftcard_data;
        if (gd && gd.giftcard_number != null && String(gd.giftcard_number).trim() !== '') {
            return String(gd.giftcard_number).trim();
        }
    }
    return (fallback || '').toString().trim();
}


function wallregiManualGiftCardCreated(form) {
    // Prefer a single input element (form['name'] can be a RadioNodeList and break .disabled / .value).
    const couponCodeEl = form.querySelector('input[name="giftcard_coupon_code"]');
    let selectGiftProduct = form['giftcard_product_id'];
    let couponAmount = form['giftcard_coupon_amount'];
    let couponCurrentBalance = form['giftcard_coupon_current_balance'];
    let selectExpiryDate = form['wallregi_giftcard_expiry_date'];
    let recipientName = form['wallregi_recipient_name'];
    let recipientEmail = form['wallregi_recipient_email'];
    let recipientPhone = form['wallregi_recipient_phone'];
    let deliveryChannel = form['wallregi_delivery_channel'];
    let senderName = form['wallregi_sender_name'];
    let wallregiMessage = form['wallregi_message'];
    let preferredDateTime = form['wallregi_preferred_date_time'];
    let wallregiEmailSend = form['wallregi_email_send'];
    let submitButton = form['save_gift_card'];
    let post_id = Number(submitButton.getAttribute('data-identifier'));
    let giftcardPDFThumb = form['wallregi_pdf_thumbnail'];
    let showErrorMessage = form.querySelector("#showErrorMessage");

    

    // Select all notices and error messages
    const showErrorMgs = form.querySelector('#wallregi_show_errorMessage');
    const showNotices = document.querySelectorAll(".wallregi_giftcard_notice");
    let isValid = true;

    // Clear all previous errors first
    const allErrors = form.querySelectorAll(".wallregi_error_mgs");
    allErrors.forEach(el => el.remove());


    // Store 'checked' or 'unchecked' in a variable
    let isCheckedStatus = wallregiEmailSend.checked ? 'checked' : 'unchecked';

    showNotices.forEach(item => {
        const dismissButton = item.querySelector(".notice-dismiss");

        if (dismissButton) {
            dismissButton.addEventListener("click", function () {
                item.style.display = "none";
            });
        }
    });

    // Determine if coupon field is disabled by checkbox (auto-generate on server).
    const isCouponDisabled = !!(couponCodeEl && couponCodeEl.disabled);

    // Clean and format coupon code only if enabled
    let cleanedCode = '';

    // Get localized strings (fallback to defaults if not available)
    const strings = (typeof wallregi_manual_giftcard_obj !== 'undefined' && wallregi_manual_giftcard_obj.strings) ? wallregi_manual_giftcard_obj.strings : {
        couponCodeRequired: 'Coupon Code is required.',
        couponCodeLength: 'Coupon code must be between 5 and 19 characters long.',
        couponCodePattern: (typeof wallregi_manual_giftcard_obj !== 'undefined' && wallregi_manual_giftcard_obj.codeFormatType === 'digits')
            ? 'Coupon code must be 5–19 characters, digits only (hyphens (-) or underscores (_) optional).'
            : 'Coupon code must be 5–19 characters, include both letters and numbers required, (hyphens (-) or underscores (_) optional).',
        initialAmountRequired: 'Please enter a valid initial coupon amount.',
        currentBalanceRequired: 'Please enter a valid current coupon balance.',
        expiryDateRequired: 'Please select a valid expiry date',
        emailRequired: 'Please enter a valid email address.',
        receiverNameRequired: 'Receiver name is required.',
        senderNameRequired: 'Sender name is required.',
        phoneRequired: 'Please enter a valid recipient phone number.',
    };

    const selectedChannel = deliveryChannel ? String(deliveryChannel.value || 'email') : 'email';
    const needsEmail = selectedChannel === 'email' || selectedChannel === 'both';
    const needsPhone = selectedChannel === 'sms' || selectedChannel === 'both';

    if (!isCouponDisabled && couponCodeEl) {
        cleanedCode = couponCodeEl.value.trim().replace(/\s+/g, '-').toUpperCase();
        // Check if empty
        if (cleanedCode === '') {
            wallregiShowValidationError(couponCodeEl, strings.couponCodeRequired);
            isValid = false;
        }
        // Check length
        else if (cleanedCode.length < wallregiGiftcardCodeMinLength() || cleanedCode.length > wallregiGiftcardCodeMaxLength()) {
            wallregiShowValidationError(
                couponCodeEl,
                wallregiFormatLocalizedString(strings.couponCodeLength, [ wallregiGiftcardCodeMinLength(), wallregiGiftcardCodeMaxLength() ])
            );
            isValid = false;
        }
        // Check pattern
        else if (!wallregiIsValidCouponCode(cleanedCode)) {
            wallregiShowValidationError(
                couponCodeEl,
                strings.couponCodePattern
            );
            isValid = false;
        }
    }

    // Validate Initial Amount 
    if (isNaN(couponAmount.value.trim()) || couponAmount.value.trim() <= 0) {
        wallregiShowValidationError(couponAmount, strings.initialAmountRequired);
        isValid = false;
    }

    // Validate Current Amount
    if (isNaN(couponCurrentBalance.value.trim()) || couponCurrentBalance.value.trim() <=0) {
        wallregiShowValidationError(couponCurrentBalance, strings.currentBalanceRequired);
        isValid = false;
    }

    // Validate expiry date
    if (selectExpiryDate.value === '' ) {
        wallregiShowValidationError(selectExpiryDate, strings.expiryDateRequired);
        isValid = false;
    }

    // Validate email when required by delivery method
    if (needsEmail && recipientEmail && (recipientEmail.value.trim() === '' || !wallregiIsValidEmail(recipientEmail.value.trim()))) {
        wallregiShowValidationError(recipientEmail, strings.emailRequired);
        isValid = false;
    }

    // Validate phone when required by delivery method
    if (needsPhone && recipientPhone) {
        const phoneValue = recipientPhone.value.trim().replace(/[^\d+]/g, '');
        if (phoneValue === '' || phoneValue.charAt(0) !== '+' || phoneValue.length < 9) {
            wallregiShowValidationError(recipientPhone, strings.phoneRequired);
            isValid = false;
        }
    }

    // Validate Receiver Name
    if (recipientName.value.trim() === '') {
        wallregiShowValidationError(recipientName, strings.receiverNameRequired);
        isValid = false;
    }

    // Validate Sender Name
    if (senderName.value.trim() === '') {
        wallregiShowValidationError(senderName, strings.senderNameRequired);
        isValid = false;
    }

    let preferredDateTimeValue = preferredDateTime.value.trim();
    if (preferredDateTimeValue === '') {
        const now = new Date();
        const pad = (n) => (n < 10 ? '0' + n : n);
        preferredDateTimeValue = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}`;
    }

    // Produc ID 
    const productIdRaw = selectGiftProduct.value.trim();
    const productId = productIdRaw === '-1' ? 0 : parseInt(productIdRaw, 10);
    
    // Prepare data for fetch
    const formData = {
        action: 'wallregi_manual_giftcard_created',
        wallreginonce: wallregi_dashboard_obj.nonce,
        giftcard_number: cleanedCode,
        auto_generate_giftcard: isCouponDisabled ? '1' : '0',
        initial_amount: couponAmount.value.trim(),
        current_amount: couponCurrentBalance.value.trim(),
        expiry_period: selectExpiryDate.value.trim(),
        receipent_name: recipientName.value.trim(),
        receipent_email: recipientEmail ? recipientEmail.value.trim() : '',
        receipent_phone: recipientPhone ? recipientPhone.value.trim() : '',
        delivery_channel: selectedChannel,
        sender_name: senderName.value.trim(),
        message: wallregiMessage.value.trim(),
        preferred_date_time: preferredDateTimeValue,
        email_send_notification: isCheckedStatus,
        postid: post_id,
        giftcard_pdf_thumbnail: giftcardPDFThumb.value.trim(),
        order_id: form['order_id'].value,
        item_id: form['item_id'].value,
        product_id: productId,
    };

    if (!isValid) return false; // Stop if validation failed

    // Create spinner element inside submitButton
    const loadingSpinner = document.createElement("span");
    loadingSpinner.classList.add("loading-spinner");
    submitButton.prepend(loadingSpinner);

    // Disable button to prevent multiple clicks
    submitButton.disabled = true;

    // Submit the form using Fetch API
    fetch(wallregi_dashboard_obj.ajaxurl, {
        method: 'POST',
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams(formData).toString()
    })
    .then(response => response.json())
    .then((json) => {
        const success = json && (json.success === true || json.success === 1 || json.success === '1');
        const payload = wallregiNormalizeWpAjaxPayload(json);
        const savedCode = wallregiExtractSavedGiftcardCode(json, cleanedCode);
        const messageText = (payload && payload.message) ? String(payload.message) : '';

        if (success) {
            if (messageText) {
                const para = document.createElement('p');
                para.className = 'wallregi_error_mgs';
                para.textContent = savedCode ? `[${savedCode}] ${messageText}` : messageText;

                // Apply color based on success or error
                para.style.color = success ? 'green' : 'red';

                // Clear previous messages if needed
                if (showErrorMgs) {
                    showErrorMgs.innerHTML = '';
                    showErrorMgs.append(para);
                    showErrorMgs.style.display = 'block';
                }
            }

            // Show notice if available (use server-returned code when field was empty / auto-generated).
            showNotices.forEach(item => {
                const noticeMgs = item.querySelector('p');
                if (!noticeMgs) {
                    return;
                }
                item.style.display = 'block';
                const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
                const codePrefix = savedCode
                    ? `<span style="color: green;">[${esc(savedCode)}]</span> `
                    : '';
                noticeMgs.innerHTML = `${codePrefix}${esc(messageText)}`;
            });

            // Reset the form only on success, then restore generated code so it stays visible.
            if (!post_id) {
                form.reset();
                if (savedCode && couponCodeEl) {
                    const autoGenCb = form.querySelector('#wallregi_enable_coupon_input');
                    if (autoGenCb) {
                        autoGenCb.checked = false;
                    }
                    couponCodeEl.disabled = false;
                    couponCodeEl.value = savedCode;
                }
            }
        } else {
            let errMsg = messageText;
            if (!errMsg && json && json.data) {
                if (typeof json.data === 'object' && json.data.message) {
                    errMsg = String(json.data.message);
                } else if (typeof json.data === 'string') {
                    errMsg = json.data;
                }
            }
            if (!errMsg) {
                errMsg = 'Request failed.';
            }
            showErrorMessage.innerHTML = `<span style="color: red;">${errMsg}</span>`;
            showErrorMessage.style.display = 'block';

            // Hide the error message after 2 seconds
            setTimeout(() => {
                showErrorMessage.style.display = 'none';
            }, 5000);
        }
    })
    .catch(error => {
        console.error("Error:", error);
    })
    .finally(() => {
        // Remove spinner after request completes
        submitButton.removeChild(loadingSpinner);
        submitButton.disabled = false;
    });

    return false; 
}

// Helper: read configured manual gift card code length limits from localized script data.
function wallregiGiftcardCodeMinLength() {
    return (typeof wallregi_manual_giftcard_obj !== 'undefined' && wallregi_manual_giftcard_obj.codeMinLength)
        ? parseInt(wallregi_manual_giftcard_obj.codeMinLength, 10)
        : 5;
}

function wallregiGiftcardCodeMaxLength() {
    return (typeof wallregi_manual_giftcard_obj !== 'undefined' && wallregi_manual_giftcard_obj.codeMaxLength)
        ? parseInt(wallregi_manual_giftcard_obj.codeMaxLength, 10)
        : 19;
}

function wallregiFormatLocalizedString(template, values) {
    let output = String(template || '');
    values.forEach((value, index) => {
        output = output.replace(new RegExp('%' + (index + 1) + '\\$[ds]', 'g'), String(value));
    });
    return output;
}

function wallregiShowValidationError(element, message) {
    // Check if next sibling exists and doesn't already have the error class
    if (!element.nextElementSibling || !element.nextElementSibling.classList.contains('wallregi_error_mgs')) {
        const errorMessage = document.createElement('div');
        errorMessage.className = 'wallregi_error_mgs';
        errorMessage.style.cssText = `margin: 5px 0px; color: red;`;
        errorMessage.textContent = message;
        element.insertAdjacentElement('afterend', errorMessage); 
    }
}

// Helper function: simple email validation
function wallregiIsValidEmail(email) {
    // Basic regex for email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function wallregiGiftcardCodeFormatType() {
    return (typeof wallregi_manual_giftcard_obj !== 'undefined' && wallregi_manual_giftcard_obj.codeFormatType === 'digits')
        ? 'digits'
        : 'mixed';
}

// Helper function: coupon code validation (respects configured digits-only vs mixed format).
function wallregiIsValidCouponCode(code) {
    const min = wallregiGiftcardCodeMinLength();
    const max = wallregiGiftcardCodeMaxLength();
    if (wallregiGiftcardCodeFormatType() === 'digits') {
        const regex = new RegExp('^(?=.*\\d)[0-9_-]{' + min + ',' + max + '}$');
        return regex.test(code);
    }
    const regex = new RegExp('^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z0-9_-]{' + min + ',' + max + '}$');
    return regex.test(code);
}

// Check gift card code number available 
function wallregiCheckGiftcardNumberExists(inputField, event) {
    event.preventDefault();

    let couponCode = inputField.value.trim();

    // Clean up any existing UI elements
    const parent = inputField.parentNode;
    
    const oldSpinner = parent.querySelector('.wallregi_spinner');
    const oldIcon = parent.querySelector('.giftcard_status_icon');
    if (oldSpinner) oldSpinner.remove();
    if (oldIcon) oldIcon.remove();

    const showErrorMessage = document.querySelector('#giftcard_code_error');
    showErrorMessage.style.display = 'none';
    showErrorMessage.innerHTML = '';

    if (!couponCode) return;

    // Create and show spinner
    const spinner = document.createElement('span');
    spinner.className = 'wallregi_spinner';
    spinner.innerHTML = '<span class="dashicons dashicons-update spin"></span>';
    parent.appendChild(spinner);

    // Prepare AJAX request
    const formData = {
        action: 'wallregi_check_giftcard_number_exists',
        wallreginonce: wallregi_dashboard_obj.nonce,
        giftcard_number: couponCode,
    };

    fetch(wallregi_dashboard_obj.ajaxurl, {
        method: 'POST',
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams(formData).toString()
    })
    .then(response => response.json())
    .then(({ success }) => {
        spinner.remove(); 

        // Create status icon
        const icon = document.createElement('span');
        icon.className = 'giftcard_status_icon';
        icon.innerHTML = success
            ? '<span class="dashicons dashicons-yes"></span>'
            : '<span class="dashicons dashicons-no"></span>';
        parent.appendChild(icon);

        // Get localized strings (fallback to defaults if not available)
        const checkStrings = (typeof wallregi_manual_giftcard_obj !== 'undefined' && wallregi_manual_giftcard_obj.strings) ? wallregi_manual_giftcard_obj.strings : {
            giftcardAvailable: 'Gift card number <strong style="color: #7d60a9; font-size: 18px;"> [ ' + couponCode + ' ] </strong> is available.',
            giftcardExists: 'Gift card number <strong style="color: #7d60a9; font-size: 18px;"> [ ' + couponCode + ' ] </strong> already exists. Please choose another number.',
        };

        // Show success/error message
        const availableMsg = checkStrings.giftcardAvailable.replace('%s', couponCode);
        const existsMsg = checkStrings.giftcardExists.replace('%s', couponCode);
        showErrorMessage.innerHTML = success
            ? `<span style="color: green;">${availableMsg}</span>`
            : `<span style="color: red;">${existsMsg}</span>`;
        showErrorMessage.style.display = 'block';

        // Auto-hide
        setTimeout(() => {
            showErrorMessage.style.display = 'none';
        }, 5000);
    })
    .catch(error => {
        console.error("Gift card check failed:", error);
        spinner.remove();
    });
}



// Giftcard coupon code generator
function wallregiAutoGenerateCouponCode(generateBtn, event) {
    event.preventDefault();

    // Get the closest parent .wallregi_coupon_wrapper
    const wrapper = generateBtn.closest('.wallregi_coupon_wrapper');
    const inputField = wrapper.querySelector('.item_left input[type="text"]');
    // const checkbox = wrapper.querySelector('.item_right input[type="checkbox"]');

    if (!inputField) return;

    // Check if checkbox is checked
    // const isChecked = checkbox.checked;

    // Get localized strings (fallback to defaults if not available)
    const genStrings = (typeof wallregi_manual_giftcard_obj !== 'undefined' && wallregi_manual_giftcard_obj.strings) ? wallregi_manual_giftcard_obj.strings : {
        generating: 'Generating...',
        generateCode: 'Generate Code',
    };

    generateBtn.disabled = true;
    generateBtn.textContent = genStrings.generating;

    // You can also fetch a prefix/suffix from other inputs if needed
    const prefix = document.querySelector('#prefix_field')?.value ?? ''; // optional
    const suffix = document.querySelector('#suffix_field')?.value ?? ''; // optional 

    fetch(wallregi_dashboard_obj.ajaxurl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            action: 'wallregi_auto_generate_coupon_code',
            wallreginonce: wallregi_dashboard_obj.nonce,
            prefix: prefix, // optional: pass your prefix here
            suffix: suffix, // optional: pass your prefix here
        }),
    })
    .then(response => response.json())
    .then(({ success, data }) => {
        if (success && data) {
            inputField.value = data.code;
            inputField.dispatchEvent(new Event('change')); // re-trigger validation if needed
        }
    })
    .finally(() => {
        const genStrings = (typeof wallregi_manual_giftcard_obj !== 'undefined' && wallregi_manual_giftcard_obj.strings) ? wallregi_manual_giftcard_obj.strings : {
            generateCode: 'Generate Code',
        };
        generateBtn.disabled = false;
        generateBtn.textContent = genStrings.generateCode;
    });

}


// Diasable Coupon Code 
function wallregi_toggle_coupon_fields(checkbox) {
    const wrapper = checkbox.closest('.wallregi_coupon_wrapper');

    const inputField = wrapper.querySelector('input[name="giftcard_coupon_code"]');
    const generateButton = wrapper.querySelector('.wallregi_auto_generator');

    const isDisabled = checkbox.checked;

    if (inputField) inputField.disabled = isDisabled;
    if (generateButton) generateButton.disabled = isDisabled;

}




function wallregi_toggle_custom_expiry(checkbox, event) {

    const customExpiryRow = document.querySelector('#wallregi_custom_expiry_group');
    const customExpiryField = document.querySelector('#wallregi_custom_expiry_fields');

    if (!customExpiryRow || !customExpiryField) return;

    if (customExpiryRow && customExpiryField) {
        customExpiryRow.style.display = checkbox.checked ? 'table-row' : 'none';
        customExpiryField.style.display = checkbox.checked ? 'block' : 'none';
    }

    
}

function wallregiSyncManualDeliveryFields(selectEl) {
    const channel = selectEl ? String(selectEl.value || 'email') : 'email';
    const needsEmail = channel === 'email' || channel === 'both';
    const needsPhone = channel === 'sms' || channel === 'both';
    const emailRow = document.getElementById('wallregi_recipient_email');
    const phoneRow = document.getElementById('wallregi_recipient_phone');
    const emailMarker = document.querySelector('.wallregi-email-required-marker');
    const phoneMarker = document.querySelector('.wallregi-phone-required-marker');

    if (emailRow) {
        emailRow.style.display = needsEmail ? '' : 'none';
    }
    if (phoneRow) {
        phoneRow.style.display = needsPhone ? '' : 'none';
    }
    if (emailMarker) {
        emailMarker.style.display = needsEmail ? '' : 'none';
    }
    if (phoneMarker) {
        phoneMarker.style.display = needsPhone ? '' : 'none';
    }
}

jQuery(document).ready(function () {
    const deliverySelect = document.getElementById('wallregi_delivery_channel');
    if (deliverySelect) {
        wallregiSyncManualDeliveryFields(deliverySelect);
        deliverySelect.addEventListener('change', function () {
            wallregiSyncManualDeliveryFields(deliverySelect);
        });
    }
});



    





