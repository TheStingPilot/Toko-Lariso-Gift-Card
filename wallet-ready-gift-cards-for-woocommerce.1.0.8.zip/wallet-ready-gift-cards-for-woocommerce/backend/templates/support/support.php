<?php
// Ensure this file is not accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

?>

<div class="wallregi_card wallregi_support_card" id="wallregi_support" style="display: <?php
    $wallregi_tab = '';
    if (isset($_GET['tab'])) {
        $wallregi_tab = sanitize_text_field(wp_unslash($_GET['tab']));
    }
    if (isset($_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'wallregi_nonce_action')) {
        echo ('' === $wallregi_tab || 'wallregi_support' === $wallregi_tab) ? 'block' : 'none'; 
    }

    ?>;">
       <div class="wallregi_card_header" >
            <h3 class="wallregi_page_title"><?php esc_html_e('Get in Touch with Our Support Team', 'wallet-ready-gift-cards-for-woocommerce'); ?></h3>
            <p><?php esc_html_e('Need assistance or have questions? Our team is here to help you every step of the way. Explore our support channels below to get in touch, find helpful resources, or connect with our community.', 'wallet-ready-gift-cards-for-woocommerce'); ?></p>
        </div>
    <div class="contents" style="padding:50px;">
        <div class="container-for-support">    
            <div class="grid-support">        
                <div class="support-item">            
                    <strong><span class="dashicons dashicons-admin-site-alt3"></span> 
                    <?php esc_html_e('Website:','wallet-ready-gift-cards-for-woocommerce'); ?></strong>            
                    <a href="https://webcartisan.com/" target="_blank"><?php esc_html_e('webcartisan.com','wallet-ready-gift-cards-for-woocommerce'); ?></a>            
                    <p><?php esc_html_e('Visit our official website for live chat and more information, tutorials, and resources.','wallet-ready-gift-cards-for-woocommerce'); ?></p>        
                </div>        
                <div class="support-item">            
                    <strong><span class="dashicons dashicons-facebook-alt"></span><?php esc_html_e('Facebook:','wallet-ready-gift-cards-for-woocommerce'); ?></strong>            
                    <a href="https://www.facebook.com/webcartisan" target="_blank"><?php esc_html_e('Follow us','wallet-ready-gift-cards-for-woocommerce'); ?></a>            
                    <p><?php esc_html_e('Join our community on Facebook for support, updates, and discussions.','wallet-ready-gift-cards-for-woocommerce'); ?></p>        
                </div>        
                <div class="support-item">            
                    <strong><span class="dashicons dashicons-whatsapp"></span> <?php esc_html_e('WhatsApp:','wallet-ready-gift-cards-for-woocommerce'); ?></strong>            
                    <a href="https://wa.me/+8801926167151" target="_blank"><?php esc_html_e('Chat Now ','wallet-ready-gift-cards-for-woocommerce'); ?></a>            
                    <p><?php esc_html_e('Get instant support by chatting with us on WhatsApp. We’re here to help!','wallet-ready-gift-cards-for-woocommerce'); ?></p>        
                </div>        
                <div class="support-item">            
                    <strong><span class="dashicons dashicons-email-alt"></span> <?php esc_html_e('Email:','wallet-ready-gift-cards-for-woocommerce'); ?></strong><a href="mailto:support@webcartisan.com"><?php esc_html_e('support@webcartisan.com','wallet-ready-gift-cards-for-woocommerce'); ?></a>            
                    <p><?php esc_html_e('Feel free to reach out to us via email for any inquiries or support requests.','wallet-ready-gift-cards-for-woocommerce'); ?></p>        
                </div>        
                <div class="support-item">            
                    <strong><span class="dashicons dashicons-linkedin"></span> <?php esc_html_e('LinkedIn:','wallet-ready-gift-cards-for-woocommerce'); ?></strong>            
                    <a href="https://www.linkedin.com/company/webcartisan" target="_blank"><?php esc_html_e('Connect on LinkedIn','wallet-ready-gift-cards-for-woocommerce'); ?></a>            
                    <p><?php esc_html_e('Let’s connect on LinkedIn for networking, updates, and professional support.','wallet-ready-gift-cards-for-woocommerce'); ?></p>        
                </div>        
                <div class="support-item">            
                    <strong><span class="dashicons dashicons-twitter"></span> <?php esc_html_e('Twitter:','wallet-ready-gift-cards-for-woocommerce'); ?></strong><a href="https://x.com/webcartisan" target="_blank"><?php esc_html_e('Follow us','wallet-ready-gift-cards-for-woocommerce'); ?></a>            
                    <p><?php esc_html_e('Stay updated with the latest news and announcements by following us on Twitter.','wallet-ready-gift-cards-for-woocommerce'); ?></p>        
                </div>        
                <div class="support-item">            
                    <strong><span class="dashicons dashicons-youtube"></span> <?php esc_html_e('YouTube:','wallet-ready-gift-cards-for-woocommerce'); ?></strong><a href="https://www.youtube.com/@webcartisan" target="_blank"><?php esc_html_e('Subscribe','wallet-ready-gift-cards-for-woocommerce'); ?></a>            
                    <p><?php esc_html_e('Check out our YouTube channel for video tutorials and product showcases.','wallet-ready-gift-cards-for-woocommerce'); ?></p>        
                </div>        
                <div class="support-item">            
                    <strong><span class="dashicons dashicons-instagram"></span> <?php esc_html_e('Instagram:','wallet-ready-gift-cards-for-woocommerce'); ?></strong>            
                    <a href="https://www.instagram.com/webcartisan/" target="_blank"><?php esc_html_e('Follow us','wallet-ready-gift-cards-for-woocommerce'); ?></a>            
                    <p><?php esc_html_e('See behind-the-scenes content and our latest updates on Instagram.','wallet-ready-gift-cards-for-woocommerce'); ?></p>        
                </div> 
            </div>
        </div>
        <a href="<?php echo esc_url('https://webcartisan.com/contact-us/') ?>" target="_blank" style=" margin-top:20px; text-decoration: none; background-color: #7d60a9; color: #fff; padding: 20px 20px; border-radius: 5px; font-size: 16px; font-weight: bold; transition: background-color 0.3s ease; display: block; width: 100%; text-align: center;">
                <?php esc_html_e('Contact us', 'wallet-ready-gift-cards-for-woocommerce'); ?>
        </a>
    </div>
</div>

