<?php
// Security check
if (!defined('ABSPATH')) {
    exit;
}


$wallregi_sidebar_menus  = apply_filters( 'wallregi_sidebar_menu_items', [
    [
        'type'       => 'link',
        'tab'        => 'wallregi_dashboard',
        'icon'       => 'dashicons-dashboard',
        'label'      => __('Dashboard', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
    [
        'type'       => 'link',
        'tab'        => 'wallregi_scheduled_deliveries',
        'icon'       => 'dashicons-email-alt',
        'label'      => __( 'Scheduled deliveries', 'wallet-ready-gift-cards-for-woocommerce' ),
    ],
    [
        'type'       => 'submenu',
        'icon'       => 'dashicons-admin-generic',
        'label'      => __('Settings', 'wallet-ready-gift-cards-for-woocommerce'),
        'sub_items'  => [
            [
                'tab'   => 'wallregi_general',
                'label' => __('General Settings', 'wallet-ready-gift-cards-for-woocommerce'),
            ],
            [
                'tab'   => 'wallregi_form',
                'label' => __('Gift card form', 'wallet-ready-gift-cards-for-woocommerce'),
            ],
            [
                'tab'   => 'wallregi_templates',
                'label' => __('PDF & email card design', 'wallet-ready-gift-cards-for-woocommerce'),
            ],
            [
                'tab'   => 'wallregi_email',
                'label' => __('Email Settings', 'wallet-ready-gift-cards-for-woocommerce'),
            ],
            [
                'tab'   => 'wallregi_wallet',
                'label' => __( 'Google/Apple Wallet', 'wallet-ready-gift-cards-for-woocommerce' ),
            ],
            [
                'tab'   => 'wallregi_status',
                'label' => __('System status', 'wallet-ready-gift-cards-for-woocommerce'),
            ],
        ],
    ],
     [
        'type'       => 'link',
        'tab'        => 'wallregi_features',
        'icon'       => 'dashicons-list-view',
        'label'      => __( 'What\'s included', 'wallet-ready-gift-cards-for-woocommerce' ),
    ],
    [
        'type'       => 'link',
        'tab'        => 'wallregi_support',
        'icon'       => 'dashicons-sos',
        'label'      => __('Get Support', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
    [
        'type'       => 'static',
        'icon'       => 'dashicons-admin-collapse',
        'label'      => __('Collapse', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
]);



// Function to build tab links
function wallregi_admin_tab_url($tab) {
    return wallregi_gift_cards_admin_url(
        [
            'tab'      => $tab,
            '_wpnonce' => wp_create_nonce( 'wallregi_nonce_action' ),
        ]
    );
}


?>
<div class="wallregi_panel_sidebar">
    <div class="wallregi_sidebar_header">
        <a href="<?php echo esc_url(wallregi_admin_tab_url('wallregi_dashboard')); ?>" class="plugin_logo">
            <span class="logo_text"><?php esc_html_e( 'Gift Cards', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
        </a>
    </div>

    <div class="wallregi_sidebar_menu_wrapper">
        <ul class="wallregi_sidebar_menu">
            <?php foreach ($wallregi_sidebar_menus as $menu): ?>
                <?php if ($menu['type'] === 'link'): ?>
                    <li class="menu-item" data-tab="<?php echo esc_attr($menu['tab']); ?>">
                        <a href="<?php echo esc_url(wallregi_admin_tab_url($menu['tab'])); ?>" class="item-link">
                            <span class="dashicons <?php echo esc_attr($menu['icon']); ?>"></span>
                            <span class="name"><?php echo esc_html($menu['label']); ?></span>
                        </a>
                    </li>
                <?php elseif ($menu['type'] === 'submenu'): ?>
                    <li class="menu-item<?php echo ! empty( $menu['pro_section'] ) ? ' menu-item--pro-section' : ''; ?>">
                        <a href="#" class="item-link">
                            <span class="dashicons <?php echo esc_attr($menu['icon']); ?>"></span>
                            <span class="name"><?php echo esc_html($menu['label']); ?></span>
                            <?php if ( ! empty( $menu['pro_section'] ) ) : ?>
                                <span class="wallregi-label pro"><?php esc_html_e( 'Pro', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
                            <?php endif; ?>
                            <span class="dashicons dashicons-arrow-down-alt2 arrow-icon"></span>
                        </a>
                        <ul class="wallregi_panel_submenu">
                            <?php foreach ($menu['sub_items'] as $wallregi_sub): ?>
                                <?php
                                $wallregi_sub_href = ! empty( $wallregi_sub['href'] )
                                    ? $wallregi_sub['href']
                                    : wallregi_admin_tab_url( $wallregi_sub['tab'] ?? 'wallregi_features' );
                                $wallregi_sub_tab   = isset( $wallregi_sub['tab'] ) ? (string) $wallregi_sub['tab'] : '';
                                ?>
                                <li class="submenu-item<?php echo ! empty( $wallregi_sub['pro_badge'] ) ? ' submenu-item--pro-placeholder' : ''; ?>">
                                    <a href="<?php echo esc_url( $wallregi_sub_href ); ?>" class="item-link"<?php echo '' !== $wallregi_sub_tab ? ' data-tab="' . esc_attr( $wallregi_sub_tab ) . '"' : ''; ?>>
                                        <?php echo esc_html( $wallregi_sub['label'] ); ?>
                                        <?php if ( ! empty( $wallregi_sub['pro_badge'] ) ) : ?>
                                            <span class="wallregi-label pro"><?php esc_html_e( 'Pro', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
                                        <?php endif; ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                <?php elseif ($menu['type'] === 'static'): ?>
                    <li class="menu-item collapse-item">
                        <a href="#" class="item-link">
                            <span class="dashicons <?php echo esc_attr($menu['icon']); ?>"></span>
                            <span class="name"><?php echo esc_html($menu['label']); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="wallregi-setup-help-notice">
          <?php
    $wallregi_first_activated = get_option( 'wallregi_first_activated_time' );
    if ( ! $wallregi_first_activated ) {
        $wallregi_first_activated = time();
        add_option( 'wallregi_first_activated_time', $wallregi_first_activated );
    }
    $wallregi_total_free_days = 30;
    $wallregi_days_passed     = (int) floor( ( time() - (int) $wallregi_first_activated ) / DAY_IN_SECONDS );
    $wallregi_days_left       = max( 0, $wallregi_total_free_days - $wallregi_days_passed );
    if ( $wallregi_days_left > 0 ) {
        /* translators: %d: number of days left */
        $wallregi_days_text = sprintf( esc_html__( '%d days left', 'wallet-ready-gift-cards-for-woocommerce' ), $wallregi_days_left );
    } else {
        $wallregi_days_text = esc_html__( '0 days left', 'wallet-ready-gift-cards-for-woocommerce' );
    }
    $wallregi_whatsapp_url = 'https://giftrocketwp.com/free-setup';
    ?>
    <a href="<?php echo esc_url( $wallregi_whatsapp_url ); ?>" target="_blank" rel="noopener noreferrer" class="wallregi-sidebar-setup-card">
        <div class="wallregi-sidebar-setup-top">
            <div class="wallregi-sidebar-avatar-wrap">
                <svg width="38" height="38" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg" class="wallregi-sidebar-avatar-img">
                    <circle cx="40" cy="40" r="40" fill="#E2E8F0"/>
                    <path d="M16 68C16 56 26 48 40 48C54 48 64 56 64 68" fill="#475569"/>
                    <path d="M32 48L40 58L48 48" fill="#FFFFFF"/>
                    <path d="M34 40V46C34 49.3 36.7 52 40 52C43.3 52 46 49.3 46 46V40" fill="#FDBA74"/>
                    <circle cx="40" cy="32" r="14" fill="#FDBA74"/>
                    <path d="M26 28C26 20 32 16 40 16C48 16 54 20 54 28C54 28 50 24 40 24C30 24 26 28 26 28Z" fill="#334155"/>
                    <rect x="29" y="29" width="9" height="7" rx="2" fill="none" stroke="#1E293B" stroke-width="2"/>
                    <rect x="42" y="29" width="9" height="7" rx="2" fill="none" stroke="#1E293B" stroke-width="2"/>
                    <line x1="38" y1="32" x2="42" y2="32" stroke="#1E293B" stroke-width="2"/>
                    <path d="M36 38C36 40 38 41 40 41C42 41 44 40 44 38" stroke="#C2410C" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M24 32C24 23 31 16 40 16C49 16 56 23 56 32" stroke="#0F172A" stroke-width="3" stroke-linecap="round" fill="none"/>
                    <rect x="22" y="28" width="4" height="8" rx="2" fill="#0F172A"/>
                    <rect x="54" y="28" width="4" height="8" rx="2" fill="#0F172A"/>
                    <path d="M24 34C24 40 30 42 34 42" stroke="#0F172A" stroke-width="2" stroke-linecap="round" fill="none"/>
                    <circle cx="35" cy="42" r="2.5" fill="#22C55E"/>
                </svg>
                <span class="wallregi-sidebar-status-dot"></span>
            </div>
            <div class="wallregi-sidebar-badge">
                <span><?php echo esc_html( $wallregi_days_text ); ?></span>
            </div>
        </div>
        <div class="wallregi-sidebar-setup-content">
            <h4 class="wallregi-sidebar-setup-title"><?php esc_html_e( 'Get free setup help', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h4>
            <p class="wallregi-sidebar-setup-desc"><?php esc_html_e( 'Get help from our experts at no cost', 'wallet-ready-gift-cards-for-woocommerce' ); ?></p>
        </div>
    </a>
    </div>
</div>

