<?php
/**
 * Security audit log (admin).
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! current_user_can( 'manage_woocommerce' ) ) {
	wp_die( esc_html__( 'You do not have permission to access this page.', 'wallet-ready-gift-cards-for-woocommerce' ) );
}

global $wpdb;

$wallregi_current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
if (
	'wallregi_security' !== $wallregi_current_tab ||
	! isset( $_GET['_wpnonce'] ) ||
	! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'wallregi_nonce_action' )
) {
	return;
}

$wallregi_table = wallregi_security_audit_db_table_name();

$wallregi_search = '';
if ( isset( $_GET['wallregi_audit_s'] ) && isset( $_GET['_wpnonce_audit'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce_audit'] ) ), 'wallregi_audit_log_search' ) ) {
	$wallregi_search = sanitize_text_field( wp_unslash( (string) $_GET['wallregi_audit_s'] ) );
}

$wallregi_per_page = 50;
$wallregi_paged    = isset( $_GET['paged'] ) ? max( 1, (int) wp_unslash( $_GET['paged'] ) ) : 1;
$wallregi_offset   = ( $wallregi_paged - 1 ) * $wallregi_per_page;

if ( '' !== $wallregi_search ) {
	$like = '%' . $wpdb->esc_like( $wallregi_search ) . '%';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin audit list.
	$wallregi_total = (int) $wpdb->get_var(
		$wpdb->prepare(
			'SELECT COUNT(*) FROM %i WHERE (`action` LIKE %s OR `ip` LIKE %s OR `identifier` LIKE %s OR `detail` LIKE %s OR `result` LIKE %s)',
			$wallregi_table,
			$like,
			$like,
			$like,
			$like,
			$like
		)
	);
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wallregi_rows = $wpdb->get_results(
		$wpdb->prepare(
			'SELECT * FROM %i WHERE (`action` LIKE %s OR `ip` LIKE %s OR `identifier` LIKE %s OR `detail` LIKE %s OR `result` LIKE %s) ORDER BY `id` DESC LIMIT %d OFFSET %d',
			$wallregi_table,
			$like,
			$like,
			$like,
			$like,
			$like,
			$wallregi_per_page,
			$wallregi_offset
		),
		OBJECT
	);
} else {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wallregi_total = (int) $wpdb->get_var(
		$wpdb->prepare(
			'SELECT COUNT(*) FROM %i',
			$wallregi_table
		)
	);
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wallregi_rows = $wpdb->get_results(
		$wpdb->prepare(
			'SELECT * FROM %i ORDER BY `id` DESC LIMIT %d OFFSET %d',
			$wallregi_table,
			$wallregi_per_page,
			$wallregi_offset
		),
		OBJECT
	);
}

$wallregi_total_pages = max( 1, (int) ceil( $wallregi_total / $wallregi_per_page ) );

$wallregi_pg_args = array(
	'tab'     => 'wallregi_security',
	'_wpnonce' => wp_create_nonce( 'wallregi_nonce_action' ),
	'paged'   => '%#%',
);
if ( '' !== $wallregi_search ) {
	$wallregi_pg_args['wallregi_audit_s'] = $wallregi_search;
	$wallregi_pg_args['_wpnonce_audit']  = wp_create_nonce( 'wallregi_audit_log_search' );
}

$wallregi_pagination = paginate_links(
	array(
		'base'      => wallregi_gift_cards_admin_url( $wallregi_pg_args ),
		'format'    => '',
		'current'   => $wallregi_paged,
		'total'     => $wallregi_total_pages,
		'prev_text' => '&laquo;',
		'next_text' => '&raquo;',
	)
);

?>

<div class="wallregi_card" id="wallregi_security" style="display: block;">
	<div class="wallregi_card_header">
		<span class="wallregi_page_title"><?php esc_html_e( 'Security audit log', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
		<p class="description" style="margin: 0.5rem 0 0; font-weight: normal;">
			<?php esc_html_e( 'Rate-limit blocks and selected admin actions are recorded when “Fraud & abuse safeguards” is enabled under General settings. Retention is configured there; old rows are pruned on the daily expiry check job.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
		</p>
	</div>

	<div class="wallregi_card_body" style="padding: 1rem;">
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="wallregi-audit-search" style="margin-bottom: 1rem; display: flex; flex-wrap: wrap; gap: 0.5rem; align-items: center;">
			<input type="hidden" name="page" value="<?php echo esc_attr( wallregi_gift_cards_parent_menu_slug() ); ?>" />
			<input type="hidden" name="tab" value="wallregi_security" />
			<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'wallregi_nonce_action' ) ); ?>" />
			<input type="hidden" name="_wpnonce_audit" value="<?php echo esc_attr( wp_create_nonce( 'wallregi_audit_log_search' ) ); ?>" />
			<label>
				<span class="screen-reader-text"><?php esc_html_e( 'Search log', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
				<input type="search" name="wallregi_audit_s" value="<?php echo esc_attr( $wallregi_search ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'Action, IP, result, detail…', 'wallet-ready-gift-cards-for-woocommerce' ); ?>" />
			</label>
			<button type="submit" class="button"><?php esc_html_e( 'Search', 'wallet-ready-gift-cards-for-woocommerce' ); ?></button>
		</form>

		<p style="margin: 0 0 1rem;">
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: number of rows shown, 2: total matching rows */
					__( 'Showing %1$d of %2$d entries.', 'wallet-ready-gift-cards-for-woocommerce' ),
					is_array( $wallregi_rows ) ? count( $wallregi_rows ) : 0,
					$wallregi_total
				)
			);
			?>
		</p>

		<?php if ( ! empty( $wallregi_pagination ) ) : ?>
			<div class="tablenav top" style="margin-bottom: 0.75rem;"><?php echo wp_kses_post( $wallregi_pagination ); ?></div>
		<?php endif; ?>

		<div style="overflow-x: auto;">
			<table class="widefat striped">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Time', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Action', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Result', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<th scope="col"><?php esc_html_e( 'IP', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<th scope="col"><?php esc_html_e( 'User', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Identifier / detail', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $wallregi_rows ) ) : ?>
						<tr>
							<td colspan="6"><?php esc_html_e( 'No log entries yet.', 'wallet-ready-gift-cards-for-woocommerce' ); ?></td>
						</tr>
					<?php else : ?>
						<?php foreach ( $wallregi_rows as $wallregi_row ) : ?>
							<tr>
								<td><?php echo esc_html( isset( $wallregi_row->created_at ) ? (string) $wallregi_row->created_at : '' ); ?></td>
								<td><code><?php echo esc_html( isset( $wallregi_row->action ) ? (string) $wallregi_row->action : '' ); ?></code></td>
								<td><?php echo esc_html( isset( $wallregi_row->result ) ? (string) $wallregi_row->result : '' ); ?></td>
								<td><?php echo esc_html( isset( $wallregi_row->ip ) ? (string) $wallregi_row->ip : '' ); ?></td>
								<td>
									<?php
									$wallregi_uid = isset( $wallregi_row->user_id ) ? (int) $wallregi_row->user_id : 0;
									echo $wallregi_uid > 0 ? esc_html( (string) $wallregi_uid ) : '&mdash;';
									?>
								</td>
								<td>
									<?php
									$wallregi_idf = isset( $wallregi_row->identifier ) ? (string) $wallregi_row->identifier : '';
									$wallregi_det = isset( $wallregi_row->detail ) ? (string) $wallregi_row->detail : '';
									if ( '' !== $wallregi_idf ) {
										echo '<div><strong>' . esc_html__( 'ID:', 'wallet-ready-gift-cards-for-woocommerce' ) . '</strong> ' . esc_html( $wallregi_idf ) . '</div>';
									}
									if ( '' !== $wallregi_det ) {
										echo '<div><strong>' . esc_html__( 'Detail:', 'wallet-ready-gift-cards-for-woocommerce' ) . '</strong> ' . esc_html( $wallregi_det ) . '</div>';
									}
									if ( '' === $wallregi_idf && '' === $wallregi_det ) {
										echo '&mdash;';
									}
									?>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

		<?php if ( ! empty( $wallregi_pagination ) ) : ?>
			<div class="tablenav bottom" style="margin-top: 0.75rem;"><?php echo wp_kses_post( $wallregi_pagination ); ?></div>
		<?php endif; ?>
	</div>
</div>
