<?php
/**
 * Admin: scheduled gift card deliveries.
 *
 * @package Wallet_Ready_Gift_Cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $wpdb;

$wallregi_table = wallregi_giftcard_db_table_name();
$wallregi_tab   = '';

if ( isset( $_GET['tab'] ) ) {
	$wallregi_tab = sanitize_text_field( wp_unslash( $_GET['tab'] ) );
}

$wallregi_show_panel = false;
if ( isset( $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'wallregi_nonce_action' ) ) {
	$wallregi_show_panel = ( 'wallregi_scheduled_deliveries' === $wallregi_tab );
}

$wallregi_status_filter = 'all';
if ( $wallregi_show_panel && isset( $_GET['delivery_status_filter'] ) ) {
	$wallregi_status_filter = sanitize_key( wp_unslash( $_GET['delivery_status_filter'] ) );
}
if ( isset( $_GET['email_delivery_filter'] ) && 'all' === $wallregi_status_filter ) {
	$wallregi_status_filter = sanitize_key( wp_unslash( $_GET['email_delivery_filter'] ) );
}
$wallregi_valid_filters = array( 'all', 'pending', 'sent', 'failed' );
if ( ! in_array( $wallregi_status_filter, $wallregi_valid_filters, true ) ) {
	$wallregi_status_filter = 'all';
}

$wallregi_search_query = '';
if ( $wallregi_show_panel && isset( $_GET['delivery_search'] ) ) {
	$wallregi_search_query = sanitize_text_field( wp_unslash( $_GET['delivery_search'] ) );
}

$wallregi_per_page     = 20;
$wallregi_current_page = 1;
if ( $wallregi_show_panel && isset( $_GET['paged'] ) ) {
	$wallregi_current_page = max( 1, absint( wp_unslash( $_GET['paged'] ) ) );
}
$wallregi_offset = ( $wallregi_current_page - 1 ) * $wallregi_per_page;

$wallregi_where_parts = array( wallregi_giftcard_scheduled_delivery_base_where_sql() );
$wallregi_where_args  = array();

if ( 'all' !== $wallregi_status_filter ) {
	$wallregi_where_parts[] = wallregi_giftcard_scheduled_delivery_status_where_sql( $wallregi_status_filter );
}

if ( '' !== $wallregi_search_query ) {
	$wallregi_like          = '%' . $wpdb->esc_like( $wallregi_search_query ) . '%';
	$wallregi_where_parts[] = '( `giftcard_number` LIKE %s OR `receipent_email` LIKE %s OR `receipent_name` LIKE %s OR `receipent_phone` LIKE %s )';
	$wallregi_where_args[]  = $wallregi_like;
	$wallregi_where_args[]  = $wallregi_like;
	$wallregi_where_args[]  = $wallregi_like;
	$wallregi_where_args[]  = $wallregi_like;
}

$wallregi_where_sql = 'WHERE ' . implode( ' AND ', $wallregi_where_parts );

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin scheduled delivery list.
$wallregi_count_sql  = "SELECT COUNT(*) FROM %i {$wallregi_where_sql}";
$wallregi_count_args = array_merge( array( $wallregi_table ), $wallregi_where_args );
$wallregi_total_items = (int) $wpdb->get_var( $wpdb->prepare( $wallregi_count_sql, ...$wallregi_count_args ) );

$wallregi_total_pages = $wallregi_per_page > 0 ? (int) ceil( $wallregi_total_items / $wallregi_per_page ) : 1;

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin scheduled delivery list.
$wallregi_list_sql = "
	SELECT *
	FROM %i
	{$wallregi_where_sql}
	ORDER BY `preferred_date_time` DESC, `id` DESC
	LIMIT %d OFFSET %d
";
$wallregi_list_args = array_merge(
	array( $wallregi_table ),
	$wallregi_where_args,
	array( $wallregi_per_page, $wallregi_offset )
);
$wallregi_deliveries = $wpdb->get_results( $wpdb->prepare( $wallregi_list_sql, ...$wallregi_list_args ), ARRAY_A );

$wallregi_base_url_args = array(
	'tab'      => 'wallregi_scheduled_deliveries',
	'_wpnonce' => wp_create_nonce( 'wallregi_nonce_action' ),
);
if ( 'all' !== $wallregi_status_filter ) {
	$wallregi_base_url_args['delivery_status_filter'] = $wallregi_status_filter;
}
if ( '' !== $wallregi_search_query ) {
	$wallregi_base_url_args['delivery_search'] = $wallregi_search_query;
}
$wallregi_base_url = wallregi_gift_cards_admin_url( $wallregi_base_url_args );

$wallregi_sms_available = function_exists( 'wallregi_giftcard_sms_delivery_available' ) && wallregi_giftcard_sms_delivery_available();

?>

<div class="wallregi_card wallregi_overview_card" id="wallregi_scheduled_deliveries" style="display: <?php echo $wallregi_show_panel ? 'block' : 'none'; ?>;">
	<div class="wallregi_card_header">
		<div class="wrap">
			<div class="header_wrapper">
				<span class="wallregi_page_title"><?php esc_html_e( 'Scheduled deliveries', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
			</div>
			<p><?php esc_html_e( 'View gift cards with scheduled or completed delivery by email and/or SMS. Pending deliveries are sent automatically when the scheduled time passes (checked every 5 minutes).', 'wallet-ready-gift-cards-for-woocommerce' ); ?></p>
		</div>
	</div>

	<div class="wallregi_card_body posts-filter" id="wallregi_scheduled_deliveries_wrap">
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="wallregi_scheduled_deliveries_filters">
			<input type="hidden" name="page" value="<?php echo esc_attr( wallregi_gift_cards_parent_menu_slug() ); ?>" />
			<input type="hidden" name="tab" value="wallregi_scheduled_deliveries" />
			<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'wallregi_nonce_action' ) ); ?>" />

			<div class="wallregi_tablenav_box">
				<div class="wallregi_tablenav_group">
					<div class="wallregi_status_tablenav">
						<label for="wallregi_delivery_status_filter" class="screen-reader-text"><?php esc_html_e( 'Filter by delivery status', 'wallet-ready-gift-cards-for-woocommerce' ); ?></label>
						<select name="delivery_status_filter" id="wallregi_delivery_status_filter" onchange="this.form.submit()">
							<option value="all" <?php selected( $wallregi_status_filter, 'all' ); ?>><?php esc_html_e( 'All delivery statuses', 'wallet-ready-gift-cards-for-woocommerce' ); ?></option>
							<option value="pending" <?php selected( $wallregi_status_filter, 'pending' ); ?>><?php esc_html_e( 'Pending', 'wallet-ready-gift-cards-for-woocommerce' ); ?></option>
							<option value="sent" <?php selected( $wallregi_status_filter, 'sent' ); ?>><?php esc_html_e( 'Sent', 'wallet-ready-gift-cards-for-woocommerce' ); ?></option>
							<option value="failed" <?php selected( $wallregi_status_filter, 'failed' ); ?>><?php esc_html_e( 'Failed', 'wallet-ready-gift-cards-for-woocommerce' ); ?></option>
						</select>
					</div>
				</div>

				<div class="wallregi_tablenav_right_side">
					<p class="wallregi_search_box">
						<label for="wallregi_delivery_search" class="screen-reader-text"><?php esc_html_e( 'Search deliveries', 'wallet-ready-gift-cards-for-woocommerce' ); ?></label>
						<input type="search" id="wallregi_delivery_search" name="delivery_search" value="<?php echo esc_attr( $wallregi_search_query ); ?>" placeholder="<?php esc_attr_e( 'Search code, email, phone, or name', 'wallet-ready-gift-cards-for-woocommerce' ); ?>" />
						<input type="submit" class="button" value="<?php esc_attr_e( 'Search', 'wallet-ready-gift-cards-for-woocommerce' ); ?>" />
					</p>
					<div class="tablenav-pages">
						<span class="displaying-num">
							<?php
							echo esc_html(
								sprintf(
									/* translators: %d: number of gift card delivery rows */
									_n( '%d item', '%d items', $wallregi_total_items, 'wallet-ready-gift-cards-for-woocommerce' ),
									$wallregi_total_items
								)
							);
							?>
						</span>
					</div>
				</div>
			</div>
		</form>

		<?php if ( ! empty( $wallregi_deliveries ) ) : ?>
			<table class="wallregi_table wallregi_scheduled_deliveries_table wp-list-table widefat fixed striped table-view-list posts" id="wallregi_scheduled_deliveries_table">
				<thead>
					<tr>
						<th scope="col" class="manage-column column-code column-primary"><?php esc_html_e( 'Code', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<th scope="col" class="manage-column column-order"><?php esc_html_e( 'Order', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<th scope="col" class="manage-column column-delivery-method"><?php esc_html_e( 'Delivery method', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<th scope="col" class="manage-column column-recipient"><?php esc_html_e( 'Recipient', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<th scope="col" class="manage-column column-scheduled"><?php esc_html_e( 'Scheduled for', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<th scope="col" class="manage-column column-email-status"><?php esc_html_e( 'Email status', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<?php if ( $wallregi_sms_available ) : ?>
							<th scope="col" class="manage-column column-sms-status"><?php esc_html_e( 'SMS status', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<?php endif; ?>
						<th scope="col" class="manage-column column-sent-at"><?php esc_html_e( 'Sent at', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
						<th scope="col" class="manage-column column-actions"><?php esc_html_e( 'Actions', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $wallregi_deliveries as $wallregi_row ) : ?>
						<?php
						$wallregi_giftcard_id    = isset( $wallregi_row['id'] ) ? (int) $wallregi_row['id'] : 0;
						$wallregi_email_status   = isset( $wallregi_row['email_status'] ) ? (int) $wallregi_row['email_status'] : 0;
						$wallregi_sms_status     = isset( $wallregi_row['sms_status'] ) ? (int) $wallregi_row['sms_status'] : 0;
						$wallregi_channel        = function_exists( 'wallregi_normalize_delivery_channel' )
							? wallregi_normalize_delivery_channel( $wallregi_row['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL )
							: WALLREGI_DELIVERY_CHANNEL_EMAIL;
						$wallregi_row_obj        = (object) $wallregi_row;
						$wallregi_show_email     = function_exists( 'wallregi_giftcard_should_send_email_for_channel' )
							? wallregi_giftcard_should_send_email_for_channel( $wallregi_row_obj )
							: in_array( $wallregi_channel, array( WALLREGI_DELIVERY_CHANNEL_EMAIL, WALLREGI_DELIVERY_CHANNEL_BOTH ), true );
						$wallregi_show_sms       = $wallregi_sms_available && function_exists( 'wallregi_giftcard_should_send_sms_for_channel' )
							? wallregi_giftcard_should_send_sms_for_channel( $wallregi_row_obj )
							: false;
						$wallregi_can_resend_email = $wallregi_show_email && ! empty( $wallregi_row['receipent_email'] ) && is_email( $wallregi_row['receipent_email'] );
						$wallregi_can_resend_sms   = $wallregi_show_sms && ! empty( $wallregi_row['receipent_phone'] );
						$wallregi_order_display  = ! empty( $wallregi_row['order_id'] ) ? (string) $wallregi_row['order_id'] : __( 'Manual', 'wallet-ready-gift-cards-for-woocommerce' );
						$wallregi_sent_at_lines  = array();
						if ( $wallregi_show_email && ! empty( $wallregi_row['sent_at'] ) && '0000-00-00 00:00:00' !== (string) $wallregi_row['sent_at'] ) {
							$wallregi_sent_at_lines[] = sprintf(
								/* translators: %s: formatted datetime */
								__( 'Email: %s', 'wallet-ready-gift-cards-for-woocommerce' ),
								wallregi_format_giftcard_admin_datetime( $wallregi_row['sent_at'] )
							);
						}
						if ( $wallregi_show_sms && ! empty( $wallregi_row['sms_sent_at'] ) && '0000-00-00 00:00:00' !== (string) $wallregi_row['sms_sent_at'] ) {
							$wallregi_sent_at_lines[] = sprintf(
								/* translators: %s: formatted datetime */
								__( 'SMS: %s', 'wallet-ready-gift-cards-for-woocommerce' ),
								wallregi_format_giftcard_admin_datetime( $wallregi_row['sms_sent_at'] )
							);
						}
						?>
						<tr data-giftcard-id="<?php echo esc_attr( (string) $wallregi_giftcard_id ); ?>" data-delivery-channel="<?php echo esc_attr( $wallregi_channel ); ?>">
							<td class="code column-code" data-colname="code">
								<strong><?php echo esc_html( $wallregi_row['giftcard_number'] ?? '' ); ?></strong>
							</td>
							<td class="order column-order" data-colname="order">
								<?php echo esc_html( $wallregi_order_display ); ?>
							</td>
							<td class="delivery-method column-delivery-method" data-colname="delivery-method">
								<?php echo esc_html( wallregi_giftcard_delivery_channel_label( $wallregi_channel ) ); ?>
							</td>
							<td class="recipient column-recipient" data-colname="recipient">
								<?php if ( ! empty( $wallregi_row['receipent_name'] ) ) : ?>
									<div><?php echo esc_html( $wallregi_row['receipent_name'] ); ?></div>
								<?php endif; ?>
								<?php if ( $wallregi_show_email && ! empty( $wallregi_row['receipent_email'] ) ) : ?>
									<a href="mailto:<?php echo esc_attr( $wallregi_row['receipent_email'] ); ?>"><?php echo esc_html( $wallregi_row['receipent_email'] ); ?></a>
								<?php endif; ?>
								<?php if ( $wallregi_show_sms && ! empty( $wallregi_row['receipent_phone'] ) ) : ?>
									<?php if ( $wallregi_show_email && ! empty( $wallregi_row['receipent_email'] ) ) : ?>
										<br />
									<?php endif; ?>
									<span class="wallregi-recipient-phone"><?php echo esc_html( $wallregi_row['receipent_phone'] ); ?></span>
								<?php endif; ?>
							</td>
							<td class="scheduled column-scheduled" data-colname="scheduled">
								<?php echo esc_html( wallregi_format_giftcard_admin_datetime( $wallregi_row['preferred_date_time'] ?? '' ) ); ?>
							</td>
							<td class="email-status column-email-status" data-colname="email-status">
								<?php
								if ( $wallregi_show_email ) {
									echo wp_kses_post( wallregi_giftcard_email_status_badge_html( $wallregi_email_status ) );
								} else {
									echo '<span class="description">—</span>';
								}
								?>
							</td>
							<?php if ( $wallregi_sms_available ) : ?>
								<td class="sms-status column-sms-status" data-colname="sms-status">
									<?php
									if ( $wallregi_show_sms ) {
										echo wp_kses_post( wallregi_giftcard_sms_status_badge_html( $wallregi_sms_status ) );
									} else {
										echo '<span class="description">—</span>';
									}
									?>
								</td>
							<?php endif; ?>
							<td class="sent-at column-sent-at" data-colname="sent-at">
								<span class="wallregi-sent-at-value">
									<?php
									if ( ! empty( $wallregi_sent_at_lines ) ) {
										echo esc_html( implode( ' · ', $wallregi_sent_at_lines ) );
									} else {
										echo '—';
									}
									?>
								</span>
							</td>
							<td class="actions column-actions" data-colname="actions">
								<?php if ( $wallregi_can_resend_email ) : ?>
									<button
										type="button"
										class="button button-secondary wallregi-resend-giftcard-email"
										data-giftcard-id="<?php echo esc_attr( (string) $wallregi_giftcard_id ); ?>"
										data-giftcard-code="<?php echo esc_attr( $wallregi_row['giftcard_number'] ?? '' ); ?>"
									>
										<?php esc_html_e( 'Re-send email', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
									</button>
								<?php endif; ?>
								<?php if ( $wallregi_can_resend_sms ) : ?>
									<button
										type="button"
										class="button button-secondary wallregi-resend-giftcard-sms"
										data-giftcard-id="<?php echo esc_attr( (string) $wallregi_giftcard_id ); ?>"
										data-giftcard-code="<?php echo esc_attr( $wallregi_row['giftcard_number'] ?? '' ); ?>"
									>
										<?php esc_html_e( 'Re-send SMS', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
									</button>
								<?php endif; ?>
								<?php if ( ! $wallregi_can_resend_email && ! $wallregi_can_resend_sms ) : ?>
									<span class="description wallregi-no-delivery-contact"><?php esc_html_e( 'No delivery contact', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $wallregi_total_pages > 1 ) : ?>
				<div class="tablenav bottom">
					<div class="tablenav-pages">
						<span class="pagination-links">
							<?php
							echo wp_kses_post(
								paginate_links(
									array(
										'base'      => add_query_arg( 'paged', '%#%', $wallregi_base_url ),
										'format'    => '',
										'prev_text' => '&laquo;',
										'next_text' => '&raquo;',
										'total'     => $wallregi_total_pages,
										'current'   => $wallregi_current_page,
									)
								)
							);
							?>
						</span>
					</div>
				</div>
			<?php endif; ?>
		<?php else : ?>
			<p class="wallregi-no-deliveries"><?php esc_html_e( 'No scheduled or sent gift card deliveries match your filters.', 'wallet-ready-gift-cards-for-woocommerce' ); ?></p>
		<?php endif; ?>
	</div>
</div>
