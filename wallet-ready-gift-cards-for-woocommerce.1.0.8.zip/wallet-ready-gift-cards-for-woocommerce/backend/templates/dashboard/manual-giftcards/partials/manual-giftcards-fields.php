<?php
// Security check
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;

// Check if editing an existing gift card
// phpcs:ignore
$wallregi_gift_card = null;
$post_id = null;
// phpcs:ignore
$gift_pdf_thumb = WALLREGI_PLUGIN_URL. 'backend/assets/giftcard-thumb.png';


if (isset($_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'wallregi_nonce_action')) {
    $wallregi_action = isset($_GET['action']) ? sanitize_text_field(wp_unslash($_GET['action'])) : '';
    if (isset($_GET['postid'], $_GET['action']) && 'edit' === $wallregi_action) {
        $post_id = intval(wp_unslash($_GET['postid']));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
        $wallregi_gift_card = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM %i WHERE `id` = %d',
                wallregi_giftcard_db_table_name(),
                $post_id
            ),
            ARRAY_A
        );
    }
}


// phpcs:ignore
$wallregi_gift_card      = $wallregi_gift_card ?? [];
// phpcs:ignore
$wallregi_currency_symbol = get_woocommerce_currency_symbol();

// Fetch WooCommerce products
// phpcs:ignore
$products = wc_get_products([
    'status' => 'publish',
    'limit'  => -1,
    'orderby' => 'title',
    'order'   => 'ASC',
]);

// Prepare options array
// phpcs:ignore
$product_options = [
    '-1' => __('— Select a Gift Card Product —', 'wallet-ready-gift-cards-for-woocommerce') // Placeholder option
];
// phpcs:ignore
foreach ($products as $product) {
    if ( $product->get_type() === 'wxgiftcard' ) {
        // phpcs:ignore
        $product_options[$product->get_id()] = $product->get_name();
    }
}


// Unified field configuration
$wallregi_delivery_choices = function_exists( 'wallregi_giftcard_delivery_channel_choices' )
    ? wallregi_giftcard_delivery_channel_choices()
    : array( WALLREGI_DELIVERY_CHANNEL_EMAIL => __( 'Email only', 'wallet-ready-gift-cards-for-woocommerce' ) );
$wallregi_stored_channel = function_exists( 'wallregi_normalize_delivery_channel' )
    ? wallregi_normalize_delivery_channel( $wallregi_gift_card['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL )
    : WALLREGI_DELIVERY_CHANNEL_EMAIL;
$wallregi_sms_available = function_exists( 'wallregi_giftcard_sms_delivery_available' ) && wallregi_giftcard_sms_delivery_available();

$wallregi_giftcard_fields = [
    'giftcard_coupon_code' => [
        'label' => __('Gift Card Code', 'wallet-ready-gift-cards-for-woocommerce') . ' <span class="required-field">*</span>',
        'type'  => 'text',
        'value' => $wallregi_gift_card['giftcard_number'] ?? '',
        'desc'  => __('Enter a unique code that the customer will use to redeem this gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
        'attr'  => 'onchange="wallregiCheckGiftcardNumberExists(this, event);"',
        'class' => 'wallregi_input wallregi_coupon_code',
        'placeholder' => __('Enter gift card code', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
    'giftcard_product_id' => [
        'label'       => __('Select Gift Card Product', 'wallet-ready-gift-cards-for-woocommerce'),
        'type'        => 'select',
        'value'       => $wallregi_gift_card['product_id'] ?? '-1',
        'options'     => $product_options, 
        'desc'        => __('Select the WooCommerce product that represents the gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
        'class'       => 'wallregi_input wallregi_initial_amount',
        'placeholder' => __('Select a product', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
    'giftcard_coupon_amount' => [
        'label' => __('Initial Amount', 'wallet-ready-gift-cards-for-woocommerce') . " ($wallregi_currency_symbol)" . ' <span class="required-field">*</span>',
        'type'  => 'number',
        'value' => $wallregi_gift_card['initial_amount'] ?? '',
        'desc'  => __('Set the original balance of the gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
        'attr'  => 'min="0"',
        'class' => 'wallregi_input wallregi_initial_amount',
        'placeholder' => __('Enter initial amount', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
    'giftcard_coupon_current_balance' => [
        'label' => __('Current Balance', 'wallet-ready-gift-cards-for-woocommerce') . " ($wallregi_currency_symbol)" . ' <span class="required-field">*</span>',
        'type'  => 'number',
        'value' => $wallregi_gift_card['current_amount'] ?? '',
        'desc'  => __('The remaining balance on this gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
        'attr'  => 'min="0"',
        'class' => 'wallregi_input wallregi_current_balance',
        'placeholder' => __('Enter current balance', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
    'wallregi_giftcard_expiry_date' => [
        'label' => __('Expire Date', 'wallet-ready-gift-cards-for-woocommerce') . ' <span class="required-field">*</span>',
        'type'  => 'text',
        'value' => $wallregi_gift_card['expiry_date'] ?? '',
        'desc'  => __('Set how long this gift card remains valid.', 'wallet-ready-gift-cards-for-woocommerce'),
        'class' => 'wallregi_input wallregi_expiry_date',
        'placeholder' => __('Select expiry date', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
    'wallregi_recipient_name' => [
        'label' => __('Recipient\'s Name', 'wallet-ready-gift-cards-for-woocommerce') . ' <span class="required-field">*</span>',
        'type'  => 'text',
        'value' => $wallregi_gift_card['receipent_name'] ?? '',
        'desc'  => __('Name of the person who will receive the gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
        'class' => 'wallregi_input wallregi_recipient_name',
        'placeholder' => __('Enter recipient name', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
    'wallregi_delivery_channel' => [
        'label' => __('Delivery method', 'wallet-ready-gift-cards-for-woocommerce') . ' <span class="required-field">*</span>',
        'type'  => 'select',
        'value' => $wallregi_stored_channel,
        'options' => $wallregi_delivery_choices,
        'desc'  => __('How the gift card should be delivered to the recipient.', 'wallet-ready-gift-cards-for-woocommerce'),
        'class' => 'wallregi_input wallregi_delivery_channel',
    ],
    'wallregi_recipient_email' => [
        'label' => __('Recipient\'s Email', 'wallet-ready-gift-cards-for-woocommerce') . ' <span class="required-field wallregi-email-required-marker">*</span>',
        'type'  => 'email',
        'value' => $wallregi_gift_card['receipent_email'] ?? '',
        'desc'  => __('Enter the email address where the gift card will be sent.', 'wallet-ready-gift-cards-for-woocommerce'),
        'class' => 'wallregi_input wallregi_recipient_email',
        'placeholder' => __('Enter recipient email', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
    'wallregi_recipient_phone' => [
        'label' => __('Recipient\'s Phone', 'wallet-ready-gift-cards-for-woocommerce') . ' <span class="required-field wallregi-phone-required-marker" style="display:none;">*</span>',
        'type'  => 'tel',
        'value' => $wallregi_gift_card['receipent_phone'] ?? '',
        'desc'  => __('Include country code (e.g. +1…). Required for SMS delivery.', 'wallet-ready-gift-cards-for-woocommerce'),
        'class' => 'wallregi_input wallregi_recipient_phone',
        'placeholder' => __('Enter recipient phone', 'wallet-ready-gift-cards-for-woocommerce'),
        'style' => $wallregi_sms_available ? '' : 'display:none;',
    ],
    'wallregi_sender_name' => [
        'label' => __('Sender Name', 'wallet-ready-gift-cards-for-woocommerce') . ' <span class="required-field">*</span>',
        'type'  => 'text',
        'value' => $wallregi_gift_card['sender_name'] ?? '',
        'desc'  => __('Name of the person sending the gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
        'class' => 'wallregi_input wallregi_sender_name',
        'placeholder' => __('Enter sender name', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
    'wallregi_message' => [
        'label' => __('Message', 'wallet-ready-gift-cards-for-woocommerce'),
        'type'  => 'textarea',
        'value' => $wallregi_gift_card['message'] ?? '',
        'desc'  => __('Optional message to be sent with the gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
        'class' => 'wallregi_textarea wallregi_message',
        'placeholder' => __('Enter your message here...', 'wallet-ready-gift-cards-for-woocommerce'),
    ],
    'wallregi_pdf_thumbnail' => [
        'label' => __('PDF Thumbnail', 'wallet-ready-gift-cards-for-woocommerce'),
        'type'  => 'hidden',
        'value' => $wallregi_gift_card['giftcard_image'] ?? '',
        'desc'  => __('Choose the preferred date to send the gift card email to the recipient.', 'wallet-ready-gift-cards-for-woocommerce'),
        'class' => 'wallregi_input wallregi_pdf_thumbnail',
    ],
    'wallregi_preferred_date_time' => [
        'label' => __('Preferred date time', 'wallet-ready-gift-cards-for-woocommerce'),
        'type'  => 'text',
        'value' => $wallregi_gift_card['preferred_date_time'] ?? '',
        'desc'  => __('Choose the preferred date and time to deliver the gift card to the recipient.', 'wallet-ready-gift-cards-for-woocommerce'),
        'class' => 'wallregi_input preferred_date_time',
        'placeholder' => __('Select preferred send date/time', 'wallet-ready-gift-cards-for-woocommerce'),
    ],

    'wallregi_email_send' => [
        'label' => __('Send gift card now', 'wallet-ready-gift-cards-for-woocommerce'),
        'type'  => 'checkbox',
        'checked' => false,
        'desc'  => __('Send immediately using the selected delivery method(s). Otherwise delivery runs at the scheduled time.', 'wallet-ready-gift-cards-for-woocommerce'),
        'class' => 'wallregi_input wallregi_send_email',
    ],
];



