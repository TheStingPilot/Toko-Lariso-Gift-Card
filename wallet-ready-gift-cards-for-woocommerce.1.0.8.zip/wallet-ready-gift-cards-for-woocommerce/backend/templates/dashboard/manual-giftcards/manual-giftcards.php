<?php
    // Security check
    if (!defined('ABSPATH')) {
        exit;
    }

    // include files
    if (file_exists(plugin_dir_path(__FILE__) . 'partials/manual-giftcards-fields.php')) {
        include_once plugin_dir_path(__FILE__) . 'partials/manual-giftcards-fields.php';
    }

$wallregi_show_new_form = (
    isset($_GET['new_giftcard'], $_GET['_wpnonce']) &&
    'true' === sanitize_text_field(wp_unslash($_GET['new_giftcard'])) &&
    wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'wallregi_nonce_action')
);

?>


<div class="wallregi_card wallregi_new_gc_form" id="wallregi_new_giftcard_form"  style="display: <?php echo $wallregi_show_new_form ? 'block' : 'none'; ?>;">
    <div class="wallregi_card_header">
        <a id="backto" class="bradcrumb_style" href="<?php echo esc_url( wallregi_gift_cards_admin_url( [ 'tab' => 'wallregi_dashboard', '_wpnonce' => wp_create_nonce( 'wallregi_nonce_action' ) ] ) ); ?>"><?php esc_html_e('Back to "All Gift Cards"', 'wallet-ready-gift-cards-for-woocommerce' ) ?></a>

        <span class="wallregi_page_title">
        <?php 

            if (isset($post_id)) {
                esc_html_e('Edit Gift Card Details', 'wallet-ready-gift-cards-for-woocommerce');
            } else {
                esc_html_e('Add New Gift Card', 'wallet-ready-gift-cards-for-woocommerce');
            }

        ?>
        </span>
        <p class="wallregi_desc">
        <?php 

            if (isset($post_id)) {
                esc_html_e('Edit the gift card details, including balance and recipient information, to keep it up to date for customer use.', 'wallet-ready-gift-cards-for-woocommerce');
            } else {
                esc_html_e('Create a gift card that customers can redeem or reload with additional balance for future purchases.', 'wallet-ready-gift-cards-for-woocommerce');
            }
        
        ?>


    </div>

   
    <?php 
        // Trigger the dashboard admin notices function via hook
        do_action('wallregi_display_admin_notice');

    ?>

    <div class="wallregi_card_body">
        <form method="post" class="wallregi_manual_form" onsubmit="return wallregiManualGiftCardCreated(this)">
            <input type="hidden" name="giftcard_id" value="<?php echo esc_attr($wallregi_gift_card['id'] ?? ''); ?>">
            <div id="showErrorMessage" style="display: none"></div>
            <table class="form-table">
                <?php foreach ($wallregi_giftcard_fields as $wallregi_field_id => $wallregi_field) : ?>
                    <tr class="wallregi-form-field" id="<?php echo esc_attr($wallregi_field_id); ?>" style="<?php echo esc_attr($wallregi_field['style'] ?? ''); ?>">
                        <th scope="row">
                            <label for="<?php echo esc_attr($wallregi_field_id); ?>" class="wallregi_label">
                                <?php echo wp_kses_post($wallregi_field['label'] ?? ''); ?>
                            </label>
                        </th>

                        <td class="wallregi_table_data">
                            <?php 
                                if ($wallregi_field_id === 'giftcard_coupon_code') : 
                                    
                                    echo'<input type="hidden" name="order_id" value="'.esc_attr($wallregi_gift_card['order_id'] ?? 0).'">';
                                    echo'<input type="hidden" name="item_id" value="'.esc_attr($wallregi_gift_card['item_id'] ?? 0).'">';
                             
                                    
                                    if(isset($wallregi_gift_card['id'])){
                                        echo '<b>'.esc_attr($wallregi_field['value'] ?? '').'</b>';
                                        echo'<input type="hidden" name="giftcard_coupon_code" value="'.esc_attr($wallregi_field['value'] ?? '').'">';
                                        $wallregi_field['desc'] = '';
                                    }else{
                            ?>
                                <div class="wallregi_coupon_wrapper">
                                    <div class="input_item_box item_left">
                                        <input
                                            type="<?php echo esc_attr($wallregi_field['type']); ?>"
                                            id="<?php echo esc_attr($wallregi_field_id); ?>"
                                            name="<?php echo esc_attr($wallregi_field_id); ?>"
                                            value="<?php echo esc_attr($wallregi_field['value'] ?? ''); ?>"
                                            class="regular-text <?php echo esc_attr($wallregi_field['class'] ?? ''); ?>"
                                            placeholder="<?php echo esc_attr($wallregi_field['placeholder'] ?? ''); ?>"
                                            <?php echo wp_kses($wallregi_field['attr'] ?? '', [
                                                'readonly' => true,
                                                'disabled' => true,
                                                'data-*'   => true,
                                            ]); ?>
                                        />
                                    </div>
                                    <div class="wallregi_button_groups item_right">
                                        <button
                                            type="button"
                                            class="wallregi_auto_generator"
                                            onclick="wallregiAutoGenerateCouponCode(this, event)"
                                        >
                                            <?php esc_html_e("Generate Code", "wallet-ready-gift-cards-for-woocommerce"); ?>
                                        </button>

                                        <label for="wallregi_enable_coupon_input" class="wallregi_switch">
                                            <input
                                                type="checkbox"
                                                id="wallregi_enable_coupon_input"
                                                name="wallregi_enable_coupon_input"
                                                onchange="wallregi_toggle_coupon_fields(this)"
                                            />
                                            <span class="slider round"></span>
                                        </label>

                                        <div class="wallregi_tooltip_box">
                                            <span class="tooltipicon">?</span>
                                            <span class="tooltiptext"><?php esc_html_e('Disable coupon code field and generate automatically on form submit.', 'wallet-ready-gift-cards-for-woocommerce'); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div id="giftcard_code_error" style="display: none; font-size: 14px; margin-top: 5px; color: #b32d2e;"></div>

                            <?php 
                                }
                            elseif (in_array($wallregi_field['type'], ['text', 'email', 'number', 'date', 'tel'], true)) :
                            ?>
                                <div class="wallregi_input_wrapper">
                                    <input
                                        type="<?php echo esc_attr($wallregi_field['type']); ?>"
                                        id="<?php echo esc_attr($wallregi_field_id); ?>"
                                        name="<?php echo esc_attr($wallregi_field_id); ?>"
                                        value="<?php echo esc_attr($wallregi_field['value'] ?? ''); ?>"
                                        class="regular-text <?php echo esc_attr($wallregi_field['class'] ?? ''); ?>"
                                        placeholder="<?php echo esc_attr($wallregi_field['placeholder'] ?? ''); ?>"
                                        min="<?php echo esc_attr($wallregi_field['min'] ?? ''); ?>"
                                    />
                                </div>

                            <?php elseif ($wallregi_field['type'] === 'textarea') : ?>
                                <div class="wallregi_input_wrapper">
                                    <textarea
                                        id="<?php echo esc_attr($wallregi_field_id); ?>"
                                        name="<?php echo esc_attr($wallregi_field_id); ?>"
                                        rows="5"
                                        class="regular-text <?php echo esc_attr($wallregi_field['class'] ?? ''); ?>"
                                        placeholder="<?php echo esc_attr($wallregi_field['placeholder'] ?? ''); ?>"
                                    ><?php echo esc_textarea($wallregi_field['value'] ?? ''); ?></textarea>
                                </div>

                            <?php elseif ($wallregi_field_id === 'wallregi_pdf_thumbnail') : ?>
                                <div class="wallregi_input_wrapper">
                                    <input
                                        type="hidden"
                                        id="<?php echo esc_attr($wallregi_field_id); ?>"
                                        name="<?php echo esc_attr($wallregi_field_id); ?>"
                                        value="<?php echo esc_attr($wallregi_gift_card['giftcard_image'] ?? $gift_pdf_thumb); ?>"
                                        class="<?php echo esc_attr($wallregi_field['class'] ?? ''); ?>"
                                    />
                                    <button type="button" class="button wallregi-media-upload-button" data-target="<?php echo esc_attr($wallregi_field_id); ?>">
                                        <?php esc_html_e('Change / Upload Image', 'wallet-ready-gift-cards-for-woocommerce'); ?>
                                    </button>
                                    <div class="wallregi_show_pdf_thumbnail" style="<?php echo !empty($wallregi_gift_card['giftcard_image']) ? '' : 'display:none;'; ?>">
                                        <?php 
                                            if (!empty($wallregi_gift_card['giftcard_image'])) {
                                                echo '<img src="' . esc_url($wallregi_gift_card['giftcard_image']) . '" alt="PDF Thumbnail" />';
                                                echo '<span class="remove_image dashicons dashicons-no-alt" style="cursor: pointer;"></span>';
                                            }
                                        ?>
                                    </div>
                                    
                                </div>

                            <?php elseif ($wallregi_field['type'] === 'select') : ?>
                                <div class="wallregi_input_wrapper">
                                    <select
                                        id="<?php echo esc_attr($wallregi_field_id); ?>"
                                        name="<?php echo esc_attr($wallregi_field_id); ?>"
                                        class="regular-text <?php echo esc_attr($wallregi_field['class'] ?? ''); ?>"
                                    >
                                        <?php foreach ($wallregi_field['options'] as $wallregi_option_value => $wallregi_option_label) : ?>
                                            <option value="<?php echo esc_attr($wallregi_option_value); ?>" <?php selected($wallregi_option_value, $wallregi_field['value'] ?? ''); ?> <?php echo $wallregi_option_value === '-1' ? 'disabled' : ''; ?>>
                                                <?php echo esc_html($wallregi_option_label); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                            <?php elseif ($wallregi_field['type'] === 'checkbox') : ?>
                                <label class="wallregi_switch">
                                    <input type="checkbox"
                                        id="<?php echo esc_attr($wallregi_field_id); ?>"
                                        name="<?php echo esc_attr($wallregi_field_id); ?>"
                                        class="<?php echo esc_attr($wallregi_field['class'] ?? ''); ?>"
                                        <?php checked($wallregi_field['checked'] ?? false); ?> 
                                        <?php echo wp_kses($wallregi_field['attr'] ?? '', [
                                            'readonly' => true,
                                            'disabled' => true,
                                            'data-*'   => true,
                                        ]); ?> 
                                        />
                                    <span class="slider round"></span>
                                </label>

                            <?php elseif ($wallregi_field['type'] === 'group' && $wallregi_field_id === 'wallregi_custom_expiry_group') : ?>
                                <div id="wallregi_custom_expiry_fields" style="<?php echo esc_attr($wallregi_field['style'] ?? ''); ?>">

                                    <!-- Expiry Value + Duration -->
                                    <div class="wallregi_input_wrapper" style="margin-bottom: 10px;">
                                        <label class="wallregi_label"><?php echo esc_html($wallregi_field['content']['custom_expiry_value']['label']); ?></label>
                                        <div style="display: flex; gap: 10px;">
                                            <input
                                                type="number"
                                                name="custom_expiry_value"
                                                id="custom_expiry_value"
                                                class="<?php echo esc_attr($wallregi_field['content']['custom_expiry_value']['class']); ?>"
                                                placeholder="<?php echo esc_attr($wallregi_field['content']['custom_expiry_value']['placeholder']); ?>"
                                                min="<?php echo esc_attr($wallregi_field['content']['custom_expiry_value']['min']); ?>"
                                                value="<?php echo esc_attr($wallregi_field['content']['custom_expiry_value']['value'] ?? ''); ?>"
                                            />
                                            <select
                                                name="custom_expiry_duration"
                                                id="custom_expiry_duration"
                                                class="<?php echo esc_attr($wallregi_field['content']['custom_expiry_duration']['class']); ?>"
                                            >
                                                <?php foreach ($wallregi_field['content']['custom_expiry_duration']['options'] as $wallregi_option_value => $wallregi_option_label) : ?>
                                                    <option value="<?php echo esc_attr($wallregi_option_value); ?>" <?php selected($wallregi_option_value, $wallregi_field['content']['custom_expiry_duration']['selected'] ?? ''); ?>>
                                                        <?php echo esc_html($wallregi_option_label); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <?php if (!empty($wallregi_field['desc'])) : ?>
                                            <p class="description"><?php echo esc_html($wallregi_field['desc']); ?></p>
                                        <?php endif; ?>
                                    </div>

                                    <!-- OR Separator -->
                                    <div class="wallregi_or_seperator" ><span>-- OR --</span></div>

                                    <!-- Manual Date -->
                                    <div class="wallregi_input_wrapper">
                                        <label class="wallregi_label" for="manual_expiry_date"><?php echo esc_html($wallregi_field['content']['manual_expiry_date']['label']); ?></label>
                                        <div style="display: flex; gap: 10px; align-items: center;">
                                            <input
                                                type="date"
                                                name="manual_expiry_date"
                                                id="manual_expiry_date"
                                                class="<?php echo esc_attr($wallregi_field['content']['manual_expiry_date']['class']); ?>"
                                                value="<?php echo esc_attr($wallregi_field['content']['manual_expiry_date']['value'] ?? ''); ?>"
                                            />
                                            <button type="button" class="button button-secondary" onclick="document.getElementById('manual_expiry_date').value = '';">
                                                <?php esc_html_e('Clear', 'wallet-ready-gift-cards-for-woocommerce'); ?>
                                            </button>
                                        </div>
                                    </div>

                                </div>
                            <?php endif; ?>

                            <?php if (!empty($wallregi_field['desc']) && $wallregi_field['type'] !== 'group') : ?>
                                <p class="description"><?php echo esc_html($wallregi_field['desc']); ?></p>
                            <?php endif; ?>
                            <?php
                            /** @see WALLREGI_Pro_AI_Surfaces */
                            do_action( 'wallregi_manual_giftcard_field_after_description', $wallregi_field_id, $wallregi_field );
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>


            <div class="wallregi_flex_wrap">
                <p class="submit_btn_wrap">
                    <button type="submit" name="save_gift_card" data-identifier="<?php echo esc_attr($post_id); ?>" class="button button-primary">
                        <?php if ($wallregi_gift_card): ?>
                            <span class="update_giftcard"><?php esc_html_e('Update Gift Card', 'wallet-ready-gift-cards-for-woocommerce'); ?></span>
                        <?php else: ?>
                            <span class="create_giftcard"><?php esc_html_e('Save Gift Card', 'wallet-ready-gift-cards-for-woocommerce'); ?></span>
                        <?php endif; ?>
                    </button>
                </p>

                <div id="wallregi_show_errorMessage" class="wallregi_show_errorMessage" style="display:none"></div>
            </div>
        </form>
    </div>
</div>
