<?php
// Ensure this file is not accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;

// Show both active & cancelled
$wallregi_status_list = ['active', 'used', 'expired', 'cancelled'];
$wallregi_table = wallregi_giftcard_db_table_name();

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
$wallregi_gift_cards = $wpdb->get_results(
    $wpdb->prepare(
        'SELECT * FROM %i WHERE `status` IN (%s,%s,%s,%s)',
        $wallregi_table,
        $wallregi_status_list[0],
        $wallregi_status_list[1],
        $wallregi_status_list[2],
        $wallregi_status_list[3]
    ),
    ARRAY_A
);

$wallregi_all_items = $wallregi_gift_cards;



$wallregi_current_page = 1;
$per_page = 10;
$wallregi_offset = 0;

if (isset($_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'gift_card_pagination')) {
    $wallregi_current_page = isset($_GET['paged']) ? max(1, intval(wp_unslash($_GET['paged']))) : 1;
    $per_page = 10; // You can change this to fit your needs
    $wallregi_offset = ($wallregi_current_page - 1) * $per_page;
}

// Calculate total pages
$wallregi_total_pages = ($per_page > 0) ? ceil(count($wallregi_all_items) / $per_page) : 1;


// Modify main query with LIMIT and OFFSET
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
$wallregi_gift_cards = $wpdb->get_results(
    $wpdb->prepare(
        'SELECT * FROM %i WHERE `status` IN (%s,%s,%s,%s) ORDER BY `id` DESC LIMIT %d OFFSET %d',
        $wallregi_table,
        $wallregi_status_list[0],
        $wallregi_status_list[1],
        $wallregi_status_list[2],
        $wallregi_status_list[3],
        $per_page,
        $wallregi_offset
    ),
    ARRAY_A
);


?>

<div class="wallregi_card wallregi_overview_card" id="wallregi_dashboard" style="display: <?php
    $wallregi_tab = '';
    if (isset($_GET['tab'])) {
        $wallregi_tab = sanitize_text_field(wp_unslash($_GET['tab']));
    }
    if (isset($_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'wallregi_nonce_action')) {
        echo ('' === $wallregi_tab || 'wallregi_dashboard' === $wallregi_tab) ? 'block' : 'none'; 
    }

    ?>;">
    
    <div class="wallregi_card_header">
        <div class="wrap">
            <div class="header_wrapper">
                <span class="wallregi_page_title"><?php esc_html_e('All Gift Cards', 'wallet-ready-gift-cards-for-woocommerce'); ?></span>
                <div class="button_groups">
                    <a href="<?php echo esc_url( wallregi_gift_cards_admin_url( [ 'tab' => 'new_giftcard', '_wpnonce' => wp_create_nonce( 'wallregi_nonce_action' ) ] ) ); ?>" class="button button-primary" id="new_giftcard"><?php esc_html_e('Create Giftcard', 'wallet-ready-gift-cards-for-woocommerce'); ?></a>
                </div>
            </div>
            <p><?php esc_html_e('View and manage all generated gift card codes from your store in one centralized table. Quickly create, view, or organize gift cards with ease.', 'wallet-ready-gift-cards-for-woocommerce'); ?></p>

        </div>
    </div>


    <?php 
        // Trigger the dashboard admin notices function via hook
        do_action('wallregi_display_admin_notice');
    ?>


    <?php if (!empty($wallregi_gift_cards)) : ?>
        <form action="#" method="get" id="wallregi_giftcard_filter_form" class="wallregi_card_body posts-filter">

            <?php wp_nonce_field( 'wallregi_bulk_delete_action', 'wallregi_bulk_delete_nonce' ); ?>
            
            <div class="wallregi_tablenav_box">
                <div class="wallregi_tablenav_group">
                    <div class="wallregi_bulk_tablenav">
                        <select name="wallregi_bulk_action_option" >
                            <option value="-1"><?php esc_html_e('Bulk actions', 'wallet-ready-gift-cards-for-woocommerce') ?></option>
                            <option value="wallregi_delete"><?php esc_html_e('Delete', 'wallet-ready-gift-cards-for-woocommerce') ?></option>
                        </select>
                        <input type="submit" name="wallregi_bulk_action" id="wallregi_doaction" class="button action" value="<?php esc_html_e('Apply', 'wallet-ready-gift-cards-for-woocommerce') ?>">
                    </div>
                    <div class="wallregi_status_tablenav">
                        <select name="wallregi_filter_status" onchange="wallregiFilterByStatus(this.value, event)">
                            <option value="all" selected><?php esc_html_e('All', 'wallet-ready-gift-cards-for-woocommerce') ?></option>
                            <option value="active"><?php esc_html_e('Active', 'wallet-ready-gift-cards-for-woocommerce') ?></option>
                            <option value="used"><?php esc_html_e('Used', 'wallet-ready-gift-cards-for-woocommerce') ?></option>
                            <option value="expired"><?php esc_html_e('Expired', 'wallet-ready-gift-cards-for-woocommerce') ?></option>
                            <option value="cancelled"><?php esc_html_e('Cancelled', 'wallet-ready-gift-cards-for-woocommerce') ?></option>
                        </select>
                    </div>
                </div>

                <div class="wallregi_tablenav_right_side">
                    <p class="wallregi_search_box">
                        <input type="search" id="wallregi_search_query" name="search_query" value="" placeholder="<?php esc_html_e('Search', 'wallet-ready-gift-cards-for-woocommerce') ?>">
                    </p>
    
                    <div class="tablenav-pages one-page">
                        <span class="displaying-num"><?php echo count($wallregi_all_items); esc_html_e(' items', 'wallet-ready-gift-cards-for-woocommerce');?> </span>
                    </div>
                </div>
            </div> 



            <?php
            // Pagination
      
            ?>
            <table class="wallregi_table wp-list-table widefat fixed striped table-view-list posts" id="wallregi_giftcard_table">
                <caption class="screen-reader-text">Table ordered by Date. Descending.</caption>
                <thead>
                    <tr>
                        <td id="cb" class="manage-column column-cb check-column">
                            <input type="checkbox" id="wallregi_cb_select_all">
                        </td>
                    
                        <th scope="col" id="code" class="manage-column column-code column-primary"><?php esc_html_e('Code', 'wallet-ready-gift-cards-for-woocommerce'); ?></th>
                        <th scope="col" id="order" class="manage-column column-order"><?php esc_html_e('Order', 'wallet-ready-gift-cards-for-woocommerce'); ?></th>
                        <th scope="col" id="balance" class="manage-column column-balance"><?php esc_html_e('Balance', 'wallet-ready-gift-cards-for-woocommerce'); ?></th>
                        <th scope="col" id="redeem" class="manage-column column-redeem"><?php esc_html_e('Redeem', 'wallet-ready-gift-cards-for-woocommerce'); ?></th>
                        <th scope="col" id="expiration" class="manage-column column-expiration"><?php esc_html_e('Expire On', 'wallet-ready-gift-cards-for-woocommerce'); ?></th>
                        <th scope="col" id="recipient" class="manage-column column-recipient"><?php esc_html_e('Email', 'wallet-ready-gift-cards-for-woocommerce'); ?></th>
                        <th scope="col" id="status" class="manage-column column-status"><?php esc_html_e('Status', 'wallet-ready-gift-cards-for-woocommerce'); ?></th>
                        <th scope="col" id="actions" class="manage-column column-actions"><?php esc_html_e('Actions', 'wallet-ready-gift-cards-for-woocommerce'); ?></th>
                        
                    </tr>
                </thead>
                <tbody id="wallregi_table_list">
                    <?php 
                    // phpcs:ignore
                    foreach ($wallregi_gift_cards as $wallregi_gift_card) : ?>
                        <tr id="post-<?php echo esc_attr($wallregi_gift_card['id']); ?>" class="iedit author-self level-0 post-null type-gift_card status-publish hentry publish">

                            <th scope="row" class="check-column">
                                <input type="checkbox" name="wallregi_giftcard_ids[]" value="<?php echo esc_attr($wallregi_gift_card['id']); ?>">
                            </th>
     
                            <td class="code column-code" data-colname="code">
                                <div class="giftcard_code_wrapper">
                                    <div id="giftcard_code_field" class="giftcard_code_field">
                                        <div class="giftcard_code"><?php echo esc_html($wallregi_gift_card['giftcard_number']); ?></div>
                                        <div class="wallregi_copy_to_clipboard" onClick="return copyTextToClipboard(this)">
                                            <span class="icon"></span>
                                            <span>copy</span>
                                        </div>
                                    </div>
                                    <span id="toast_mgs" class="toast-message"><?php esc_html_e('Copied!', 'wallet-ready-gift-cards-for-woocommerce') ?></span>
                                </div>
                            </td>
                            <td class="order column-order" data-colname="order">
                                <?php

                                if (!empty($wallregi_gift_card['order_id'])) {
                                    $wallregi_gift_card['order_id'];
                                } elseif (empty($wallregi_gift_card['order_id'])) { 
                                    // phpcs:ignore
                                    $wallregi_gift_card['order_id'] = esc_html_e('Manual', 'wallet-ready-gift-cards-for-woocommerce');
                                }

                                ?>

                                <span><?php echo esc_html($wallregi_gift_card['order_id']); ?></span>

                            </td>
                            <td class="balance column-balance" data-colname="balance">
                                <span class="wallregi_giftcard_price"><?php echo esc_html($wallregi_gift_card['current_amount']); ?></span>
                                <span class="wallregi_currency_symbol"><?php echo esc_html(get_woocommerce_currency_symbol()); ?></span>
                            </td>
                            <td class="redeem column-redeem" data-colname="redeem">
                                <span class="wallregi_redeem_amout"><?php echo esc_html($wallregi_gift_card['total_redeem']); ?></span>
                                <span class="wallregi_currency_symbol"><?php echo esc_html(get_woocommerce_currency_symbol()); ?></span>
                            </td>
                            <td class="expiration column-expiration" data-colname="expire on">
                            <?php 
                                $wallregi_giftcard_create_date = $wallregi_gift_card['created_at']; 
                                $wallregi_expiry_period = $wallregi_gift_card['expiry_period']; 
                                $wallregi_expiry_date = $wallregi_gift_card['expiry_date'];

                                $wallregi_calculated_expiry_date = '';

                                if (!empty($wallregi_giftcard_create_date) && $wallregi_giftcard_create_date != "0000-00-00" && 'custom' !== (string) $wallregi_expiry_period) {
                                    try {
                                        $wallregi_create_date = new DateTime($wallregi_giftcard_create_date);
                                        $wallregi_create_date->modify("+$wallregi_expiry_period");
                                        $wallregi_calculated_expiry_date = $wallregi_create_date->format('Y-m-d');
                                    } catch (Exception $e) {
                                        $wallregi_calculated_expiry_date = 'Invalid date';
                                    }
                                }

                                if (empty($wallregi_expiry_date) || $wallregi_expiry_date === "0000-00-00") {
                                    ?>
                                    <span class="wallregi_expire_date"><?php echo esc_html($wallregi_calculated_expiry_date); ?></span>
                                    <?php 
                                } else {
                                    ?>
                                    <span class="wallregi_expire_date"><?php echo esc_html($wallregi_expiry_date); ?></span>
                                    <?php 
                                }
                            ?>
                            </td>
                            <td class="recipient column-recipient" data-colname="recipient">
                                <a href="mailto:<?php echo esc_attr($wallregi_gift_card['receipent_email']); ?>" class="wallregi_recipient">
                                    <?php echo esc_html($wallregi_gift_card['receipent_email']); ?>
                                </a>
                            </td>
                     
                            <td class="enabled column-status" data-colname="status">
                                <?php
                                $wallregi_status_label = '';
                                switch ($wallregi_gift_card['status']) {
                                    case 'active':
                                        $wallregi_status_label = '<span class="status-label status-active">' . esc_html__('Active', 'wallet-ready-gift-cards-for-woocommerce') . '</span>';
                                        break;
                                    case 'used':
                                        $wallregi_status_label = '<span class="status-label status-used">' . esc_html__('Used', 'wallet-ready-gift-cards-for-woocommerce') . '</span>';
                                        break;
                                    case 'expired':
                                        $wallregi_status_label = '<span class="status-label status-expired">' . esc_html__('Expired', 'wallet-ready-gift-cards-for-woocommerce') . '</span>';
                                        break;
                                    case 'cancelled':
                                        $wallregi_status_label = '<span class="status-label status-cancelled">' . esc_html__('Cancelled', 'wallet-ready-gift-cards-for-woocommerce') . '</span>';
                                        break;
                                    default:
                                        $wallregi_status_label = '<span class="status-label status-active">' . esc_html__('Active', 'wallet-ready-gift-cards-for-woocommerce') . '</span>';
                                        break;
                                }

                                echo wp_kses_post($wallregi_status_label);
                                ?>
                            </td>
                            <td class="actions column-actions" data-colname="#">
                                <?php
                                if ( isset( $wallregi_gift_card['epass_data'] ) && is_string( $wallregi_gift_card['epass_data'] ) && '' !== $wallregi_gift_card['epass_data'] ) {
                                    $wallregi_decoded = json_decode( $wallregi_gift_card['epass_data'], true );
                                    $wallregi_passLink = ( is_array( $wallregi_decoded ) && isset( $wallregi_decoded['passLink'] ) )
                                        ? (string) $wallregi_decoded['passLink']
                                        : '';
                                } else {
                                    $wallregi_passLink = '';
                                }
                                ?>
                                <a
                                    href="<?php echo esc_url( wallregi_gift_cards_admin_url( [
                                        'tab' => 'new_giftcard',
                                        'postid' => $wallregi_gift_card['id'],
                                        'action' => 'edit',
                                        '_wpnonce' => wp_create_nonce( 'wallregi_nonce_action' ),
                                    ] ) ); ?>">
                                    <span class="dashicons dashicons-edit"></span>
                                </a>
 
                                <a href="#" class="wallregi_download_pdf"
                                    data-giftcode="<?php echo esc_attr($wallregi_gift_card['giftcard_number']) ?>"
                                    onclick="wallregiDownloadPDF(this, event)">
                                    <span class="dashicons dashicons-pdf"></span>
                                </a>
                                <?php
                                $wallregi_pass_link_trim = trim( (string) $wallregi_passLink );
                                $wallregi_use_epass_issue = ( ! function_exists( 'wallregi_wallet_should_use_epasscard' ) || wallregi_wallet_should_use_epasscard() );
                                if ( '' === $wallregi_pass_link_trim && $wallregi_use_epass_issue ) :
                                    ?>
                                    <button
                                        type="button"
                                        class="button-link wallregi-epass-issue-missing-pass wallregi-epass-issue-missing-pass--warning"
                                        data-giftcard-id="<?php echo esc_attr( (string) (int) $wallregi_gift_card['id'] ); ?>"
                                        title="<?php esc_attr_e( 'Wallet pass not generated — click to create Google / Apple Wallet pass', 'wallet-ready-gift-cards-for-woocommerce' ); ?>"
                                        aria-label="<?php esc_attr_e( 'Wallet pass not generated. Generate Google / Apple Wallet pass', 'wallet-ready-gift-cards-for-woocommerce' ); ?>"
                                    >
                                        <span class="dashicons dashicons-smartphone"></span>
                                    </button>
                                    <?php
                                endif;
                                ?>
                                <?php
                                // phpcs:ignore
                                do_action('wallregi_epass_generate_button', $wallregi_passLink, $wallregi_gift_card['id']);
                                // phpcs:ignore
                                do_action( 'wallregi_giftcard_dashboard_wallet_actions', $wallregi_gift_card );
                                ?>
                                <span class="dashicons dashicons-trash"></span>
                            </td>
                            
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php
                $wallregi_nonce = wp_create_nonce('gift_card_pagination');
            ?>

            <ul class="pagination">

                <?php if ($wallregi_current_page > 1) : ?>
                    <li>
                        <a href="<?php echo esc_url(add_query_arg([
                            'paged' => $wallregi_current_page - 1,
                            '_wpnonce' => $wallregi_nonce
                        ])); ?>">
                            <?php esc_html_e('Previous', 'wallet-ready-gift-cards-for-woocommerce'); ?>
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php 
                // phpcs:ignore
                for ($i = 1; $i <= $wallregi_total_pages; $i++) : ?>
                    <li class="<?php echo $i == $wallregi_current_page ? 'active' : ''; ?>">
                        <a href="<?php echo esc_url(add_query_arg([
                            'paged' => $i,
                            '_wpnonce' => $wallregi_nonce
                        ])); ?>">
                            <?php echo esc_html($i); ?>
                        </a>
                    </li>
                <?php endfor; ?>

                <?php if ($wallregi_current_page < $wallregi_total_pages) : ?>
                    <li>
                        <a href="<?php echo esc_url(add_query_arg([
                            'paged' => $wallregi_current_page + 1,
                            '_wpnonce' => $wallregi_nonce
                        ])); ?>">
                            <?php esc_html_e('Next', 'wallet-ready-gift-cards-for-woocommerce'); ?>
                        </a>
                    </li>
                <?php endif; ?>

            </ul>
        </form>
    <?php else : ?>
        <!-- No gift cards message -->
        <div class="no-gift-cards-message" style="text-align: center; padding: 60px 24px; width: 750px; margin: 50px auto;">
            
            
            <p class="no-gift-cards" style="font-size: 16px; margin-bottom: 36px;">
                <?php esc_html_e('You don’t have any gift card codes yet. Once a user purchases a gift card, the code will appear here. Alternatively, you can create one manually.', 'wallet-ready-gift-cards-for-woocommerce'); ?>
            </p>

            <!-- Create Gift Card Button -->
            <a href="<?php echo esc_url( wallregi_gift_cards_admin_url( [ 'tab' => 'new_giftcard', '_wpnonce' => wp_create_nonce( 'wallregi_nonce_action' ) ] ) ); ?>" class="button button-primary" id="new_giftcard"><?php esc_html_e('Create Giftcard', 'wallet-ready-gift-cards-for-woocommerce'); ?></a>
        </div>

    <?php endif; ?>


</div>

<div class="wrap">
    <div class="wallregi_modal_wrapper" id="wallregi_modal">
        <div class="wallregi_popup_card">
            <div class="popup_card_header">
                <h3><?php esc_html_e('Confirm delete', 'wallet-ready-gift-cards-for-woocommerce') ?></h3>
                <span class="dashicons dashicons-no-alt" id="timeClose"></span>
            </div>
            <div class="popup_card_content">
                <div class="message">
                        <?php esc_html_e(' Are you sure you want to delete this gift card?', 'wallet-ready-gift-cards-for-woocommerce');?>                           
                        <p><?php esc_html_e(' This action cannot be undone and you will be not able to recover this data.', 'wallet-ready-gift-cards-for-woocommerce');?></p> 
                </div>
                <div class="confarmation">
                    <button type="button" class="button buuton-reset" id="btnSelectNo"><?php esc_html_e('no', 'wallet-ready-gift-cards-for-woocommerce'); ?></button>                 
                    <button type="button" class="button button-primary" id="btnSelectYesDelete">
                        <span><?php esc_html_e('yes delete', 'wallet-ready-gift-cards-for-woocommerce'); ?></span>
                    </button>                 
                </div>                         
            </div>
        </div>
    </div>
</div>
