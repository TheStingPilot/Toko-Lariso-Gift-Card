<?php
/**
 * Pro feature placeholder screen (WordPress admin submenu).
 *
 * @var string $wallregi_pro_placeholder_title
 * @var string $wallregi_pro_placeholder_description
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wallregi_pro_cta_url = WALLREGI_Pro_Admin_Placeholders::wallregi_get_cta_url();

if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

if ( is_plugin_active( 'wallet-ready-gift-cards-for-woocommerce-pro/wallet-ready-gift-cards-for-woocommerce-pro.php' ) ) {
	$wallregi_pro_cta_label = __( 'Activate your Pro license', 'wallet-ready-gift-cards-for-woocommerce' );
} else {
	$wallregi_pro_cta_label = __( 'Get GiftRocket Pro', 'wallet-ready-gift-cards-for-woocommerce' );
}
?>
<div class="wrap wallregi-pro-placeholder-screen">
	<h1>
		<?php echo esc_html( $wallregi_pro_placeholder_title ); ?>
		<span class="wallregi-label pro wallregi-pro-badge"><?php esc_html_e( 'Pro', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
	</h1>

	<div class="wallregi-pro-placeholder-card">
		<p><?php echo esc_html( $wallregi_pro_placeholder_description ); ?></p>
		<p class="description">
			<?php esc_html_e( 'This feature is part of GiftRocket Pro. Install and activate a valid license to use it on this site.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
		</p>
		<p>
			<a href="<?php echo esc_url( $wallregi_pro_cta_url ); ?>" class="button button-primary">
				<?php echo esc_html( $wallregi_pro_cta_label ); ?>
			</a>
			<a href="<?php echo esc_url( WALLREGI_Pro_Admin_Placeholders::wallregi_get_purchase_url() ); ?>" class="button" target="_blank" rel="noopener noreferrer">
				<?php esc_html_e( 'View Pro plans', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
			</a>
		</p>
	</div>
</div>
