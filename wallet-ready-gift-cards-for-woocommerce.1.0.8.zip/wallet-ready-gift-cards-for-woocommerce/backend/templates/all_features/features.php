<?php
// Security check.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var string[] Core (free) plugin capabilities — marketing / overview only. */
$wallregi_features = [
	__( 'Dedicated Gift Card product type for WooCommerce (catalog, product page, cart, orders, and PDFs)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'GiftRocket admin: gift card dashboard, search and filters, manual issuance, and balance history tied to orders', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'PDF footer text (product short description)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Barcode, PDF417 & QR on downloadable PDFs (gift card number or apply-at-checkout link)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Optional Google & Apple Wallet passes via ePasscard (your API key; issuance, order & email links, dashboard tools, purchaser My Account when a pass exists)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Optional full product description on the gift card product page', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Live character counter for the gift message field', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Custom label above the card design gallery', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Configurable gift card code length and format pattern', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Let buyers edit gift card details from the cart (classic cart and WooCommerce Cart block when enabled)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Apply / redeem gift card codes from cart & checkout', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Apply gift card codes when creating or editing orders in wp-admin (order totals panel)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'WooCommerce Cart & Checkout Blocks: wallet apply/redeem, Store API cart line data for gift cards, and block cart line editing when cart editing is enabled (classic shortcode pages supported too)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Purchaser My Account “Gift cards” tab: list purchased cards with PDF download and wallet pass link when a pass exists', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Two-column layout: illustrated card vs. price & options (page & PDF)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Solid, gradient, image, or no background behind the card preview', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Card layout borders and divider colors', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Flexible and custom gift card amounts', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Accordion / tab hover and active states', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Custom form title and field labels', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Recipient name field label', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Recipient email field label', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Personal message field label', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Maximum length for the personal message', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Sender name field label', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Optional per-product checkout: hide recipient fields on the product page and take recipient name & email from billing or shipping instead', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Custom add to cart button text', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Archive / shop loop button text for gift cards', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Minimum and maximum custom amount limits', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Cap on quantity added in a single add-to-cart', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Fraud & abuse safeguards (rate limits, security audit log)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Separator between product title and card code in headings', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Add multiple different gift cards from the product page', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Schedule email delivery with date & time', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Preset amounts plus enter-your-own pricing', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Per-product expiry options for issued gift cards', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Bulk CSV import / migration: validate and import many gift cards (up to 500 rows per file; higher with Pro license)', 'wallet-ready-gift-cards-for-woocommerce' ),
];

/**
 * Wallet Ready Gift Cards Pro — shipped modules (same plugin adds these).
 *
 * @var string[]
 */
$wallregi_pro_features_shipped = [
	__( 'Edit gift card details during checkout (shortcode checkout and WooCommerce Checkout block when enabled)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Buyer-uploaded custom images on the card (with cleanup of unused uploads)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Expiry reminder emails & scheduling', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Preset greeting message snippets / quick-pick chips', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Buyer partial-redemption UX: amount entry, preview, checkout & Blocks flows', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Order rules: max gift cards per order and redemption amount caps (where configured)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'CSV import: up to 5,000 gift card rows per file (when Pro license is active; free tier 500 rows)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Outstanding balance / liability CSV export', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'WooCommerce REST API: gift card lookup & transactions (wc/v3/wallregi-giftcards/…)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'AI writing assistant (your API key): choose OpenAI, OpenRouter, Google Gemini, or Anthropic under GiftRocket → AI', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'AI for shoppers: optional greeting suggest, improve, and translate (occasion, tone, language; off by default; daily credit limits)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'AI for staff: delivery email copy, expiry reminder templates, preset line generator, product heading/footer, manual gift card messages, and field translate', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'AI cost controls: separate storefront/admin credit pools, rate limits, encrypted keys, shopper-safe errors, and email alert near daily limit', 'wallet-ready-gift-cards-for-woocommerce' ),
];

/**
 * Roadmap and research ideas — not commitments; may include integrations beyond this plugin.
 *
 * @var string[]
 */
$wallregi_features_roadmap = [
	__( 'Redemption Rewards (Pro, planned): promotional discount or free shipping when shoppers pay with a GiftRocket gift card — merchant-defined rules at checkout', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Product Gifting (Pro, planned): let buyers purchase allowed WooCommerce products as a gift — recipient, personal message, scheduling, and ship-to-recipient / claim flows', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Extended PDF & email designer polish (beyond current styling controls)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Curated card & PDF theme packs (pick a look without full CSS tweaking)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Admin: preview recipient email & PDF with sample merge data', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Marketing automation events (received, redeemed, balance low)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Deeper WooCommerce Store API & headless/mobile patterns (beyond wc/v3 REST)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Role-based purchase limits & B2B-style rules (beyond current caps)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Gift card bundles & composite product patterns', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'POS / gateway companion patterns (documented integration paths)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Category-based design image sets', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'More notification channels (SMS, WhatsApp where supported)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Balance top-up and hybrid redeem flows', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Additional flexible redemption modes', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Stronger multilingual, multi-currency & RTL PDF/email polish', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'High-volume email queue & deliverability hardening', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'Formal accessibility audit (WCAG-minded forms, modals, PDF text)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'AI: generate custom card imagery from prompts or brand palette (image generation — planned)', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'AI: suggest amounts or contextual upsell hints on the gift card product', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'AI: seasonal or campaign-matched imagery & copy variants', 'wallet-ready-gift-cards-for-woocommerce' ),
	__( 'AI optional: light moderation flags on buyer-submitted message text', 'wallet-ready-gift-cards-for-woocommerce' ),
];

if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
}
$wallregi_pro_plugin_active = is_plugin_active( 'wallet-ready-gift-cards-for-woocommerce-pro/wallet-ready-gift-cards-for-woocommerce-pro.php' );

?>

<div class="wallregi_card" id="wallregi_features" style="display: block;">
	<div class="wallregi_card_header">
		<span class="wallregi_page_title"><?php esc_html_e( 'Free plugin: what is included', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
		<p class="description" style="margin: 0.5rem 0 0; font-weight: normal;">
			<?php esc_html_e( 'These capabilities ship with Wallet Ready Gift Cards for WooCommerce. Configure them from the WordPress admin under GiftRocket → Gift Cards (tabs for General, gift card form, PDF & email design, email delivery, extensions, and more).', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
		</p>
	</div>
	<div class="wallregi-features-grid">
		<?php foreach ( $wallregi_features as $wallregi_feature ) : ?>
			<div class="wallregi-feature-item">
				<span class="wallregi-feature-label"><?php echo esc_html( $wallregi_feature ); ?></span>

				<label class="wallregi-switch">
					<span class="wallregi-label free">
						<?php esc_html_e( 'Included', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
					</span>
				</label>
			</div>
		<?php endforeach; ?>
	</div>

	<?php if ( ! empty( $wallregi_pro_features_shipped ) ) : ?>
	<div class="wallregi_card_header" style="margin-top: 1.5rem;">
		<span class="wallregi_page_title"><?php esc_html_e( 'Pro edition', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
		<p class="description" style="margin: 0.5rem 0 0; font-weight: normal;">
			<?php if ( $wallregi_pro_plugin_active ) : ?>
				<?php esc_html_e( 'The Pro add-on is active on this site — the features below are available.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
			<?php else : ?>
				<?php esc_html_e( 'Install and activate Wallet Ready Gift Cards Pro to unlock the following.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
			<?php endif; ?>
		</p>
	</div>
	<div class="wallregi-features-grid">
		<?php foreach ( $wallregi_pro_features_shipped as $wallregi_pro_item ) : ?>
			<div class="wallregi-feature-item wallregi-feature-item--pro">
				<span class="wallregi-feature-label"><?php echo esc_html( $wallregi_pro_item ); ?></span>
				<span class="wallregi-label pro">
					<?php if ( $wallregi_pro_plugin_active ) : ?>
						<?php esc_html_e( 'Included', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
					<?php else : ?>
						<?php esc_html_e( 'Pro', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
					<?php endif; ?>
				</span>
			</div>
		<?php endforeach; ?>
	</div>
	<?php endif; ?>

	<?php if ( ! empty( $wallregi_features_roadmap ) ) : ?>
	<div class="wallregi_card_header" style="margin-top: 1.5rem;">
		<span class="wallregi_page_title"><?php esc_html_e( 'Roadmap & upcoming ideas', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
		<p class="description" style="margin: 0.5rem 0 0; font-weight: normal;">
			<?php esc_html_e( 'Planned Pro extensions and longer-term ideas (including optional AI tools). Availability may vary; not commitments for any release.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
		</p>
	</div>
	<div class="wallregi-features-grid">
		<?php foreach ( $wallregi_features_roadmap as $wallregi_roadmap_item ) : ?>
			<div class="wallregi-feature-item wallregi-feature-item--roadmap">
				<span class="wallregi-feature-label"><?php echo esc_html( $wallregi_roadmap_item ); ?></span>
				<span class="wallregi-label upcoming">
					<?php esc_html_e( 'Roadmap', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
				</span>
			</div>
		<?php endforeach; ?>
	</div>
	<?php endif; ?>
</div>
