<?php
/**
 * Unified settings hub: all store settings tabs on one screen with AJAX save (no full reload).
 *
 * Expects $wallregi_active_tab_key from admin router (or falls back to dashboard tab).
 *
 * @package Wallet_Ready_Gift_Cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-admin-settings-persistence.php';

// Non-JS fallback: save via classic POST when JavaScript is unavailable.
if (
	isset( $_SERVER['REQUEST_METHOD'], $_POST['wallregi_save_settings'], $_POST['wallregi_settings_tab_dispatch'] )
	&& 'POST' === $_SERVER['REQUEST_METHOD']
) {
	if (
		! isset( $_POST['settings_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['settings_nonce'] ) ), 'wallregi_save_settings_action' )
	) {
		wp_die( esc_html__( 'Security check failed', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$wallregi_dispatch_tab = sanitize_text_field( wp_unslash( (string) $_POST['wallregi_settings_tab_dispatch'] ) );
	if ( ! in_array( $wallregi_dispatch_tab, wallregi_admin_settings_hub_tab_keys(), true ) ) {
		wp_die( esc_html__( 'Invalid settings section.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$wallregi_post_request = wp_unslash( $_POST );

	if ( 'wallregi_email' === $wallregi_dispatch_tab ) {
		$wallregi_dispatch_result = wallregi_admin_settings_save_email_from_request( $wallregi_post_request );
	} elseif ( 'wallregi_wallet' === $wallregi_dispatch_tab ) {
		$wallregi_dispatch_result = wallregi_admin_settings_save_wallet_from_request( $wallregi_post_request );
	} else {
		$wallregi_data_dir = WALLREGI_PLUGIN_DIR . 'backend/templates/settings/partials/settings-data/';
		$wallregi_map       = [
			'wallregi_general'   => 'general-data.php',
			'wallregi_form'      => 'form-data.php',
			'wallregi_templates' => 'pdf-data.php',
		];
		$wallregi_file      = $wallregi_map[ $wallregi_dispatch_tab ] ?? '';
		if ( '' === $wallregi_file ) {
			wp_die( esc_html__( 'Invalid settings definition.', 'wallet-ready-gift-cards-for-woocommerce' ) );
		}
		$wallregi_dispatch_result = wallregi_admin_settings_save_from_request( $wallregi_data_dir . $wallregi_file, $wallregi_post_request );
	}

	if ( is_wp_error( $wallregi_dispatch_result ) ) {
		wp_die( esc_html( $wallregi_dispatch_result->get_error_message() ) );
	}

	wp_safe_redirect(
		add_query_arg(
			'settings-updated',
			'true',
			wp_get_referer() ? wp_get_referer() : admin_url()
		)
	);
	exit;
}

if ( ! isset( $wallregi_active_tab_key ) ) {
	$wallregi_active_tab_key = isset( $tab ) ? $tab : 'wallregi_general';
}

$wallregi_settings_data_dir = WALLREGI_PLUGIN_DIR . 'backend/templates/settings/partials/settings-data/';

$wallregi_hub_tabs = apply_filters(
	'wallregi_settings_hub_tabs',
	[
		'wallregi_general'   => __( 'General', 'wallet-ready-gift-cards-for-woocommerce' ),
		'wallregi_form'      => __( 'Gift card form', 'wallet-ready-gift-cards-for-woocommerce' ),
		'wallregi_templates' => __( 'PDF & email card design', 'wallet-ready-gift-cards-for-woocommerce' ),
		'wallregi_email'     => __( 'Email delivery', 'wallet-ready-gift-cards-for-woocommerce' ),
		'wallregi_wallet'    => __( 'Google/Apple Wallet', 'wallet-ready-gift-cards-for-woocommerce' ),
	]
);

?>

<div
	class="wallregi-settings-hub"
	id="wallregi-settings-hub"
	data-active-tab="<?php echo esc_attr( $wallregi_active_tab_key ); ?>"
>
	<nav class="wallregi-settings-hub__nav" aria-label="<?php esc_attr_e( 'Settings sections', 'wallet-ready-gift-cards-for-woocommerce' ); ?>">
		<?php foreach ( $wallregi_hub_tabs as $wallregi_hub_key => $wallregi_hub_label ) : ?>
			<button
				type="button"
				class="wallregi-settings-hub__tab <?php echo $wallregi_hub_key === $wallregi_active_tab_key ? 'is-active' : ''; ?>"
				data-wallregi-hub-tab="<?php echo esc_attr( $wallregi_hub_key ); ?>"
				id="<?php echo esc_attr( 'wallregi-hub-tab-' . $wallregi_hub_key ); ?>"
				aria-selected="<?php echo $wallregi_hub_key === $wallregi_active_tab_key ? 'true' : 'false'; ?>"
				role="tab"
			>
				<?php echo esc_html( $wallregi_hub_label ); ?>
			</button>
		<?php endforeach; ?>
	</nav>

	<div class="wallregi-settings-hub__panels" role="tabpanel">
		<?php
		// General.
		$wallregi_settings_data_file = $wallregi_settings_data_dir . 'general-data.php';
		$wallregi_ctx                = wallregi_admin_settings_bootstrap_from_data_file( $wallregi_settings_data_file );
		$wallregi_input_fields       = $wallregi_ctx['wallregi_input_fields'];
		$wallregi_select_fields      = $wallregi_ctx['wallregi_select_fields'];
		$wallregi_defaults           = $wallregi_ctx['wallregi_defaults'];
		$wallregi_settings           = $wallregi_ctx['wallregi_settings'];
		$wallregi_grouped_fields     = $wallregi_ctx['wallregi_grouped_fields'];
		include WALLREGI_PLUGIN_DIR . 'backend/templates/settings/partials/settings-ui/general-settings-ui.php';

		// Gift card form.
		$wallregi_settings_data_file = $wallregi_settings_data_dir . 'form-data.php';
		$wallregi_ctx                = wallregi_admin_settings_bootstrap_from_data_file( $wallregi_settings_data_file );
		$wallregi_input_fields       = $wallregi_ctx['wallregi_input_fields'];
		$wallregi_select_fields      = $wallregi_ctx['wallregi_select_fields'];
		$wallregi_defaults           = $wallregi_ctx['wallregi_defaults'];
		$wallregi_settings           = $wallregi_ctx['wallregi_settings'];
		$wallregi_grouped_fields     = $wallregi_ctx['wallregi_grouped_fields'];
		include WALLREGI_PLUGIN_DIR . 'backend/templates/settings/partials/settings-ui/form-settings-ui.php';

		// PDF template.
		$wallregi_settings_data_file = $wallregi_settings_data_dir . 'pdf-data.php';
		$wallregi_ctx                = wallregi_admin_settings_bootstrap_from_data_file( $wallregi_settings_data_file );
		$wallregi_input_fields       = $wallregi_ctx['wallregi_input_fields'];
		$wallregi_select_fields      = $wallregi_ctx['wallregi_select_fields'];
		$wallregi_defaults           = $wallregi_ctx['wallregi_defaults'];
		$wallregi_settings           = $wallregi_ctx['wallregi_settings'];
		$wallregi_grouped_fields     = $wallregi_ctx['wallregi_grouped_fields'];
		include WALLREGI_PLUGIN_DIR . 'backend/templates/settings/partials/settings-ui/pdf-settings-ui.php';

		// Email (separate option).
		$wallregi_email_ctx    = wallregi_admin_settings_bootstrap_email();
		$wallregi_settings     = $wallregi_email_ctx['wallregi_settings'];
		$email_fields          = $wallregi_email_ctx['email_fields'];
		include WALLREGI_PLUGIN_DIR . 'backend/templates/settings/partials/settings-ui/email-settings-ui.php';

		// Google / Apple Wallet (placeholder panel; extend with options later).
		include WALLREGI_PLUGIN_DIR . 'backend/templates/settings/partials/settings-ui/wallet-settings-ui.php';
		?>
	</div>
</div>
