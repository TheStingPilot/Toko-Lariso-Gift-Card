<?php
/**
 * Legacy email settings route (standalone tab). The unified hub replaces day-to-day use;
 * this file remains for backwards compatibility if loaded directly.
 *
 * @package Wallet_Ready_Gift_Cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-admin-settings-persistence.php';

$wallregi_email_ctx = wallregi_admin_settings_bootstrap_email();
$wallregi_settings  = $wallregi_email_ctx['wallregi_settings'];
$email_fields       = $wallregi_email_ctx['email_fields'];

if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['wallregi_save_settings'] ) ) {
	if ( ! isset( $_POST['settings_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['settings_nonce'] ) ), 'wallregi_save_settings_action' ) ) {
		wp_die( esc_html__( 'Security check failed', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$result = wallregi_admin_settings_save_email_from_request( wp_unslash( $_POST ) );
	if ( is_wp_error( $result ) ) {
		wp_die( esc_html( $result->get_error_message() ) );
	}

	wp_safe_redirect( add_query_arg( 'settings-updated', 'true', wp_get_referer() ? wp_get_referer() : admin_url() ) );
	exit;
}

include_once WALLREGI_PLUGIN_DIR . 'backend/templates/settings/partials/settings-ui/email-settings-ui.php';
