<?php
// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! isset( $wallregi_settings_data_file ) || ! file_exists( $wallregi_settings_data_file ) ) {
	return;
}

require_once WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-admin-settings-persistence.php';

$wallregi_ctx              = wallregi_admin_settings_bootstrap_from_data_file( $wallregi_settings_data_file );
$wallregi_input_fields     = $wallregi_ctx['wallregi_input_fields'];
$wallregi_select_fields    = $wallregi_ctx['wallregi_select_fields'];
$wallregi_defaults         = $wallregi_ctx['wallregi_defaults'];
$wallregi_settings         = $wallregi_ctx['wallregi_settings'];
$wallregi_grouped_fields   = $wallregi_ctx['wallregi_grouped_fields'];

// Legacy full-page POST save (AJAX hub bypasses redirect).
if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['wallregi_save_settings'] ) ) {
	if ( ! isset( $_POST['settings_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['settings_nonce'] ) ), 'wallregi_save_settings_action' ) ) {
		wp_die( esc_html__( 'Security check failed', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$request = wp_unslash( $_POST );
	$result  = wallregi_admin_settings_save_from_request( $wallregi_settings_data_file, $request );
	if ( is_wp_error( $result ) ) {
		wp_die( esc_html( $result->get_error_message() ) );
	}

	wp_safe_redirect( add_query_arg( 'settings-updated', 'true', wp_get_referer() ? wp_get_referer() : admin_url() ) );
	exit;
}
