<?php
// Ensure this file is not accessed directly
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;

// Define both table names
$wallregi_giftcard_table = wallregi_giftcard_db_table_name();
$wallregi_transaction_table = wallregi_transaction_db_table_name();

// Expected columns (single source of truth with DB schema)
$wallregi_giftcard_columns = wallregi_get_giftcard_table_column_names();

$wallregi_transaction_columns = [
    'id', 'giftcard_id', 'amount', 'order_id', 'created_at', 'updated_at', 'created_by',
    'updated_by', 'reconciled', 'message'
];

// Check if tables exist
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin settings health check.
$wallregi_giftcard_table_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wallregi_giftcard_table ) ) === $wallregi_giftcard_table );
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin settings health check.
$wallregi_transaction_table_exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wallregi_transaction_table ) ) === $wallregi_transaction_table );

// Check if columns exist in gift card table
$wallregi_giftcard_columns_exist = $wallregi_giftcard_table_exists ? wallregi_check_table_columns_exist( $wallregi_giftcard_table, $wallregi_giftcard_columns ) : false;

// Check if columns exist in transaction table
$wallregi_transaction_columns_exist = $wallregi_transaction_table_exists ? wallregi_check_table_columns_exist( $wallregi_transaction_table, $wallregi_transaction_columns ) : false;

?>

<div class="wallregi_card wallregi_status_card" id="wallregi_status" style="display: <?php

if (isset($_GET['tab'])) {
    $wallregi_tab = sanitize_text_field(wp_unslash($_GET['tab']));
} else {
    $wallregi_tab = '';
}
if (isset($_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'wallregi_nonce_action')) {
    echo ('wallregi_status' === $wallregi_tab) ? 'block' : 'none'; 
}?>;">

    <div class="wallregi_giftcard_table_status">
        <div class="table_panel">
            <div class="wallregi_table_status">
                <div class="panel_rows">
                    <div class="left_part">
                        <h4 class="heading"><?php esc_html_e( 'Gift card database table', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h4>
                    </div>
                    <div class="right_part">
                        <?php if ($wallregi_giftcard_table_exists) : ?>
                            <span class="dashicons dashicons-yes" style="color: green;"></span>
                        <?php else : ?>
                            <span class="dashicons dashicons-no-alt" style="color: red;"></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="wallregi_column_status">
                <div class="panel_rows">
                    <div class="left_part">
                        <h4 class="heading"><?php esc_html_e( 'Gift card table structure', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h4>
                    </div>
                    <div class="right_part">
                        <?php if ($wallregi_giftcard_columns_exist) : ?>
                            <span class="dashicons dashicons-yes" style="color: green;"></span>
                        <?php else : ?>
                            <span class="dashicons dashicons-no-alt" style="color: red;"></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="wallregi_transaction_table_status">
        <div class="table_panel">
            <div class="wallregi_table_status">
                <div class="panel_rows">
                    <div class="left_part">
                        <h4 class="heading"><?php esc_html_e( 'Transaction database table', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h4>
                    </div>
                    <div class="right_part">
                        <?php if ($wallregi_transaction_table_exists) : ?>
                            <span class="dashicons dashicons-yes" style="color: green;"></span>
                        <?php else : ?>
                            <span class="dashicons dashicons-no-alt" style="color: red;"></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="wallregi_column_status">
                <div class="panel_rows">
                    <div class="left_part">
                        <h4 class="heading"><?php esc_html_e( 'Transaction table structure', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h4>
                    </div>
                    <div class="right_part">
                        <?php if ($wallregi_transaction_columns_exist) : ?>
                            <span class="dashicons dashicons-yes" style="color: green;"></span>
                        <?php else : ?>
                            <span class="dashicons dashicons-no-alt" style="color: red;"></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>