<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

return [
    'input_fields' => [

        // Checkbox fields
        [
            'name'        => 'wallregi_pdf_footer_text',
            'key'         => 'pdf_footer_text',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Show product short description in PDF footer', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'When enabled, the WooCommerce product short description appears at the bottom of the generated PDF.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'checkbox',
            'default'     => 'yes',
            'help_link'   => 'https://youtu.be/qvivWOx2uBI?si=_CYoGM1K8FnOrEpJ',
        ],
        [
            'name'        => 'wallregi_giftcard_summary_text',
            'key'         => 'giftcard_summary_text',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Show full product description on gift card pages', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Shows the full WooCommerce description on the gift card product page (not only in the PDF).', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'checkbox',
            'default'     => 'yes',
            'help_link'   => 'https://youtu.be/vfF2TCXwGiw',
        ],
        [
            'name'        => 'wallregi_character_counts',
            'key'         => 'character_counts',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Show live character counter for message field', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Shows how many characters the shopper has typed under the personal message box. The maximum length is set under the Gift card form tab.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'checkbox',
            'default'     => 'yes',
            'help_link'   => 'https://youtu.be/nOAOudFiPcI',
        ],
        [
            'name'        => 'wallregi_giftcard_edit_in_cart',
            'key'         => 'giftcard_edit_in_cart',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __('Allow editing in cart', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Enable this option to allow customers to edit gift card details directly from the cart.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'checkbox',
            'default'     => 'yes',
            'help_link'   => 'https://youtu.be/-xKd_ZZnHg8',
        ],

        // --- Gift Card Preview: Logo Option ---
        [
            'name'        => 'wallregi_show_card_logo',
            'key'         => 'show_card_logo',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Show logo on gift card preview', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'When enabled, the site logo appears inside the gift card frame (before the card image). You can set its alignment and upload a custom logo below.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'checkbox',
            'default'     => 'no',
        ],
        [
            'name'        => 'wallregi_card_logo_position',
            'key'         => 'card_logo_position',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Logo alignment', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Horizontal alignment of the logo inside the gift card frame.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'select',
            'default'     => 'center',
            'depends_on'  => 'wallregi_show_card_logo',
            'options'     => [
                'left'   => __( 'Left',   'wallet-ready-gift-cards-for-woocommerce' ),
                'center' => __( 'Center', 'wallet-ready-gift-cards-for-woocommerce' ),
                'right'  => __( 'Right',  'wallet-ready-gift-cards-for-woocommerce' ),
            ],
        ],
        [
            'name'        => 'wallregi_card_custom_logo',
            'key'         => 'card_custom_logo',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Custom logo for gift card', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Upload a custom logo to display instead of the default site logo. Leave empty to use the site logo.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'image_upload',
            'default'     => '',
            'depends_on'  => 'wallregi_show_card_logo',
        ],

        // --- Gift Card Preview: Date Option ---
        [
            'name'        => 'wallregi_show_card_date',
            'key'         => 'show_card_date',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Show current date on gift card preview', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'When enabled, today\'s date is displayed inside the card body, before the title (e.g. "Date: dd-mm-yyyy").', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'checkbox',
            'default'     => 'no',
        ],
        [
            'name'        => 'wallregi_card_date_position',
            'key'         => 'card_date_position',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Date alignment', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Horizontal alignment of the date text inside the card body.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'select',
            'default'     => 'left',
            'depends_on'  => 'wallregi_show_card_date',
            'options'     => [
                'left'   => __( 'Left',   'wallet-ready-gift-cards-for-woocommerce' ),
                'center' => __( 'Center', 'wallet-ready-gift-cards-for-woocommerce' ),
                'right'  => __( 'Right',  'wallet-ready-gift-cards-for-woocommerce' ),
            ],
        ],
        [
            'name'        => 'wallregi_card_date_label',
            'key'         => 'card_date_label',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Date label text', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Customize the label text displayed next to the date on the gift card (default: "Date:").', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => 'Date:',
            'depends_on'  => 'wallregi_show_card_date',
        ],

        // Text fields
        [
            'name'        => 'wallregi_price_label_text',
            'key'         => 'price_label',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __('Custom Price Option Label', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Label for price selection area.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'text',
            'default'     => __('Choose an amount', 'wallet-ready-gift-cards-for-woocommerce'),
            'help_link'   => 'https://youtu.be/NNUqCEznDoI',
        ],
        [
            'name'        => 'wallregi_manual_price_placeholder',
            'key'         => 'manual_price_placeholder',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __('Manual Price Input Placeholder', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Placeholder text for manual price.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'text',
            'default'     => __('Enter custom amount', 'wallet-ready-gift-cards-for-woocommerce'),
            'help_link'   => 'https://youtu.be/LiNtSZvsH7w',
        ],
        [
            'name'        => 'wallregi_gallery_label_text',
            'key'         => 'gallery_label',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __('Gallery label text', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __( 'Heading displayed above selectable card artwork on the gift card product page.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __( 'Choose a gift card design', 'wallet-ready-gift-cards-for-woocommerce' ),
            'help_link'   => 'https://youtu.be/rQaVpNVFSSE',
        ],

        [
            'name'        => 'wallregi_giftcard_code_length',
            'key'         => 'giftcard_code_length',
            'sec_name'    => __( 'Limits & formatting', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'advanced_settings',
            'label'       => __( 'Gift card code length', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Number of random characters in auto-generated gift card codes (5–19). Changing this updates the format pattern below unless you customize it.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'number',
            'default'     => 16,
            'help_link'   => 'https://youtu.be/Xjp7_6we1uA?si=Ff73sPv9Y1UGRyIN',
        ],
        [
            'name'        => 'wallregi_coupon_code_pattren',
            'key'         => 'coupon_pattren',
            'sec_name'    => __( 'Limits & formatting', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'advanced_settings',
            'label'       => __( 'Gift card code format', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Pattern for auto-generated codes: * = letter or digit, D = digit only, - or _ = separator. The count of * and D must match the code length above.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => '****-****-****-****',
            'help_link'   => 'https://youtu.be/Xjp7_6we1uA?si=Ff73sPv9Y1UGRyIN',
        ],
        [
            'name'        => 'wallregi_shop_giftcard_button',
            'key'         => 'shop_giftcard_button',
            'sec_name'    => __( 'Limits & formatting', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'advanced_settings',
            'label'       => __( 'Gift card button text on product archives', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Text for the gift card quick-action button in shop/category loops.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __( 'View gift card', 'wallet-ready-gift-cards-for-woocommerce' ),
            'help_link'   => 'https://youtu.be/F3EA2KX281Q',
        ],
        [
            'name'        => 'wallregi_min_cprice',
            'key'         => 'min_cprice',
            'sec_name'    => __( 'Limits & formatting', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'advanced_settings',
            'label'       => __('Custom price minimum value', 'wallet-ready-gift-cards-for-woocommerce') . ' (' . get_woocommerce_currency_symbol() . ')',
            'description' => __('Set the minimum allowed custom gift card price.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'number',
            'default'     => 1,
            'help_link'   => 'https://youtu.be/Fj7aPSkDjEQ',
        ],
        [
            'name'        => 'wallregi_max_cprice',
            'key'         => 'max_cprice',
            'sec_name'    => __( 'Limits & formatting', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'advanced_settings',
            'label'       => __('Custom price maximum value', 'wallet-ready-gift-cards-for-woocommerce') . ' (' . get_woocommerce_currency_symbol() . ')',
            'description' => __('Set the maximum allowed custom gift card price.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'number',
            'default'     => 9990,
            'help_link'   => 'https://youtu.be/VARwm73xaUk',
        ],
        [
            'name'        => 'wallregi_max_giftcard_qty',
            'key'         => 'max_giftcard_qty',
            'sec_name'    => __( 'Limits & formatting', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'advanced_settings',
            'label'       => __( 'Maximum gift cards per purchase (single add-to-cart)', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Upper limit on quantity when adding this gift card product to the cart in one click.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'number',
            'default'     => 5,
            'help_link'   => 'https://youtu.be/MbqHkaNmhr8',
        ],
        [
            'name'        => 'wallregi_giftcard_hseparator',
            'key'         => 'giftcard_hseparator',
            'sec_name'    => __( 'Limits & formatting', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'advanced_settings',
            'label'       => __( 'Separator between title and card code', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __('Choose a symbol to separate the gift card heading and number, e.g. "-", ":", or "|".', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'text',
            'default'     => '-',
            'help_link'   => 'https://youtu.be/_hw_UfZfmP4?si=vuGOdAicfrA5NsYg',
        ],

        // Single Giftcard Layout Header Title Text Styling Fields
        [
            'name'        => 'wallregi_giftcard_header_title_styles_group',
            'key'         => 'giftcard_header_title_styles_group',
            'sec_name'    => __( 'Gift card (page & PDF): accordion tabs', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_header_styles',
            'label'       => __( 'Accordion tab (inactive): title appearance', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/D5IJbHXemSs',
            'fields'      => [
                // Text color
                [
                    'name'    => 'wallregi_giftcard_header_title_text_color',
                    'key'     => 'giftcard_header_title_text_color',
                    'label'   => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#333333',
                ],
                // Font size
                [
                    'name'    => 'wallregi_giftcard_header_title_font_size',
                    'key'     => 'giftcard_header_title_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 16,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_giftcard_header_title_font_weight',
                    'key'     => 'giftcard_header_title_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],
                // Text alignment
                [
                    'name'    => 'wallregi_giftcard_header_title_text_align',
                    'key'     => 'giftcard_header_title_text_align',
                    'label'   => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_giftcard_header_title_text_transform',
                    'key'     => 'giftcard_header_title_text_transform',
                    'label'   => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'capitalize',
                ],
            ]
        ],

        // Single Giftcard Layout Header Border & BG Color Styling Fields
        [
            'name'        => 'wallregi_giftcard_header_border_group',
            'key'         => 'giftcard_header_border_group',
            'sec_name'    => __( 'Gift card (page & PDF): accordion tabs', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_header_styles',
            'label'       => __( 'Accordion tab (inactive): border & background', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/v5u76NwKmxg',
            'fields'      => [

                // Border Width
                [
                    'name'    => 'wallregi_giftcard_header_border_width',
                    'key'     => 'giftcard_header_border_width',
                    'label'   => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 1,
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_giftcard_header_border_styles',
                    'key'     => 'giftcard_header_border_styles',
                    'label'   => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_giftcard_header_border_color',
                    'key'     => 'giftcard_header_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#c5c5c5',
                ],

                // BG Color
                [
                    'name'    => 'wallregi_giftcard_header_bg_color',
                    'key'     => 'giftcard_header_bg_color',
                    'label'   => __('BG Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#f3f3f3',
                ],

                // Border Position
                [
                    'name'    => 'wallregi_giftcard_header_border_position',
                    'key'     => 'giftcard_header_border_position',
                    'label'   => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bottom',
                ],
            ],
        ],

        // Single Giftcard Layout Header Box Model Styling Fields
        [
            'name'        => 'wallregi_giftcard_header_box_model_group',
            'key'         => 'giftcard_header_box_model_group',
            'sec_name'    => __( 'Gift card (page & PDF): accordion tabs', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_header_styles',
            'label'       => __( 'Accordion tab (inactive): padding & corner radius', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/xujDebnIAgM',
            'fields'      => [
                // Padding Width
                [
                    'name'    => 'wallregi_giftcard_header_padding_width',
                    'key'     => 'giftcard_header_padding_width',
                    'label'   => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 8,
                ],

                // Padding Position
                [
                    'name'    => 'wallregi_giftcard_header_padding_position',
                    'key'     => 'giftcard_header_padding_position',
                    'label'   => __('Padding position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

                // Border Radius Width
                [
                    'name'    => 'wallregi_giftcard_header_radius_width',
                    'key'     => 'giftcard_header_radius_width',
                    'label'   => __('Border radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Border Radius Position Fields
                [
                    'name'    => 'wallregi_giftcard_header_radius_position',
                    'key'     => 'giftcard_header_radius_position',
                    'label'   => __('Radius position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'          => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left'     => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right'    => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left'  => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'          => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'       => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'         => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'        => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'         => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
                
            ],
        ],

        // Single Giftcard Layout Default Header Pseudo Styling Fields
        [
            'name'        => 'wallregi_giftcard_header_pseudo_styles_group',
            'key'         => 'giftcard_header_pseudo_styles_group',
            'sec_name'    => __( 'Gift card (page & PDF): accordion tabs', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_header_styles',
            'label'       => __( 'Accordion tab (inactive): hover styles', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Text, background, and border when the shopper hovers an inactive accordion tab.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/va3xen4TQ4k',
            'fields'      => [

                // Text Color 
                [
                    'name'    => 'wallregi_giftcard_header_pseudo_text_color',
                    'key'     => 'giftcard_header_pseudo_text_color',
                    'label'   => __('Text Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7e7c7c',
                ],

                // BG Color 
                [
                    'name'    => 'wallregi_giftcard_header_pseudo_bg_color',
                    'key'     => 'giftcard_header_pseudo_bg_color',
                    'label'   => __('BG Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#f4f8fb',
                ],
                
                // Border Color 
                [
                    'name'    => 'wallregi_giftcard_header_pseudo_border_color',
                    'key'     => 'giftcard_header_pseudo_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#be88eb',
                ],
            ]
        ],

        // Single Giftcard Layout Active Header Title Text Styling Fields
        [
            'name'        => 'wallregi_giftcard_active_header_title_styles_group',
            'key'         => 'giftcard_active_header_title_styles_group',
            'sec_name'    => __( 'Gift card (page & PDF): accordion tabs', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_header_styles',
            'label'       => __( 'Accordion tab (open section): title appearance', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/E52fKNQ5Y48',
            'fields'      => [
                // Text color
                [
                    'name'    => 'wallregi_giftcard_active_header_title_text_color',
                    'key'     => 'giftcard_active_header_title_text_color',
                    'label'   => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#ffffff',
                ],
                // Font size
                [
                    'name'    => 'wallregi_giftcard_active_header_title_font_size',
                    'key'     => 'giftcard_active_header_title_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 18,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_giftcard_active_header_title_font_weight',
                    'key'     => 'giftcard_active_header_title_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bold',
                ],
                // Text alignment
                [
                    'name'    => 'wallregi_giftcard_active_header_title_text_align',
                    'key'     => 'giftcard_active_header_title_text_align',
                    'label'   => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_giftcard_active_header_title_text_transform',
                    'key'     => 'giftcard_active_header_title_text_transform',
                    'label'   => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'capitalize',
                ],
            ]
        ],

        // Single Giftcard Layout Active Header Border & BG Color Styling Fields
        [
            'name'        => 'wallregi_giftcard_active_header_border_group',
            'key'         => 'giftcard_active_header_border_group',
            'sec_name'    => __( 'Gift card (page & PDF): accordion tabs', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_header_styles',
            'label'       => __( 'Accordion tab (open section): border & background', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/S4BfWcvgB0A',
            'fields'      => [

                // Border Width
                [
                    'name'    => 'wallregi_giftcard_active_header_border_width',
                    'key'     => 'giftcard_active_header_border_width',
                    'label'   => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 1,
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_giftcard_active_header_border_styles',
                    'key'     => 'giftcard_active_header_border_styles',
                    'label'   => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_giftcard_active_header_border_color',
                    'key'     => 'giftcard_active_header_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],

                // BG Color
                [
                    'name'    => 'wallregi_giftcard_active_header_bg_color',
                    'key'     => 'giftcard_active_header_bg_color',
                    'label'   => __('BG Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],

                // Border Position
                [
                    'name'    => 'wallregi_giftcard_active_header_border_position',
                    'key'     => 'giftcard_active_header_border_position',
                    'label'   => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'top',
                ],
            ],
        ],

        // Single Giftcard Layout Active Header Box Model Styling Fields
        [
            'name'        => 'wallregi_giftcard_active_header_box_model_group',
            'key'         => 'giftcard_active_header_box_model_group',
            'sec_name'    => __( 'Gift card (page & PDF): accordion tabs', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_header_styles',
            'label'       => __( 'Accordion tab (open section): padding & corner radius', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/tj1LCHf4JDU',
            'fields'      => [
                // Padding Width
                [
                    'name'    => 'wallregi_giftcard_active_header_padding_width',
                    'key'     => 'giftcard_active_header_padding_width',
                    'label'   => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 8,
                ],

                // Padding Position
                [
                    'name'    => 'wallregi_giftcard_active_header_padding_position',
                    'key'     => 'giftcard_active_header_padding_position',
                    'label'   => __('Padding position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

                // Border Radius
                [
                    'name'    => 'wallregi_giftcard_active_header_radius_width',
                    'key'     => 'giftcard_active_header_radius_width',
                    'label'   => __('Border radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Border Radius Position Fields
                [
                    'name'    => 'wallregi_giftcard_active_header_radius_position',
                    'key'     => 'giftcard_active_header_radius_position',
                    'label'   => __('Radius position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'          => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left'     => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right'    => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left'  => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'          => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'       => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'         => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'        => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'         => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
                
            ],
        ],

        // Single Giftcard Layout Active Header Pseudo Styling Fields
        [
            'name'        => 'wallregi_giftcard_active_header_pseudo_styles_group',
            'key'         => 'giftcard_active_header_pseudo_styles_group',
            'sec_name'    => __( 'Gift card (page & PDF): accordion tabs', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_header_styles',
            'label'       => __( 'Accordion tab (open section): hover styles', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Text, background, and border when hovering the open accordion tab.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/wfh7ZQ7cnKQ',
            'fields'      => [

                // Text Color 
                [
                    'name'    => 'wallregi_giftcard_active_header_pseudo_text_color',
                    'key'     => 'giftcard_active_header_pseudo_text_color',
                    'label'   => __('Text Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#f4f8fb',
                ],

                // BG Color 
                [
                    'name'    => 'wallregi_giftcard_active_header_pseudo_bg_color',
                    'key'     => 'giftcard_active_header_pseudo_bg_color',
                    'label'   => __('BG Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#be88eb',
                ],
                
                // Border Color 
                [
                    'name'    => 'wallregi_giftcard_active_header_pseudo_border_color',
                    'key'     => 'giftcard_active_header_pseudo_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#f4f8fb',
                ],
            ]
        ],

        // Single Giftcard Layout Contents Body Fields
        [
            'name'        => 'wallregi_giftcard_body_fields_group',
            'key'         => 'giftcard_body_fields_group',
            'sec_name'    => __( 'Gift card (page & PDF): card preview area', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_contents_body_styles',
            'label'       => __( 'Main card frame: spacing, border & corners', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Outer box around the illustrated gift card (shown on the product page and in the PDF preview).', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/qcSCH59oU6Y',
            'fields'      => [

                // Border Width
                [
                    'name'    => 'wallregi_giftcard_body_border_width',
                    'key'     => 'giftcard_body_border_width',
                    'label'   => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 1,
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_giftcard_body_border_styles',
                    'key'     => 'giftcard_body_border_styles',
                    'label'   => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_giftcard_body_border_color',
                    'key'     => 'giftcard_body_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],

                // Border Position
                [
                    'name'    => 'wallregi_giftcard_body_border_position',
                    'key'     => 'giftcard_body_border_position',
                    'label'   => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

                // Border Radius
                [
                    'name'    => 'wallregi_giftcard_body_radius_width',
                    'key'     => 'giftcard_body_radius_width',
                    'label'   => __('Border radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 5,
                ],

                // Border Radius Position Fields
                [
                    'name'    => 'wallregi_giftcard_body_radius_position',
                    'key'     => 'giftcard_body_radius_position',
                    'label'   => __('Radius position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'          => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left'     => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right'    => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left'  => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'          => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'       => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'         => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'        => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'         => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bottom',
                ],

                // Padding Width
                [
                    'name'    => 'wallregi_giftcard_body_padding_width',
                    'key'     => 'giftcard_body_padding_width',
                    'label'   => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 15,
                ],

                // Padding Position
                [
                    'name'    => 'wallregi_giftcard_body_padding_position',
                    'key'     => 'giftcard_body_padding_position',
                    'label'   => __('Padding position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

            ],
        ],


        /*====================================================
        * Single Giftcard Layout Contents Body Right Side Contents Fields Start
        *========================================================================= */

        //  Giftcard Right Side Summary Contents Paragraph Fields
        [
            'name'        => 'wallregi_giftcard_right_side_contents_group',
            'key'         => 'giftcard_right_side_contents_group',
            'sec_name'    => __( 'Gift card (page & PDF): card preview area', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_contents_body_styles',
            'label'       => __( 'Details column: summary text & code block', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __('Set text color, font size, alignment, and spacing for the right-side content of the gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/nlaiRNmcgT0',
            'fields'      => [
                // Text color
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_text_color',
                    'key'     => 'giftcard_right_side_contents_text_color',
                    'label'   => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#333333',
                ],
                // Font size
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_font_size',
                    'key'     => 'giftcard_right_side_contents_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 14,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_font_weight',
                    'key'     => 'giftcard_right_side_contents_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],
                // Text alignment
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_text_align',
                    'key'     => 'giftcard_right_side_contents_text_align',
                    'label'   => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'justify',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_text_transform',
                    'key'     => 'giftcard_right_side_contents_text_transform',
                    'label'   => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Border Width
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_border_width',
                    'key'     => 'giftcard_right_side_contents_border_width',
                    'label'   => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_border_styles',
                    'key'     => 'giftcard_right_side_contents_border_styles',
                    'label'   => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_border_color',
                    'key'     => 'giftcard_right_side_contents_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],

                // Border Position
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_border_position',
                    'key'     => 'giftcard_right_side_contents_border_position',
                    'label'   => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Border Radius
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_radius_width',
                    'key'     => 'giftcard_right_side_contents_radius_width',
                    'label'   => __('Radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Border Radius Position Fields
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_radius_position',
                    'key'     => 'giftcard_right_side_contents_radius_position',
                    'label'   => __('Radius Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'          => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left'     => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right'    => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left'  => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'          => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'       => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'         => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'        => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'         => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Padding Width
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_padding_width',
                    'key'     => 'giftcard_right_side_contents_padding_width',
                    'label'   => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Padding Position
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_padding_position',
                    'key'     => 'giftcard_right_side_contents_padding_position',
                    'label'   => __('Padding Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Margin Width
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_margin_width',
                    'key'     => 'giftcard_right_side_contents_margin_width',
                    'label'   => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 10,
                ],

                // Margin Position
                [
                    'name'    => 'wallregi_giftcard_right_side_contents_margin_position',
                    'key'     => 'giftcard_right_side_contents_margin_position',
                    'label'   => __('Margin Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bottom',
                ],

            ]
        ],

        //  Giftcard Right Side Custom Price Box Fields
        [
            'name'        => 'wallregi_giftcard_custom_price_box_group',
            'key'         => 'giftcard_custom_price_box_group',
            'sec_name'    => __( 'Gift card (page & PDF): card preview area', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_contents_body_styles',
            'label'       => __( 'Custom amount box: border & spacing', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __('Customize the border property of the gift card content area.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/7uV1ZP5fhvQ',
            'fields'      => [

                // Border Width
                [
                    'name'    => 'wallregi_giftcard_custom_price_box_border_width',
                    'key'     => 'giftcard_custom_price_box_border_width',
                    'label'   => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_giftcard_custom_price_box_border_styles',
                    'key'     => 'giftcard_custom_price_box_border_styles',
                    'label'   => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_giftcard_custom_price_box_border_color',
                    'key'     => 'giftcard_custom_price_box_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],

                // Border Position
                [
                    'name'    => 'wallregi_giftcard_custom_price_box_border_position',
                    'key'     => 'giftcard_custom_price_box_border_position',
                    'label'   => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Border Radius Width
                [
                    'name'    => 'wallregi_giftcard_custom_price_box_radius_width',
                    'key'     => 'giftcard_custom_price_box_radius_width',
                    'label'   => __('Border Radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Border Radius Position 
                [
                    'name'    => 'wallregi_giftcard_custom_price_box_radius_position',
                    'key'     => 'giftcard_custom_price_box_radius_position',
                    'label'   => __('Radius Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'          => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left'     => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right'    => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left'  => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'          => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'       => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'         => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'        => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'         => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Padding Width
                [
                    'name'    => 'wallregi_giftcard_custom_price_box_padding_width',
                    'key'     => 'giftcard_custom_price_box_padding_width',
                    'label'   => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Padding Position
                [
                    'name'    => 'wallregi_giftcard_custom_price_box_padding_position',
                    'key'     => 'giftcard_custom_price_box_padding_position',
                    'label'   => __('Padding Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Margin Width
                [
                    'name'    => 'wallregi_giftcard_custom_price_box_margin_width',
                    'key'     => 'giftcard_custom_price_box_margin_width',
                    'label'   => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 10,
                ],

                // Margin Position
                [
                    'name'    => 'wallregi_giftcard_custom_price_box_margin_position',
                    'key'     => 'giftcard_custom_price_box_margin_position',
                    'label'   => __('Margin Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'top_bottom',
                ],
                
            ],
        ],


        //  Giftcard Right Side Column Custom Price Heading Fields
        [
            'name'        => 'wallregi_giftcard_custom_price_heading_group',
            'key'         => 'giftcard_custom_price_heading_group',
            'sec_name'    => __( 'Gift card (page & PDF): card preview area', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_contents_body_styles',
            'label'       => __( '“Choose amount” heading style', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __('Set text color, font size, alignment, and spacing for the right-side content of the gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/DX01-_rPYIk',
            'fields'      => [
                // Text color
                [
                    'name'    => 'wallregi_giftcard_custom_price_heading_text_color',
                    'key'     => 'giftcard_custom_price_heading_text_color',
                    'label'   => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#333333',
                ],
                // Font size
                [
                    'name'    => 'wallregi_giftcard_custom_price_heading_font_size',
                    'key'     => 'giftcard_custom_price_heading_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 16,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_giftcard_custom_price_heading_font_weight',
                    'key'     => 'giftcard_custom_price_heading_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],
                // Text alignment
                [
                    'name'    => 'wallregi_giftcard_custom_price_heading_text_align',
                    'key'     => 'giftcard_custom_price_heading_text_align',
                    'label'   => __('Text Alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_giftcard_custom_price_heading_text_transform',
                    'key'     => 'giftcard_custom_price_heading_text_transform',
                    'label'   => __('Text Transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Margin Width
                [
                    'name'    => 'wallregi_giftcard_custom_price_heading_margin_width',
                    'key'     => 'giftcard_custom_price_heading_margin_width',
                    'label'   => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 10,
                ],

                // Margin Position
                [
                    'name'    => 'wallregi_giftcard_custom_price_heading_margin_position',
                    'key'     => 'giftcard_custom_price_heading_margin_position',
                    'label'   => __('Margin Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bottom',
                ],
            ]
        ],

        //  Giftcard Right Side Images Gallery Fields
        [
            'name'        => 'wallregi_giftcard_img_gallery_box_group',
            'key'         => 'giftcard_img_gallery_box_group',
            'sec_name'    => __( 'Gift card (page & PDF): card preview area', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_contents_body_styles',
            'label'       => __( 'Design gallery container: border & spacing', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __('Customize the border property of the gift card content area.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/JuWX1k29Cxs',
            'fields'      => [

                // Border Width
                [
                    'name'    => 'wallregi_giftcard_img_gallery_box_border_width',
                    'key'     => 'giftcard_img_gallery_box_border_width',
                    'label'   => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_giftcard_img_gallery_box_border_styles',
                    'key'     => 'giftcard_img_gallery_box_border_styles',
                    'label'   => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_giftcard_img_gallery_box_border_color',
                    'key'     => 'giftcard_img_gallery_box_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],

                // Border Position
                [
                    'name'    => 'wallregi_giftcard_img_gallery_box_border_position',
                    'key'     => 'giftcard_img_gallery_box_border_position',
                    'label'   => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Border Radius Width
                [
                    'name'    => 'wallregi_giftcard_img_gallery_box_radius_width',
                    'key'     => 'giftcard_img_gallery_box_radius_width',
                    'label'   => __('Border Radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Border Radius Position 
                [
                    'name'    => 'wallregi_giftcard_img_gallery_box_radius_position',
                    'key'     => 'giftcard_img_gallery_box_radius_position',
                    'label'   => __('Radius Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'          => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left'     => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right'    => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left'  => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'          => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'       => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'         => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'        => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'         => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Padding Width
                [
                    'name'    => 'wallregi_giftcard_img_gallery_box_padding_width',
                    'key'     => 'giftcard_img_gallery_box_padding_width',
                    'label'   => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Padding Position
                [
                    'name'    => 'wallregi_giftcard_img_gallery_box_padding_position',
                    'key'     => 'giftcard_img_gallery_box_padding_position',
                    'label'   => __('Padding Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Margin Width
                [
                    'name'    => 'wallregi_giftcard_img_gallery_box_margin_width',
                    'key'     => 'giftcard_img_gallery_box_margin_width',
                    'label'   => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 10,
                ],

                // Margin Position
                [
                    'name'    => 'wallregi_giftcard_img_gallery_box_margin_position',
                    'key'     => 'giftcard_img_gallery_box_margin_position',
                    'label'   => __('Margin Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'top_bottom',
                ],
                
            ],
        ],


        //  Giftcard Right Side Column Images Gallery Heading Fields
        [
            'name'        => 'wallregi_giftcard_img_gallery_heading_group',
            'key'         => 'giftcard_img_gallery_heading_group',
            'sec_name'    => __( 'Gift card (page & PDF): card preview area', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_contents_body_styles',
            'label'       => __( 'Design gallery heading typography', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __('Set text color, font size, alignment, and spacing for the right-side content of the gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/9qCV_3m3wQ8',
            'fields'      => [
                // Text color
                [
                    'name'    => 'wallregi_giftcard_img_gallery_heading_text_color',
                    'key'     => 'giftcard_img_gallery_heading_text_color',
                    'label'   => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#333333',
                ],
                // Font size
                [
                    'name'    => 'wallregi_giftcard_img_gallery_heading_font_size',
                    'key'     => 'giftcard_img_gallery_heading_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 16,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_giftcard_img_gallery_heading_font_weight',
                    'key'     => 'giftcard_img_gallery_heading_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],
                // Text alignment
                [
                    'name'    => 'wallregi_giftcard_img_gallery_heading_text_align',
                    'key'     => 'giftcard_img_gallery_heading_text_align',
                    'label'   => __('Text Alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_giftcard_img_gallery_heading_text_transform',
                    'key'     => 'giftcard_img_gallery_heading_text_transform',
                    'label'   => __('Text Transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Margin Width
                [
                    'name'    => 'wallregi_giftcard_img_gallery_heading_margin_width',
                    'key'     => 'giftcard_img_gallery_heading_margin_width',
                    'label'   => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 10,
                ],

                // Margin Position
                [
                    'name'    => 'wallregi_giftcard_img_gallery_heading_margin_position',
                    'key'     => 'giftcard_img_gallery_heading_margin_position',
                    'label'   => __('Margin Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bottom',
                ],
            ]
        ],

        //  Giftcard Right Side Images Gallery Item Fields
        [
            'name'        => 'wallregi_giftcard_img_gallery_item_group',
            'key'         => 'giftcard_img_gallery_item_group',
            'sec_name'    => __( 'Gift card (page & PDF): card preview area', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_contents_body_styles',
            'label'       => __( 'Individual design thumbnail tiles', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/EHB4H6XXmXs',
            'fields'      => [

                // Border Width
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_border_width',
                    'key'     => 'giftcard_img_gallery_item_border_width',
                    'label'   => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 1,
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_border_styles',
                    'key'     => 'giftcard_img_gallery_item_border_styles',
                    'label'   => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_border_color',
                    'key'     => 'giftcard_img_gallery_item_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],

                // Border Position
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_border_position',
                    'key'     => 'giftcard_img_gallery_item_border_position',
                    'label'   => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

                // Border Radius Width
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_radius_width',
                    'key'     => 'giftcard_img_gallery_item_radius_width',
                    'label'   => __('Border Radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 2,
                ],

                // Border Radius Position 
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_radius_position',
                    'key'     => 'giftcard_img_gallery_item_radius_position',
                    'label'   => __('Radius Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'          => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left'     => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right'    => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left'  => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'          => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'       => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'         => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'        => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'         => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],
                
            ],
        ],

        // Giftcard Gallery Images Box Shadow 
        [
            'name'        => 'wallregi_giftcard_img_gallery_item_pseudo_group',
            'key'         => 'giftcard_img_gallery_item_pseudo_group',
            'sec_name'    => __( 'Gift card (page & PDF): card preview area', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_contents_body_styles',
            'label'       => __( 'Design thumbnails: hover & selected states', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/nfo0gGr7FN4',
            'fields'      => [

                // Box Shadow Type
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_pseudo_shadow_type',
                    'key'     => 'giftcard_img_gallery_item_pseudo_shadow_type',
                    'label'   => __('Shadow Type', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'  => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'outer' => __('Outer', 'wallet-ready-gift-cards-for-woocommerce'),
                        'inset' => __('Inner (Inset)', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'outer',
                ],

                // Shadow Horizontal
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_pseudo_shadow_horizontal',
                    'key'     => 'giftcard_img_gallery_item_pseudo_shadow_horizontal',
                    'label'   => __('Horizontal (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Shadow Vertical
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_pseudo_shadow_vertical',
                    'key'     => 'giftcard_img_gallery_item_pseudo_shadow_vertical',
                    'label'   => __('Vertical (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 4,
                ],

                // Shadow Blur Radius
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_pseudo_shadow_blur',
                    'key'     => 'giftcard_img_gallery_item_pseudo_shadow_blur',
                    'label'   => __('Blur Radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 12,
                ],

                // Shadow Spread
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_pseudo_shadow_spread',
                    'key'     => 'giftcard_img_gallery_item_pseudo_shadow_spread',
                    'label'   => __('Spread Radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 0,
                ],

                // Shadow Color
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_pseudo_shadow_color',
                    'key'     => 'giftcard_img_gallery_item_pseudo_shadow_color',
                    'label'   => __('Shadow Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#c0c0c0',
                ],


                // Border Styles
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_pseudo_border_styles',
                    'key'     => 'giftcard_img_gallery_item_pseudo_border_styles',
                    'label'   => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_giftcard_img_gallery_item_pseudo_border_color',
                    'key'     => 'giftcard_img_gallery_item_pseudo_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#be88eb',
                ],



            ]
        ],



         /*====================================================
        * Single Giftcard Layout Contents Body Right Side Contents Fields End
        *======================================================================= */

        /*===========================
        * Apply Giftcard Accordion Fields Start
        *========================================= */

        [
            'name'        => 'wallregi_apply_giftcard_container_group',
            'key'         => 'apply_giftcard_container_group',
            'sec_name'    => __( 'Cart & checkout: redeem / apply codes', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'apply_giftcard_accordion_container_content_styles',
            'label'       => __( 'Redeem panel: outer container', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Box that wraps the cart/checkout “apply gift card” area.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/y4wHrGahHEU',
            'fields'      => [

                // Border Width
                [
                    'name'    => 'wallregi_apply_giftcard_container_border_width',
                    'key'     => 'apply_giftcard_container_border_width',
                    'label'   => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 2,
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_apply_giftcard_container_border_styles',
                    'key'     => 'apply_giftcard_container_border_styles',
                    'label'   => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_apply_giftcard_container_border_color',
                    'key'     => 'apply_giftcard_container_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],

                // Border Position
                [
                    'name'    => 'wallregi_apply_giftcard_container_border_position',
                    'key'     => 'apply_giftcard_container_border_position',
                    'label'   => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

                // Border Radius Width
                [
                    'name'    => 'wallregi_apply_giftcard_container_radius_width',
                    'key'     => 'apply_giftcard_container_radius_width',
                    'label'   => __('Border Radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 5,
                ],

                // Border Radius Position 
                [
                    'name'    => 'wallregi_apply_giftcard_container_radius_position',
                    'key'     => 'apply_giftcard_container_radius_position',
                    'label'   => __('Radius Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'          => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left'     => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right'    => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left'  => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'          => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'       => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'         => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'        => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'         => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],
                
            ],
        ],

        [
            'name'        => 'wallregi_apply_giftcard_container_header_group',
            'key'         => 'apply_giftcard_container_header_group',
            'sec_name'    => __( 'Cart & checkout: redeem / apply codes', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'apply_giftcard_accordion_container_content_styles',
            'label'       => __( 'Redeem panel: collapsed header bar', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/TDVsAvtNu7U',
            'fields'      => [

                // Text color
                [
                    'name'    => 'wallregi_apply_giftcard_container_header_text_color',
                    'key'     => 'apply_giftcard_container_header_text_color',
                    'label'   => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#ffffff',
                ],

                // BG color
                [
                    'name'    => 'wallregi_apply_giftcard_container_header_bg_color',
                    'key'     => 'apply_giftcard_container_header_bg_color',
                    'label'   => __('BG color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],
                // Font size
                [
                    'name'    => 'wallregi_apply_giftcard_container_header_font_size',
                    'key'     => 'apply_giftcard_container_header_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 16,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_apply_giftcard_container_header_font_weight',
                    'key'     => 'apply_giftcard_container_header_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],

                // Text alignment
                [
                    'name'    => 'wallregi_apply_giftcard_container_header_text_align',
                    'key'     => 'apply_giftcard_container_header_text_align',
                    'label'   => __('Text Alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_apply_giftcard_container_header_text_transform',
                    'key'     => 'apply_giftcard_container_header_text_transform',
                    'label'   => __('Text Transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Padding Width
                [
                    'name'    => 'wallregi_apply_giftcard_container_header_padding_width',
                    'key'     => 'apply_giftcard_container_header_padding_width',
                    'label'   => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 15,
                ],

                // Padding Position
                [
                    'name'    => 'wallregi_apply_giftcard_container_header_padding_position',
                    'key'     => 'apply_giftcard_container_header_padding_position',
                    'label'   => __('Padding Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

                
            ],
        ],

        [
            'name'        => 'wallregi_apply_giftcard_coupon_code_box_group',
            'key'         => 'apply_giftcard_coupon_code_box_group',
            'sec_name'    => __( 'Cart & checkout: redeem / apply codes', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'apply_giftcard_accordion_container_content_styles',
            'label'       => __( 'Code field area: inner padding', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/5VrM5QHrPR4',
            'fields'      => [

                // Padding Width
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_box_padding_width',
                    'key'     => 'apply_giftcard_coupon_code_box_padding_width',
                    'label'   => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 10,
                ],

                // Padding Position
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_box_padding_position',
                    'key'     => 'apply_giftcard_coupon_code_box_padding_position',
                    'label'   => __('Padding Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ]
                
            ],
        ],

        [
            'name'        => 'wallregi_apply_giftcard_coupon_code_group',
            'key'         => 'apply_giftcard_coupon_code_group',
            'sec_name'    => __( 'Cart & checkout: redeem / apply codes', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'apply_giftcard_accordion_container_content_styles',
            'label'       => __( 'Applied codes list: each line', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/quD729WNh9s',
            'fields'      => [

                // Text color
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_text_color',
                    'key'     => 'apply_giftcard_coupon_code_text_color',
                    'label'   => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#333333',
                ],

                // Font size
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_font_size',
                    'key'     => 'apply_giftcard_coupon_code_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 14,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_font_weight',
                    'key'     => 'apply_giftcard_coupon_code_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],

                // Text alignment
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_text_align',
                    'key'     => 'apply_giftcard_coupon_code_text_align',
                    'label'   => __('Text Alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],


                // Padding Width
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_padding_width',
                    'key'     => 'apply_giftcard_coupon_code_padding_width',
                    'label'   => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 10,
                ],

                // Padding Position
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_padding_position',
                    'key'     => 'apply_giftcard_coupon_code_padding_position',
                    'label'   => __('Padding Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bottom',
                ],

                // Margin Width
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_margin_width',
                    'key'     => 'apply_giftcard_coupon_code_margin_width',
                    'label'   => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 5,
                ],

                // Margin Position
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_margin_position',
                    'key'     => 'apply_giftcard_coupon_code_margin_position',
                    'label'   => __('Margin Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'top_bottom',
                ],

                // Border Width
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_border_width',
                    'key'     => 'apply_giftcard_coupon_code_border_width',
                    'label'   => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 1,
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_border_styles',
                    'key'     => 'apply_giftcard_coupon_code_border_styles',
                    'label'   => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_border_color',
                    'key'     => 'apply_giftcard_coupon_code_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],

                // Border Position
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_border_position',
                    'key'     => 'apply_giftcard_coupon_code_border_position',
                    'label'   => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

                // Border Radius Width
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_radius_width',
                    'key'     => 'apply_giftcard_coupon_code_radius_width',
                    'label'   => __('Border Radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 5,
                ],

                // Border Radius Position 
                [
                    'name'    => 'wallregi_apply_giftcard_coupon_code_radius_position',
                    'key'     => 'apply_giftcard_coupon_code_radius_position',
                    'label'   => __('Radius Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'          => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left'     => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right'    => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left'  => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'          => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'       => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'         => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'        => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'         => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

            ],
        ],



        /*===========================
        * Apply Giftcard Accordion Fields End
        *========================================= */



    ],

    'select_fields' => [
        [
            'name'        => 'wallregi_apply_giftcard_redirect_to',
            'key'         => 'apply_giftcard_redirect_to',
            'sec_name'    => __( 'Essential options', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Page for “apply gift card” links and QR codes', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Visitors who open a URL with ?wallregi_apply_giftcard= (for example from a PDF QR code) are sent here. When customers must choose how much to redeem, they are redirected to the same page after the link is processed.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'select',
            'default'     => 'checkout',
            'options'     => [
            'checkout'    => __( 'Checkout', 'wallet-ready-gift-cards-for-woocommerce' ),
            'cart'        => __( 'Cart', 'wallet-ready-gift-cards-for-woocommerce' ),
            ],
        ],
        [
            'name'        => 'wallregi_pdf_scannable_code_type',
            'key'         => 'pdf_scannable_code_type',
            'sec_name'    => __( 'BarCode Settings', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Barcode, QR, or PDF417 on PDF', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Optional code on the PDF. Barcode and PDF417 encode the card number; QR opens checkout to apply the card.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'select',
            'default'     => 'none',
            'options'     => [
            'none'        => __( 'None', 'wallet-ready-gift-cards-for-woocommerce' ),
            'barcode'     => __( 'Barcode (gift card number)', 'wallet-ready-gift-cards-for-woocommerce' ),
            'pdf417'      => __( 'PDF417 (gift card number)', 'wallet-ready-gift-cards-for-woocommerce' ),
            'qr'          => __( 'QR code (apply at checkout URL)', 'wallet-ready-gift-cards-for-woocommerce' ),
            'barcode_qr'  => __( 'Barcode and QR code', 'wallet-ready-gift-cards-for-woocommerce' ),
            ],
        ],
        [
            'name'        => 'wallregi_pdf_barcode_symbology',
            'key'         => 'pdf_barcode_symbology',
            'sec_name'    => __( 'BarCode Settings', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Barcode format', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Used when linear barcode is enabled; ignored for QR, PDF417, or none.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'select',
            'default'     => 'C128',
            'options'     => [
                'C128'    => 'CODE 128',
                'C128B'   => 'CODE 128 B',
                'C39'     => 'CODE 39',
                'C39+'    => 'CODE 39 + checksum',
                'C93'     => 'CODE 93',
                'I25'     => __( 'Interleaved 2 of 5', 'wallet-ready-gift-cards-for-woocommerce' ),
                'CODABAR' => 'Codabar',
            ],
        ],
        [
            'name'        => 'wallregi_pdf_show_placeholder_scannable_product',
            'key'         => 'pdf_show_placeholder_scannable_product',
            'sec_name'    => __( 'BarCode Settings', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'basic_settings',
            'label'       => __( 'Show sample scannable code on product page', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'When a barcode, PDF417, or QR on PDF is enabled, show a centered sample on the gift card product preview (illustrative only, not a real card).', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'select',
            'default'     => 'no',
            'options'     => [
                'no'  => __( 'No', 'wallet-ready-gift-cards-for-woocommerce' ),
                'yes' => __( 'Yes', 'wallet-ready-gift-cards-for-woocommerce' ),
            ],
        ],

    ],

];
