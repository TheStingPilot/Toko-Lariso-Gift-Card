<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

return [
    'input_fields' => [
        // Giftcard PDF Full Template Layout Container Style Fields
        [
            'name' => 'wallregi_pdf_template_container_group',
            'key' => 'pdf_template_container_group',
            'sec_name' => __('PDF: outer frame & header image', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key' => 'pdf_template_header_styles',
            'label' => __('Page margin & outer border (full PDF)', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Customize the outer layout of the generated gift card PDF. You can control the border width, style, color, position, and radius, as well as the container margin and its placement. These settings help visually frame the entire PDF gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type' => 'group',
            'help_link' => 'https://youtu.be/aH3Ji224tMM',
            'fields' => [
                // Border width
                [
                    'name' => 'wallregi_pdf_template_container_border_width',
                    'key' => 'pdf_template_container_border_width',
                    'label' => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 4,
                ],
                // Border styles
                [
                    'name' => 'wallregi_pdf_template_container_border_styles',
                    'key' => 'pdf_template_container_border_styles',
                    'label' => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'solid' => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed' => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted' => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double' => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove' => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge' => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],
                // Border width
                [
                    'name' => 'wallregi_pdf_template_container_border_color',
                    'key' => 'pdf_template_container_border_color',
                    'label' => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'color',
                    'default' => '#7f54b3',
                ],
                // Border position
                [
                    'name' => 'wallregi_pdf_template_container_border_position',
                    'key' => 'pdf_template_container_border_position',
                    'label' => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],
                // Border Radius
                [
                    'name' => 'wallregi_pdf_template_container_radius_width',
                    'key' => 'pdf_template_container_radius_width',
                    'label' => __('Border radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 7,
                ],
                // Border Radius Position Fields
                [
                    'name' => 'wallregi_pdf_template_container_radius_position',
                    'key' => 'pdf_template_container_radius_position',
                    'label' => __('Radius position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left' => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right' => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left' => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],
                // Margin Width
                [
                    'name' => 'wallregi_pdf_template_container_margin_width',
                    'key' => 'pdf_template_container_margin_width',
                    'label' => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 0,
                ],
                // Margin Position
                [
                    'name' => 'wallregi_pdf_template_container_margin_position',
                    'key' => 'pdf_template_container_margin_position',
                    'label' => __('Margin position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
            ]
        ],
        // Giftcard PDF Template Header Style Fields
        [
            'name' => 'wallregi_pdf_header_style_group',
            'key' => 'pdf_header_style_group',
            'sec_name' => __('PDF: outer frame & header image', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key' => 'pdf_template_header_styles',
            'label' => __('Top banner / artwork box', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Border, spacing, and margins around the hero image on the PDF.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type' => 'group',
            'help_link' => 'https://youtu.be/riflAknyHuY',
            'fields' => [
                // Border width
                [
                    'name' => 'wallregi_pdf_header_style_border_width',
                    'key' => 'pdf_header_style_border_width',
                    'label' => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 0,
                ],
                // Border styles
                [
                    'name' => 'wallregi_pdf_header_style_border_styles',
                    'key' => 'pdf_header_style_border_styles',
                    'label' => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'solid' => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed' => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted' => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double' => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove' => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge' => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
                // Border width
                [
                    'name' => 'wallregi_pdf_header_style_border_color',
                    'key' => 'pdf_header_style_border_color',
                    'label' => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'color',
                    'default' => '#cccccc',
                ],
                // Border position
                [
                    'name' => 'wallregi_pdf_header_style_border_position',
                    'key' => 'pdf_header_style_border_position',
                    'label' => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
                // Padding Width
                [
                    'name' => 'wallregi_pdf_header_style_padding_width',
                    'key' => 'pdf_header_style_padding_width',
                    'label' => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 0,
                ],
                // Padding Position
                [
                    'name' => 'wallregi_pdf_header_style_padding_position',
                    'key' => 'pdf_header_style_padding_position',
                    'label' => __('Padding position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
                // Margin Width
                [
                    'name' => 'wallregi_pdf_header_style_margin_width',
                    'key' => 'pdf_header_style_margin_width',
                    'label' => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 0,
                ],
                // Margin Position
                [
                    'name' => 'wallregi_pdf_header_style_margin_position',
                    'key' => 'pdf_header_style_margin_position',
                    'label' => __('Margin position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
            ]
        ],
        // Giftcard PDF Template Header Box Shadow
        [
            'name' => 'wallregi_pdf_header_box_shadow_group',
            'key' => 'pdf_header_box_shadow_group',
            'sec_name' => __('PDF: outer frame & header image', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key' => 'pdf_template_header_styles',
            'label' => __('PDF Template Header Box Shadow', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Drop shadow applied to the top image area (outer or inset).', 'wallet-ready-gift-cards-for-woocommerce'),
            'type' => 'group',
            'help_link' => 'https://youtu.be/DiSNANCpHa8',
            'fields' => [
                // Box Shadow Type
                [
                    'name' => 'wallregi_pdf_header_shadow_type',
                    'key' => 'pdf_header_shadow_type',
                    'label' => __('Shadow Type', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'outer' => __('Outer', 'wallet-ready-gift-cards-for-woocommerce'),
                        'inset' => __('Inner (Inset)', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
                // Shadow Horizontal
                [
                    'name' => 'wallregi_pdf_header_shadow_horizontal',
                    'key' => 'pdf_header_shadow_horizontal',
                    'label' => __('Horizontal (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 0,
                ],
                // Shadow Vertical
                [
                    'name' => 'wallregi_pdf_header_shadow_vertical',
                    'key' => 'pdf_header_shadow_vertical',
                    'label' => __('Vertical (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 4,
                ],
                // Shadow Blur Radius
                [
                    'name' => 'wallregi_pdf_header_shadow_blur',
                    'key' => 'pdf_header_shadow_blur',
                    'label' => __('Blur Radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 10,
                ],
                // Shadow Spread
                [
                    'name' => 'wallregi_pdf_header_shadow_spread',
                    'key' => 'pdf_header_shadow_spread',
                    'label' => __('Spread Radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 0,
                ],
                // Shadow Color
                [
                    'name' => 'wallregi_pdf_header_shadow_color',
                    'key' => 'pdf_header_shadow_color',
                    'label' => __('Shadow Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'color',
                    'default' => '#c0c0c0',
                ],
            ]
        ],
        // PDF Template Content Body Layout Style Fields
        [
            'name' => 'wallregi_pdf_content_style_group',
            'key' => 'pdf_content_style_group',
            'sec_name' => __('PDF: title, price & message', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key' => 'pdf_template_content_styles',
            'label' => __('Middle content block layout', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Style the inner content area of the PDF gift card, including its border, padding, and margin.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type' => 'group',
            'help_link' => 'https://youtu.be/FXemMx3BNx8',
            'fields' => [
                // Border width
                [
                    'name' => 'wallregi_pdf_content_style_border_width',
                    'key' => 'pdf_content_style_border_width',
                    'label' => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 1,
                ],
                // Border styles
                [
                    'name' => 'wallregi_pdf_content_style_border_styles',
                    'key' => 'pdf_content_style_border_styles',
                    'label' => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'solid' => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed' => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted' => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double' => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove' => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge' => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],
                // Border Color
                [
                    'name' => 'wallregi_pdf_content_style_border_color',
                    'key' => 'pdf_content_style_border_color',
                    'label' => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'color',
                    'default' => '#cccccc',
                ],
                // Border position
                [
                    'name' => 'wallregi_pdf_content_style_border_position',
                    'key' => 'pdf_content_style_border_position',
                    'label' => __('Border position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'top',
                ],
                // Padding Width
                [
                    'name' => 'wallregi_pdf_content_style_padding_width',
                    'key' => 'pdf_content_style_padding_width',
                    'label' => __('Padding width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 10,
                ],
                // Padding position
                [
                    'name' => 'wallregi_pdf_content_style_padding_position',
                    'key' => 'pdf_content_style_padding_position',
                    'label' => __('Padding position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],
                // Margin width
                [
                    'name' => 'wallregi_pdf_content_style_margin_width',
                    'key' => 'pdf_content_style_margin_width',
                    'label' => __('Margin width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 10,
                ],
                // Margin position
                [
                    'name' => 'wallregi_pdf_content_style_margin_position',
                    'key' => 'pdf_content_style_margin_position',
                    'label' => __('Margin position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bottom',
                ],
            ]
        ],
        // PDF Title Styles Fields
        [
            'name' => 'wallregi_pdf_title_text_style_group',
            'key' => 'pdf_title_text_style_group',
            'sec_name' => __('PDF: title, price & message', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key' => 'pdf_template_content_styles',
            'label' => __('Printed title typography', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Typography for the headline above the balance on the PDF.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type' => 'group',
            'help_link' => 'https://youtu.be/S5fNhC9mOjA',
            'fields' => [
                // Text color
                [
                    'name' => 'wallregi_pdf_title_text_style_text_color',
                    'key' => 'pdf_title_text_style_text_color',
                    'label' => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'color',
                    'default' => '#333333',
                ],
                // Font size
                [
                    'name' => 'wallregi_pdf_title_text_style_font_size',
                    'key' => 'pdf_title_text_style_font_size',
                    'label' => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 18,
                ],
                // Font weight
                [
                    'name' => 'wallregi_pdf_title_text_style_font_weight',
                    'key' => 'pdf_title_text_style_font_weight',
                    'label' => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold' => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bold',
                ],
                // Text alignment
                [
                    'name' => 'wallregi_pdf_title_text_style_text_align',
                    'key' => 'pdf_title_text_style_text_align',
                    'label' => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center' => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'center',
                ],
                // Text transform
                [
                    'name' => 'wallregi_pdf_title_text_style_text_transform',
                    'key' => 'pdf_title_text_style_text_transform',
                    'label' => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase' => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase' => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
                // // Padding width
                // [
                //     'name'    => 'wallregi_pdf_title_text_style_padding_width',
                //     'key'     => 'pdf_title_text_style_padding_width',
                //     'label'   => __('Padding width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                //     'type'    => 'number',
                //     'default' => 5,
                // ],
                // // Padding position
                // [
                //     'name'    => 'wallregi_pdf_title_text_style_padding_position',
                //     'key'     => 'pdf_title_text_style_padding_position',
                //     'label'   => __('Padding position', 'wallet-ready-gift-cards-for-woocommerce'),
                //     'type'    => 'select',
                //     'options' => [
                //         'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                //         'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                //         'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                //         'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                //         'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                //         'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                //         'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                //         'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                //     ],
                //     'default' => 'all',
                // ],
                // Margin width
                [
                    'name' => 'wallregi_pdf_title_text_style_margin_width',
                    'key' => 'pdf_title_text_style_margin_width',
                    'label' => __('Margin width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 10,
                ],
                // Margin position
                [
                    'name' => 'wallregi_pdf_title_text_style_margin_position',
                    'key' => 'pdf_title_text_style_margin_position',
                    'label' => __('Margin position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'top_bottom',
                ],
            ]
        ],
        // PDF Price Section Style Fields
        [
            'name' => 'wallregi_pdf_giftcard_price_style_group',
            'key' => 'pdf_giftcard_price_style_group',
            'sec_name' => __('PDF: title, price & message', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key' => 'pdf_template_content_styles',
            'label' => __('Gift amount / balance display', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Large price block styling on the PDF.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type' => 'group',
            'help_link' => 'https://youtu.be/YKY1Z692tLk',
            'fields' => [
                // Text color
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_text_color',
                    'key' => 'pdf_giftcard_price_style_text_color',
                    'label' => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'color',
                    'default' => '#333333',
                ],
                // Font size
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_font_size',
                    'key' => 'pdf_giftcard_price_style_font_size',
                    'label' => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 32,
                ],
                // Font weight
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_font_weight',
                    'key' => 'pdf_giftcard_price_style_font_weight',
                    'label' => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold' => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bold',
                ],
                // Text alignment
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_text_align',
                    'key' => 'pdf_giftcard_price_style_text_align',
                    'label' => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center' => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'center',
                ],
                // Border width
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_border_width',
                    'key' => 'pdf_giftcard_price_style_border_width',
                    'label' => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 3,
                ],
                // Border styles
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_border_styles',
                    'key' => 'pdf_giftcard_price_style_border_styles',
                    'label' => __('Border Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'solid' => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed' => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted' => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double' => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove' => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge' => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],
                // Border width
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_border_color',
                    'key' => 'pdf_giftcard_price_style_border_color',
                    'label' => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'color',
                    'default' => '#7f54b3',
                ],
                // Border position
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_border_position',
                    'key' => 'pdf_giftcard_price_style_border_position',
                    'label' => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'top_bottom',
                ],
                // Padding Width
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_padding_width',
                    'key' => 'pdf_giftcard_price_style_padding_width',
                    'label' => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 10,
                ],
                // Padding Position
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_padding_position',
                    'key' => 'pdf_giftcard_price_style_padding_position',
                    'label' => __('Padding position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'top_bottom',
                ],
                // Margin Width
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_margin_width',
                    'key' => 'pdf_giftcard_price_style_margin_width',
                    'label' => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 20,
                ],
                // Margin Position
                [
                    'name' => 'wallregi_pdf_giftcard_price_style_margin_position',
                    'key' => 'pdf_giftcard_price_style_margin_position',
                    'label' => __('Margin position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bottom',
                ],
            ]
        ],
        // PDF Preview Message Section Styling Fields
        [
            'name' => 'wallregi_pdf_preview_mgs_style_group',
            'key' => 'pdf_preview_mgs_style_group',
            'sec_name' => __('PDF: title, price & message', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key' => 'pdf_template_content_styles',
            'label' => __('Personal message preview', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Typography and frame for the greeting text on the PDF.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type' => 'group',
            'help_link' => 'https://youtu.be/gB0_FWRk4d0',
            'fields' => [
                // Text color
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_text_color',
                    'key' => 'pdf_preview_mgs_style_text_color',
                    'label' => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'color',
                    'default' => '#333333',
                ],
                // Font size
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_font_size',
                    'key' => 'pdf_preview_mgs_style_font_size',
                    'label' => __('Font size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 14,
                ],
                // Font weight
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_font_weight',
                    'key' => 'pdf_preview_mgs_style_font_weight',
                    'label' => __('Font weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold' => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],
                // Text align
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_text_align',
                    'key' => 'pdf_preview_mgs_style_text_align',
                    'label' => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center' => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'center',
                ],
                // Text transform
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_text_transform',
                    'key' => 'pdf_preview_mgs_style_text_transform',
                    'label' => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase' => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase' => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
                // Border Width
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_border_width',
                    'key' => 'pdf_preview_mgs_style_border_width',
                    'label' => __('Border width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 0,
                ],
                // Border Style
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_border_styles',
                    'key' => 'pdf_preview_mgs_style_border_styles',
                    'label' => __('Border styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'solid' => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed' => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted' => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double' => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove' => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge' => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],
                // Border Color
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_border_color',
                    'key' => 'pdf_preview_mgs_style_border_color',
                    'label' => __('Border color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'color',
                    'default' => '#cccccc',
                ],
                // Border Position
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_border_position',
                    'key' => 'pdf_preview_mgs_style_border_position',
                    'label' => __('Border position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
                // Padding Width
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_padding_width',
                    'key' => 'pdf_preview_mgs_style_padding_width',
                    'label' => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 0,
                ],
                // Padding Position
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_padding_position',
                    'key' => 'pdf_preview_mgs_style_padding_position',
                    'label' => __('Padding position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
                // Margin Width
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_margin_width',
                    'key' => 'pdf_preview_mgs_style_margin_width',
                    'label' => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 0,
                ],
                // Margin Position
                [
                    'name' => 'wallregi_pdf_preview_mgs_style_margin_position',
                    'key' => 'pdf_preview_mgs_style_margin_position',
                    'label' => __('Margin position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
            ]
        ],
        // PDF Footer Text Styling Fields
        [
            'name' => 'wallregi_pdf_footer_styles_group',
            'key' => 'pdf_footer_styles_group',
            'sec_name' => __('PDF: footer', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key' => 'pdf_template_footer_styles',
            'label' => __('PDF Footer Text Styling', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Customize the PDF footer text with typography and layout styles.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type' => 'group',
            'help_link' => 'https://youtu.be/UPjQACdqmo0',
            'fields' => [
                // Text color
                [
                    'name' => 'wallregi_pdf_footer_text_color',
                    'key' => 'pdf_footer_text_color',
                    'label' => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'color',
                    'default' => '#333333',
                ],
                // Font size
                [
                    'name' => 'wallregi_pdf_footer_font_size',
                    'key' => 'pdf_footer_font_size',
                    'label' => __('Font size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 13,
                ],
                // Font weight
                [
                    'name' => 'wallregi_pdf_footer_font_weight',
                    'key' => 'pdf_footer_font_weight',
                    'label' => __('Font weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold' => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],
                // Text align
                [
                    'name' => 'wallregi_pdf_footer_text_align',
                    'key' => 'pdf_footer_text_align',
                    'label' => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center' => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'center',
                ],
                // Text transform
                [
                    'name' => 'wallregi_pdf_footer_text_transform',
                    'key' => 'pdf_footer_text_transform',
                    'label' => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase' => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase' => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
            ],
        ],
        // PDF Footer Border Styling Fields
        [
            'name' => 'wallregi_pdf_footer_border_group',
            'key' => 'pdf_footer_border_group',
            'sec_name' => __('PDF: footer', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key' => 'pdf_template_footer_styles',
            'label' => __('PDF Footer Border Styling', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Set border for the PDF footer section.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type' => 'group',
            'help_link' => 'https://youtu.be/CdIP-w9LowI',
            'fields' => [
                // Border width
                [
                    'name' => 'wallregi_pdf_footer_border_width',
                    'key' => 'pdf_footer_border_width',
                    'label' => __('Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 1,
                ],
                // Border style
                [
                    'name' => 'wallregi_pdf_footer_border_styles',
                    'key' => 'pdf_footer_border_styles',
                    'label' => __('Styles', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'solid' => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed' => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted' => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double' => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove' => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge' => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],
                // Border color
                [
                    'name' => 'wallregi_pdf_footer_border_color',
                    'key' => 'pdf_footer_border_color',
                    'label' => __('Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'color',
                    'default' => '#cccccc',
                ],
                // Border position
                [
                    'name' => 'wallregi_pdf_footer_border_position',
                    'key' => 'pdf_footer_border_position',
                    'label' => __('Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'top',
                ],
            ],
        ],
        // PDF Footer Spacing (Padding & Margin) Fields
        [
            'name' => 'wallregi_pdf_footer_box_model_group',
            'key' => 'pdf_footer_box_model_group',
            'sec_name' => __('PDF: footer', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key' => 'pdf_template_footer_styles',
            'label' => __('PDF Footer Spacing (Padding & Margin)', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Adjust padding and margin around the footer text.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type' => 'group',
            'help_link' => 'https://youtu.be/nV40HeEEUWM',
            'fields' => [
                // Padding
                [
                    'name' => 'wallregi_pdf_footer_padding_width',
                    'key' => 'pdf_footer_padding_width',
                    'label' => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 10,
                ],
                [
                    'name' => 'wallregi_pdf_footer_padding_position',
                    'key' => 'pdf_footer_padding_position',
                    'label' => __('Padding position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],
                // Margin
                [
                    'name' => 'wallregi_pdf_footer_margin_width',
                    'key' => 'pdf_footer_margin_width',
                    'label' => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'number',
                    'default' => 10,
                ],
                [
                    'name' => 'wallregi_pdf_footer_margin_position',
                    'key' => 'pdf_footer_margin_position',
                    'label' => __('Margin position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'all' => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top' => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right' => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom' => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left' => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom' => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right' => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none' => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'bottom',
                ],
            ],
        ],
        // Custom pdf layout Settings
        [
            'name' => 'wallregi_enable_custom_pdf_layout',
            'key' => 'enable_custom_pdf_layout',
            'sec_name' => __('Custom PDF Layout Settings', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key' => 'custom_pdf_layout_settings',
            'label' => __('Enable Custom PDF Layout', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('When enabled, you can customize the PDF HTML and CSS layout for each gift card product in the WooCommerce Product edit screen under General data.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type' => 'checkbox',
            'default' => 'no',
        ],
    ],
    'select_fields' => [],
];
