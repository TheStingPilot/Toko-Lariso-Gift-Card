<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}


// Email Settings Fields 
// phpcs:ignore
$email_fields = [
    [   
        'name'              => 'wallregi_email_placeholder',
        'key'               => 'email_placeholder',
        'label'             => __( 'Placeholders (drag, drop, or copy into subject, heading, or body)', 'wallet-ready-gift-cards-for-woocommerce' ),
        'description'       => __( 'Insert placeholder tags like [giftcard_code] into the subject, heading, or email body fields.', 'wallet-ready-gift-cards-for-woocommerce' ),
        'placeholders'      => [
            '[giftcard_code]', '[giftcard_value]', '[expiry_date]',
            '[sender_name]', '[receiver_name]', '[receiver_email]', '[email_heading]',
            '[gift_card_message]', '[pass_link]'
        ],
        'type'              => 'placeholders',
    ],
    [
        'name'          => 'wallregi_email_subject',
        'key'           => 'email_subject',
        'label'         => __('Email Subject', 'wallet-ready-gift-cards-for-woocommerce'),
        'description'   => __('Customize the subject line for the gift card email. You can drag and drop placeholders like [giftcard_code] to automatically insert gift card details.', 'wallet-ready-gift-cards-for-woocommerce'),
        'type'          => 'text',
    ],
    [
        'name'          => 'wallregi_email_heading',
        'key'           => 'email_heading',
        'label'         => __('Email Heading', 'wallet-ready-gift-cards-for-woocommerce'),
        'description'   => __('Set the heading that appears at the top of the gift card email. Use drag and drop to insert placeholders such as [giftcard_code] for dynamic personalization.', 'wallet-ready-gift-cards-for-woocommerce'),
        'type'          => 'text',
    ],
    [
        'name'          => 'wallregi_email_body',
        'key'           => 'email_body',
        'label'         => __( 'Email body (HTML)', 'wallet-ready-gift-cards-for-woocommerce' ),
        'description'   => __( 'Main message shown in the email. Drag or paste placeholders such as [giftcard_code] into the editor.', 'wallet-ready-gift-cards-for-woocommerce' ),
        'type'          => 'editor',
    ],
    [
        'name'          => 'wallregi_email_pdf_attach',
        'key'           => 'email_pdf_attach',
        'label'         => __('Attach Gift Card PDF to Email', 'wallet-ready-gift-cards-for-woocommerce'),
        'description'   => __('Enable this option to automatically attach the gift card as a PDF file in the recipient\'s email.', 'wallet-ready-gift-cards-for-woocommerce'),
        'type'          => 'checkbox',
        'default'       => 'yes',
    ],
    [
        'name'          => 'wallregi_email_batch_size',
        'key'           => 'email_batch_size',
        'label'         => __( 'Emails per batch', 'wallet-ready-gift-cards-for-woocommerce' ),
        'description'   => __( 'How many gift card emails are processed per batch when sending large volumes (helps avoid timeouts). Default is 5.', 'wallet-ready-gift-cards-for-woocommerce' ),
        'type'          => 'number',
        'default'       => 5,
    ],

];