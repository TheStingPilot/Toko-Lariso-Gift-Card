<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

return [
    'input_fields' => [

        // input text fields for giftcard form
        [
            'name'        => 'wallregi_form_title',
            'key'         => 'form_title',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __( 'Form heading', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Main title above the recipient / message fields on the gift card product page.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __('Send a Gift Card', 'wallet-ready-gift-cards-for-woocommerce'),
            'help_link'   => 'https://youtu.be/mpSpsyxpyAY'
        ],
        [
            'name'        => 'wallregi_receiver_name_label',
            'key'         => 'name_label',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __( 'Recipient name — field label', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Label shown for the person receiving the gift (who gets the email).', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __( 'Recipient name', 'wallet-ready-gift-cards-for-woocommerce' ),
            'help_link'   => 'https://youtu.be/R4FomB8fpzI',
        ],
        [
            'name'        => 'wallregi_receiver_email_label',
            'key'         => 'email_label',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __( 'Recipient email — field label', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Label shown for the delivery email address.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __( 'Recipient email', 'wallet-ready-gift-cards-for-woocommerce' ),
            'help_link'   => 'https://youtu.be/PqiRAqKVQ0w',
        ],
        [
            'name'        => 'wallregi_greeting_label_text',
            'key'         => 'greeting_label',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __( 'Personal message — field label', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Shown above the longer message the buyer writes for the recipient.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __('Greeting/Message', 'wallet-ready-gift-cards-for-woocommerce'),
            'help_link'   => 'https://youtu.be/gHRgt8Vkucs',
        ],
        [
            'name'        => 'wallregi_greeting_max_message_length',
            'key'         => 'max_mgs_length',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __('Maximum message length (characters)', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __( 'Hard character limit for the personal message. Optional live counter is under General settings.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'number',
            'default'     => 250,
            'help_link'   => 'https://youtu.be/m-t0BZHmh_k',
        ],
        [
            'name'        => 'wallregi_sender_name_label',
            'key'         => 'sender_label',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __( 'Buyer / sender name — field label', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Shown for the person purchasing or sending the gift.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __('Sender Name', 'wallet-ready-gift-cards-for-woocommerce'),
            'help_link'   => 'https://youtu.be/t53zDxDGWuY',
        ],
        [
            'name'        => 'wallregi_datepicker_label',
            'key'         => 'datepicker_label',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __('Scheduled delivery label', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Label for when the gift card email should be sent (date/time picker).', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'text',
            'default'     => __('Send at', 'wallet-ready-gift-cards-for-woocommerce'),
            'help_link'   => 'https://youtu.be/JtVAYegFjwk',
        ],
        [
            'name'        => 'wallregi_submit_btn_text',
            'key'         => 'submit_btn_text',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __('Add to cart button text', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __( 'Primary button on the gift card product form (usually Add to cart).', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __('Add to Cart', 'wallet-ready-gift-cards-for-woocommerce'),
            'help_link'   => 'https://youtu.be/MlAhMMZiTkE',
        ],
        [
            'name'        => 'wallregi_valid_mgs_receiver',
            'key'         => 'valid_mgs_receiver',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __( 'Recipient name — empty error', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Shown when the recipient name is empty.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __( 'Please enter the recipient\'s name.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'help_link'   => 'https://youtu.be/t-XZEXEeUl4',
        ],
        [
            'name'        => 'wallregi_valid_mgs_receiver_email',
            'key'         => 'valid_mgs_receiver_email',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __( 'Recipient email — missing/invalid error', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Shown when the recipient email is missing or invalid.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __( 'Please enter the recipient\'s email.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'help_link'   => 'https://youtu.be/_SgNQ9XsI5s',
        ],
        [
            'name'        => 'wallregi_invalid_email',
            'key'         => 'invalid_email',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __('Invalid email error message', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Message shown when the email address format is invalid.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'text',
            'default'     => __('Invalid email format.', 'wallet-ready-gift-cards-for-woocommerce'),
            'help_link'   => 'https://youtu.be/KkOSMNAkjj4',
        ],
        [
            'name'        => 'wallregi_valid_mgs_sender',
            'key'         => 'valid_mgs_sender',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __( 'Sender name — empty error', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Shown when the buyer/sender name is required but missing.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __('Please enter sender name.', 'wallet-ready-gift-cards-for-woocommerce'),
            'help_link'   => 'https://youtu.be/_lf8LhKs_40',
        ],
        [
            'name'        => 'wallregi_response_success_mgs',
            'key'         => 'response_success_mgs',
            'sec_name'    => __('Gift card form text & validation', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_form_settings',
            'label'       => __( 'After add to cart — success message', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Short confirmation after the gift card line is added to the cart.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'text',
            'default'     => __('Gift card added to cart successfully!', 'wallet-ready-gift-cards-for-woocommerce'),
            'help_link'   => 'https://youtu.be/P-NpsuD-UrI',
        ],

        // Gift Card (page & PDF) Preview area settings

        [
            'name'        => 'wallregi_giftcrd_layout',
            'key'         => 'giftcrd_layout',
            'sec_name'    => __( 'Gift Card (page & PDF) Preview area settings', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_contents_body_styles',
            'label'       => __( 'Two-column order (preview vs form)', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Flip whether the illustrated card appears on the left or right relative to price & options (product page and PDF preview).', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'select',
            'default'     => 'row',
            'help_link'   => 'https://youtu.be/66J1ewTwqxg',
            'options'     => [
                'row'         => __( 'Card preview on the left', 'wallet-ready-gift-cards-for-woocommerce' ),
                'row-reverse' => __( 'Card preview on the right', 'wallet-ready-gift-cards-for-woocommerce' ),
            ],
        ],
        [
            'name'         => 'wallregi_background_style',
            'key'          => 'background_style',
            'sec_name'    => __( 'Gift Card (page & PDF) Preview area settings', 'wallet-ready-gift-cards-for-woocommerce' ),
            'sec_key'     => 'single_giftcard_layout_contents_body_styles',
            'label'        => __( 'Behind the card preview', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description'  => __( 'Background fill for the illustrated gift card region (product page and PDF).', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'         => 'select', 
            'default'      => 'solid',
            'help_link'    => 'https://youtu.be/Hk20nKgyUgY',
            'extra_render' => 'background_options',
            'options'      => [
                'none'     => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                'solid'    => __('Solid color', 'wallet-ready-gift-cards-for-woocommerce'),
                'image'    => __('Background image', 'wallet-ready-gift-cards-for-woocommerce'),
                'gradient' => __('Gradient', 'wallet-ready-gift-cards-for-woocommerce'),
            ],
        ],

        // Giftcard form heading fields
        [
            'name'        => 'wallregi_giftcard_form_items_heading_group',
            'key'         => 'giftcard_form_items_heading_group',
            'sec_name'    => __('Form fields & buttons appearance', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'form_items_styles',
            'label'       => __( 'Section heading typography inside the form', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __('Control the style of form section headings such as font color, size, weight, and text transform.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/5NJ51ZmoEig',
            'fields'      => [
                // Text color
                [
                    'name'    => 'wallregi_giftcard_form_items_heading_text_color',
                    'key'     => 'giftcard_form_items_heading_text_color',
                    'label'   => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#333333',
                ],
                // Font size
                [
                    'name'    => 'wallregi_giftcard_form_items_heading_font_size',
                    'key'     => 'giftcard_form_items_heading_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 16,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_giftcard_form_items_heading_font_weight',
                    'key'     => 'giftcard_form_items_heading_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],
                // Text alignment
                [
                    'name'    => 'wallregi_giftcard_form_items_heading_text_align',
                    'key'     => 'giftcard_form_items_heading_text_align',
                    'label'   => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_giftcard_form_items_heading_text_transform',
                    'key'     => 'giftcard_form_items_heading_text_transform',
                    'label'   => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
            ],
        ],

        // Giftcard Form Label Fields
        [
            'name'        => 'wallregi_giftcard_form_items_label_group',
            'key'         => 'giftcard_form_items_label_group',
            'sec_name'    => __('Form fields & buttons appearance', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'form_items_styles',
            'label'       => __( 'Field labels — typography', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Font styling for the small captions above each input.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/ZfA4PvlHAdc',
            'fields'      => [
                // Text color
                [
                    'name'    => 'wallregi_giftcard_form_items_label_text_color',
                    'key'     => 'giftcard_form_items_label_text_color',
                    'label'   => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7e7c7c',
                ],
                // Font size
                [
                    'name'    => 'wallregi_giftcard_form_items_label_font_size',
                    'key'     => 'giftcard_form_items_label_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 14,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_giftcard_form_items_label_font_weight',
                    'key'     => 'giftcard_form_items_label_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],
                // Text alignment
                [
                    'name'    => 'wallregi_giftcard_form_items_label_text_align',
                    'key'     => 'giftcard_form_items_label_text_align',
                    'label'   => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_giftcard_form_items_label_text_transform',
                    'key'     => 'giftcard_form_items_label_text_transform',
                    'label'   => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'capitalize',
                ],
            ],
        ],

        // Giftcard form items box model fields
        [
            'name'        => 'wallregi_giftcard_form_items_box_model_group',
            'key'         => 'giftcard_form_items_box_model_group',
            'sec_name'    => __('Form fields & buttons appearance', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'form_items_styles',
            'label'       => __( 'Inputs — border, radius & padding', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Box around text fields and the message area (not the overall product page card).', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/ZdNA5GIfpek',
            'fields'      => [

                // Border Width 
                [
                    'name'    => 'wallregi_giftcard_form_items_border_width',
                    'key'     => 'giftcard_form_items_border_width',
                    'label'   => __('Border Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 1,
                ],

                // Border Styles 
                [
                    'name'    => 'wallregi_giftcard_form_items_border_styles',
                    'key'     => 'giftcard_form_items_border_styles',
                    'label'   => __('Border style', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_giftcard_form_items_border_color',
                    'key'     => 'giftcard_form_items_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],

                // Border Position 
                [
                    'name'    => 'wallregi_giftcard_form_items_border_position',
                    'key'     => 'giftcard_form_items_border_position',
                    'label'   => __('Border Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

                // Border Radius
                [
                    'name'    => 'wallregi_giftcard_form_items_radius_width',
                    'key'     => 'giftcard_form_items_radius_width',
                    'label'   => __('Border radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 7,
                ],

                // Border Radius Position Fields
                [
                    'name'    => 'wallregi_giftcard_form_items_radius_position',
                    'key'     => 'giftcard_form_items_radius_position',
                    'label'   => __('Radius position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'          => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left'     => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right'    => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left'  => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'          => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'       => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'         => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'        => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'         => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

                // Padding Width
                [
                    'name'    => 'wallregi_giftcard_form_items_padding_width',
                    'key'     => 'giftcard_form_items_padding_width',
                    'label'   => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 12,
                ],

                // Padding Position
                [
                    'name'    => 'wallregi_giftcard_form_items_padding_position',
                    'key'     => 'giftcard_form_items_padding_position',
                    'label'   => __('Padding position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],
            ]
        ],



        // Giftcard Form input styling fields
        [
            'name'        => 'wallregi_giftcard_form_items_styles_group',
            'key'         => 'giftcard_form_items_styles_group',
            'sec_name'    => __('Form fields & buttons appearance', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'form_items_styles',
            'label'       => __( 'Inputs — text & background', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'How typed text and field fill colors look inside inputs and the message box.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/KnvHqGyVZxU',
            'fields'      => [

                // Text Color 
                [
                    'name'    => 'wallregi_giftcard_form_items_text_color',
                    'key'     => 'giftcard_form_items_text_color',
                    'label'   => __('Text Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#333333',
                ],

                // Font Size 
                [
                    'name'    => 'wallregi_giftcard_form_items_font_size',
                    'key'     => 'giftcard_form_items_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 14,
                ],

                // BG Color 
                [
                    'name'    => 'wallregi_giftcard_form_items_bg_color',
                    'key'     => 'giftcard_form_items_bg_color',
                    'label'   => __('BG Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#f3f3f3',
                ],
            ]
        ],

        // Giftcard form items placeholder styling fields
        [
            'name'        => 'wallregi_giftcard_form_items_placeholder_group',
            'key'         => 'giftcard_form_items_placeholder_group',
            'sec_name'    => __('Form fields & buttons appearance', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'form_items_styles',
            'label'       => __( 'Placeholder hint text', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Style for grey hint text inside empty fields.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/ywjfAXfP3l8',
            'fields'     => [

                // Text Color 
                [
                    'name'    => 'wallregi_giftcard_form_items_placeholder_text_color',
                    'key'     => 'giftcard_form_items_placeholder_text_color',
                    'label'   => __('Text Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7e7c7c',
                ],

                // Font Size 
                [
                    'name'    => 'wallregi_giftcard_form_items_placeholder_font_size',
                    'key'     => 'giftcard_form_items_placeholder_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 13,
                ],

                // Font Weight 
                [
                    'name'    => 'wallregi_giftcard_form_items_placeholder_font_weight',
                    'key'     => 'giftcard_form_items_placeholder_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],

                // Text alignment
                [
                    'name'    => 'wallregi_giftcard_form_items_placeholder_text_align',
                    'key'     => 'giftcard_form_items_placeholder_text_align',
                    'label'   => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_giftcard_form_items_placeholder_text_transform',
                    'key'     => 'giftcard_form_items_placeholder_text_transform',
                    'label'   => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'capitalize',
                ],
            ],
        ],

        // Giftcard form items focus styling fields
        [
            'name'        => 'wallregi_giftcard_form_items_pseudo_group',
            'key'         => 'giftcard_form_items_pseudo_group',
            'sec_name'    => __('Form fields & buttons appearance', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'form_items_styles',
            'label'       => __( 'Focused input state (outline & colors)', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __('Control border width, style, and color when an input/textarea is focused.', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/xJjiB2wPm7s',
            'fields'      => [

                // Text Color 
                [
                    'name'    => 'wallregi_giftcard_form_items_pseudo_text_color',
                    'key'     => 'giftcard_form_items_pseudo_text_color',
                    'label'   => __('Text Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7e7c7c',
                ],

                // BG Color 
                [
                    'name'    => 'wallregi_giftcard_form_items_pseudo_bg_color',
                    'key'     => 'giftcard_form_items_pseudo_bg_color',
                    'label'   => __('BG Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#f4f8fb',
                ],
                
                // Border Color 
                [
                    'name'    => 'wallregi_giftcard_form_items_pseudo_border_color',
                    'key'     => 'giftcard_form_items_pseudo_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#be88eb',
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_giftcard_form_items_pseudo_border_styles',
                    'key'     => 'giftcard_form_items_pseudo_border_styles',
                    'label'   => __('Border style', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],
            ]
        ],

        // Giftcard ajax from submit message fields
        [
            'name'        => 'wallregi_giftcard_form_submit_mgs_group',
            'key'         => 'giftcard_form_submit_mgs_group',
            'sec_name'    => __('Form fields & buttons appearance', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'form_items_styles',
            'label'       => __('After submit: feedback message appearance', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __( 'Typography for inline notices after AJAX add-to-cart / validation.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/o7i61rQDrQ8',
            'fields'      => [

                // Font size
                [
                    'name'    => 'wallregi_giftcard_form_submit_mgs_font_size',
                    'key'     => 'giftcard_form_submit_mgs_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 14,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_giftcard_form_submit_mgs_font_weight',
                    'key'     => 'giftcard_form_submit_mgs_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],
                // Text alignment
                [
                    'name'    => 'wallregi_giftcard_form_submit_mgs_text_align',
                    'key'     => 'giftcard_form_submit_mgs_text_align',
                    'label'   => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_giftcard_form_submit_mgs_text_transform',
                    'key'     => 'giftcard_form_submit_mgs_text_transform',
                    'label'   => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],
            ],
        ],


        // Edit Giftcard Form Label fields
        [
            'name'        => 'wallregi_edit_giftcard_label_style_group',
            'key'         => 'edit_giftcard_label_style_group',
            'sec_name'    => __('Form fields & buttons appearance', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'form_items_styles',
            'label'       => __( 'Cart / checkout edit panel — label typography', 'wallet-ready-gift-cards-for-woocommerce' ),
            'description' => __( 'Typography for labels in the modal/panel used to edit a gift card from cart or checkout.', 'wallet-ready-gift-cards-for-woocommerce' ),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/jJ5bSD50U9U',
            'fields'      => [

                // Text Color
                [
                    'name'    => 'wallregi_edit_giftcard_label_style_text_color',
                    'key'     => 'edit_giftcard_label_style_text_color',
                    'label'   => __('Text Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#333333',
                ],
                // Font size
                [
                    'name'    => 'wallregi_edit_giftcard_label_style_font_size',
                    'key'     => 'edit_giftcard_label_style_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 14,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_edit_giftcard_label_style_font_weight',
                    'key'     => 'edit_giftcard_label_style_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],
                // Text alignment
                [
                    'name'    => 'wallregi_edit_giftcard_label_style_text_align',
                    'key'     => 'edit_giftcard_label_style_text_align',
                    'label'   => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_edit_giftcard_label_style_text_transform',
                    'key'     => 'edit_giftcard_label_style_text_transform',
                    'label'   => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'none',
                ],

                // Margin Width
                [
                    'name'    => 'wallregi_edit_giftcard_label_style_margin_width',
                    'key'     => 'edit_giftcard_label_style_margin_width',
                    'label'   => __('Margin (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 10,
                ],

                // Margin Position
                [
                    'name'    => 'wallregi_edit_giftcard_label_style_margin_position',
                    'key'     => 'edit_giftcard_label_style_margin_position',
                    'label'   => __('Margin position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],
            ],
        ],

        /*==================================
        * GIFTCARD SIDE ALL BUTTON STYLE FIELDS START
        *============================================= */

        // Giftcard ALL Button Groups Styling Fields
        [
            'name'        => 'wallregi_giftcard_all_buttons_styles_group',
            'key'         => 'giftcard_all_buttons_styles_group',
            'sec_name'    => __('Shared button styles', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_all_button_styles_group_settings',
            'label'       => __('Button typography (global)', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/uxJuG4t8MUQ',
            'fields'      => [
                // Text color
                [
                    'name'    => 'wallregi_giftcard_all_buttons_text_color',
                    'key'     => 'giftcard_all_buttons_text_color',
                    'label'   => __('Text color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#333333',
                ],
                // Font size
                [
                    'name'    => 'wallregi_giftcard_all_buttons_font_size',
                    'key'     => 'giftcard_all_buttons_font_size',
                    'label'   => __('Font Size (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 16,
                ],
                // Font weight
                [
                    'name'    => 'wallregi_giftcard_all_buttons_font_weight',
                    'key'     => 'giftcard_all_buttons_font_weight',
                    'label'   => __('Font Weight', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'normal' => __('Normal', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bold'   => __('Bold', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lighter' => __('Lighter', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bolder' => __('Bolder', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'normal',
                ],
                // Text alignment
                [
                    'name'    => 'wallregi_giftcard_all_buttons_text_align',
                    'key'     => 'giftcard_all_buttons_text_align',
                    'label'   => __('Text alignment', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'left'    => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'center'  => __('Center', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'   => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'justify' => __('Justify', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left',
                ],

                // Text transform
                [
                    'name'    => 'wallregi_giftcard_all_buttons_text_transform',
                    'key'     => 'giftcard_all_buttons_text_transform',
                    'label'   => __('Text transform', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'none'       => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                        'capitalize' => __('Capitalize', 'wallet-ready-gift-cards-for-woocommerce'),
                        'uppercase'  => __('Uppercase', 'wallet-ready-gift-cards-for-woocommerce'),
                        'lowercase'  => __('Lowercase', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'capitalize',
                ],
            ]
        ],

        // Giftcard ALL Button Groups Border & BG Color Styling Fields
        [
            'name'        => 'wallregi_giftcard_all_buttons_border_group',
            'key'         => 'giftcard_all_buttons_border_group',
            'sec_name'    => __('Shared button styles', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_all_button_styles_group_settings',
            'label'       => __('Default button border & background', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/sAgvaAcOya8',
            'fields'      => [

                // Border Width
                [
                    'name'    => 'wallregi_giftcard_all_buttons_border_width',
                    'key'     => 'giftcard_all_buttons_border_width',
                    'label'   => __('Width (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 1,
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_giftcard_all_buttons_border_styles',
                    'key'     => 'giftcard_all_buttons_border_styles',
                    'label'   => __('Border style', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],

                // Border Color
                [
                    'name'    => 'wallregi_giftcard_all_buttons_border_color',
                    'key'     => 'giftcard_all_buttons_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],

                // Border Position
                [
                    'name'    => 'wallregi_giftcard_all_buttons_border_position',
                    'key'     => 'giftcard_all_buttons_border_position',
                    'label'   => __('Position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'           => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'           => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'         => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'        => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'          => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'    => __('Top Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'     => __('Left Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'          => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],

                // BG Color
                [
                    'name'    => 'wallregi_giftcard_all_buttons_bg_color',
                    'key'     => 'giftcard_all_buttons_bg_color',
                    'label'   => __('BG Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#f3f3f3',
                ],
            ],
        ],

        // Giftcard ALL Button Groups Box Model Styling Fields
        [
            'name'        => 'wallregi_giftcard_all_buttons_box_model_group',
            'key'         => 'giftcard_all_buttons_box_model_group',
            'sec_name'    => __('Shared button styles', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_all_button_styles_group_settings',
            'label'       => __('Default button padding & corner radius', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/Q5epXaAtRlk',
            'fields'      => [
                // Padding Width
                [
                    'name'    => 'wallregi_giftcard_all_buttons_padding_width',
                    'key'     => 'giftcard_all_buttons_padding_width',
                    'label'   => __('Padding (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 25,
                ],

                // Padding Position
                [
                    'name'    => 'wallregi_giftcard_all_buttons_padding_position',
                    'key'     => 'giftcard_all_buttons_padding_position',
                    'label'   => __('Padding position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'         => __('All Sides', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'         => __('Top', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'       => __('Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'      => __('Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'        => __('Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_bottom'  => __('Top & Bottom', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left_right'   => __('Left & Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'        => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'left_right',
                ],

                // Border Radius
                [
                    'name'    => 'wallregi_giftcard_all_buttons_radius_width',
                    'key'     => 'giftcard_all_buttons_radius_width',
                    'label'   => __('Border radius (px)', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'number',
                    'default' => 8,
                ],

                // Border Radius Position Fields
                [
                    'name'    => 'wallregi_giftcard_all_buttons_radius_position',
                    'key'     => 'giftcard_all_buttons_radius_position',
                    'label'   => __('Radius position', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'all'          => __('All Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_left'     => __('Top Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top_right'    => __('Top Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_left'  => __('Bottom Left', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom_right' => __('Bottom Right', 'wallet-ready-gift-cards-for-woocommerce'),
                        'top'          => __('Top Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'bottom'       => __('Bottom Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'left'         => __('Left Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'right'        => __('Right Corners', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'         => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'all',
                ],
                
            ],
        ],

        // Giftcard ALL Button Groups Pseudo Styling Fields
        [
            'name'        => 'wallregi_giftcard_all_buttons_pseudo_styles_group',
            'key'         => 'giftcard_all_buttons_pseudo_styles_group',
            'sec_name'    => __('Shared button styles', 'wallet-ready-gift-cards-for-woocommerce'),
            'sec_key'     => 'giftcard_all_button_styles_group_settings',
            'label'       => __('Button hover styles (global)', 'wallet-ready-gift-cards-for-woocommerce'),
            'description' => __('Colors for buttons when hovered (outline, fill, borders).', 'wallet-ready-gift-cards-for-woocommerce'),
            'type'        => 'group',
            'help_link'   => 'https://youtu.be/Ag0AgyRbFEs',
            'fields'      => [

                // Text Color 
                [
                    'name'    => 'wallregi_giftcard_all_buttons_pseudo_text_color',
                    'key'     => 'giftcard_all_buttons_pseudo_text_color',
                    'label'   => __('Text Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#f3f3f3',
                ],

                // BG Color 
                [
                    'name'    => 'wallregi_giftcard_all_buttons_pseudo_bg_color',
                    'key'     => 'giftcard_all_buttons_pseudo_bg_color',
                    'label'   => __('BG Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#7f54b3',
                ],
                
                // Border Color 
                [
                    'name'    => 'wallregi_giftcard_all_buttons_pseudo_border_color',
                    'key'     => 'giftcard_all_buttons_pseudo_border_color',
                    'label'   => __('Border Color', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'color',
                    'default' => '#be88eb',
                ],

                // Border Styles
                [
                    'name'    => 'wallregi_giftcard_all_buttons_pseudo_border_styles',
                    'key'     => 'giftcard_all_buttons_pseudo_border_styles',
                    'label'   => __('Border style', 'wallet-ready-gift-cards-for-woocommerce'),
                    'type'    => 'select',
                    'options' => [
                        'solid'   => __('Solid', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dashed'  => __('Dashed', 'wallet-ready-gift-cards-for-woocommerce'),
                        'dotted'  => __('Dotted', 'wallet-ready-gift-cards-for-woocommerce'),
                        'double'  => __('Double', 'wallet-ready-gift-cards-for-woocommerce'),
                        'groove'  => __('Groove', 'wallet-ready-gift-cards-for-woocommerce'),
                        'ridge'   => __('Ridge', 'wallet-ready-gift-cards-for-woocommerce'),
                        'none'    => __('None', 'wallet-ready-gift-cards-for-woocommerce'),
                    ],
                    'default' => 'solid',
                ],
            ]
        ],

        /*==================================
        * GIFTCARD SIDE ALL BUTTON STYLE FIELDS END
        *============================================= */
    ],
];
