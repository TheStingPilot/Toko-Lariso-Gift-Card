<?php
// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wallregi_epass_api_keys_url = 'https://app.epasscard.com/api-keys';
$wallregi_gtw_settings_url   = admin_url( 'admin.php?page=wx-gift-cards-gtw' );
$wallregi_wallet_provider    = function_exists( 'wallregi_get_wallet_provider' )
	? wallregi_get_wallet_provider()
	: (string) ( $wallregi_wallet_settings['wallet_provider'] ?? 'none' );
$wallregi_provider_choices   = function_exists( 'wallregi_wallet_provider_choices' )
	? wallregi_wallet_provider_choices()
	: [];
$wallregi_gtw_ext_active     = function_exists( 'wallregi_gtw_extension_is_active' ) && wallregi_gtw_extension_is_active();
$wallregi_has_encrypted_key   = ! empty( $wallregi_wallet_settings['epass_api_key_encrypted'] );
$wallregi_legacy_plain_key   = ! $wallregi_has_encrypted_key && ! empty( $wallregi_wallet_settings['epass_api_key'] )
	? (string) $wallregi_wallet_settings['epass_api_key']
	: '';
$wallregi_expiry_utc          = isset( $wallregi_wallet_settings['epass_key_expires_utc'] ) ? (string) $wallregi_wallet_settings['epass_key_expires_utc'] : '';
$wallregi_expiry_display      = wallregi_wallet_format_expiry_for_display( $wallregi_expiry_utc );
$wallregi_input_value         = $wallregi_has_encrypted_key ? '' : $wallregi_legacy_plain_key;
$wallregi_input_placeholder   = $wallregi_has_encrypted_key ? '****' : '';
$wallregi_input_masked_attr   = $wallregi_has_encrypted_key ? '1' : '0';

/**
 * @param string $panel_provider Panel slug (epasscard, gifttowallet, none).
 * @param string $active       Currently saved provider.
 * @return string
 */
$wallregi_wallet_panel_style = static function ( $panel_provider, $active ) {
	return $panel_provider === $active ? '' : 'display:none;';
};

?>

<section class="wallregi_card_body">
	<div class="wallregi_section_panel" style="border-bottom: none">
		<div class="wodg_panels">
			<div class="single_section_panel wallregi_options">
				<div class="panel_rows">
					<div class="option_showhide full_width_body">
						<table class="form-table" role="presentation">
							<tr class="wallregi-form-field">
								<th scope="row">
									<label for="wallregi_wallet_provider"><?php esc_html_e( 'Wallet provider', 'wallet-ready-gift-cards-for-woocommerce' ); ?></label>
								</th>
								<td>
									<select name="wallregi_wallet_provider" id="wallregi_wallet_provider" class="regular-text">
										<?php foreach ( $wallregi_provider_choices as $wallregi_provider_slug => $wallregi_provider_label ) : ?>
											<?php
											$wallregi_disabled = ( 'gifttowallet' === $wallregi_provider_slug && ! $wallregi_gtw_ext_active );
											?>
											<option
												value="<?php echo esc_attr( $wallregi_provider_slug ); ?>"
												<?php selected( $wallregi_wallet_provider, $wallregi_provider_slug ); ?>
												<?php disabled( $wallregi_disabled ); ?>
											><?php echo esc_html( $wallregi_provider_label ); ?></option>
										<?php endforeach; ?>
									</select>
									<p class="description">
										<?php esc_html_e( 'Choose one wallet integration for your store. ePasscard and GiftToWallet cannot be active at the same time.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
									</p>
									<?php if ( ! $wallregi_gtw_ext_active ) : ?>
										<p class="description wallregi-wallet-provider-hint" data-wallet-provider-hint="gtw-install">
											<?php esc_html_e( 'Install the GiftToWallet extension to enable the GiftToWallet provider.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
										</p>
									<?php else : ?>
										<p
											class="description wallregi-wallet-provider-hint"
											data-wallet-provider-hint="gtw-settings"
											style="<?php echo esc_attr( $wallregi_wallet_panel_style( 'gifttowallet', $wallregi_wallet_provider ) ); ?>"
										>
											<a href="<?php echo esc_url( $wallregi_gtw_settings_url ); ?>"><?php esc_html_e( 'Open GiftToWallet settings', 'wallet-ready-gift-cards-for-woocommerce' ); ?></a>
										</p>
									<?php endif; ?>
								</td>
							</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<div id="wallregi_wallet_provider_panels">
	<div
		class="wallregi-wallet-provider-panel"
		data-wallet-provider-panel="epasscard"
		style="<?php echo esc_attr( $wallregi_wallet_panel_style( 'epasscard', $wallregi_wallet_provider ) ); ?>"
	>
		<section class="wallregi_card_body wallregi-wallet-epass-panel">
			<div class="wallregi_section_panel" style="border-bottom: none">
				<div class="wodg_panels">
					<div class="single_section_panel wallregi_options">
						<div class="panel_rows">
							<div class="option_showhide full_width_body">
								<table class="form-table" role="presentation">
									<tr class="wallregi-form-field">
										<th scope="row">
											<label for="wallregi_epass_api_key"><?php esc_html_e( 'API Key', 'wallet-ready-gift-cards-for-woocommerce' ); ?></label>
										</th>
										<td>
											<div class="wallregi-wallet-api-key-row" style="display: flex; flex-wrap: wrap; gap: 10px; align-items: center; max-width: 52rem;">
												<input
													type="text"
													id="wallregi_epass_api_key"
													name="wallregi_epass_api_key"
													value="<?php echo esc_attr( $wallregi_input_value ); ?>"
													<?php echo $wallregi_input_placeholder ? 'placeholder="' . esc_attr( $wallregi_input_placeholder ) . '"' : ''; ?>
													class="regular-text"
													autocomplete="off"
													spellcheck="false"
													data-wallregi-masked="<?php echo esc_attr( $wallregi_input_masked_attr ); ?>"
													style="flex: 1 1 220px; min-width: 12rem;"
												/>
												<button type="button" id="wallregi_wallet_connect_btn" class="wallregi_button btn_grad">
													<?php esc_html_e( 'Connect', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
												</button>
											</div>
											<p class="description" style="margin-top: 12px;">
												<?php
												echo wp_kses_post(
													sprintf(
														/* translators: 1: URL (href), 2: visible URL text */
														__( 'Get your API key from <a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>.', 'wallet-ready-gift-cards-for-woocommerce' ),
														esc_url( $wallregi_epass_api_keys_url ),
														esc_html( $wallregi_epass_api_keys_url )
													)
												);
												?>
											</p>

											<div
												id="wallregi-wallet-status"
												class="wallregi-wallet-status"
												style="margin-top: 14px;"
												aria-live="polite"
											>
												<?php if ( $wallregi_has_encrypted_key ) : ?>
													<div class="notice notice-success inline wallregi-wallet-status__inner">
														<p><strong><?php esc_html_e( 'Connected successfully.', 'wallet-ready-gift-cards-for-woocommerce' ); ?></strong></p>
														<?php if ( '' !== $wallregi_expiry_display ) : ?>
															<p class="description" style="margin: 0.35em 0 0;">
																<?php
																printf(
																	/* translators: %s: formatted date/time in site timezone */
																	esc_html__( 'Key expiry (your site time): %s', 'wallet-ready-gift-cards-for-woocommerce' ),
																	esc_html( $wallregi_expiry_display )
																);
																?>
															</p>
														<?php endif; ?>
													</div>
												<?php endif; ?>
											</div>
										</td>
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php
		$wallregi_epass_api_file = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-public-api.php';
		if ( file_exists( $wallregi_epass_api_file ) ) {
			require_once $wallregi_epass_api_file;
		}
		if ( function_exists( 'wallregi_wallet_epass_is_api_configured' ) && wallregi_wallet_epass_is_api_configured() ) {
			$wallregi_global_pass_partial = __DIR__ . '/content-wallet-global-pass.php';
			if ( file_exists( $wallregi_global_pass_partial ) ) {
				include $wallregi_global_pass_partial;
			}
		} else {
			?>
			<section class="wallregi_card_body wallregi-wallet-global-pass--disabled">
				<p class="description" style="margin: 0;">
					<?php esc_html_e( 'Connect your ePasscard API key above to configure a global pass template and field mapping.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
				</p>
			</section>
			<?php
		}
		?>
	</div>

	<div
		class="wallregi-wallet-provider-panel"
		data-wallet-provider-panel="gifttowallet"
		style="<?php echo esc_attr( $wallregi_wallet_panel_style( 'gifttowallet', $wallregi_wallet_provider ) ); ?>"
	>
		<section class="wallregi_card_body wallregi-wallet-gtw-panel">
			<p class="description" style="margin: 0;">
				<?php
				echo wp_kses_post(
					sprintf(
						/* translators: %s: admin URL to GTW settings */
						__( 'GiftToWallet is your active wallet provider. Configure API credentials and issuance options on the <a href="%s">GiftToWallet settings</a> screen.', 'wallet-ready-gift-cards-for-woocommerce' ),
						esc_url( $wallregi_gtw_settings_url )
					)
				);
				?>
			</p>
		</section>
	</div>

	<div
		class="wallregi-wallet-provider-panel"
		data-wallet-provider-panel="none"
		style="<?php echo esc_attr( $wallregi_wallet_panel_style( 'none', $wallregi_wallet_provider ) ); ?>"
	>
		<section class="wallregi_card_body wallregi-wallet-none-panel">
			<p class="description" style="margin: 0;">
				<?php esc_html_e( 'Wallet passes are disabled. Gift cards will still be sold and delivered by email and PDF without an Apple or Google Wallet link.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
			</p>
		</section>
	</div>
</div>
