<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$wallregi_button_label = $wallregi_button_label ?? __('Save Options', 'wallet-ready-gift-cards-for-woocommerce');
if ( ! isset( $wallregi_show_hub_save_button ) ) {
	$wallregi_show_hub_save_button = true;
}
?>

<section class="wallregi_card_footer">
	<?php if ( $wallregi_show_hub_save_button ) : ?>
    <button type="submit" name="wallregi_save_settings" class="wallregi_button btn_grad">
        <?php echo esc_html($wallregi_button_label); ?>
    </button>
	<?php endif; ?>
</section>
