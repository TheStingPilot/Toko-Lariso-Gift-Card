<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$wallregi_header_title    = $wallregi_header_title ?? __( 'General settings', 'wallet-ready-gift-cards-for-woocommerce' );
$wallregi_header_desc     = $wallregi_header_desc ?? __( 'Store-wide behavior, labels, and shared appearance for gift cards. Layout and styling in this tab apply to the gift card product page and to the generated PDF (download / email attachment) unless a setting is clearly PDF-only under “PDF & email card design.”', 'wallet-ready-gift-cards-for-woocommerce' );
$wallregi_button_label    = $wallregi_button_label ?? __( 'Save settings', 'wallet-ready-gift-cards-for-woocommerce' );
$wallregi_notice_message  = $wallregi_notice_message ?? __('Settings saved successfully.', 'wallet-ready-gift-cards-for-woocommerce');
if ( ! isset( $wallregi_show_hub_save_button ) ) {
	$wallregi_show_hub_save_button = true;
}

?>

<section class="wallregi_card_header">
    <div class="wallregi_header_group">
        <h3 class="wallregi_page_title"><?php echo esc_html($wallregi_header_title); ?></h3>
		<?php if ( $wallregi_show_hub_save_button ) : ?>
        <button type="submit" name="wallregi_save_settings" class="wallregi_button btn_grad">
            <?php echo esc_html($wallregi_button_label); ?>
        </button>
		<?php endif; ?>
    </div>
    <p><?php echo esc_html($wallregi_header_desc); ?></p>
</section>


<?php
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin query arg after options.php redirect.
$wallregi_settings_updated = isset($_GET['settings-updated']) ? sanitize_text_field(wp_unslash($_GET['settings-updated'])) : '';
if ('true' === $wallregi_settings_updated): ?>
    <div class="notice notice-success is-dismissible wallregi_save_notice">
        <p><?php echo esc_html($wallregi_notice_message); ?></p>
    </div>
<?php endif; ?>
