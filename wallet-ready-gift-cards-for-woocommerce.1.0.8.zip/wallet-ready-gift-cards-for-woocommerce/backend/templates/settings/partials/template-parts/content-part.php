<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

?>

<!-- ===================
 All Other Settings Options UI Contents  
 ======================================= -->

<section class="wallregi_card_body" >
    <?php foreach ($wallregi_grouped_fields as $wallregi_section_title => $wallregi_fields): ?>
    <div class="wallregi_section_panel">
        <div class="wallregi_sec_flexbox" onclick="wallregiSectionToggleHandler(this);">
            <div class="sec_header">
                <h3 class="sec_title"><?php echo esc_html($wallregi_section_title); ?></h3>
            </div>
            <div class="wallregi_switcher_icon">
                <span class="dashicons dashicons-arrow-down-alt2"></span>
            </div>
        </div>

        <div class="wodg_panels" style="display: <?php
            // Get section key from the first field
            $wallregi_section_key = $wallregi_fields[0]['sec_key'] ?? ''; 
            $wallregi_default_open_keys = [ 'basic_settings', 'giftcard_form_settings', 'pdf_template_header_styles' ];
        
            echo in_array($wallregi_section_key, $wallregi_default_open_keys, true) ? 'block' : 'none';
        
        ?>;">

            <div class="sub_section_panel">

                <?php foreach ($wallregi_fields as $wallregi_field):
                    $wallregi_name  = esc_attr($wallregi_field['name']);
                    $wallregi_key   = esc_attr($wallregi_field['key']);
                    $wallregi_field_plain_key = $wallregi_field['key'] ?? '';
                    $wallregi_raw_stored        = $wallregi_settings[ $wallregi_field_plain_key ] ?? '';
                    $wallregi_raw_stored        = is_array($wallregi_raw_stored) ? '' : (string) $wallregi_raw_stored;
                    $wallregi_value             = esc_attr($wallregi_raw_stored);

                    ?>
                    <div class="panel_rows<?php echo ! empty( $wallregi_field['pro_placeholder'] ) ? ' panel_rows--pro-placeholder' : ''; ?>"<?php echo ! empty( $wallregi_field['depends_on'] ) ? ' data-depends-on="' . esc_attr( $wallregi_field['depends_on'] ) . '"' : ''; ?>>
                        <div class="left_part">
                            <h4 class="heading">
                                <?php echo esc_html( $wallregi_field['label'] ); ?>
                                <?php if ( ! empty( $wallregi_field['pro_placeholder'] ) ) : ?>
                                    <span class="wallregi-label pro wallregi-pro-badge"><?php esc_html_e( 'Pro', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
                                <?php endif; ?>
                            </h4>
                            <?php if (!empty($wallregi_field['help_link'])): ?>
                                <?php wallregi_help_youtube_link($wallregi_field['help_link']); ?>
                            <?php endif; ?>
                        </div>
                        <div class="right_part">
                            <?php

                            // REGULAR FIELD TYPES
                            switch ($wallregi_field['type']) {
                                case 'checkbox':
                                    $wallregi_cb_disabled = ! empty( $wallregi_field['disabled'] ) || ! empty( $wallregi_field['pro_placeholder'] );
                                    ?>
                                    <label class="wallregi_switch<?php echo $wallregi_cb_disabled ? ' wallregi_switch--disabled' : ''; ?>">
                                        <input type="checkbox" name="<?php echo esc_attr($wallregi_name); ?>" id="<?php echo esc_attr($wallregi_name); ?>" value="yes" <?php checked($wallregi_value, 'yes'); ?> <?php disabled($wallregi_cb_disabled); ?> <?php echo $wallregi_cb_disabled ? 'aria-disabled="true"' : ''; ?> />
                                        <span class="slider round"></span>
                                    </label>
                                    <?php
                                    if ( $wallregi_cb_disabled && ! empty( $wallregi_field['disabled_note'] ) ) {
                                        echo '<p class="description" style="margin-top:8px;max-width:32rem;">' . wp_kses_post( $wallregi_field['disabled_note'] ) . '</p>';
                                    }
                                    break;



                                case 'color':
                                    ?>
                                    <input
                                        type="color"
                                        id="<?php echo esc_attr($wallregi_name); ?>"
                                        name="<?php echo esc_attr($wallregi_name); ?>"
                                        value="<?php echo esc_attr($wallregi_value); ?>"
                                        <?php disabled( ! empty( $wallregi_field['pro_placeholder'] ) ); ?>
                                    />
                                    <?php
                                    break;

                                case 'number':
                                case 'text':
                                    ?>
                                    <input
                                        type="<?php echo esc_attr($wallregi_field['type']); ?>"
                                        id="<?php echo esc_attr($wallregi_name); ?>"
                                        name="<?php echo esc_attr($wallregi_name); ?>"
                                        value="<?php echo esc_attr($wallregi_value); ?>"
                                        class="regular-text"
                                        <?php disabled( ! empty( $wallregi_field['pro_placeholder'] ) ); ?>
                                    />
                                    <?php
                                    break;

                                case 'textarea':
                                    $wallregi_textarea_rows = isset($wallregi_field['rows']) ? (int) $wallregi_field['rows'] : 10;
                                    ?>
                                    <textarea
                                        id="<?php echo esc_attr($wallregi_name); ?>"
                                        name="<?php echo esc_attr($wallregi_name); ?>"
                                        rows="<?php echo max(3, min(30, $wallregi_textarea_rows)); ?>"
                                        class="large-text code"
                                        style="width:100%;max-width:48rem;font-family:monospace;"
                                    ><?php echo esc_textarea($wallregi_raw_stored); ?></textarea>
                                    <?php
                                    break;

                                case 'placeholders':
                                    if ( ! empty( $wallregi_field['placeholders'] ) && is_array( $wallregi_field['placeholders'] ) ) {
                                        ?>
                                        <div class="wallregi-placeholders-wrapper" style="display:flex; flex-wrap:wrap; gap:6px; margin: 4px 0;">
                                            <?php foreach ( $wallregi_field['placeholders'] as $tag ) : ?>
                                                <span class="wallregi-placeholder-tag" draggable="true" data-placeholder="<?php echo esc_attr( trim( $tag ) ); ?>" title="<?php esc_attr_e( 'Click to copy or drag into text field', 'wallet-ready-gift-cards-for-woocommerce' ); ?>" style="cursor:pointer; display:inline-block; padding:4px 8px; background:#f0f0f1; border:1px solid #c3c4c7; border-radius:4px; font-size:12px; font-family:monospace;"><?php echo esc_html( trim( $tag ) ); ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                        <?php
                                    }
                                    break;

                                case 'editor':
                                    $wallregi_editor_rows = isset( $wallregi_field['rows'] ) ? (int) $wallregi_field['rows'] : 16;
                                    wp_editor(
                                        $wallregi_raw_stored,
                                        $wallregi_name,
                                        [
                                            'textarea_name' => $wallregi_name,
                                            'textarea_rows' => max( 5, min( 40, $wallregi_editor_rows ) ),
                                            'media_buttons' => true,
                                            'teeny'         => false,
                                            'quicktags'     => true,
                                        ]
                                    );
                                    break;

                                case 'select':
                                    ?>
                                    <select name="<?php echo esc_attr($wallregi_name); ?>" id="<?php echo esc_attr($wallregi_name); ?>" class="regular-text"<?php echo ( 'wallregi_background_style' === $wallregi_name ) ? ' onchange="wallregiToggleBackgroundOptions();"' : ''; ?>>
                                        <?php
                                        // Priority: Use 'options' from field definition if available
                                        $wallregi_options = [];

                                        if (!empty($wallregi_field['options']) && is_array($wallregi_field['options'])) {
                                            $wallregi_options = $wallregi_field['options'];
                                        } else {
                                            // Fallback: predefined options
                                            switch ($wallregi_key) {
                                                case 'image_cleanup_age':
                                                    foreach ([24, 36, 48, 72] as $wallregi_hours) {
                                                        $wallregi_seconds = $wallregi_hours * HOUR_IN_SECONDS;
                                                        $wallregi_options[$wallregi_seconds] = "$wallregi_hours " . __('hours', 'wallet-ready-gift-cards-for-woocommerce');
                                                    }
                                                    foreach ([4, 5, 7, 10] as $wallregi_days) {
                                                        $wallregi_seconds = $wallregi_days * DAY_IN_SECONDS;
                                                        $wallregi_options[$wallregi_seconds] = "$wallregi_days " . __('days', 'wallet-ready-gift-cards-for-woocommerce');
                                                    }
                                                    break;
                                                default:
                                                    $wallregi_options = [];
                                            }
                                        }

                                        // Render options
                                        foreach ($wallregi_options as $wallregi_opt_val => $wallregi_opt_label) {
                                            printf(
                                                '<option value="%s" %s>%s</option>',
                                                esc_attr($wallregi_opt_val),
                                                selected($wallregi_value, $wallregi_opt_val, false),
                                                esc_html($wallregi_opt_label)
                                            );
                                        }
                                        ?>
                                    </select>

                                    <?php
                                    break;
                                
                                case 'group' :
                                    // GROUP FIELD TYPE
                                    if ($wallregi_field['type'] === 'group' && !empty($wallregi_field['fields'])) {
                                        echo '<div class="wallregi_group_wrap">';
                                        foreach ($wallregi_field['fields'] as $wallregi_subfield) {

                                            $wallregi_sub_name  = esc_attr($wallregi_subfield['name']);
                                            $wallregi_sub_key   = $wallregi_subfield['key'];

                                            // Get nested value safely
                                            $wallregi_sub_value = isset($wallregi_settings[$wallregi_field['key']][$wallregi_sub_key]) ? $wallregi_settings[$wallregi_field['key']][$wallregi_sub_key] : ( $wallregi_subfield['default'] ?? '' );

                                            $wallregi_sub_value = esc_attr($wallregi_sub_value);

                                            // Build nested input name: input_pseudo_styles[border_color]
                                            $wallregi_input_name = esc_attr($wallregi_field['key'] . '[' . $wallregi_sub_key . ']');
                                            $wallregi_input_id = esc_attr($wallregi_field['key'] . '_' . $wallregi_sub_key);


                                            echo '<div class="wallregi_group_row">';
                                            echo '<label for="' . esc_attr($wallregi_input_id) . '"><strong>' . esc_html($wallregi_subfield['label']) . '</strong></label>';

                                            switch ($wallregi_subfield['type']) {
                                                case 'color':
                                                case 'text':
                                                case 'number':
                                                    echo '<input type="' . esc_attr($wallregi_subfield['type']) . '" id="' . esc_attr($wallregi_input_id) . '" name="' . esc_attr($wallregi_input_name) . '" value="' . esc_attr($wallregi_sub_value) . '" class="regular-text" />';
                                                    break;

                                                case 'select':
                                                    echo '<select id="' . esc_attr($wallregi_input_id) . '" name="' . esc_attr($wallregi_input_name) . '" class="regular-text">';
                                                    if (!empty($wallregi_subfield['options']) && is_array($wallregi_subfield['options'])) {
                                                        foreach ($wallregi_subfield['options'] as $wallregi_option_value => $wallregi_option_label) {
                                                            echo '<option value="' . esc_attr($wallregi_option_value) . '" ' . selected($wallregi_sub_value, $wallregi_option_value, false) . '>' . esc_html($wallregi_option_label) . '</option>';
                                                        }
                                                    }
                                                    echo '</select>';
                                                    break;

                                                default:
                                                    echo '<input type="text" id="' . esc_attr($wallregi_input_id) . '" name="' . esc_attr($wallregi_input_name) . '" value="' . esc_attr($wallregi_sub_value) . '" class="regular-text" />';
                                                    break;
                                            }

                                            if (!empty($wallregi_subfield['description'])) {
                                                echo '<p class="desc">' . esc_html($wallregi_subfield['description']) . '</p>';
                                            }

                                            echo '</div>';
                                        }
                                        echo '</div>';
                                    }

                                    break;

                                case 'image_upload':
                                    $wallregi_img_url = esc_url( $wallregi_raw_stored );
                                    ?>
                                    <div class="wallregi_select_image">
                                        <input type="hidden"
                                               id="<?php echo esc_attr( $wallregi_name ); ?>"
                                               name="<?php echo esc_attr( $wallregi_name ); ?>"
                                               value="<?php echo $wallregi_img_url; ?>" />
                                        <button type="button" class="button wallregi-media-upload-btn"
                                                data-target="<?php echo esc_attr( $wallregi_name ); ?>">
                                            <?php esc_html_e( 'Choose Image', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
                                        </button>
                                    </div>
                                    <div class="wallregi_image_preview" style="margin-top:8px;">
                                        <div class="wallregi_remove_image" style="text-align:right;">
                                            <span class="wallregi-media-remove-btn dashicons dashicons-no-alt"
                                                data-target="<?php echo esc_attr( $wallregi_name ); ?>"
                                                style="cursor:pointer; vertical-align:middle; margin-left:6px; <?php echo $wallregi_img_url ? '' : 'display:none;'; ?>">
                                            </span>
                                        </div>
                                        <?php // phpcs:ignore WordPress.Security.EscapeOutput ?>
                                        <img src="<?php echo esc_attr( $wallregi_img_url ); ?>"
                                             id="<?php echo esc_attr( $wallregi_name ); ?>_preview"
                                             style="max-width:180px; max-height:70px; border:1px solid #ddd; padding:4px; <?php echo $wallregi_img_url ? '' : 'display:none;'; ?>" />
                                    </div>
                                    <?php
                                    break;

                                default:
                                    // fallback input
                                    ?>
                                    <input
                                        type="text"
                                        id="<?php echo esc_attr($wallregi_name); ?>"
                                        name="<?php echo esc_attr($wallregi_name); ?>"
                                        value="<?php echo esc_attr($wallregi_value); ?>"
                                        class="regular-text"
                                    />
                                    <?php
                                    break;
                            }




                            ?>
                            <?php if (!empty($wallregi_field['description'])): ?>
                                <p class="desc"><?php echo esc_html($wallregi_field['description']); ?></p>
                            <?php endif; ?>
                            <?php
                            /**
                             * After a settings hub field description (Pro AI, etc.).
                             *
                             * @param array $wallregi_field  Field definition.
                             * @param array $wallregi_settings Saved settings.
                             */
                            do_action( 'wallregi_settings_field_after_description', $wallregi_field, $wallregi_settings ?? [] );
                            ?>

                            <!-- Render extended sections like background options and junk cleaner  -->
                            <?php 
                                // Extra Render Logic
                                if ( ! empty( $wallregi_field['extra_render'] ) ) {
                                    switch ( $wallregi_field['extra_render'] ) {
                                        case 'background_options':
                                            $wallregi_background_style = $wallregi_settings['background_style'] ?? 'solid';
                                            ?>
                                                <!-- Hidden background options container -->
                                                <div id="wallregi_bg_options">

                                                    <!-- Solid Color Option -->
                                                    <div id="solid_color_options" style="display: <?php echo ($wallregi_background_style === 'solid') ? 'block' : 'none'; ?>;">
                                                        <input type="color" name="wallregi_solid_color" value="<?php echo esc_attr($wallregi_settings['solid_color'] ?? '#f8fafb'); ?>">
                                                    </div>

                                                    <!-- Background Image Option -->
                                                    <div id="image_background_options" style="display: <?php echo ($wallregi_background_style === 'image') ? 'block' : 'none'; ?>;">
                                                        <div class="wallregi_select_image">
                                                            <input type="hidden" id="wallregi_bg_image" name="wallregi_bg_image" value="<?php echo esc_url($wallregi_settings['bg_image_url'] ?? ''); ?>" />
                                                            <button type="button" class="button" id="upload_bg_image_btn"><?php esc_html_e('Choose Image', 'wallet-ready-gift-cards-for-woocommerce'); ?></button>
                                                        </div>
                                                        <?php $wallregi_bg_image_url = esc_url($wallregi_settings['bg_image_url'] ?? ''); ?>
                                                        <div class="wallregi_image_preview">
                                                            <?php // phpcs:ignore ?>
                                                            <img src="<?php echo esc_attr($wallregi_bg_image_url); ?>" 
                                                                alt="<?php esc_attr_e('Background image', 'wallet-ready-gift-cards-for-woocommerce'); ?>" 
                                                                id="wallregi_bg_image_preview" 
                                                                style="display: <?php echo !empty($wallregi_bg_image_url) ? 'block' : 'none'; ?>">
                                                            <span id="remove_bg_image_btn" class="dashicons dashicons-no-alt" 
                                                                style="display: <?php echo !empty($wallregi_bg_image_url) ? 'inline-flex' : 'none'; ?>; cursor: pointer;"></span>
                                                        </div>
                                                    </div>

                                                    <!-- Gradient Option -->
                                                    <div id="gradient_options" style="display: <?php echo ($wallregi_background_style === 'gradient') ? 'block' : 'none'; ?>;">
                                                        <input type="color" id="wallregi_gradient_start" name="wallregi_gradient_start"
                                                            value="<?php echo esc_attr($wallregi_settings['gradient_start'] ?? '#e7eff2'); ?>">

                                                        <input type="color" id="wallregi_gradient_middle" name="wallregi_gradient_middle"
                                                            value="<?php echo esc_attr($wallregi_settings['gradient_middle'] ?? '#d7ebe7'); ?>">

                                                        <input type="color" id="wallregi_gradient_end" name="wallregi_gradient_end"
                                                            value="<?php echo esc_attr($wallregi_settings['gradient_end'] ?? '#e7eff2'); ?>">
                                                    </div>
                                                </div>
                                            <?php
                                            break;

                                        case 'junk_cleaner':
                                            ?>
                                            <div class="wallregi_junk_cleaner_box" style="margin-top: 15px;">
                                                <input type="button" name="wallregi_run_junk_cleaner" class="button button-secondary"
                                                    value="<?php esc_attr_e('Run Junk Cleaner', 'wallet-ready-gift-cards-for-woocommerce'); ?>"
                                                    onclick="wallregiInitializeJunkCleanerButton(this)" />
                                                <p class="description">
                                                    <?php esc_html_e('Delete old gift card images to free up space and keep your site clean.', 'wallet-ready-gift-cards-for-woocommerce'); ?>
                                                </p>
                                                <div id="wallregi_junk_cleaner_result" style="margin-top: 10px; display: none;"></div>
                                            </div>
                                            <?php
                                            break;
                                    }
                                }
                            
                            ?>


                        </div>
                    </div>
                <?php endforeach; ?>

            </div>
        </div>
    </div>
    <?php endforeach; ?>
</section>


