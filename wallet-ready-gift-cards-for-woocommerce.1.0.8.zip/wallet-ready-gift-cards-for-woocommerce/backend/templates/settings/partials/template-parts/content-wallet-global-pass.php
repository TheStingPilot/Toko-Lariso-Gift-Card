<?php
/**
 * Global ePasscard pass template + mapping (Google/Apple Wallet settings).
 *
 * Expects $wallregi_wallet_settings from wallet-settings-ui bootstrap.
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wallregi_gp_saved = isset( $wallregi_wallet_settings['epass_global_pass_config'] ) && is_array( $wallregi_wallet_settings['epass_global_pass_config'] )
	? $wallregi_wallet_settings['epass_global_pass_config']
	: [];
$wallregi_gp_stripe = isset( $wallregi_wallet_settings['epass_global_stripe_image_url'] )
	? esc_url( (string) $wallregi_wallet_settings['epass_global_stripe_image_url'] )
	: '';
$wallregi_gp_uid   = isset( $wallregi_gp_saved['template_uid'] ) ? (string) $wallregi_gp_saved['template_uid'] : '';
$wallregi_gp_name  = isset( $wallregi_gp_saved['template_name'] ) ? (string) $wallregi_gp_saved['template_name'] : '';
$wallregi_gp_tid   = isset( $wallregi_gp_saved['template_id'] ) ? (int) $wallregi_gp_saved['template_id'] : 0;
$wallregi_gp_fields = isset( $wallregi_gp_saved['pass_fields'] ) && is_array( $wallregi_gp_saved['pass_fields'] ) ? $wallregi_gp_saved['pass_fields'] : [];

?>

<section class="wallregi_card_body wallregi-wallet-global-pass" id="wallregi-wallet-global-pass-config">
	<div class="wallregi_section_panel" style="border-bottom: none">
		<div class="wodg_panels">
			<div class="single_section_panel wallregi_options">
				<h4 style="margin: 0 0 8px;">
					<?php esc_html_e( 'Global pass template', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
				</h4>
				<p class="description" style="margin: 0 0 16px;">
					<?php esc_html_e( 'Choose a default pass template for gift cards when a product has no template of its own. Map each gift card value to a pass field.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
				</p>

				<div class="option_showhide full_width_body">
					<table class="form-table" role="presentation">
						<tr class="wallregi-form-field">
							<th scope="row">
								<label for="wallregi_wallet_global_template_uid"><?php esc_html_e( 'Pass template', 'wallet-ready-gift-cards-for-woocommerce' ); ?></label>
							</th>
							<td>
								<select name="wallregi_global_epass_template_uid" id="wallregi_wallet_global_template_uid" style="max-width: 28rem;">
									<option value=""><?php esc_html_e( '— Select —', 'wallet-ready-gift-cards-for-woocommerce' ); ?></option>
									<?php if ( '' !== $wallregi_gp_uid ) : ?>
										<option value="<?php echo esc_attr( $wallregi_gp_uid ); ?>" selected>
											<?php echo esc_html( $wallregi_gp_name !== '' ? $wallregi_gp_name : $wallregi_gp_uid ); ?>
										</option>
									<?php endif; ?>
								</select>
								<span class="description wallregi-wallet-global-template-status" style="display:block;margin-top:6px;"></span>
								<input type="hidden" name="wallregi_global_epass_template_name" id="wallregi_wallet_global_template_name" value="<?php echo esc_attr( $wallregi_gp_name ); ?>" />
								<input type="hidden" name="wallregi_global_epass_template_id" id="wallregi_wallet_global_template_id" value="<?php echo esc_attr( (string) $wallregi_gp_tid ); ?>" />
							</td>
						</tr>
						<tr id="wallregi_wallet_global_mapping_wrap" class="wallregi-form-field" style="display: none;">
							<th scope="row"><?php esc_html_e( 'Field mapping', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
							<td>
								<div id="wallregi_wallet_global_mapping_rows"></div>
							</td>
						</tr>
						<tr class="wallregi-form-field">
							<th scope="row">
								<label for="wallregi_wallet_global_stripe_image_url"><?php esc_html_e( 'Stripe image (fallback)', 'wallet-ready-gift-cards-for-woocommerce' ); ?></label>
							</th>
							<td>
								<p class="description" style="margin-top: 0;">
									<?php esc_html_e( 'Optional image URL used later as a fallback for the wallet pass stripe graphic.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
								</p>
								<div style="display: flex; flex-wrap: wrap; gap: 8px; align-items: center; max-width: 48rem;">
									<input
										type="text"
										name="wallregi_global_epass_stripe_image_url"
										id="wallregi_wallet_global_stripe_image_url"
										value="<?php echo esc_attr( $wallregi_gp_stripe ); ?>"
										class="regular-text"
										placeholder="https://"
										style="flex: 1 1 220px;"
									/>
									<button type="button" class="button" id="wallregi_wallet_global_stripe_pick">
										<?php esc_html_e( 'Select image', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
									</button>
								</div>
							</td>
						</tr>
					</table>

					<textarea name="wallregi_global_epass_pass_fields_json" id="wallregi_wallet_global_pass_fields_json" style="display:none;"><?php echo esc_textarea( wp_json_encode( $wallregi_gp_fields, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) ); ?></textarea>
				</div>
			</div>
		</div>
	</div>
</section>
