<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

?>



<!-- ===================
 Email Settings Options UI Contents  
 ======================================= -->

<section class="wallregi_card_body">
    <div class="wallregi_section_panel" style="border-bottom: none">
        <div class="wodg_panels">
            <div class="single_section_panel wallregi_options">
                <div class="panel_rows">
                    <div class="option_showhide full_width_body">
                        <table class="form-table" id="wallregi_email_settings">
                            <?php foreach ($email_fields as $wallregi_field): 
                                $wallregi_name  = esc_attr($wallregi_field['name']);
                                $wallregi_key   = esc_attr($wallregi_field['key']);
                                $wallregi_value = esc_attr($wallregi_settings[$wallregi_key] ?? '');
                            ?>
                                <tr class="wallregi-form-field<?php echo ! empty( $wallregi_field['pro_placeholder'] ) ? ' wallregi-form-field--pro-placeholder' : ''; ?>">
                                    <th scope="row">
                                        <h4>
                                            <?php echo esc_html( $wallregi_field['label'] ); ?>
                                            <?php if ( ! empty( $wallregi_field['pro_placeholder'] ) ) : ?>
                                                <span class="wallregi-label pro wallregi-pro-badge"><?php esc_html_e( 'Pro', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
                                            <?php endif; ?>
                                        </h4>
                                    </th>
                                    <td>
                                        <?php if ( ! empty( $wallregi_field['pro_placeholder'] ) && 'pro_notice' === ( $wallregi_field['type'] ?? '' ) ) : ?>
                                            <div class="wallregi-pro-notice-box">
                                                <?php if ( ! empty( $wallregi_field['disabled_note'] ) ) : ?>
                                                    <p class="wallregi_desc"><?php echo wp_kses_post( $wallregi_field['disabled_note'] ); ?></p>
                                                <?php endif; ?>
                                            </div>
                                        <?php elseif ($wallregi_field['type'] === 'placeholders'): ?>
                                            <div class="placeholder_data" style="display: flex; flex-wrap: wrap; gap: 8px;">
                                                <?php foreach ($wallregi_field['placeholders'] as $tag): ?>
                                                    <span class="wallregi-placeholder-tag" draggable="true" data-placeholder="<?php echo esc_attr(trim($tag)); ?>" title="<?php esc_attr_e('Click to copy or drag into text field', 'wallet-ready-gift-cards-for-woocommerce'); ?>"><?php echo esc_html(trim($tag)); ?></span>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php elseif ($wallregi_field['type'] === 'text'): ?>
                                            <input type="<?php echo esc_attr($wallregi_field['type']); ?>" id="<?php echo esc_attr($wallregi_name); ?>" name="<?php echo esc_attr($wallregi_name); ?>" value="<?php echo esc_attr($wallregi_value); ?>" class="regular-text">
                                        <?php elseif ($wallregi_field['type'] === 'number'): ?>
                                            <input type="<?php echo esc_attr($wallregi_field['type']); ?>" id="<?php echo esc_attr($wallregi_name); ?>" name="<?php echo esc_attr($wallregi_name); ?>" value="<?php echo esc_attr($wallregi_value); ?>" class="small-text" min="1">
                                        <?php elseif ($wallregi_field['type'] === 'editor'): ?>
                                            <?php
                                            wp_editor(
                                                $wallregi_value,
                                                $wallregi_name,
                                                [
                                                    'textarea_name' => $wallregi_name,
                                                    'textarea_rows' => 18,
                                                    'media_buttons' => false,
                                                    'teeny'         => true,
                                                    'quicktags'     => true,
                                                ]
                                            );
                                            ?>
                                        <?php elseif ($wallregi_field['type'] === 'checkbox'): ?>
                                            <label class="wallregi_switch">
                                                <input type="<?php echo esc_attr($wallregi_field['type']); ?>" name="<?php echo esc_attr($wallregi_name); ?>" value="yes" <?php checked($wallregi_value, 'yes'); ?>/>
                                                <span class="slider round"></span>
                                            </label>
                                        <?php endif; ?>

                                        <?php if (!empty($wallregi_field['description'])): ?>
                                            <p class="wallregi_desc"><?php echo esc_html($wallregi_field['description']); ?></p>
                                        <?php endif; ?>
                                        <?php
                                        /**
                                         * After an email settings field (Pro AI buttons, etc.).
                                         *
                                         * @param array $wallregi_field   Field definition.
                                         * @param array $wallregi_settings Saved email settings.
                                         */
                                        do_action( 'wallregi_email_field_after_description', $wallregi_field, $wallregi_settings ?? [] );
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>