<?php
    // Exit if accessed directly
    if (!defined('ABSPATH')) {
        exit;
    }

if ( isset( $wallregi_active_tab_key ) ) {
    $wallregi_show_general_tab = ( 'wallregi_general' === $wallregi_active_tab_key );
} else {
    $wallregi_current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
    $wallregi_show_general_tab = (
        isset( $_GET['tab'], $_GET['_wpnonce'] ) &&
        'wallregi_general' === $wallregi_current_tab &&
        wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'wallregi_nonce_action' )
    );
}
?>

<div class="wallregi_card wallregi_genneral_card wallregi-settings-hub-panel" id="wallregi_general" data-settings-tab="wallregi_general" style="display: <?php echo $wallregi_show_general_tab ? 'block' : 'none'; ?>;">
    <form method="POST" id="wallregi_settings_form_general" class="wallregi-settings-hub-form" data-settings-tab="wallregi_general" autocomplete="off">
        <?php wp_nonce_field('wallregi_save_settings_action', 'settings_nonce'); ?>
        <input type="hidden" name="wallregi_settings_tab_dispatch" value="wallregi_general" />

        <!-- Template Include -->

        <?php
            // Load partials
            $wallregi_partials = [
                'header'    => 'header-part.php',
                'content'   => 'content-part.php',
                'footer'    => 'footer-part.php',
            ];
          //phpcs:ignore
            foreach($wallregi_partials as $wallregi_key => $wallregi_file){
                // Use include (not include_once): unified hub renders multiple cards on one screen.
                if (file_exists(plugin_dir_path(__DIR__) . 'template-parts/' . $wallregi_file)) {
                    include plugin_dir_path(__DIR__) . 'template-parts/' . $wallregi_file;
                }
            }
        ?>

    </form>
</div>


