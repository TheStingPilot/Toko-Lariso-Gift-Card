<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wallregi_header_title    = __( 'Google/Apple Wallet', 'wallet-ready-gift-cards-for-woocommerce' );
$wallregi_header_desc      = __( 'Options for adding gift cards to Google Wallet and Apple Wallet will appear here.', 'wallet-ready-gift-cards-for-woocommerce' );
$wallregi_notice_message   = __( 'Settings saved successfully.', 'wallet-ready-gift-cards-for-woocommerce' );
$wallregi_button_label     = __( 'Save settings', 'wallet-ready-gift-cards-for-woocommerce' );
/** @var bool $wallregi_show_hub_save_button Save wallet provider + global pass mapping. */
$wallregi_show_hub_save_button = true;

if ( isset( $wallregi_active_tab_key ) ) {
	$wallregi_show_wallet_tab = ( 'wallregi_wallet' === $wallregi_active_tab_key );
} else {
	$wallregi_current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
	$wallregi_show_wallet_tab = (
		isset( $_GET['tab'], $_GET['_wpnonce'] ) &&
		'wallregi_wallet' === $wallregi_current_tab &&
		wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'wallregi_nonce_action' )
	);
}

$wallregi_wallet_ctx        = wallregi_admin_settings_bootstrap_wallet();
$wallregi_wallet_settings  = $wallregi_wallet_ctx['wallregi_wallet_settings'];

?>

<div class="wallregi_card wallregi_wallet_card wallregi-settings-hub-panel" id="wallregi_wallet" data-settings-tab="wallregi_wallet" style="display: <?php echo $wallregi_show_wallet_tab ? 'block' : 'none'; ?>;">

	<form method="POST" id="wallregi_settings_form_wallet" class="wallregi-settings-hub-form" data-settings-tab="wallregi_wallet" autocomplete="off">
		<?php wp_nonce_field( 'wallregi_save_settings_action', 'settings_nonce' ); ?>
		<input type="hidden" name="wallregi_settings_tab_dispatch" value="wallregi_wallet" />

		<?php
		$wallregi_partials = [
			'header'  => 'header-part.php',
			'content' => 'content-wallet.php',
			'footer'  => 'footer-part.php',
		];
		// phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable
		foreach ( $wallregi_partials as $wallregi_key => $wallregi_file ) {
			if ( file_exists( plugin_dir_path( __DIR__ ) . 'template-parts/' . $wallregi_file ) ) {
				include plugin_dir_path( __DIR__ ) . 'template-parts/' . $wallregi_file;
			}
		}
		?>

	</form>
</div>
