<?php
    // Exit if accessed directly
    if (!defined('ABSPATH')) {
        exit;
    }
    
    $wallregi_header_title    = __( 'PDF template appearance', 'wallet-ready-gift-cards-for-woocommerce' );
    $wallregi_header_desc     = __( 'Fine-tune the printable PDF only (layout, typography, margins). For styles shared with the product page, use General settings; both use the same design tokens where applicable.', 'wallet-ready-gift-cards-for-woocommerce' );
    $wallregi_button_label    = __( 'Save settings', 'wallet-ready-gift-cards-for-woocommerce' );
    $wallregi_notice_message  = __('Saved successfully.', 'wallet-ready-gift-cards-for-woocommerce');

if ( isset( $wallregi_active_tab_key ) ) {
    $wallregi_show_pdf_templates_tab = ( 'wallregi_templates' === $wallregi_active_tab_key );
} else {
    $wallregi_current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
    $wallregi_show_pdf_templates_tab = (
        isset( $_GET['tab'], $_GET['_wpnonce'] ) &&
        'wallregi_templates' === $wallregi_current_tab &&
        wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'wallregi_nonce_action' )
    );
}
?>

<div class="wallregi_card wallregi_templates_card wallregi-settings-hub-panel" id="wallregi_templates" data-settings-tab="wallregi_templates" style="display: <?php echo $wallregi_show_pdf_templates_tab ? 'block' : 'none'; ?>;">
    <form method="POST" id="wallregi_settings_form_templates" class="wallregi-settings-hub-form" data-settings-tab="wallregi_templates" autocomplete="off">
        <?php wp_nonce_field('wallregi_save_settings_action', 'settings_nonce'); ?>
        <input type="hidden" name="wallregi_settings_tab_dispatch" value="wallregi_templates" />

        <!-- Template Include -->

        <?php
            // Load partials
            $wallregi_partials = [
                'header'    => 'header-part.php',
                'content'   => 'content-part.php',
                'footer'    => 'footer-part.php',
            ];
            //phpcs:ignore
            foreach($wallregi_partials as $wallregi_key => $wallregi_file){
                // Use include (not include_once): unified hub renders multiple cards on one screen.
                if (file_exists(plugin_dir_path(__DIR__) . 'template-parts/' . $wallregi_file)) {
                    include plugin_dir_path(__DIR__) . 'template-parts/' . $wallregi_file;
                }
            }
        ?>

    </form>
</div>


