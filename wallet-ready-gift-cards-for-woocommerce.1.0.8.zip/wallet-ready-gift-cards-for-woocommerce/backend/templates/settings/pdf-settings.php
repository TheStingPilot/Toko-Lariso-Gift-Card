<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}


$wallregi_settings_data_file = plugin_dir_path(__FILE__) . 'partials/settings-data/pdf-data.php';
include plugin_dir_path(__FILE__) . 'settings-helper.php';

$wallregi_render_file = plugin_dir_path(__FILE__) . 'partials/settings-ui/pdf-settings-ui.php';
if (file_exists($wallregi_render_file)) {
    include_once $wallregi_render_file;
}
