<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}


// phpcs:ignore
$wallregi_settings_data_file = plugin_dir_path(__FILE__) . 'partials/settings-data/form-data.php';
include plugin_dir_path(__FILE__) . 'settings-helper.php';
// phpcs:ignore
$wallregi_render_file = plugin_dir_path(__FILE__) . 'partials/settings-ui/form-settings-ui.php';
if (file_exists($wallregi_render_file)) {
    include_once $wallregi_render_file;
}
