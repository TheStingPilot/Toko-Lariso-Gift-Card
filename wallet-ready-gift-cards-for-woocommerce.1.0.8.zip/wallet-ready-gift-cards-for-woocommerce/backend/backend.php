<?php

// Ensure this file is not accessed directly
if (!defined('ABSPATH')) {
    exit;
}
if (!class_exists('WALLREGI_Gift_Card_Backend')) {
    class WALLREGI_Gift_Card_Backend
    {
        /**
         * Constructor - Register all backend hooks and actions
         */
        public function __construct()
        {
            // Load plugin when WooCommerce is loaded
            add_action('woocommerce_loaded', [$this, 'wallregi_load_plugin']);

            // Add custom product type "Gift Card"
            add_filter('product_type_selector', [$this, 'wallregi_add_type']);

            // Display gift card fields in product general tab
            add_action('woocommerce_product_options_general_product_data', [$this, 'wallregi_enable_js_on_wc_product']);

            // Save gift card expiry date when product is saved
            add_action('woocommerce_process_product_meta', [$this, 'wallregi_save_giftcard_settings_data'], 99, 1);

            // Top-level "GiftRocket" admin menu (Gift Cards dashboard).
            add_action('admin_menu', array($this, 'wallregi_add_giftcard_submenu_options'));

            // Enqueue backend admin scripts and styles
            add_action('admin_enqueue_scripts', [$this, 'wallregi_admin_enqueue_backend_assets']);

            // Handle AJAX request to manually create a gift card
            add_action('wp_ajax_wallregi_manual_giftcard_created', [$this, 'wallregi_manual_giftcard_created']);

            // Handle AJAX request to check if gift card number exists
            add_action('wp_ajax_wallregi_check_giftcard_number_exists', [$this, 'wallregi_check_giftcard_number_exists_callback']);

            // Handle AJAX request to delete a gift card
            add_action('wp_ajax_wallregi_delete_giftcard', [$this, 'wallregi_delete_giftcard']);

            // Handle AJAX request to search gift cards
            add_action('wp_ajax_wallregi_search_gift_cards', [$this, 'wallregi_search_gift_cards_callback']);

            // Hook the AJAX action for logged-in users to the callback function
            add_action('wp_ajax_wallregi_bulk_delete_giftcards', [$this, 'wallregi_bulk_delete_giftcards_callback']);

            // Handle AJAX request to auto generate gift card codes
            add_action('wp_ajax_wallregi_auto_generate_coupon_code', [$this, 'wallregi_auto_generate_coupon_code_callback']);

            // Handle AJAX request to download PDF from dashbord table
            add_action('wp_ajax_wallregi_generate_pdf', [$this, 'wallregi_generate_pdf_ajax_handler']);

            add_action('wp_ajax_wallregi_epass_issue_missing_pass', [$this, 'wallregi_epass_issue_missing_pass_ajax_handler']);

            add_action('wp_ajax_wallregi_admin_save_settings', [$this, 'wallregi_ajax_admin_save_settings']);
            add_action('wp_ajax_wallregi_wallet_epass_connect', [$this, 'wallregi_ajax_wallet_epass_connect']);
            add_action('wp_ajax_wallregi_wallet_epass_global_get_templates', [$this, 'wallregi_ajax_wallet_epass_global_get_templates']);
            add_action('wp_ajax_wallregi_wallet_epass_global_get_pass_fields', [$this, 'wallregi_ajax_wallet_epass_global_get_pass_fields']);
            add_action('wp_ajax_wallregi_resend_giftcard_email', [$this, 'wallregi_resend_giftcard_email_callback']);
            add_action('wp_ajax_wallregi_resend_giftcard_sms', [$this, 'wallregi_resend_giftcard_sms_callback']);
        }

        /**
         * Load WC Dependencies
         *
         * @return void
         */
        public function wallregi_load_plugin()
        {
            if (file_exists(WALLREGI_PLUGIN_DIR . 'backend/class-wc-product-wxgiftcard.php')) {
                include_once WALLREGI_PLUGIN_DIR . 'backend/class-wc-product-wxgiftcard.php';
            }

            // Register the custom product class with WooCommerce
            add_filter('woocommerce_product_class', [$this, 'wallregi_product_class'], 10, 2);
        }

        /**
         * Register custom product class for wxgiftcard type
         *
         * @param string $classname The product class name.
         * @param string $product_type The product type.
         * @return string
         */
        public function wallregi_product_class($classname, $product_type)
        {
            if ('wxgiftcard' === $product_type && class_exists('WALLREGI_Product_Wxgiftcard')) {
                return 'WALLREGI_Product_Wxgiftcard';
            }
            return $classname;
        }

        /**
         * Gift Cardd Type
         *
         * @param array $types
         * @return void
         */
        public function wallregi_add_type($types)
        {
            $types['wxgiftcard'] = __('Gift Card', 'wallet-ready-gift-cards-for-woocommerce');

            return $types;
        }

        /**
         * Installing on activation
         *
         * @return void
         */
        // Showing Regular pricing Options for a custom WooCommerce Product Type | hide shipping tabs

        /**
         * Installing on activation
         *
         * @return void
         */
        // Showing Regular pricing Options for a custom WooCommerce Product Type | hide shipping tabs
        public function wallregi_enable_js_on_wc_product()
        {
            global $post;

            if (!$post) {
                return;
            }

            $wallregi_enable_variation_price = get_post_meta($post->ID, '_wallregi_enable_variation_price', true);
            $wallregi_enable_manual_price = get_post_meta($post->ID, '_wallregi_enable_manual_price', true);

            $wallregi_custom_prices = get_post_meta($post->ID, '_wallregi_custom_prices', true);
            $wallregi_custom_prices = is_array($wallregi_custom_prices) ? $wallregi_custom_prices : [];

            // Fetch global min/max from plugin settings
            $plugin_settings = get_option('wallregi_settings', []);
            $wallregi_defaults = [
                'min_cprice' => 1,
                'max_cprice' => 9990,
            ];
            $plugin_settings = wp_parse_args($plugin_settings, $wallregi_defaults);
            $global_min = intval($plugin_settings['min_cprice']);
            $global_max = intval($plugin_settings['max_cprice']);

            // Determine expiry date
            $enable_custom_expiry_date = get_post_meta($post->ID, '_wallregi_enable_custom_expiry_date', true);
            $selected_expiry = get_post_meta($post->ID, '_wallregi_expiry_date', true);  // Saved expiry
            $expiry_value = get_post_meta($post->ID, '_wallregi_expiry_value', true);
            $expiry_duration = get_post_meta($post->ID, '_wallregi_expiry_duration', true);
            $manual_expiry_date = get_post_meta($post->ID, '_wallregi_manual_expiry_date', true);

            if (empty($selected_expiry)) {
                $selected_expiry = '3 months';
            }

            // phpcs:ignore
            $today = date('Y-m-d');
            $wallregi_expiry_date = '';

            if ($enable_custom_expiry_date === 'yes') {
                // Priority: manual expiry date
                if (!empty($manual_expiry_date)) {
                    $wallregi_expiry_date = $manual_expiry_date;
                }
                // Otherwise calculate based on value + duration
                elseif (!empty($expiry_value) && !empty($expiry_duration)) {
                    $date = new DateTime();
                    switch ($expiry_duration) {
                        case 'days':
                            $date->modify("+{$expiry_value} days");
                            break;
                        case 'weeks':
                            $date->modify("+{$expiry_value} weeks");
                            break;
                        case 'months':
                            $date->modify("+{$expiry_value} months");
                            break;
                        case 'years':
                            $date->modify("+{$expiry_value} years");
                            break;
                    }
                    $wallregi_expiry_date = $date->format('Y-m-d');
                } else {
                    // Custom expiry enabled but no manual or calculated expiry — fallback
                    // phpcs:ignore
                    $wallregi_expiry_date = date('Y-m-d', strtotime($selected_expiry));
                }
            } else {
                // Use selected expiry or fallback
                // phpcs:ignore
                $wallregi_expiry_date = date('Y-m-d', strtotime($selected_expiry));
            }

            // Group 1: Custom Price Group
            echo '<div id="wallet-ready-gift-cards-for-woocommerce-admin-product-settings" style="display:none;">
            <div class="options_group wallregi_custom_price_group">';

            // Variation Price Checkbox Field
            woocommerce_wp_checkbox(array(
                'id' => 'wallregi_enable_variation_price',
                'label' => __('Enable Variation Price', 'wallet-ready-gift-cards-for-woocommerce') . ' (' . get_woocommerce_currency_symbol() . ') :',
                'value' => $wallregi_enable_variation_price === 'yes' ? 'yes' : 'no',
            ));

            echo '<div class="wallregi_custom_price_contents">';

            // Manual Price Checkbox Field
            woocommerce_wp_checkbox(array(
                'id' => 'wallregi_enable_manual_price',
                'label' => sprintf(
                    /* translators: %s: currency symbol */
                    __('Enable Manual Price (%s):', 'wallet-ready-gift-cards-for-woocommerce'),
                    esc_html(get_woocommerce_currency_symbol())
                ),
                'value' => $wallregi_enable_manual_price === 'yes' ? 'yes' : 'no',
            ));

            echo '<p class="form-field wallregi-price-row-wrapper">
                         <label>'
                . esc_html__('Custom Gift Card Price', 'wallet-ready-gift-cards-for-woocommerce')
                . ' ('
                . esc_html(get_woocommerce_currency_symbol())
                . '):</label>
                        <span class="wallregi-price-right">
                            <button type="button" class="button add_custom_price_row" style="margin-bottom:10px;">' . esc_html__('Add Price', 'wallet-ready-gift-cards-for-woocommerce') . '</button>
                            <div class="wallregi-price-fields" style="display: none;">';

            if (!empty($wallregi_custom_prices)) {
                foreach ($wallregi_custom_prices as $wallregi_price) {
                    echo '<div class="wallregi-price-input">
                                        <input type="number" step="any" min="' . esc_attr($global_min) . '" max="' . esc_attr($global_max) . '" name="wallregi_custom_prices[]" value="' . esc_attr($wallregi_price) . '" class="small-price-input" />
                                        <button type="button" class="button remove_custom_price_row">×</button>
                                    </div>';
                }
            }

            echo '</div>
                        </span>
                    </p>
                </div>';

            echo '</div>';  // Close wallregi_custom_price_group

            // Group 2: Expiry Date Group
            echo '<div class="options_group wallregi_expiry_date_group">';

            wp_nonce_field('save_giftcard_expiry_date', 'wallregi_expiry_date_nonce');

            woocommerce_wp_select(array(
                'id' => 'wallregi_expiry_date',
                'label' => __('Gift Card Expiry Date', 'wallet-ready-gift-cards-for-woocommerce'),
                'options' => array(
                    '1 month' => __('1 Month', 'wallet-ready-gift-cards-for-woocommerce'),
                    '3 months' => __('3 Months', 'wallet-ready-gift-cards-for-woocommerce'),
                    '6 months' => __('6 Months', 'wallet-ready-gift-cards-for-woocommerce'),
                    '1 year' => __('1 Year', 'wallet-ready-gift-cards-for-woocommerce')
                ),
                'value' => $selected_expiry
            ));

            // Enable Custom Expiry Date checkbox
            woocommerce_wp_checkbox(array(
                'id' => 'wallregi_enable_custom_expiry_date',
                'label' => __('Enable Custom Expiry Date', 'wallet-ready-gift-cards-for-woocommerce'),
                'value' => $enable_custom_expiry_date === 'yes' ? 'yes' : 'no',
            ));

            ?>
                    <div class="wallregi_expiry_date_wrapper">
                        <div class="wallregi_flexbox_top">
                            <div class="row_label_item">
                                <label for="wallregi_expiry_duration"><?php esc_html_e('Custom Expiry Date Options', 'wallet-ready-gift-cards-for-woocommerce'); ?></label> 
                            </div>
                            <div class="wallregi_flexbox_contents">
                                <?php

                                // Expiry Value (number)
                                woocommerce_wp_text_input(array(
                                    'id' => 'wallregi_expiry_value',
                                    'label' => __('Expiry Value', 'wallet-ready-gift-cards-for-woocommerce'),
                                    'type' => 'number',
                                    'value' => $expiry_value,
                                    'custom_attributes' => array('min' => '1'),
                                ));

                                // Expiry Duration (select)
                                woocommerce_wp_select(array(
                                    'id' => 'wallregi_expiry_duration',
                                    'label' => __('Expiry Duration', 'wallet-ready-gift-cards-for-woocommerce'),
                                    'value' => $expiry_duration,
                                    'options' => array(
                                        'days' => __('Days', 'wallet-ready-gift-cards-for-woocommerce'),
                                        'weeks' => __('Weeks', 'wallet-ready-gift-cards-for-woocommerce'),
                                        'months' => __('Months', 'wallet-ready-gift-cards-for-woocommerce'),
                                        'years' => __('Years', 'wallet-ready-gift-cards-for-woocommerce'),
                                    ),
                                ));

                                ?>
                            </div>
                        </div>
                        <div class="wallregi_seperator"><span> -- <?php esc_html_e('OR', 'wallet-ready-gift-cards-for-woocommerce'); ?> -- </span></div>

                        <p class="form-field wallregi_manual_expiry_date_field">
                            <label for="wallregi_manual_expiry_date"><?php esc_html_e('Manual Expiry Date', 'wallet-ready-gift-cards-for-woocommerce'); ?></label>
                            <input type="date"
                                class="short"
                                name="wallregi_manual_expiry_date"
                                id="wallregi_manual_expiry_date"
                                value="<?php echo esc_attr($manual_expiry_date); ?>"
                                min="<?php echo esc_attr($today); ?>"
                                         
                                />

                            <button type="button" class="button" id="clear_manual_expiry_date" style="margin-left:10px;">
                                <?php esc_html_e('Clear', 'wallet-ready-gift-cards-for-woocommerce'); ?>
                            </button>
                        </p>

                    </div>

                <?php

                echo '</div>';  // Close wallregi_expiry_date_group

                // Group 3: Email Schedule Settings
                echo '<div class="options_group wallregi_email_schedule_group">';

                // Get saved meta
                $wallregi_enable_email_schedule = get_post_meta($post->ID, '_wallregi_enable_email_schedule', true);

                // Checkbox: Enable Email Schedule
                woocommerce_wp_checkbox(array(
                    'id' => 'wallregi_enable_email_schedule',
                    'label' => __('Enable Email Schedule', 'wallet-ready-gift-cards-for-woocommerce'),
                    'value' => $wallregi_enable_email_schedule === 'yes' ? 'yes' : 'no',
                ));

                echo '</div>';

                // Group 4: Recipient form — use checkout address instead of product-page form.
                echo '<div class="options_group wallregi_checkout_receiver_group">';

                $wallregi_checkout_receiver_address = get_post_meta($post->ID, '_wallregi_checkout_receiver_address', true);
                $wallregi_checkout_receiver_address = is_string($wallregi_checkout_receiver_address) ? strtolower(trim($wallregi_checkout_receiver_address)) : '';
                if (!in_array($wallregi_checkout_receiver_address, array('billing', 'shipping'), true)) {
                    $wallregi_checkout_receiver_address = '';
                }

                woocommerce_wp_select(
                    array(
                        'id' => 'wallregi_checkout_receiver_address',
                        'name' => 'wallregi_checkout_receiver_address',
                        'label' => __('Recipient details on product page', 'wallet-ready-gift-cards-for-woocommerce'),
                        'desc_tip' => true,
                        'description' => __('When set to billing or shipping, the recipient form is hidden on the product page and details are taken from the customer’s checkout address when the order is placed.', 'wallet-ready-gift-cards-for-woocommerce'),
                        'options' => array(
                            '' => __('Show recipient form (default)', 'wallet-ready-gift-cards-for-woocommerce'),
                            'billing' => __('Hide form — use billing address at checkout', 'wallet-ready-gift-cards-for-woocommerce'),
                            'shipping' => __('Hide form — use shipping address at checkout', 'wallet-ready-gift-cards-for-woocommerce'),
                        ),
                        'value' => $wallregi_checkout_receiver_address,
                    )
                );

                echo '</div>';

                // Group 5: Custom PDF Layout Settings (only shown if enabled globally in Settings Hub)
                $global_custom_pdf_layout_enabled = ($plugin_settings['enable_custom_pdf_layout'] ?? 'no') === 'yes';

                if ($global_custom_pdf_layout_enabled) {
                    echo '<style>
                .woocommerce_options_panel .wallregi_custom_pdf_layout_group,
                #woocommerce-product-data .panel .wallregi_custom_pdf_layout_group {
                    padding: 16px 20px 24px 20px !important;
                    border-top: 1px solid #dcdcde !important;
                    background-color: #fafafa !important;
                    clear: both !important;
                }
                .woocommerce_options_panel .wallregi_custom_pdf_layout_group p.wallregi_enable_custom_pdf_layout_field,
                #woocommerce-product-data .panel .wallregi_custom_pdf_layout_group p.wallregi_enable_custom_pdf_layout_field {
                    margin: 4px 0 14px 0 !important;
                    padding: 5px 20px 5px 162px !important;
                }
                #wallregi_custom_pdf_layout_contents.wallregi-custom-pdf-panel {
                    background: #ffffff !important;
                    border: 1px solid #ccd0d4 !important;
                    border-radius: 8px !important;
                    padding: 22px 24px !important;
                    margin: 15px 0 10px 0 !important;
                    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04) !important;
                    clear: both !important;
                    box-sizing: border-box !important;
                    width: 100% !important;
                }
                #wallregi_custom_pdf_layout_contents .wallregi-custom-pdf-banner {
                    display: flex !important;
                    align-items: flex-start !important;
                    background: #f0f6fc !important;
                    border: 1px solid #c8d7e1 !important;
                    border-left: 4px solid #2271b1 !important;
                    border-radius: 4px !important;
                    padding: 12px 16px !important;
                    margin-bottom: 20px !important;
                }
                #wallregi_custom_pdf_layout_contents .wallregi-custom-pdf-banner .dashicons {
                    font-size: 22px !important;
                    width: 22px !important;
                    height: 22px !important;
                    color: #2271b1 !important;
                    margin-right: 10px !important;
                    margin-top: 1px !important;
                    flex-shrink: 0 !important;
                }
                #wallregi_custom_pdf_layout_contents .wallregi-custom-pdf-banner-text strong {
                    display: block !important;
                    font-size: 13px !important;
                    color: #1d2327 !important;
                    margin-bottom: 3px !important;
                }
                #wallregi_custom_pdf_layout_contents .wallregi-custom-pdf-banner-text p {
                    margin: 0 !important;
                    color: #50575e !important;
                    font-size: 12px !important;
                    line-height: 1.5 !important;
                }
                #wallregi_custom_pdf_layout_contents .wallregi-custom-pdf-field {
                    padding: 0 !important;
                    margin: 0 0 22px 0 !important;
                    float: none !important;
                    clear: both !important;
                    width: 100% !important;
                    box-sizing: border-box !important;
                    display: block !important;
                }
                #wallregi_custom_pdf_layout_contents .wallregi-custom-pdf-field:last-child {
                    margin-bottom: 0 !important;
                }
                #woocommerce-product-data .panel #wallregi_custom_pdf_layout_contents label,
                .woocommerce_options_panel #wallregi_custom_pdf_layout_contents label,
                #wallregi_custom_pdf_layout_contents label.wallregi-custom-pdf-label {
                    display: flex !important;
                    align-items: center !important;
                    float: none !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    margin: 0 0 4px 0 !important;
                    padding: 0 !important;
                    font-size: 13px !important;
                    font-weight: 600 !important;
                    color: #1d2327 !important;
                    text-align: left !important;
                    line-height: 1.4 !important;
                    cursor: default !important;
                }
                #wallregi_custom_pdf_layout_contents label.wallregi-custom-pdf-label .dashicons {
                    font-size: 18px !important;
                    width: 18px !important;
                    height: 18px !important;
                    margin-right: 6px !important;
                    color: #2271b1 !important;
                }
                #woocommerce-product-data .panel #wallregi_custom_pdf_layout_contents .wallregi-custom-pdf-desc,
                .woocommerce_options_panel #wallregi_custom_pdf_layout_contents .wallregi-custom-pdf-desc,
                #wallregi_custom_pdf_layout_contents .wallregi-custom-pdf-desc {
                    display: block !important;
                    float: none !important;
                    margin: 0 0 10px 0 !important;
                    padding: 0 !important;
                    color: #646970 !important;
                    font-size: 12px !important;
                    font-style: normal !important;
                    line-height: 1.5 !important;
                    clear: both !important;
                }
                #wallregi_custom_pdf_layout_contents .wallregi-placeholders-wrapper {
                    display: flex !important;
                    flex-wrap: wrap !important;
                    gap: 8px !important;
                    margin: 6px 0 0 0 !important;
                    padding: 12px 14px !important;
                    background: #f6f7f7 !important;
                    border: 1px solid #dcdcde !important;
                    border-radius: 6px !important;
                    box-sizing: border-box !important;
                }
                #wallregi_custom_pdf_layout_contents button.wallregi-placeholder-tag {
                    cursor: pointer !important;
                    display: inline-flex !important;
                    align-items: center !important;
                    gap: 6px !important;
                    padding: 5px 10px !important;
                    background: #ffffff !important;
                    border: 1px solid #c3c4c7 !important;
                    border-radius: 4px !important;
                    font-size: 12px !important;
                    line-height: 1.4 !important;
                    color: #1d2327 !important;
                    user-select: none !important;
                    transition: all 0.15s ease-in-out !important;
                    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04) !important;
                    height: auto !important;
                    margin: 0 !important;
                }
                #wallregi_custom_pdf_layout_contents button.wallregi-placeholder-tag code {
                    font-family: Consolas, Monaco, "Courier New", monospace !important;
                    font-size: 12px !important;
                    color: #2271b1 !important;
                    background: transparent !important;
                    padding: 0 !important;
                    margin: 0 !important;
                    font-weight: 600 !important;
                }
                #wallregi_custom_pdf_layout_contents button.wallregi-placeholder-tag .wallregi-tag-label {
                    font-size: 11px !important;
                    color: #646970 !important;
                    border-left: 1px solid #dcdcde !important;
                    padding-left: 6px !important;
                }
                #wallregi_custom_pdf_layout_contents button.wallregi-placeholder-tag:hover {
                    background: #2271b1 !important;
                    border-color: #2271b1 !important;
                    color: #ffffff !important;
                    transform: translateY(-1px) !important;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12) !important;
                }
                #wallregi_custom_pdf_layout_contents button.wallregi-placeholder-tag:hover code {
                    color: #ffffff !important;
                }
                #wallregi_custom_pdf_layout_contents button.wallregi-placeholder-tag:hover .wallregi-tag-label {
                    color: #e0e7ff !important;
                    border-left-color: rgba(255, 255, 255, 0.4) !important;
                }
                #wallregi_custom_pdf_layout_contents button.wallregi-placeholder-tag.is-copied {
                    background: #008a20 !important;
                    border-color: #008a20 !important;
                    color: #ffffff !important;
                }
                #wallregi_custom_pdf_layout_contents button.wallregi-placeholder-tag.is-copied code,
                #wallregi_custom_pdf_layout_contents button.wallregi-placeholder-tag.is-copied .wallregi-tag-label {
                    color: #ffffff !important;
                }
                #wallregi_custom_pdf_layout_contents textarea.wallregi-css-editor {
                    width: 100% !important;
                    max-width: 100% !important;
                    min-height: 180px !important;
                    font-family: Consolas, Monaco, "Courier New", monospace !important;
                    font-size: 13px !important;
                    line-height: 1.5 !important;
                    border: 1px solid #8c8f94 !important;
                    border-radius: 4px !important;
                    padding: 12px 14px !important;
                    background: #fdfdfd !important;
                    color: #1d2327 !important;
                    box-sizing: border-box !important;
                    display: block !important;
                    float: none !important;
                    margin: 0 !important;
                    resize: vertical !important;
                }
                #wallregi_custom_pdf_layout_contents textarea.wallregi-css-editor:focus {
                    background: #ffffff !important;
                    border-color: #2271b1 !important;
                    box-shadow: 0 0 0 1px #2271b1 !important;
                    outline: none !important;
                }
                #wallregi_custom_pdf_layout_contents .wallregi-tinymce-wrapper {
                    width: 100% !important;
                    max-width: 100% !important;
                    display: block !important;
                    float: none !important;
                    clear: both !important;
                    margin-top: 6px !important;
                    overflow: hidden !important;
                }
                #wallregi_custom_pdf_layout_contents .wp-editor-wrap.html-active #wallregi_custom_pdf_html {
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                    border: 1px solid #8c8f94 !important;
                    border-top: none !important;
                    border-radius: 0 0 4px 4px !important;
                    padding: 12px 14px !important;
                    font-family: Consolas, Monaco, "Courier New", monospace !important;
                    font-size: 13px !important;
                    line-height: 1.6 !important;
                    white-space: pre-wrap !important;
                    word-wrap: break-word !important;
                    overflow-wrap: break-word !important;
                    resize: vertical !important;
                    background: #fdfdfd !important;
                    color: #1d2327 !important;
                    display: block !important;
                    float: none !important;
                    margin: 0 !important;
                }
                #wallregi_custom_pdf_layout_contents .wp-editor-wrap.html-active #wallregi_custom_pdf_html:focus {
                    background: #ffffff !important;
                    border-color: #2271b1 !important;
                    box-shadow: 0 0 0 1px #2271b1 !important;
                    outline: none !important;
                }
                #wallregi_custom_pdf_layout_contents .wp-editor-wrap {
                    width: 100% !important;
                    box-sizing: border-box !important;
                }
                #wallregi_custom_pdf_layout_contents .wp-editor-tools {
                    clear: both !important;
                }
                </style>';

                    echo '<div class="options_group wallregi_custom_pdf_layout_group">';

                    $wallregi_enable_custom_pdf_layout = get_post_meta($post->ID, '_wallregi_enable_custom_pdf_layout', true);
                    $wallregi_custom_pdf_css = get_post_meta($post->ID, '_wallregi_custom_pdf_css', true);
                    $wallregi_custom_pdf_html = get_post_meta($post->ID, '_wallregi_custom_pdf_html', true);

                    // Checkbox: Enable Custom PDF Layout
                    woocommerce_wp_checkbox(array(
                        'id' => 'wallregi_enable_custom_pdf_layout',
                        'name' => 'wallregi_enable_custom_pdf_layout',
                        'label' => __('Enable Custom PDF Layout', 'wallet-ready-gift-cards-for-woocommerce'),
                        'description' => __('Enable custom HTML and CSS layout for this gift card product.', 'wallet-ready-gift-cards-for-woocommerce'),
                        'desc_tip' => false,
                        'value' => $wallregi_enable_custom_pdf_layout === 'yes' ? 'yes' : 'no',
                    ));

                    // Container for conditional options (Placeholders, CSS, TinyMCE HTML)
                    $is_custom_pdf_enabled = ($wallregi_enable_custom_pdf_layout === 'yes');
                    echo '<div id="wallregi_custom_pdf_layout_contents" class="wallregi-custom-pdf-panel" style="display:' . ($is_custom_pdf_enabled ? 'block' : 'none') . ';">';

                    // Notice Banner
                    echo '<div class="wallregi-custom-pdf-banner">';
                    echo '<span class="dashicons dashicons-media-document"></span>';
                    echo '<div class="wallregi-custom-pdf-banner-text">';
                    echo '<strong>' . esc_html__('Custom PDF Layout Designer (Applies to PDF Download Only)', 'wallet-ready-gift-cards-for-woocommerce') . '</strong>';
                    echo '<p>' . esc_html__('Define custom HTML structure and CSS styling for this gift card product. This custom design will apply exclusively to the generated PDF download for this gift card, while the frontend single gift card page continues to show the standard default preview.', 'wallet-ready-gift-cards-for-woocommerce') . '</p>';
                    echo '</div>';
                    echo '</div>';

                    // 1. Placeholders (Click to copy into HTML or CSS)
                    $placeholders = [
                        '[giftcard_title]' => __('Gift Card Title', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[giftcard_price]' => __('Formatted Price', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[giftcard_code]' => __('Gift Card Code', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[giftcard_image]' => __('Card Artwork Image', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[giftcard_logo]' => __('Card Logo', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[giftcard_scannable]' => __('Barcode / QR Code', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[giftcard_qrcode]' => __('QR Code Only', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[giftcard_barcode]' => __('Barcode Only', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[giftcard_expiry]' => __('Expiry Date', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[giftcard_date]' => __('Issue Date', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[giftcard_message]' => __('Personal Message', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[giftcard_footer]' => __('Short Description / Footer', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[site_title]' => __('Site Title', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[site_url]' => __('Site URL', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[recipient_name]' => __('Recipient Name', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[recipient_email]' => __('Recipient Email', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[sender_name]' => __('Sender Name', 'wallet-ready-gift-cards-for-woocommerce'),
                        '[apply_url]' => __('One-click Redeem URL', 'wallet-ready-gift-cards-for-woocommerce'),
                    ];

                    echo '<div class="wallregi-custom-pdf-field wallregi-custom-pdf-placeholders-row">';
                    echo '<label class="wallregi-custom-pdf-label"><span class="dashicons dashicons-tag"></span>' . esc_html__('Placeholders (Click to copy or insert into editor)', 'wallet-ready-gift-cards-for-woocommerce') . '</label>';
                    echo '<p class="wallregi-custom-pdf-desc">' . esc_html__('Click any placeholder tag below to copy it to your clipboard or insert it directly at the cursor position in the HTML editor.', 'wallet-ready-gift-cards-for-woocommerce') . '</p>';
                    echo '<div class="wallregi-placeholders-wrapper">';
                    foreach ($placeholders as $tag => $label) {
                        echo '<button type="button" class="wallregi-placeholder-tag" data-placeholder="' . esc_attr($tag) . '" title="' . esc_attr($label . ' — ' . __('Click to copy/insert', 'wallet-ready-gift-cards-for-woocommerce')) . '">';
                        echo '<code>' . esc_html($tag) . '</code>';
                        echo '<span class="wallregi-tag-label">' . esc_html($label) . '</span>';
                        echo '</button>';
                    }
                    echo '</div>';
                    echo '</div>';

                    // 2. Custom PDF CSS (textarea)
                    echo '<div class="wallregi-custom-pdf-field wallregi-custom-pdf-css-row">';
                    echo '<label for="wallregi_custom_pdf_css" class="wallregi-custom-pdf-label"><span class="dashicons dashicons-editor-code"></span>' . esc_html__('Custom PDF CSS', 'wallet-ready-gift-cards-for-woocommerce') . '</label>';
                    echo '<p class="wallregi-custom-pdf-desc">' . esc_html__('Add custom CSS stylesheet rules for this gift card product preview and PDF.', 'wallet-ready-gift-cards-for-woocommerce') . '</p>';
                    echo '<textarea name="wallregi_custom_pdf_css" id="wallregi_custom_pdf_css" rows="9" class="wallregi-css-editor" placeholder="' . esc_attr('.custom-card { padding: 20px; font-family: sans-serif; }') . '">' . esc_textarea($wallregi_custom_pdf_css) . '</textarea>';
                    echo '</div>';

                    // 3. Custom PDF HTML Content (TinyMCE)
                    echo '<div class="wallregi-custom-pdf-field wallregi-custom-pdf-html-row">';
                    echo '<label for="wallregi_custom_pdf_html" class="wallregi-custom-pdf-label"><span class="dashicons dashicons-layout"></span>' . esc_html__('Custom PDF HTML Content (Visual / HTML)', 'wallet-ready-gift-cards-for-woocommerce') . '</label>';
                    echo '<p class="wallregi-custom-pdf-desc">' . esc_html__('Design your layout using the visual or HTML editor. Use the placeholders above to insert dynamic gift card details.', 'wallet-ready-gift-cards-for-woocommerce') . '</p>';
                    echo '<div class="wallregi-tinymce-wrapper">';
                    wp_editor(
                        $wallregi_custom_pdf_html,
                        'wallregi_custom_pdf_html',
                        array(
                            'textarea_name' => 'wallregi_custom_pdf_html',
                            'textarea_rows' => 16,
                            'media_buttons' => true,
                            'teeny' => false,
                            'quicktags' => true,
                        )
                    );
                    echo '</div>';
                    echo '</div>';

                    echo '</div>';  // Close wallregi_custom_pdf_layout_contents
                    echo '</div>';  // Close wallregi_custom_pdf_layout_group
                }

                /**
                 * Allow extensions (e.g. Pro) to output extra fields for wxgiftcard products.
                 *
                 * @param WP_Post $post Product post object.
                 */
                do_action('wallregi_after_giftcard_product_admin_fields', $post);

                echo '</div>';  // Close wallet-ready-gift-cards-for-woocommerce-admin-product-settings
                // Save custom prices scripts

                ?>
            <script>
                jQuery(function($) {
                    const container = $('.wallregi-price-fields');

                    $('.add_custom_price_row').on('click', function(e) {
                        e.preventDefault();
                        container.show();

                        container.append(
                            '<div class=\"wallregi-price-input\">' +
                            '<input type=\"number\" step=\"any\" min=\"{$global_min}\" max=\"{$global_max}\" name=\"wallregi_custom_prices[]\" value=\"\" class=\"small-price-input\" /> ' +
                            '<button type=\"button\" class=\"button remove_custom_price_row\">×</button>' +
                            '</div>'
                        );
                    });

                    $(document).on('click', '.remove_custom_price_row', function(e) {
                        e.preventDefault();
                        $(this).closest('.wallregi-price-input').remove();

                        if (container.children('.wallregi-price-input').length === 0) {
                            container.hide();
                        }
                    });

                    if (container.children('.wallregi-price-input').length > 0) {
                        container.show();
                    }
                });

                jQuery(function($) {
                    const productType = $('#product-type').val();
                    if (productType === 'wxgiftcard') {
                        $('#wallet-ready-gift-cards-for-woocommerce-admin-product-settings').show();
                    } else {
                        $('#wallet-ready-gift-cards-for-woocommerce-admin-product-settings').hide();
                    }
                    
                    $('#product-type').on('change', function() {
                        const productType = $(this).val();
                        if (productType === 'wxgiftcard') {
                            $('#wallet-ready-gift-cards-for-woocommerce-admin-product-settings').show();
                        } else {
                            $('#wallet-ready-gift-cards-for-woocommerce-admin-product-settings').hide();
                        }
                    });
                    const container = $('.wallregi-price-fields');
                    const variationCheckbox = $('#wallregi_enable_variation_price');
                    const regularPriceRow = $('._regular_price_field');
                    const salePriceRow = $('._sale_price_field');
                    const customPriceWrapper = $('.wallregi_custom_price_contents');


                    function toggleCustomPriceFields() {
                        if (variationCheckbox.is(':checked')) {
                            container.show();
                            regularPriceRow.hide();
                            //salePriceRow.hide();
                            customPriceWrapper.show();

                        } else {
                            regularPriceRow.show();
                            //salePriceRow.show();
                            customPriceWrapper.hide();

                        }
                    }

                    // Initial call
                    toggleCustomPriceFields();

                    // On checkbox change
                    variationCheckbox.on('change', function() {
                        toggleCustomPriceFields();
                    });



                    // Remove price row
                    $(document).on('click', '.remove_custom_price_row', function(e) {
                        e.preventDefault();
                        $(this).closest('.wallregi-price-input').remove();
                        if (container.children('.wallregi-price-input').length === 0) {
                            container.hide();
                        }
                    });

                    if (container.children('.wallregi-price-input').length > 0) {
                        container.show();
                    }
                });

                jQuery(document).ready(function($) {

                    // Toggle custom expiry wrapper
                    function toggleExpiryDateWrapper() {
                        var checkbox = document.getElementById('wallregi_enable_custom_expiry_date');
                        var wrapper = document.querySelector('.wallregi_expiry_date_wrapper');
                        if (checkbox && wrapper) {
                            wrapper.style.display = checkbox.checked ? 'block' : 'none';
                        }
                    }

                    // Uncheck the custom expiry checkbox when a select option is changed
                    $('#wallregi_expiry_date').on('change', function() {
                        if (this.value !== '') {
                            $('#wallregi_enable_custom_expiry_date').prop('checked', false).trigger('change');
                            toggleExpiryDateWrapper();
                        }
                    });

                    // Run on load
                    toggleExpiryDateWrapper();

                    // Bind checkbox change
                    $('#wallregi_enable_custom_expiry_date').on('change', function() {
                        toggleExpiryDateWrapper();
                    });

                    // Clear Manual Expiry Date button
                    $('#clear_manual_expiry_date').on('click', function() {
                        $('#wallregi_manual_expiry_date').val('');
                    });

                    // Toggle Custom PDF Layout options
                    const customPdfCheckbox = $('#wallregi_enable_custom_pdf_layout');
                    const customPdfContents = $('#wallregi_custom_pdf_layout_contents');

                    function toggleCustomPdfFields() {
                        if (customPdfCheckbox.is(':checked')) {
                            customPdfContents.slideDown(200);
                        } else {
                            customPdfContents.slideUp(200);
                        }
                    }

                    customPdfCheckbox.on('change', toggleCustomPdfFields);

                    // Fallback copy-to-clipboard for non-HTTPS / older browsers
                    function wallregiFallbackCopy(text) {
                        var tmp = document.createElement('textarea');
                        tmp.value = text;
                        tmp.style.position = 'fixed';
                        tmp.style.left = '-9999px';
                        tmp.style.top = '-9999px';
                        document.body.appendChild(tmp);
                        tmp.focus();
                        tmp.select();
                        try { document.execCommand('copy'); } catch (err) { /* silent */ }
                        document.body.removeChild(tmp);
                    }

                    // Placeholders click-to-copy and insert into TinyMCE
                    $(document).on('click', '.wallregi-placeholder-tag', function(e) {
                        e.preventDefault();
                        const tag = $(this).data('placeholder');
                        if (!tag) return;

                        // Copy to clipboard with fallback
                        if (navigator.clipboard && window.isSecureContext) {
                            navigator.clipboard.writeText(tag).catch(function() {
                                wallregiFallbackCopy(tag);
                            });
                        } else {
                            wallregiFallbackCopy(tag);
                        }

                        let insertedIntoEditor = false;
                        if (window.tinymce && window.tinymce.get('wallregi_custom_pdf_html')) {
                            const editor = window.tinymce.get('wallregi_custom_pdf_html');
                            if (!editor.isHidden()) {
                                editor.insertContent(tag);
                                insertedIntoEditor = true;
                            }
                        }

                        if (!insertedIntoEditor) {
                            const $textarea = $('#wallregi_custom_pdf_html');
                            if ($textarea.length) {
                                const el = $textarea[0];
                                const start = el.selectionStart || 0;
                                const end = el.selectionEnd || 0;
                                const val = el.value;
                                el.value = val.substring(0, start) + tag + val.substring(end);
                                el.selectionStart = el.selectionEnd = start + tag.length;
                                $textarea.trigger('change');
                            }
                        }

                        const self = $(this);
                        const originalHtml = self.html();
                        self.addClass('is-copied').html('<code>✓ Copied!</code>');
                        setTimeout(function() {
                            self.removeClass('is-copied').html(originalHtml);
                        }, 1200);
                    });

                });

                jQuery(document).ready(function($) {
                    const productType = $('#product-type').val();
                    if (productType === 'wxgiftcard') {
                        $('#postimagediv,#woocommerce-product-images').append('<div class=\"wxgiftcard-image-size-hints\">".esc_html__('🖼️ Recommended Gift Card PDF Image Size: 923×400 px', 'wallet-ready-gift-cards-for-woocommerce')."</div>');
                        $('.product_data_tabs .general_options').addClass('active').show();
                        $('.product_data_tabs .marketplace-suggestions_options').removeClass('active');
                        $('.options_group.pricing').removeClass('hidden').show();
                        $('#_virtual').parent().show();
                        $('#general_product_data').show();
                        $('#_virtual').attr('checked', true);
                        $('.woocommerce_options_panel').not('#general_product_data').hide();
                        $('.form-field._sale_price_field').hide();
                    }

                    $('body').on('woocommerce-product-type-change', function(e, type) {

                        if (type === 'wxgiftcard') {
                            $('#postimagediv,#woocommerce-product-images').append('<div class=\"wxgiftcard-image-size-hints\">".esc_html__('🖼️ Recommended Gift Card PDF Image Size: 923×400 px', 'wallet-ready-gift-cards-for-woocommerce')."</div>');
                            $('.product_data_tabs .general_options').addClass('active').show();
                            $('.product_data_tabs .marketplace-suggestions_options').removeClass('active');
                            $('.options_group.pricing').removeClass('hidden').show();
                            $('#_virtual').parent().show();
                            $('#general_product_data').show();
                            $('#_virtual').attr('checked', true);
                            $('.woocommerce_options_panel').not('#general_product_data').hide();
                            $('.form-field._sale_price_field').hide();
                        }else{
                            $('#postimagediv .wxgiftcard-image-size-hints,#woocommerce-product-images .wxgiftcard-image-size-hints').remove();
                            $('.form-field._sale_price_field').show();
                        }
                    });
                });

               </script>
               <?php
        }

        public function wallregi_save_giftcard_settings_data($post_id)
        {
            // Check if the nonce is set and is valid
            if (!isset($_POST['wallregi_expiry_date_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wallregi_expiry_date_nonce'])), 'save_giftcard_expiry_date')) {
                return;
            }

            // Fetch global min/max from plugin settings
            $plugin_settings = get_option('wallregi_settings', []);
            $wallregi_defaults = [
                'min_cprice' => 1,
                'max_cprice' => 9990,
            ];
            $plugin_settings = wp_parse_args($plugin_settings, $wallregi_defaults);
            $global_min = intval($plugin_settings['min_cprice']);
            $global_max = intval($plugin_settings['max_cprice']);

            // Save custom price options (multiple)
            if (isset($_POST['wallregi_custom_prices']) && is_array($_POST['wallregi_custom_prices'])) {
                $validated = [];
                // Each entry is cast and sanitized in the loop (PHPCS cannot infer array element sanitization).
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized per element below.
                $raw_prices = wp_unslash($_POST['wallregi_custom_prices']);

                foreach ($raw_prices as $raw) {
                    if (!is_scalar($raw)) {
                        continue;
                    }

                    $sanitized_raw = sanitize_text_field((string) $raw);
                    $wallregi_price = (int) $sanitized_raw;

                    // Clamp to [min, max]
                    if ($wallregi_price < $global_min) {
                        $wallregi_price = $global_min;
                    } elseif ($wallregi_price > $global_max) {
                        $wallregi_price = $global_max;
                    }

                    // Only save positive, non-zero
                    if ($wallregi_price > 0) {
                        $validated[] = $wallregi_price;
                    }
                }

                // Update or delete meta
                if (!empty($validated)) {
                    update_post_meta($post_id, '_wallregi_custom_prices', $validated);
                } else {
                    delete_post_meta($post_id, '_wallregi_custom_prices');
                }
            } else {
                delete_post_meta($post_id, '_wallregi_custom_prices');
            }

            // Save variation price options
            if (isset($_POST['wallregi_enable_variation_price'])) {
                update_post_meta($post_id, '_wallregi_enable_variation_price', 'yes');
            } else {
                update_post_meta($post_id, '_wallregi_enable_variation_price', 'no');
            }

            // Save manual price options
            if (isset($_POST['wallregi_enable_manual_price'])) {
                update_post_meta($post_id, '_wallregi_enable_manual_price', 'yes');
            } else {
                update_post_meta($post_id, '_wallregi_enable_manual_price', 'no');
            }

            // Save expiry date options
            if (isset($_POST['wallregi_expiry_date'])) {
                update_post_meta($post_id, '_wallregi_expiry_date', sanitize_text_field(wp_unslash($_POST['wallregi_expiry_date'])));
            }

            // Save custom expiry date checkbox
            if (isset($_POST['wallregi_enable_custom_expiry_date'])) {
                update_post_meta($post_id, '_wallregi_enable_custom_expiry_date', 'yes');
            } else {
                update_post_meta($post_id, '_wallregi_enable_custom_expiry_date', 'no');
            }

            // Save expiry value (number)
            if (!empty($_POST['wallregi_expiry_value'])) {
                update_post_meta($post_id, '_wallregi_expiry_value', intval(wp_unslash($_POST['wallregi_expiry_value'])));
            } else {
                delete_post_meta($post_id, '_wallregi_expiry_value');
            }

            // Save expiry duration (select)
            if (!empty($_POST['wallregi_expiry_duration'])) {
                update_post_meta($post_id, '_wallregi_expiry_duration', sanitize_text_field(wp_unslash($_POST['wallregi_expiry_duration'])));
            } else {
                delete_post_meta($post_id, '_wallregi_expiry_duration');
            }

            // Save manual expiry date (text input - date format)
            if (!empty($_POST['wallregi_manual_expiry_date'])) {
                update_post_meta($post_id, '_wallregi_manual_expiry_date', sanitize_text_field(wp_unslash($_POST['wallregi_manual_expiry_date'])));
            } else {
                delete_post_meta($post_id, '_wallregi_manual_expiry_date');
            }

            // Save enable email schedule checkbox
            if (isset($_POST['wallregi_enable_email_schedule'])) {
                update_post_meta($post_id, '_wallregi_enable_email_schedule', 'yes');
            } else {
                update_post_meta($post_id, '_wallregi_enable_email_schedule', 'no');
            }

            // Recipient form: use checkout billing/shipping instead of product form.
            if (isset($_POST['wallregi_checkout_receiver_address'])) {
                $addr = sanitize_text_field(wp_unslash($_POST['wallregi_checkout_receiver_address']));
                $addr = strtolower(trim($addr));
                if (in_array($addr, array('billing', 'shipping'), true)) {
                    update_post_meta($post_id, '_wallregi_checkout_receiver_address', $addr);
                } else {
                    delete_post_meta($post_id, '_wallregi_checkout_receiver_address');
                }
            } else {
                delete_post_meta($post_id, '_wallregi_checkout_receiver_address');
            }

            // Save custom PDF layout options (only if globally enabled in Settings Hub)
            $wallregi_global_settings = get_option('wallregi_settings', []);
            if (($wallregi_global_settings['enable_custom_pdf_layout'] ?? 'no') === 'yes') {
                if (isset($_POST['wallregi_enable_custom_pdf_layout'])) {
                    update_post_meta($post_id, '_wallregi_enable_custom_pdf_layout', 'yes');
                } else {
                    update_post_meta($post_id, '_wallregi_enable_custom_pdf_layout', 'no');
                }

                if (isset($_POST['wallregi_custom_pdf_css'])) {
                    update_post_meta($post_id, '_wallregi_custom_pdf_css', wp_strip_all_tags(wp_unslash((string) $_POST['wallregi_custom_pdf_css'])));
                }

                if (isset($_POST['wallregi_custom_pdf_html'])) {
                    update_post_meta($post_id, '_wallregi_custom_pdf_html', wp_kses_post(wp_unslash((string) $_POST['wallregi_custom_pdf_html'])));
                }
            }

            /**
             * After core wxgiftcard product meta is saved (nonce already verified).
             *
             * @param int $post_id Product post ID.
             */
            do_action('wallregi_save_giftcard_product_meta', $post_id);
        }

        /**
         * Register top-level "GiftRocket" admin menu and the main Gift Cards screen.
         */
        public function wallregi_add_giftcard_submenu_options()
        {
            $parent_slug = wallregi_gift_cards_parent_menu_slug();
            $menu_title = apply_filters(
                'wallregi_gift_rocket_menu_title',
                __('GiftRocket', 'wallet-ready-gift-cards-for-woocommerce')
            );

            add_menu_page(
                $menu_title,
                $menu_title,
                'manage_woocommerce',
                $parent_slug,
                [$this, 'wallregi_giftcard_page_callback'],
                'dashicons-awards',
                56
            );

            // Replaces the duplicate top-level submenu entry with a clear "Gift Cards" label (same screen).
            add_submenu_page(
                $parent_slug,
                __('Gift Cards', 'wallet-ready-gift-cards-for-woocommerce'),
                __('Gift Cards', 'wallet-ready-gift-cards-for-woocommerce'),
                'manage_woocommerce',
                $parent_slug,
                [$this, 'wallregi_giftcard_page_callback']
            );
        }

        /**
         * Render custom wxgiftcard type fields in WooCommerce product panel
         */
        public function wallregi_admin_enqueue_backend_assets()
        {
            // flatpickr CSS
            wp_enqueue_style(
                'wallregi_flatpickr_css',
                WALLREGI_PLUGIN_URL . 'backend/assets/css/flatpickr.min.css',
                [],
                WALLREGI_VERSION,
                'all'
            );

            // Backend CSS For Admin Dashboard
            wp_enqueue_style('wallregi_wp_admin_style', WALLREGI_PLUGIN_URL . 'backend/assets/css/backend.css', [], WALLREGI_VERSION, 'all');
            wp_enqueue_style('wallregi_dashboard_option_style', WALLREGI_PLUGIN_URL . 'backend/assets/css/dashboard.css', [], WALLREGI_VERSION, 'all');
            // Features page styles
            wp_enqueue_style('wallregi_features_style', WALLREGI_PLUGIN_URL . 'backend/assets/css/features.css', [], WALLREGI_VERSION, 'all');

            wp_enqueue_media();

            // flatpickr JS
            wp_enqueue_script(
                'wallregi_flatpickr_script',
                WALLREGI_PLUGIN_URL . 'backend/assets/js/flatpickr.min.js',
                ['jquery'],
                WALLREGI_VERSION,
                true
            );

            // Backend Scripts For Admin Dashboard
            wp_enqueue_script('wallregi_wp_admin_script', WALLREGI_PLUGIN_URL . 'backend/assets/js/backend.js', array('jquery'), WALLREGI_VERSION, true);
            wp_enqueue_script('wallregi_dashboard_option_script', WALLREGI_PLUGIN_URL . 'backend/assets/js/dashboard.js', [], WALLREGI_VERSION, true);
            wp_enqueue_script('wallregi_dashboard_email_settings', WALLREGI_PLUGIN_URL . 'backend/assets/js/dashboard-email-settings.js', [], WALLREGI_VERSION, true);
            wp_enqueue_script('wallregi_manual_giftcard_settings', WALLREGI_PLUGIN_URL . 'backend/assets/js/manual-giftcard.js', [], WALLREGI_VERSION, true);
            wp_enqueue_script(
                'wallregi_scheduled_deliveries',
                WALLREGI_PLUGIN_URL . 'backend/assets/js/scheduled-deliveries.js',
                [],
                WALLREGI_VERSION,
                true
            );

            $wallregi_screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if ($wallregi_screen && $wallregi_screen->id === 'toplevel_page_wx-gift-cards') {
                require_once WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-admin-settings-persistence.php';
                wp_enqueue_script(
                    'wallregi_admin_settings',
                    WALLREGI_PLUGIN_URL . 'backend/assets/js/admin-settings.js',
                    [],
                    WALLREGI_VERSION,
                    true
                );
                wp_localize_script(
                    'wallregi_admin_settings',
                    'wallregiAdminSettings',
                    [
                        'ajaxUrl' => admin_url('admin-ajax.php'),
                        'nonce' => wp_create_nonce('wallregi_admin_save_settings'),
                        'hubTabKeys' => wallregi_admin_settings_hub_tab_keys(),
                        'strings' => [
                            'saved' => __('Settings saved.', 'wallet-ready-gift-cards-for-woocommerce'),
                            'saveFailed' => __('Could not save settings. Please try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                            'saving' => __('Saving…', 'wallet-ready-gift-cards-for-woocommerce'),
                            'network' => __('Network error. Check your connection and try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                            'walletEnterKey' => __('Enter your API key to connect.', 'wallet-ready-gift-cards-for-woocommerce'),
                            'walletConnecting' => __('Connecting…', 'wallet-ready-gift-cards-for-woocommerce'),
                            'walletExpiryUtcPrefix' => __('API key refresh time (UTC): ', 'wallet-ready-gift-cards-for-woocommerce'),
                        ],
                    ]
                );

                $wallregi_global_epass_js = WALLREGI_PLUGIN_DIR . 'backend/assets/js/admin-wallet-global-pass-config.js';
                if (file_exists($wallregi_global_epass_js)) {
                    wp_enqueue_script(
                        'wallregi_wallet_global_pass',
                        WALLREGI_PLUGIN_URL . 'backend/assets/js/admin-wallet-global-pass-config.js',
                        ['jquery'],
                        WALLREGI_VERSION,
                        true
                    );
                    $wallregi_wallet_ctx_boot = wallregi_admin_settings_bootstrap_wallet();
                    $wallregi_wallet_bootstrap = $wallregi_wallet_ctx_boot['wallregi_wallet_settings'];
                    $wallregi_saved_global = isset($wallregi_wallet_bootstrap['epass_global_pass_config']) && is_array($wallregi_wallet_bootstrap['epass_global_pass_config'])
                        ? $wallregi_wallet_bootstrap['epass_global_pass_config']
                        : [];
                    $wallregi_stripe_url = isset($wallregi_wallet_bootstrap['epass_global_stripe_image_url'])
                        ? (string) $wallregi_wallet_bootstrap['epass_global_stripe_image_url']
                        : '';
                    $wallregi_gift_elements = [];
                    if (class_exists('WALLREGI_Wallet_Epass_Product_Admin')) {
                        foreach (WALLREGI_Wallet_Epass_Product_Admin::get_gift_element_labels() as $slug => $label) {
                            $wallregi_gift_elements[] = [
                                'slug' => (string) $slug,
                                'label' => (string) $label,
                            ];
                        }
                    }
                    wp_localize_script(
                        'wallregi_wallet_global_pass',
                        'wallregiGlobalWalletEpass',
                        [
                            'ajaxUrl' => admin_url('admin-ajax.php'),
                            'nonce' => wp_create_nonce('wallregi_admin_save_settings'),
                            'giftElements' => $wallregi_gift_elements,
                            'savedConfig' => [
                                'template_uid' => isset($wallregi_saved_global['template_uid']) ? (string) $wallregi_saved_global['template_uid'] : '',
                                'template_name' => isset($wallregi_saved_global['template_name']) ? (string) $wallregi_saved_global['template_name'] : '',
                                'template_id' => isset($wallregi_saved_global['template_id']) ? (int) $wallregi_saved_global['template_id'] : 0,
                                'mapping' => isset($wallregi_saved_global['mapping']) && is_array($wallregi_saved_global['mapping']) ? $wallregi_saved_global['mapping'] : [],
                                'pass_fields' => isset($wallregi_saved_global['pass_fields']) && is_array($wallregi_saved_global['pass_fields']) ? $wallregi_saved_global['pass_fields'] : [],
                                'stripe_url' => $wallregi_stripe_url,
                            ],
                            'strings' => [
                                'loadingTemplates' => __('Loading templates…', 'wallet-ready-gift-cards-for-woocommerce'),
                                'loadingFields' => __('Loading pass fields…', 'wallet-ready-gift-cards-for-woocommerce'),
                                'loadFailed' => __('Could not load data from ePasscard.', 'wallet-ready-gift-cards-for-woocommerce'),
                                'notMapped' => __('— Not mapped —', 'wallet-ready-gift-cards-for-woocommerce'),
                                'selectTemplate' => __('— Select —', 'wallet-ready-gift-cards-for-woocommerce'),
                                'stripePick' => __('Select image', 'wallet-ready-gift-cards-for-woocommerce'),
                                'stripeFrameTitle' => __('Wallet pass stripe image', 'wallet-ready-gift-cards-for-woocommerce'),
                                'stripeUse' => __('Use this image', 'wallet-ready-gift-cards-for-woocommerce'),
                            ],
                        ]
                    );
                }
            }

            wp_localize_script('wallregi_wp_admin_script', 'wallregi_backend_obj', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wallregi_admin_nonce')
            ));

            wp_localize_script('wallregi_dashboard_option_script', 'wallregi_dashboard_obj', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wallregi_nonce_action'),
                'strings' => array(
                    /* translators: %s: the copied placeholder value (e.g. gift card code) */
                    'placeholderCopied' => __('Placeholder copied: %s', 'wallet-ready-gift-cards-for-woocommerce'),
                    'epassIssueWorking' => __('Creating wallet pass…', 'wallet-ready-gift-cards-for-woocommerce'),
                    'epassIssueDone' => __('Wallet pass created.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'epassIssueFailed' => __('Could not create wallet pass.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'epassIssueNetwork' => __('Network error. Try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                )
            ));

            wp_localize_script(
                'wallregi_scheduled_deliveries',
                'wallregi_scheduled_deliveries_obj',
                array(
                    'ajaxurl' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('wallregi_nonce_action'),
                    'strings' => array(
                        /* translators: %s: gift card code */
                        'resendEmailConfirm' => __('Re-send the gift card email for code %s to the recipient now?', 'wallet-ready-gift-cards-for-woocommerce'),
                        'resendEmailWorking' => __('Sending email…', 'wallet-ready-gift-cards-for-woocommerce'),
                        'resendEmailSuccess' => __('Gift card email sent successfully.', 'wallet-ready-gift-cards-for-woocommerce'),
                        'resendEmailFailed' => __('Could not send the gift card email. Check your mail settings and try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                        'resendEmailNetwork' => __('Network error. Please try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                        /* translators: %s: gift card code */
                        'resendSmsConfirm' => __('Re-send the gift card SMS for code %s to the recipient now?', 'wallet-ready-gift-cards-for-woocommerce'),
                        'resendSmsWorking' => __('Sending SMS…', 'wallet-ready-gift-cards-for-woocommerce'),
                        'resendSmsSuccess' => __('Gift card SMS sent successfully.', 'wallet-ready-gift-cards-for-woocommerce'),
                        'resendSmsFailed' => __('Could not send the gift card SMS. Check your SMS settings and try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                        'resendSmsNetwork' => __('Network error. Please try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                        'resendNetwork' => __('Network error. Please try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                    ),
                )
            );

            // Localize manual giftcard script with translatable strings
            wp_localize_script('wallregi_manual_giftcard_settings', 'wallregi_manual_giftcard_obj', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wallregi_nonce_action'),
                'codeMinLength' => wallregi_giftcard_code_min_total_length(),
                'codeMaxLength' => wallregi_giftcard_code_max_total_length(),
                'codeFormatType' => wallregi_giftcard_code_format_client_type(),
                'strings' => array(
                    'couponCodeRequired' => __('Coupon Code is required.', 'wallet-ready-gift-cards-for-woocommerce'),
                    /* translators: 1: minimum characters, 2: maximum characters */
                    'couponCodeLength' => __('Coupon code must be between %1$d and %2$d characters long.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'couponCodePattern' => wallregi_giftcard_code_format_error_message(),
                    'initialAmountRequired' => __('Please enter a valid initial coupon amount.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'currentBalanceRequired' => __('Please enter a valid current coupon balance.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'expiryDateRequired' => __('Please select a valid expiry date', 'wallet-ready-gift-cards-for-woocommerce'),
                    'emailRequired' => __('Please enter a valid email address.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'receiverNameRequired' => __('Recipient name is required.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'senderNameRequired' => __('Sender name is required.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'phoneRequired' => __('Please enter a valid recipient phone number with country code.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'giftcardAvailable' => __('Gift card number', 'wallet-ready-gift-cards-for-woocommerce') . ' <strong style="color: #7d60a9; font-size: 18px;"> [ %s ] </strong> ' . __('is available.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'giftcardExists' => __('Gift card number', 'wallet-ready-gift-cards-for-woocommerce') . ' <strong style="color: #7d60a9; font-size: 18px;"> [ %s ] </strong> ' . __('already exists. Please choose another number.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'generating' => __('Generating...', 'wallet-ready-gift-cards-for-woocommerce'),
                    'generateCode' => __('Generate Code', 'wallet-ready-gift-cards-for-woocommerce'),
                )
            ));
        }

        /**
         * Callback function to display the Gift Card Admin Dashboard
         */
        public function wallregi_giftcard_page_callback()
        {
            // Check if the current user has the required capability
            if (!current_user_can('manage_woocommerce')) {
                // Redirect to the WordPress admin dashboard if the user is not authorized
                wp_safe_redirect(admin_url());
                exit;
            }

            // Include the admin page template file
            include WALLREGI_PLUGIN_DIR . 'backend/admin/admin-page.php';
        }

        /**
         * AJAX save for unified settings hub (per-tab forms).
         *
         * @return void
         */
        public function wallregi_ajax_admin_save_settings()
        {
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(
                    ['message' => __('You do not have permission to save these settings.', 'wallet-ready-gift-cards-for-woocommerce')],
                    403
                );
            }

            check_ajax_referer('wallregi_admin_save_settings', 'nonce');

            require_once WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-admin-settings-persistence.php';

            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above (check_ajax_referer).
            $tab = isset($_POST['settings_tab']) ? sanitize_text_field(wp_unslash($_POST['settings_tab'])) : '';
            if (!in_array($tab, wallregi_admin_settings_hub_tab_keys(), true)) {
                wp_send_json_error(
                    ['message' => __('Invalid settings section.', 'wallet-ready-gift-cards-for-woocommerce')],
                    400
                );
            }

            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized in save helpers.
            $request = wp_unslash($_POST);

            if ('wallregi_email' === $tab) {
                $result = wallregi_admin_settings_save_email_from_request($request);
            } elseif ('wallregi_wallet' === $tab) {
                $result = wallregi_admin_settings_save_wallet_from_request($request);
            } else {
                $wallregi_data_dir = WALLREGI_PLUGIN_DIR . 'backend/templates/settings/partials/settings-data/';
                $wallregi_map = [
                    'wallregi_general' => 'general-data.php',
                    'wallregi_form' => 'form-data.php',
                    'wallregi_templates' => 'pdf-data.php',
                ];
                $wallregi_file = $wallregi_map[$tab] ?? '';
                if ('' === $wallregi_file || !file_exists($wallregi_data_dir . $wallregi_file)) {
                    wp_send_json_error(
                        ['message' => __('Invalid settings definition.', 'wallet-ready-gift-cards-for-woocommerce')],
                        400
                    );
                }
                $result = wallregi_admin_settings_save_from_request($wallregi_data_dir . $wallregi_file, $request);
            }

            if (is_wp_error($result)) {
                wp_send_json_error(
                    ['message' => $result->get_error_message()],
                    400
                );
            }

            wp_send_json_success(
                [
                    'message' => __('Settings saved.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'tab' => $tab,
                ]
            );
        }

        /**
         * AJAX: validate ePasscard API key remotely, then store encrypted key + UTC expiry.
         *
         * @return void
         */
        public function wallregi_ajax_wallet_epass_connect()
        {
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(
                    ['message' => __('You do not have permission to perform this action.', 'wallet-ready-gift-cards-for-woocommerce')],
                    403
                );
            }

            check_ajax_referer('wallregi_admin_save_settings', 'nonce');

            require_once WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-admin-settings-persistence.php';

            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below.
            $api_key = isset($_POST['api_key']) ? sanitize_text_field(wp_unslash((string) $_POST['api_key'])) : '';

            $validated = wallregi_wallet_validate_epass_api_key_remote($api_key);
            if (is_wp_error($validated)) {
                wp_send_json_error(
                    ['message' => $validated->get_error_message()],
                    400
                );
            }

            $persisted = wallregi_wallet_save_connected_epass_credentials($api_key, $validated);
            if (is_wp_error($persisted)) {
                wp_send_json_error(
                    ['message' => $persisted->get_error_message()],
                    400
                );
            }

            $expiry_utc = isset($validated['next_refresh']) ? sanitize_text_field((string) $validated['next_refresh']) : '';
            $expiry_label = wallregi_wallet_format_expiry_for_display($expiry_utc);

            wp_send_json_success(
                [
                    'message' => __('Connected successfully.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'expiry_label' => $expiry_label,
                    'expiry_utc' => $expiry_utc,
                    'expiry_caption' => __('Key expiry (your site time)', 'wallet-ready-gift-cards-for-woocommerce'),
                ]
            );
        }

        /**
         * AJAX: list pass templates for global wallet settings (Gift Cards admin).
         *
         * @return void
         */
        public function wallregi_ajax_wallet_epass_global_get_templates()
        {
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(['message' => __('Permission denied.', 'wallet-ready-gift-cards-for-woocommerce')], 403);
            }

            check_ajax_referer('wallregi_admin_save_settings', 'nonce');

            $api = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-public-api.php';
            if (file_exists($api)) {
                require_once $api;
            }

            if (!function_exists('wallregi_wallet_epass_get_templates_page1') || !wallregi_wallet_epass_is_api_configured()) {
                wp_send_json_error(['message' => __('Wallet API key is not configured.', 'wallet-ready-gift-cards-for-woocommerce')], 400);
            }

            $result = wallregi_wallet_epass_get_templates_page1();
            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()], 400);
            }

            wp_send_json_success(
                [
                    'templates' => $result['templates'],
                    'total_templates' => $result['total_templates'],
                ]
            );
        }

        /**
         * AJAX: pass fields for a template (global wallet settings).
         *
         * @return void
         */
        public function wallregi_ajax_wallet_epass_global_get_pass_fields()
        {
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(['message' => __('Permission denied.', 'wallet-ready-gift-cards-for-woocommerce')], 403);
            }

            check_ajax_referer('wallregi_admin_save_settings', 'nonce');

            $api = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-public-api.php';
            if (file_exists($api)) {
                require_once $api;
            }

            if (!function_exists('wallregi_wallet_epass_get_pass_fields_for_template') || !wallregi_wallet_epass_is_api_configured()) {
                wp_send_json_error(['message' => __('Wallet API key is not configured.', 'wallet-ready-gift-cards-for-woocommerce')], 400);
            }

            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $uid = isset($_POST['template_uid']) ? sanitize_text_field(wp_unslash((string) $_POST['template_uid'])) : '';
            $result = wallregi_wallet_epass_get_pass_fields_for_template($uid);
            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()], 400);
            }

            wp_send_json_success(['passFields' => $result['passFields']]);
        }

        public function wallregi_manual_giftcard_created()
        {
            // Verify nonce
            check_ajax_referer('wallregi_nonce_action', 'wallreginonce');
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'wallet-ready-gift-cards-for-woocommerce')]);
                return;
            }

            if (!apply_filters('wallregi_security_allow_admin_manual_save', true)) {
                wp_send_json_error(array('message' => wallregi_security_rate_limit_message()));
                return;
            }

            global $wpdb;

            $wallregi_giftcard_table = wallregi_giftcard_db_table_name();
            $wallregi_transaction_table = wallregi_transaction_db_table_name();

            $postid = isset($_POST['postid']) ? intval(wp_unslash($_POST['postid'])) : 0;

            $identifier = $postid ? 'update_giftcard' : 'create_giftcard';

            // Sanitize POST values
            $giftcard_number = sanitize_text_field(wp_unslash($_POST['giftcard_number'] ?? ''));
            // Client sends this when the coupon field is disabled (auto-generate on submit); only for create.
            $wallregi_auto_generate = isset($_POST['auto_generate_giftcard']) && '1' === sanitize_text_field(wp_unslash($_POST['auto_generate_giftcard']));
            if ($wallregi_auto_generate && 'create_giftcard' === $identifier) {
                $giftcard_number = '';
            }
            $initial_amount = isset($_POST['initial_amount']) ? intval(wp_unslash($_POST['initial_amount'])) : 0;
            $current_amount = isset($_POST['current_amount']) ? intval(wp_unslash($_POST['current_amount'])) : 0;
            $wallregi_expiry_period = sanitize_text_field(wp_unslash($_POST['expiry_period'] ?? ''));
            $preferred_date_time = sanitize_text_field(wp_unslash($_POST['preferred_date_time'] ?? ''));
            $receipent_name = sanitize_text_field(wp_unslash($_POST['receipent_name'] ?? ''));
            $receipent_email = isset($_POST['receipent_email']) ? sanitize_email(wp_unslash($_POST['receipent_email'])) : '';
            $sender_name = sanitize_text_field(wp_unslash($_POST['sender_name'] ?? ''));
            $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
            $email_send_notification = isset($_POST['email_send_notification']) && $_POST['email_send_notification'] === 'checked';
            $giftcard_pdf_thumbnail = sanitize_text_field(wp_unslash($_POST['giftcard_pdf_thumbnail'] ?? ''));
            $delivery_channel = function_exists('wallregi_sanitize_delivery_channel')
                ? wallregi_sanitize_delivery_channel(wp_unslash($_POST['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL))
                : WALLREGI_DELIVERY_CHANNEL_EMAIL;
            $receipent_phone = function_exists('wallregi_sanitize_giftcard_phone')
                ? wallregi_sanitize_giftcard_phone(wp_unslash($_POST['receipent_phone'] ?? ''))
                : '';

            $needs_sms_phone = in_array($delivery_channel, array(WALLREGI_DELIVERY_CHANNEL_SMS, WALLREGI_DELIVERY_CHANNEL_BOTH), true);
            if ($needs_sms_phone && function_exists('wallregi_validate_giftcard_phone')) {
                $validated_phone = wallregi_validate_giftcard_phone($receipent_phone, true);
                if (is_wp_error($validated_phone)) {
                    wp_send_json_error(array('message' => $validated_phone->get_error_message()));
                    return;
                }
                $receipent_phone = $validated_phone;
            }

            $needs_email = in_array($delivery_channel, array(WALLREGI_DELIVERY_CHANNEL_EMAIL, WALLREGI_DELIVERY_CHANNEL_BOTH), true);
            if ($needs_email && ('' === $receipent_email || !is_email($receipent_email))) {
                wp_send_json_error(array('message' => __('A valid recipient email is required for the selected delivery method.', 'wallet-ready-gift-cards-for-woocommerce')));
                return;
            }

            $order_id = isset($_POST['order_id']) ? intval(wp_unslash($_POST['order_id'])) : 0;
            $item_id = isset($_POST['item_id']) ? intval(wp_unslash($_POST['item_id'])) : 0;
            $product_id = isset($_POST['product_id']) ? intval(wp_unslash($_POST['product_id'])) : 0;

            if ($identifier === 'create_giftcard') {
                $insert_result = wallregi_insert_manual_giftcard(
                    array(
                        'auto_generate' => $wallregi_auto_generate,
                        'giftcard_number' => $giftcard_number,
                        'initial_amount' => $initial_amount,
                        'current_amount' => $current_amount,
                        'expiry_period' => $wallregi_expiry_period,
                        'preferred_date_time' => $preferred_date_time,
                        'receipent_name' => $receipent_name,
                        'receipent_email' => $receipent_email,
                        'receipent_phone' => $receipent_phone,
                        'delivery_channel' => $delivery_channel,
                        'sender_name' => $sender_name,
                        'message' => $message,
                        'order_id' => $order_id,
                        'item_id' => $item_id,
                        'product_id' => $product_id,
                        'giftcard_image' => $giftcard_pdf_thumbnail,
                    )
                );

                if (is_wp_error($insert_result)) {
                    wp_send_json_error(array('message' => $insert_result->get_error_message()));
                    return;
                }

                $giftcard_id = (int) $insert_result;

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Read back canonical code after insert/generate.
                $saved_number = $wpdb->get_var(
                    $wpdb->prepare(
                        'SELECT `giftcard_number` FROM %i WHERE `id` = %d',
                        wallregi_giftcard_db_table_name(),
                        $giftcard_id
                    )
                );
                $giftcard_number = is_string($saved_number) ? $saved_number : $giftcard_number;

                if ($email_send_notification) {
                    $this->wallregi_manual_trigger_giftcard_delivery($giftcard_number);
                }

                $giftcard_data = compact('giftcard_number', 'initial_amount', 'current_amount', 'receipent_name', 'receipent_email', 'sender_name', 'message');

                if (function_exists('wallregi_security_audit_log')) {
                    wallregi_security_audit_log(
                        'admin_manual_giftcard_save',
                        'success',
                        array(
                            'detail' => 'create',
                            'identifier' => function_exists('wallregi_security_redact_code') ? wallregi_security_redact_code((string) $giftcard_number) : '',
                        )
                    );
                }

                wp_send_json_success(
                    array(
                        'message' => __('The gift card has been successfully created.', 'wallet-ready-gift-cards-for-woocommerce'),
                        'saved_giftcard_number' => (string) $giftcard_number,
                        'giftcard_data' => $giftcard_data,
                        'email_send' => $email_send_notification,
                        'pdf_thumb' => $giftcard_pdf_thumbnail,
                    )
                );
            } elseif ($identifier === 'update_giftcard') {
                if ($postid > 0) {
                    // Get existing gift card number from DB
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                    $existing_giftcard_number = $wpdb->get_var(
                        $wpdb->prepare(
                            'SELECT `giftcard_number` FROM %i WHERE `id` = %d',
                            wallregi_giftcard_db_table_name(),
                            $postid
                        )
                    );

                    if ($existing_giftcard_number !== $giftcard_number) {
                        wp_send_json_error([
                            'message' => sprintf(
                                /* translators: %s is the original gift card number */
                                __('Gift card number cannot be edited. The original number is "%s".', 'wallet-ready-gift-cards-for-woocommerce'),
                                esc_html($existing_giftcard_number)
                            )
                        ]);
                        return;
                    }

                    // Calculate expiry date (fixed Y-m-d from admin picker, or relative period string).
                    $expiry_resolved = wallregi_resolve_manual_giftcard_expiry_input($wallregi_expiry_period);
                    if (is_wp_error($expiry_resolved)) {
                        wp_send_json_error(array('message' => $expiry_resolved->get_error_message()));
                        return;
                    }
                    $wallregi_expiry_date = $expiry_resolved['expiry_date'];
                    $wallregi_expiry_period = $expiry_resolved['expiry_period'];

                    // Prepare data for updating the gift card table
                    // Do not reset `total_redeem` here — preserve existing redeemed history
                    $giftcard_data = [
                        'order_id' => $order_id,
                        'item_id' => $item_id,
                        'product_id' => $product_id,
                        'initial_amount' => $initial_amount,
                        'current_amount' => $current_amount,
                        'giftcard_number' => $giftcard_number,
                        'expiry_date' => $wallregi_expiry_date,
                        'expiry_period' => $wallregi_expiry_period,
                        'receipent_name' => $receipent_name,
                        'receipent_email' => $receipent_email,
                        'receipent_phone' => $receipent_phone,
                        'delivery_channel' => $delivery_channel,
                        'sender_name' => $sender_name,
                        'message' => $message,
                        'send_date_time' => current_time('mysql'),
                        'preferred_date_time' => wallregi_normalize_giftcard_preferred_datetime($preferred_date_time),
                        'giftcard_image' => $giftcard_pdf_thumbnail,
                        'created_by' => get_current_user_id(),
                        'status' => 'active',
                    ];

                    // Update the gift card table using giftcard_number
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                    $updated = $wpdb->update($wallregi_giftcard_table, $giftcard_data, ['id' => $postid]);

                    if (false === $updated) {
                        wp_send_json_error(['message' => __('Failed to update giftcard table.', 'wallet-ready-gift-cards-for-woocommerce')]);
                        return;
                    }

                    // Prepare data for updating the transaction table
                    $transaction_data = [
                        'giftcard_id' => $postid,
                        'amount' => $current_amount,
                        'order_id' => $order_id,
                        'created_by' => get_current_user_id(),
                        'reconciled' => 0,
                        'message' => 'The updated gift card ready for use.',
                    ];

                    if ($updated) {
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom transaction table.
                        $updated_transaction = $wpdb->update(
                            $wallregi_transaction_table,
                            $transaction_data,
                            ['id' => $postid]
                        );

                        if (false === $updated_transaction) {
                            wp_send_json_error(['message' => __('Failed to update transaction table.', 'wallet-ready-gift-cards-for-woocommerce')]);
                        }

                        // Trigger delivery if checkbox is checked (for update as well)
                        if ($email_send_notification) {
                            $this->wallregi_manual_trigger_giftcard_delivery($giftcard_number);
                        }

                        // Hook for create pass in epasscard plugin
                        do_action('wallregi_giftcard_updated_by_admin', $postid, $identifier);

                        if (function_exists('wallregi_security_audit_log')) {
                            wallregi_security_audit_log(
                                'admin_manual_giftcard_save',
                                'success',
                                array(
                                    'detail' => 'update',
                                    'identifier' => function_exists('wallregi_security_redact_code') ? wallregi_security_redact_code((string) $giftcard_number) : '',
                                )
                            );
                        }

                        wp_send_json_success([
                            'message' => __('The gift card has been successfully updated.', 'wallet-ready-gift-cards-for-woocommerce'),
                            'saved_giftcard_number' => (string) $giftcard_number,
                            'giftcard_data' => ['giftcard_number' => $giftcard_number],
                        ]);
                    } else {
                        wp_send_json_error(['message' => __('Failed to update the gift card. Please try again.', 'wallet-ready-gift-cards-for-woocommerce')]);
                    }
                }
            }
        }

        public function wallregi_check_giftcard_number_exists_callback()
        {
            // Verify nonce
            check_ajax_referer('wallregi_nonce_action', 'wallreginonce');
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'wallet-ready-gift-cards-for-woocommerce')]);
                return;
            }

            if (!apply_filters('wallregi_security_allow_admin_check_code', true)) {
                wp_send_json_error(array('message' => wallregi_security_rate_limit_message()));
                return;
            }

            global $wpdb;

            $wallregi_giftcard_table = wallregi_giftcard_db_table_name();
            $giftcard_number = sanitize_text_field(wp_unslash($_POST['giftcard_number'] ?? ''));

            if (empty($giftcard_number)) {
                wp_send_json_error(['message' => __('Gift card number is required.', 'wallet-ready-gift-cards-for-woocommerce')]);
                return;
            }

            // Check if the gift card number exists in the database
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
            $existing_giftcard = $wpdb->get_var(
                $wpdb->prepare(
                    'SELECT COUNT(*) FROM %i WHERE `giftcard_number` = %s',
                    wallregi_giftcard_db_table_name(),
                    $giftcard_number
                )
            );

            if ($existing_giftcard > 0) {
                wp_send_json_error(['message' => __('This gift card number already exists. Please choose another number.', 'wallet-ready-gift-cards-for-woocommerce')]);
            } else {
                wp_send_json_success(['message' => __('Gift card number is available.', 'wallet-ready-gift-cards-for-woocommerce')]);
            }
        }

        public function wallregi_delete_giftcard()
        {
            // Verify nonce
            check_ajax_referer('wallregi_nonce_action', 'wallreginonce');
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'wallet-ready-gift-cards-for-woocommerce')]);
                return;
            }

            global $wpdb;

            // Validate and sanitize input
            $giftcard_id = isset($_POST['giftcard_id']) ? intval(wp_unslash($_POST['giftcard_id'])) : 0;
            $giftcard_number = isset($_POST['giftcard_number']) ? sanitize_text_field(wp_unslash($_POST['giftcard_number'])) : '';
            $receipent_email = isset($_POST['receipent_email']) ? sanitize_email(wp_unslash($_POST['receipent_email'])) : '';

            if (!$giftcard_id) {
                wp_send_json_error(['message' => __('Invalid gift card ID.', 'wallet-ready-gift-cards-for-woocommerce')]);
                return;
            }

            // Get single pass id
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
            $giftcard = $wpdb->get_row(
                $wpdb->prepare(
                    'SELECT * FROM %i WHERE `id` = %d',
                    wallregi_giftcard_db_table_name(),
                    $giftcard_id
                ),
                ARRAY_A
            );
            $epassDataJson = $giftcard['epass_data'];
            $epassData = json_decode($epassDataJson, true);
            $singlePassUid = $epassData['passUid'] ?? null;

            $conditions = array('id = %d');
            $values = array($giftcard_id);
            if (!empty($giftcard_number)) {
                $conditions[] = 'giftcard_number = %s';
                $values[] = $giftcard_number;
            }
            if (!empty($receipent_email)) {
                $conditions[] = 'receipent_email = %s';
                $values[] = $receipent_email;
            }
            $where_clause = implode(' AND ', $conditions);

            $table = wallregi_giftcard_db_table_name();
            $has_num = !empty($giftcard_number);
            $has_mail = !empty($receipent_email);

            // Explicit prepares only (Plugin Check rejects call_user_func_array + prepare).
            if ($has_num && $has_mail) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                $deleted = $wpdb->query(
                    $wpdb->prepare(
                        'DELETE FROM %i WHERE `id` = %d AND `giftcard_number` = %s AND `receipent_email` = %s',
                        $table,
                        $giftcard_id,
                        $giftcard_number,
                        $receipent_email
                    )
                );
            } elseif ($has_num) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                $deleted = $wpdb->query(
                    $wpdb->prepare(
                        'DELETE FROM %i WHERE `id` = %d AND `giftcard_number` = %s',
                        $table,
                        $giftcard_id,
                        $giftcard_number
                    )
                );
            } elseif ($has_mail) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                $deleted = $wpdb->query(
                    $wpdb->prepare(
                        'DELETE FROM %i WHERE `id` = %d AND `receipent_email` = %s',
                        $table,
                        $giftcard_id,
                        $receipent_email
                    )
                );
            } else {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                $deleted = $wpdb->query(
                    $wpdb->prepare(
                        'DELETE FROM %i WHERE `id` = %d',
                        $table,
                        $giftcard_id
                    )
                );
            }

            ob_start();
            ?>
                <div class="no-gift-cards-message" style="text-align: center; padding: 30px 24px; width: 750px; margin: 50px auto;">
                    
                    <p class="no-gift-cards" style="font-size: 16px; margin-bottom: 36px;">
                        <?php esc_html_e('You don’t have any gift card codes yet. Once a user purchases a gift card, the code will appear here. Alternatively, you can create one manually.', 'wallet-ready-gift-cards-for-woocommerce'); ?>
                    </p>
                    <!-- Create Gift Card Button -->
                    <a href="<?php echo esc_url(wallregi_gift_cards_admin_url(['tab' => 'new_giftcard', '_wpnonce' => wp_create_nonce('wallregi_nonce_action')])); ?>" class="button button-primary" id="new_giftcard"><?php esc_html_e('Create Giftcard', 'wallet-ready-gift-cards-for-woocommerce'); ?></a>
                </div>

            <?php

            $gift_wrap = ob_get_clean();

            if ($deleted !== false) {
                // Hook for delete single pass in epasscard
                do_action('wallregi_giftcard_deleted_by_admin', $singlePassUid);
                wp_send_json_success([
                    'message' => __('Gift Card coupon code deleted successfully!', 'wallet-ready-gift-cards-for-woocommerce'),
                    'giftcard_id' => $giftcard_id,
                    'conditions' => $conditions,
                    'values' => $values,
                    'where_clause' => $where_clause,
                    'gift_wrap' => $gift_wrap,
                ]);
            } else {
                wp_send_json_error(['message' => __('Database error. Could not delete record.', 'wallet-ready-gift-cards-for-woocommerce')]);
            }
        }

        /**
         * AJAX Callback: wallregi_search_gift_cards_callback
         */
        public function wallregi_search_gift_cards_callback()
        {
            // Check nonce for security
            check_ajax_referer('wallregi_nonce_action', 'wallreginonce');
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'wallet-ready-gift-cards-for-woocommerce')]);
                return;
            }

            global $wpdb;
            $search_query = isset($_POST['search_query']) ? sanitize_text_field(wp_unslash($_POST['search_query'])) : '';

            $tn = wallregi_giftcard_db_table_name();

            if ('' === $search_query) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                $results = $wpdb->get_results(
                    $wpdb->prepare(
                        'SELECT * FROM %i WHERE `status` = %s',
                        $tn,
                        'active'
                    ),
                    ARRAY_A
                );
            } else {
                $like = '%' . $wpdb->esc_like($search_query) . '%';
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                $results = $wpdb->get_results(
                    $wpdb->prepare(
                        'SELECT * FROM %i WHERE `status` = %s AND ( `giftcard_number` LIKE %s OR `receipent_email` LIKE %s OR `order_id` LIKE %s OR `receipent_name` LIKE %s )',
                        $tn,
                        'active',
                        $like,
                        $like,
                        $like,
                        $like
                    ),
                    ARRAY_A
                );
            }

            // Generate HTML for table rows
            ob_start();
            if (!empty($results)) {
                // $counter = 1;
                foreach ($results as $wallregi_gift_card) {
                    // Reuse the same row structure as your original table
                    ?>
                    <tr id="post-<?php echo esc_attr($wallregi_gift_card['id']); ?>">
                        <th scope="row" class="check-column">
                            <input type="checkbox" name="wallregi_giftcard_ids[]" value="<?php echo esc_attr($wallregi_gift_card['id']); ?>">
                        </th>
                        <td class="code column-code" data-colname="code">
                            <div class="giftcard_code_wrapper">
                                <div id="giftcard_code_field" class="giftcard_code_field">
                                    <div class="giftcard_code"><?php echo esc_html($wallregi_gift_card['giftcard_number']); ?></div>
                                    <div class="wallregi_copy_to_clipboard" onClick="return copyTextToClipboard(this)">
                                        <span class="icon"></span>
                                        <span>copy</span>
                                    </div>
                                </div>
                                <span id="toast_mgs" class="toast-message"><?php esc_html_e('Copied!', 'wallet-ready-gift-cards-for-woocommerce') ?></span>
                            </div>
                        </td>
                        <td class="order column-order" data-colname="order">
                            <?php

                            if (!empty($wallregi_gift_card['order_id'])) {
                                $wallregi_gift_card['order_id'];
                            } elseif (empty($wallregi_gift_card['order_id'])) {
                                $wallregi_gift_card['order_id'] = 'Manual Created';
                            }

                            ?>

                            <span><?php echo esc_html($wallregi_gift_card['order_id']); ?></span>

                        </td>
                        <td class="balance column-balance" data-colname="balance">
                            <span class="wallregi_giftcard_price"><?php echo esc_html($wallregi_gift_card['current_amount']); ?></span>
                            <span class="wallregi_currency_symbol"><?php echo esc_html(get_woocommerce_currency_symbol()); ?></span>
                        </td>
                        <td class="redeem column-redeem" data-colname="redeem">
                            <span class="wallregi_redeem_amout"><?php echo esc_html($wallregi_gift_card['total_redeem']); ?></span>
                            <span class="wallregi_currency_symbol"><?php echo esc_html(get_woocommerce_currency_symbol()); ?></span>
                        </td>
                        <td class="expiration column-expiration" data-colname="expire on">
                        <?php
                        $wallregi_giftcard_create_date = $wallregi_gift_card['created_at'];
                        $wallregi_expiry_period = $wallregi_gift_card['expiry_period'];
                        $wallregi_expiry_date = $wallregi_gift_card['expiry_date'];

                        $wallregi_calculated_expiry_date = '';

                        if (!empty($wallregi_giftcard_create_date) && $wallregi_giftcard_create_date != '0000-00-00' && 'custom' !== (string) $wallregi_expiry_period) {
                            try {
                                $wallregi_create_date = new DateTime($wallregi_giftcard_create_date);
                                $wallregi_create_date->modify("+$wallregi_expiry_period");
                                $wallregi_calculated_expiry_date = $wallregi_create_date->format('Y-m-d');
                            } catch (Exception $e) {
                                $wallregi_calculated_expiry_date = 'Invalid date';
                            }
                        }

                        if (empty($wallregi_expiry_date) || $wallregi_expiry_date === '0000-00-00') {
                            ?>
                                <span class="wallregi_expire_date"><?php echo esc_html($wallregi_calculated_expiry_date); ?></span>
                                <?php
                        } else {
                            ?>
                                <span class="wallregi_expire_date"><?php echo esc_html($wallregi_expiry_date); ?></span>
                                <?php
                        }
                        ?>
                        </td>
                        <td class="recipient column-recipient" data-colname="recipient">
                            <a href="mailto:<?php echo esc_attr($wallregi_gift_card['receipent_email']); ?>" class="wallregi_recipient">
                                <?php echo esc_html($wallregi_gift_card['receipent_email']); ?>
                            </a>
                        </td>
                        <td class="enabled column-enabled" data-colname="enabled">
                            <label id="wallregi_enabled" class="wallregi_switch switch_enabled">
                            <input type="checkbox" <?php echo $wallregi_gift_card['status'] === 'active' ? 'checked' : ''; ?>>
                                <span class="slider round"></span>
                            </label>
                        </td>
                        <td class="actions column-actions" data-colname="#">
                            <a href="<?php echo esc_url(wallregi_gift_cards_admin_url([
                        'tab' => 'new_giftcard',
                        'postid' => $wallregi_gift_card['id'],
                        'action' => 'edit',
                        '_wpnonce' => wp_create_nonce('wallregi_nonce_action'),
                    ])); ?>">
                                <span class="dashicons dashicons-edit"></span>
                            </a>
                            <span class="dashicons dashicons-trash"></span>
                        </td>
                        <!-- Add other columns similarly -->
                    </tr>
                    <?php
                }
            } else {
                echo '<tr><td colspan="9">' . esc_html__('No gift cards found.', 'wallet-ready-gift-cards-for-woocommerce') . '</td></tr>';
            }
            $html = ob_get_clean();

            wp_send_json_success(array('html' => $html));
        }

        /**
         * Handles the AJAX request to bulk delete gift cards.
         */
        public function wallregi_bulk_delete_giftcards_callback()
        {
            // Check nonce for security
            check_ajax_referer('wallregi_nonce_action', 'wallreginonce');

            // Check user capability - adjust as needed
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(__('You do not have permission to perform this action.', 'wallet-ready-gift-cards-for-woocommerce'));
                return;
            }

            // Check and sanitize POST input
            if (!isset($_POST['giftcard_ids'])) {
                wp_send_json_error(__('Gift card IDs not provided.', 'wallet-ready-gift-cards-for-woocommerce'));
                return;
            }

            // Decode the JSON-encoded string of IDs
            $raw_ids = json_decode(sanitize_text_field(wp_unslash($_POST['giftcard_ids'])), true);

            // Validate decoded data
            if (!is_array($raw_ids)) {
                wp_send_json_error(__('Invalid gift card IDs.', 'wallet-ready-gift-cards-for-woocommerce'));
                return;
            }

            // Sanitize: keep only positive integers
            $giftcard_ids = array_filter(array_map('absint', $raw_ids));

            if (empty($giftcard_ids)) {
                wp_send_json_error(__('No valid gift card IDs provided.', 'wallet-ready-gift-cards-for-woocommerce'));
                return;
            }

            global $wpdb;

            $table = wallregi_giftcard_db_table_name();
            $result = true;
            foreach ($giftcard_ids as $wallregi_gid) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                $del = $wpdb->delete($table, array('id' => $wallregi_gid), array('%d'));
                if (false === $del) {
                    $result = false;
                    break;
                }
            }

            if (false === $result) {
                return;
            }

            wp_send_json_success([
                'message' => __('Gift cards deleted successfully.', 'wallet-ready-gift-cards-for-woocommerce'),
                'giftcard_ids' => $giftcard_ids,
            ]);
        }

        /**
         * Handles the AJAX request to auto generate gift card codes.
         */
        public function wallregi_auto_generate_coupon_code_callback()
        {
            // Verify nonce
            check_ajax_referer('wallregi_nonce_action', 'wallreginonce');
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'wallet-ready-gift-cards-for-woocommerce')]);
                return;
            }

            $prefix = isset($_POST['prefix']) ? sanitize_text_field(wp_unslash($_POST['prefix'])) : '';
            $suffix = isset($_POST['suffix']) ? sanitize_text_field(wp_unslash($_POST['suffix'])) : '';

            $generated = wallregi_generate_giftcard_coupon_code($prefix, $suffix);
            $generated_code = preg_replace('/\s+/', '-', $generated);

            wp_send_json_success([
                'code' => $generated_code,
            ]);
        }

        /**
         * Create a missing Google / Apple Wallet pass from the gift cards dashboard.
         */
        public function wallregi_epass_issue_missing_pass_ajax_handler()
        {
            check_ajax_referer('wallregi_nonce_action', 'wallreginonce');
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(
                    [
                        'message' => __('You do not have permission to perform this action.', 'wallet-ready-gift-cards-for-woocommerce'),
                    ]
                );
            }

            $giftcard_id = isset($_POST['giftcard_id']) ? absint(wp_unslash($_POST['giftcard_id'])) : 0;
            if ($giftcard_id <= 0) {
                wp_send_json_error(
                    [
                        'message' => __('Invalid gift card ID.', 'wallet-ready-gift-cards-for-woocommerce'),
                    ]
                );
            }

            $wallregi_epass_issuance = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-issuance.php';
            if (file_exists($wallregi_epass_issuance) && !function_exists('wallregi_epass_try_issue_pass_for_giftcard')) {
                require_once $wallregi_epass_issuance;
            }
            if (!function_exists('wallregi_epass_try_issue_pass_for_giftcard')) {
                wp_send_json_error(
                    [
                        'message' => __('Wallet pass features are not available.', 'wallet-ready-gift-cards-for-woocommerce'),
                    ]
                );
            }

            $try = wallregi_epass_try_issue_pass_for_giftcard(
                $giftcard_id,
                [
                    'allow_empty_additional' => true,
                ]
            );
            if (is_wp_error($try)) {
                wp_send_json_error(
                    [
                        'message' => $try->get_error_message(),
                    ]
                );
            }
            if (true !== $try) {
                wp_send_json_error(
                    [
                        'message' => __(
                            'Could not create a wallet pass. Check that ePasscard is configured, a pass template is mapped (per product or globally), this card does not already have a pass, and that a stripe image is available (PDF thumbnail, product wallet image, global fallback, or the default packaged image).',
                            'wallet-ready-gift-cards-for-woocommerce'
                        ),
                    ]
                );
            }

            global $wpdb;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Read back issued link.
            $epass_json = $wpdb->get_var(
                $wpdb->prepare(
                    'SELECT `epass_data` FROM %i WHERE `id` = %d LIMIT 1',
                    wallregi_giftcard_db_table_name(),
                    $giftcard_id
                )
            );
            $pass_link = '';
            if (is_string($epass_json) && '' !== $epass_json) {
                $decoded = json_decode($epass_json, true);
                if (is_array($decoded) && !empty($decoded['passLink'])) {
                    $pass_link = (string) $decoded['passLink'];
                }
            }
            if ('' === trim($pass_link)) {
                wp_send_json_error(
                    [
                        'message' => __('Pass was created but the store did not receive a pass link. Please refresh and try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                    ]
                );
            }

            $wallet_html = '';
            if (function_exists('wallregi_epass_print_wallet_anchor')) {
                ob_start();
                wallregi_epass_print_wallet_anchor(
                    $pass_link,
                    [
                        'class' => 'wallregi-epass-wallet-link wallregi-epass-wallet-link--dashboard',
                    ]
                );
                $wallet_html = (string) ob_get_clean();
            }

            wp_send_json_success(
                [
                    'passLink' => $pass_link,
                    'wallet_html' => $wallet_html,
                ]
            );
        }

        /*
         * Handle the AJAX request to download pdf from dashboard
         */

        public function wallregi_generate_pdf_ajax_handler()
        {
            // Verify nonce from GET
            check_ajax_referer('wallregi_nonce_action', 'wallreginonce');
            if (!current_user_can('manage_woocommerce')) {
                wp_die(esc_html__('You do not have permission to perform this action.', 'wallet-ready-gift-cards-for-woocommerce'));
            }

            if (empty($_GET['giftcode'])) {
                wp_die('Missing gift code.');
            }

            $gift_code = sanitize_text_field(wp_unslash($_GET['giftcode']));

            // Generate PDF (should stream to browser and call exit)
            wallregi_generate_giftcard_pdf(base64_encode($gift_code), false);

            exit;
        }

        /**
         * Send gift card via all channels configured on the row (manual save / send now).
         *
         * @param string $giftcard_number Gift card code.
         * @return void
         */
        private function wallregi_manual_trigger_giftcard_delivery($giftcard_number)
        {
            $giftcard_number = sanitize_text_field((string) $giftcard_number);
            if ('' === $giftcard_number) {
                return;
            }

            global $wpdb;

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
            $giftcard = $wpdb->get_row(
                $wpdb->prepare(
                    'SELECT * FROM %i WHERE `giftcard_number` = %s',
                    wallregi_giftcard_db_table_name(),
                    $giftcard_number
                )
            );

            if (!$giftcard) {
                return;
            }

            $extra = array('manual_send' => true);

            if (function_exists('wallregi_giftcard_should_send_email_for_channel') && wallregi_giftcard_should_send_email_for_channel($giftcard)) {
                do_action('wallregi_send_giftcard_email', $giftcard_number, $extra);
            }

            if (function_exists('wallregi_giftcard_should_send_sms_for_channel') && wallregi_giftcard_should_send_sms_for_channel($giftcard)) {
                if (function_exists('wallregi_gtw_sms_delivery_is_active') && wallregi_gtw_sms_delivery_is_active() && class_exists('WALLREGI_GTW_SMS')) {
                    WALLREGI_GTW_SMS::send_for_giftcard_row($giftcard, WALLREGI_GTW_API_Client::get_settings());
                } else {
                    do_action('wallregi_send_giftcard_sms', $giftcard_number, $extra);
                }
            }
        }

        /**
         * AJAX: re-send a gift card delivery email from the scheduled deliveries screen.
         *
         * @return void
         */
        public function wallregi_resend_giftcard_email_callback()
        {
            check_ajax_referer('wallregi_nonce_action', 'wallreginonce');

            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(
                    array(
                        'message' => __('You do not have permission to perform this action.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            $giftcard_id = isset($_POST['giftcard_id']) ? absint(wp_unslash($_POST['giftcard_id'])) : 0;
            if ($giftcard_id < 1) {
                wp_send_json_error(
                    array(
                        'message' => __('Invalid gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            global $wpdb;

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
            $giftcard = $wpdb->get_row(
                $wpdb->prepare(
                    'SELECT * FROM %i WHERE `id` = %d',
                    wallregi_giftcard_db_table_name(),
                    $giftcard_id
                )
            );

            if (!$giftcard || empty($giftcard->giftcard_number)) {
                wp_send_json_error(
                    array(
                        'message' => __('Gift card not found.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            if (!function_exists('wallregi_giftcard_should_send_email_for_channel') || !wallregi_giftcard_should_send_email_for_channel($giftcard)) {
                wp_send_json_error(
                    array(
                        'message' => __('This gift card is not configured for email delivery.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            if (empty($giftcard->receipent_email) || !is_email($giftcard->receipent_email)) {
                wp_send_json_error(
                    array(
                        'message' => __('This gift card does not have a valid recipient email.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            do_action(
                'wallregi_send_giftcard_email',
                $giftcard->giftcard_number,
                array(
                    'force_resend' => true,
                    'admin_resend' => true,
                )
            );

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
            $updated = $wpdb->get_row(
                $wpdb->prepare(
                    'SELECT `email_status`, `sent_at`, `sms_sent_at`, `delivery_channel`, `sms_status` FROM %i WHERE `id` = %d',
                    wallregi_giftcard_db_table_name(),
                    $giftcard_id
                )
            );

            if (!$updated || (int) $updated->email_status !== 1) {
                wp_send_json_error(
                    array(
                        'message' => __('Could not send the gift card email. Check your mail settings and try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            $sent_lines = array(
                sprintf(
                    /* translators: %s: formatted datetime */
                    __('Email: %s', 'wallet-ready-gift-cards-for-woocommerce'),
                    wallregi_format_giftcard_admin_datetime($updated->sent_at ?? '')
                ),
            );
            if (function_exists('wallregi_giftcard_should_send_sms_for_channel') && wallregi_giftcard_should_send_sms_for_channel($updated) && !empty($updated->sms_sent_at)) {
                $sent_lines[] = sprintf(
                    /* translators: %s: formatted datetime */
                    __('SMS: %s', 'wallet-ready-gift-cards-for-woocommerce'),
                    wallregi_format_giftcard_admin_datetime($updated->sms_sent_at)
                );
            }

            wp_send_json_success(
                array(
                    'message' => __('Gift card email sent successfully.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'email_status' => (int) $updated->email_status,
                    'status_badge_html' => wallregi_giftcard_email_status_badge_html($updated->email_status),
                    'sent_at_display' => implode(' · ', $sent_lines),
                )
            );
        }

        /**
         * AJAX: re-send a gift card SMS from the scheduled deliveries screen.
         *
         * @return void
         */
        public function wallregi_resend_giftcard_sms_callback()
        {
            check_ajax_referer('wallregi_nonce_action', 'wallreginonce');

            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(
                    array(
                        'message' => __('You do not have permission to perform this action.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            $giftcard_id = isset($_POST['giftcard_id']) ? absint(wp_unslash($_POST['giftcard_id'])) : 0;
            if ($giftcard_id < 1) {
                wp_send_json_error(
                    array(
                        'message' => __('Invalid gift card.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            global $wpdb;

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
            $giftcard = $wpdb->get_row(
                $wpdb->prepare(
                    'SELECT * FROM %i WHERE `id` = %d',
                    wallregi_giftcard_db_table_name(),
                    $giftcard_id
                )
            );

            if (!$giftcard || empty($giftcard->giftcard_number)) {
                wp_send_json_error(
                    array(
                        'message' => __('Gift card not found.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            if (!function_exists('wallregi_giftcard_should_send_sms_for_channel') || !wallregi_giftcard_should_send_sms_for_channel($giftcard)) {
                wp_send_json_error(
                    array(
                        'message' => __('This gift card is not configured for SMS delivery.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            if (empty($giftcard->receipent_phone)) {
                wp_send_json_error(
                    array(
                        'message' => __('This gift card does not have a recipient phone number.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            $extra = array(
                'force_resend' => true,
                'admin_resend' => true,
            );

            if (function_exists('wallregi_gtw_sms_delivery_is_active') && wallregi_gtw_sms_delivery_is_active() && class_exists('WALLREGI_GTW_SMS')) {
                $epass = array();
                if (!empty($giftcard->epass_data)) {
                    $decoded = json_decode($giftcard->epass_data, true);
                    if (is_array($decoded)) {
                        $epass = $decoded;
                        unset($epass['smsSentAt']);
                    }
                }

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Allow GTW admin resend.
                $wpdb->update(
                    wallregi_giftcard_db_table_name(),
                    array(
                        'sms_status' => 0,
                        'epass_data' => wp_json_encode($epass),
                    ),
                    array('id' => $giftcard_id),
                    array('%d', '%s'),
                    array('%d')
                );

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Refresh row after marker reset.
                $giftcard = $wpdb->get_row(
                    $wpdb->prepare(
                        'SELECT * FROM %i WHERE `id` = %d',
                        wallregi_giftcard_db_table_name(),
                        $giftcard_id
                    )
                );

                $result = WALLREGI_GTW_SMS::send_for_giftcard_row($giftcard, WALLREGI_GTW_API_Client::get_settings());
                if (is_wp_error($result)) {
                    wp_send_json_error(array('message' => $result->get_error_message()));
                }
                if (false === $result) {
                    wp_send_json_error(
                        array(
                            'message' => __('Could not send the gift card SMS. Check your SMS settings and try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                        )
                    );
                }
            } else {
                do_action('wallregi_send_giftcard_sms', $giftcard->giftcard_number, $extra);
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
            $updated = $wpdb->get_row(
                $wpdb->prepare(
                    'SELECT `sms_status`, `sms_sent_at`, `sent_at`, `delivery_channel`, `email_status` FROM %i WHERE `id` = %d',
                    wallregi_giftcard_db_table_name(),
                    $giftcard_id
                )
            );

            if (!$updated || (int) $updated->sms_status !== 1) {
                wp_send_json_error(
                    array(
                        'message' => __('Could not send the gift card SMS. Check your SMS settings and try again.', 'wallet-ready-gift-cards-for-woocommerce'),
                    )
                );
            }

            $sent_lines = array();
            if (function_exists('wallregi_giftcard_should_send_email_for_channel') && wallregi_giftcard_should_send_email_for_channel($updated) && !empty($updated->sent_at)) {
                $sent_lines[] = sprintf(
                    /* translators: %s: formatted datetime */
                    __('Email: %s', 'wallet-ready-gift-cards-for-woocommerce'),
                    wallregi_format_giftcard_admin_datetime($updated->sent_at)
                );
            }
            $sent_lines[] = sprintf(
                /* translators: %s: formatted datetime */
                __('SMS: %s', 'wallet-ready-gift-cards-for-woocommerce'),
                wallregi_format_giftcard_admin_datetime($updated->sms_sent_at ?? '')
            );

            wp_send_json_success(
                array(
                    'message' => __('Gift card SMS sent successfully.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'sms_status' => (int) $updated->sms_status,
                    'status_badge_html' => wallregi_giftcard_sms_status_badge_html($updated->sms_status),
                    'sent_at_display' => implode(' · ', $sent_lines),
                )
            );
        }
    }
}

new WALLREGI_Gift_Card_Backend();
