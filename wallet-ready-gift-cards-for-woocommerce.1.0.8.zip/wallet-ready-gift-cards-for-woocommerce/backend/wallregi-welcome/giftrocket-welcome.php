<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function wallregi_register_welcome_page() {
    add_submenu_page(
        null,
        __( 'GiftRocket', 'wallet-ready-gift-cards-for-woocommerce' ),
        __( 'Welcome', 'wallet-ready-gift-cards-for-woocommerce' ),
        function_exists( 'wallregi_admin_capability' ) ? wallregi_admin_capability() : 'manage_options',
        'wallregi-welcome',
        'wallregi_welcome_page_callback'
    );
}
add_action( 'admin_menu', 'wallregi_register_welcome_page', 99 );

add_action( 'current_screen', 'wallregi_set_welcome_page_title' );
add_action( 'admin_head', 'wallregi_set_welcome_page_title', 1 );
function wallregi_set_welcome_page_title() {
    if ( isset( $_GET['page'] ) && 'wallregi-welcome' === $_GET['page'] ) {
        global $title;
        if ( empty( $title ) ) {
            $title = __( 'GiftRocket Welcome', 'wallet-ready-gift-cards-for-woocommerce' );
        }
    }
}

/**
 * Disable all admin notices on the Single Product Customizer Welcome page.
 */
function wallregi_disable_welcome_page_notices() {

	if ( isset( $_GET['page'] ) && 'wallregi-welcome' === sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
	}
}
add_action( 'admin_head', 'wallregi_disable_welcome_page_notices', 1 );

function wallregi_welcome_page_callback() {
    $capability = function_exists( 'wallregi_admin_capability' ) ? wallregi_admin_capability() : 'manage_options';
    if ( ! current_user_can( $capability ) ) {
        wp_die( esc_html__( 'You do not have permission to access this page.', 'wallet-ready-gift-cards-for-woocommerce' ) );
    }

    echo '<div class="wrap">';
    wallregi_welcome_content();
    echo '</div>';
}

function wallregi_enqueue_welcome_page_assets( $hook_suffix ) {
    $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
    if ( ! $screen || false === strpos( $screen->id, 'wallregi-welcome' ) ) {
        return;
    }

    wp_enqueue_style(
        'wallregi_welcome_page_style',
        WALLREGI_PLUGIN_URL . 'backend/assets/css/giftrocket-welcome.css',
        [],
        WALLREGI_VERSION,
        'all'
    );
    wp_enqueue_style(
        'wallregi-setup-notice-style',
        WALLREGI_PLUGIN_URL . 'backend/assets/css/wallregi-setup-notice.css',
        array(),
        WALLREGI_VERSION
    );

    wp_enqueue_script( 'jquery' );
    wp_enqueue_script(
        'wallregi_welcome_page_script',
        WALLREGI_PLUGIN_URL . 'backend/assets/js/giftrocket-welcome.js',
        array( 'jquery' ),
        WALLREGI_VERSION,
        true
    );

    wp_localize_script(
        'wallregi_welcome_page_script',
        'wallregi_welcome_page',
        array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wallregi_welcome_page_nonce' ),
        )
    );
}
add_action( 'admin_enqueue_scripts', 'wallregi_enqueue_welcome_page_assets' );

function wallregi_welcome_content() {

    ?>
    <div class=" wallregi-welcome">

        <div class="wallregi-header">
            <h1 style="color: #ffffff">🎉 <?php esc_html_e('Welcome to GiftRocket for WooCommerce!', 'wallet-ready-gift-cards-for-woocommerce'); ?></h1>
            <p><?php esc_html_e('Your plugin has been successfully activated!', 'wallet-ready-gift-cards-for-woocommerce'); ?></p>
        </div>

        <div class="wallregi-content">
            <h2 class="wallregi-section-title"><?php esc_html_e('Stay updated with the latest features, security updates, tips and tricks.', 'wallet-ready-gift-cards-for-woocommerce'); ?></h2>

            <form method="post">
                <div class="wallregi-form-group">
                    <label for="admin_email"><?php esc_html_e('Email Address', 'wallet-ready-gift-cards-for-woocommerce'); ?></label>
                    <input type="email"
                           id="wallregi_admin_email"
                           name="wallregi_admin_email"
                           value="<?php echo esc_attr(get_option('admin_email')); ?>"
                           class="wallregi-input"
                           required
                           placeholder="Enter your email address">
                    <p style="font-size: 12px; color: #6c757d; margin-top: 5px;">
                        <?php esc_html_e('This email will be used for notifying to you.', 'wallet-ready-gift-cards-for-woocommerce'); ?>
                    </p>
                </div>

                <div class="wallregi-buttons">
                    <button type="button"
                            name="wallregi_welcome_subscribe"
                            id="wallregi_welcome_subscribe"
                            value="subscribe"
                            class="wallregi-btn wallregi-btn-primary">
                        <?php esc_html_e('Subscribe & Continue Setup', 'wallet-ready-gift-cards-for-woocommerce'); ?>
                    </button>
                    <button type="button"
                            name="wallregi_welcome_no_thanks"
                            id="wallregi_welcome_no_thanks"
                            value="no_thanks"
                            class="wallregi-btn wallregi-btn-secondary">
                        <?php esc_html_e('Skip & Continue Setup', 'wallet-ready-gift-cards-for-woocommerce'); ?>
                    </button>
                    <a href="https://www.webcartisan.com/products/gift-card-for-woocommerce/" class="wallregi-btn wallregi-btn-dashboard">
                        <?php esc_html_e('Get Pro', 'wallet-ready-gift-cards-for-woocommerce'); ?>
                    </a>
                </div>
            </form>

        </div>
        <?php if ( class_exists( 'WALLREGI_Setup_Help_Notice' ) && ! WALLREGI_Setup_Help_Notice::is_dismissed() ) : ?>
            <div class="wallregi-content wallregi-notice-warning">
                <?php WALLREGI_Setup_Help_Notice::render_card( false ); ?>
            </div>
        <?php endif; ?>
        <div class="wallregi-content webcartisan-another-plugins">
            <h2 class="wallregi-section-title"><?php esc_html_e('Our Other Products', 'wallet-ready-gift-cards-for-woocommerce'); ?></h2>
            <div class="wallregi-features">
                <div class="wallregi-feature">
                    <h3><?php esc_html_e('Variation Monster for WooCommerce', 'wallet-ready-gift-cards-for-woocommerce'); ?></h3>
                    <p><?php esc_html_e('Manage all variation products including variation swatches, quick view, variation gallery, and variation table.', 'wallet-ready-gift-cards-for-woocommerce'); ?></p>
                </div>
                <div class="wallregi-feature">
                    <h3><?php esc_html_e('Giveaway Lottery', 'wallet-ready-gift-cards-for-woocommerce'); ?></h3>
                    <p><?php esc_html_e('Ultimate giveaway lottery plugin for WooCommerce to run contests, raffles & campaigns.', 'wallet-ready-gift-cards-for-woocommerce'); ?></p>
                </div>
                <div class="wallregi-feature">
                    <h3><?php esc_html_e('Teachable Enrollment for WooCommerce', 'wallet-ready-gift-cards-for-woocommerce'); ?></h3>
                    <p><?php esc_html_e('Seamlessly integrate Teachable courses with your WooCommerce store for automated enrollments.', 'wallet-ready-gift-cards-for-woocommerce'); ?></p>
                </div>
                <div class="wallregi-feature">
                    <h3><?php esc_html_e('Single Product Page Customizer', 'wallet-ready-gift-cards-for-woocommerce'); ?></h3>
                    <p><?php esc_html_e('Customize the appearance and layout of individual product pages in WooCommerce.', 'wallet-ready-gift-cards-for-woocommerce'); ?></p>
                </div>
            </div>
        </div>
    </div>
    <?php
}


add_action( 'wp_ajax_wallregi_welcome_api_call', 'wallregi_welcome_api_call' );
function wallregi_welcome_api_call() {
    $capability = function_exists( 'wallregi_admin_capability' ) ? wallregi_admin_capability() : 'manage_options';
    if ( ! current_user_can( $capability ) ) {
        wp_send_json_error( array( 'message' => __( 'You do not have permission to access this page.', 'wallet-ready-gift-cards-for-woocommerce' ) ) );
    }

    check_ajax_referer( 'wallregi_welcome_page_nonce', 'nonce' );

    $admin_email = isset( $_POST['admin_email'] ) ? sanitize_email( wp_unslash( $_POST['admin_email'] ) ) : get_option( 'admin_email' );
    $site_url    = get_site_url();
    $type        = isset( $_POST['type'] ) ? sanitize_text_field( wp_unslash( $_POST['type'] ) ) : '';
    $api_url     = 'https://www.webcartisan.com/wp-json/giftrocket/v1/welcome-notice';

    $data = array(
        'site_url'    => $site_url,
        'admin_email' => $admin_email,
        'type'        => $type,
    );

    wp_remote_post(
        $api_url,
        array(
            'method'  => 'POST',
            'timeout' => 5,
            'blocking' => false,
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => wp_json_encode( $data ),
        )
    );

    update_option( 'wallregi_welcome_page_seen', '1' );

    wp_send_json_success(
        array(
            'url' => wallregi_gift_cards_admin_url( array( 'tab' => 'wallregi_dashboard' ) ),
        )
    );
}