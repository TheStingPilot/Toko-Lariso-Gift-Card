<?php
defined( 'ABSPATH' ) || exit;

/**
 * Gift Rocket Campaign Admin Notice.
 */
class Giftrocket_Campaign_Notice {
	/**
	 * Notice start date.
	 *
	 * @var string
	 */
	private $notice_start_date = '2026-01-01';

	/**
	 * Notice end date.
	 *
	 * @var string
	 */
	private $notice_end_date = '2030-12-31';

	/**
	 * Option name for notice dismissal state.
	 *
	 * @var string
	 */
	private $option_name = 'giftrocket_campaign_notice';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_notices', array( $this, 'show_admin_notice' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'wp_ajax_giftrocket_dismiss_notice', array( $this, 'ajax_dismiss_notice' ) );
	}

	/**
	 * Check if notice should be displayed.
	 *
	 * @return bool
	 */
	private function should_show_notice() {
		$pro_plugin_path = WP_PLUGIN_DIR . '/wallet-ready-gift-cards-for-woocommerce-pro/wallet-ready-gift-cards-for-woocommerce-pro.php';
		if ( file_exists( $pro_plugin_path ) ) {
			return false;
		}

		$current_date     = current_time( 'Y-m-d' );
		$current_datetime = current_time( 'mysql' );

		if ( $current_date < $this->notice_start_date || $current_date > $this->notice_end_date ) {
			return false;
		}

		$notice_status = get_option( $this->option_name, array() );

		if ( isset( $notice_status['dismissed_until'] ) ) {
			if ( $current_datetime < $notice_status['dismissed_until'] ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Display admin notice.
	 *
	 * @return void
	 */
	public function show_admin_notice() {
		if ( ! $this->should_show_notice() ) {
			return;
		}

		$icon_url = 'https://ps.w.org/wallet-ready-gift-cards-for-woocommerce/assets/icon-128X128.png?rev=3534403';
		$deal_url = 'https://giftrocketwp.com/sale-booster-admin';
		?>
		<div class="notice giftrocket-campaign-notice is-dismissible">
			<button type="button" class="notice-dismiss">
				<span class="screen-reader-text"><?php esc_html_e( 'Dismiss this notice.', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
			</button>
			<div class="wallregi-notice-glow"></div>
			<div class="wallregi-notice-inner">
				<div class="wallregi-notice-icon-container">
					<img src="<?php echo esc_url( $icon_url ); ?>" alt="<?php esc_attr_e( 'Gift Rocket Logo', 'wallet-ready-gift-cards-for-woocommerce' ); ?>" class="wallregi-notice-icon" />
				</div>

				<div class="wallregi-notice-body">
					<div class="wallregi-notice-badge">
						<span class="wallregi-badge-dot"></span>
						<span><?php esc_html_e( 'SALE BOOSTER DEAL', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
						<span class="wallregi-badge-discount"><?php esc_html_e( '25% OFF', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
					</div>
					<h3 class="wallregi-notice-title">
						<?php esc_html_e( 'Boost Sales with GiftRocket Gift Cards!', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
					</h3>
					<p class="wallregi-notice-slogan">
						<?php esc_html_e( 'Create wallet-ready gift cards for your WooCommerce store and drive repeat purchases with ease.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
					</p>
				</div>

				<div class="wallregi-notice-actions">
					<a href="<?php echo esc_url( $deal_url ); ?>" target="_blank" rel="noopener noreferrer" class="wallregi-notice-cta-btn">
						<span><?php esc_html_e( 'Get 25% Discount', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
							<line x1="5" y1="12" x2="19" y2="12"></line>
							<polyline points="12 5 19 12 12 19"></polyline>
						</svg>
					</a>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Enqueue scripts and styles.
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		if ( ! $this->should_show_notice() ) {
			return;
		}

		wp_enqueue_style(
			'giftrocket-campaign-notice',
			WALLREGI_PLUGIN_URL . 'backend/assets/css/campaign-notice.css',
			array(),
			WALLREGI_VERSION
		);

		wp_enqueue_script(
			'giftrocket-campaign-notice',
			WALLREGI_PLUGIN_URL . 'backend/assets/js/bfcm-admin-notice.js',
			array( 'jquery' ),
			WALLREGI_VERSION,
			true
		);

		wp_localize_script(
			'giftrocket-campaign-notice',
			'GiftRocketNotice',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'giftrocket_notice_nonce' ),
			)
		);
	}

	/**
	 * AJAX handler for dismissing notice.
	 *
	 * @return void
	 */
	public function ajax_dismiss_notice() {
		check_ajax_referer( 'giftrocket_notice_nonce', 'nonce' );

		$action = isset( $_POST['dismiss_action'] ) ? sanitize_text_field( wp_unslash( $_POST['dismiss_action'] ) ) : '';

		if ( 'later' === $action ) {
			$tomorrow = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) + DAY_IN_SECONDS );
			update_option(
				$this->option_name,
				array(
					'dismissed_until' => $tomorrow,
				)
			);

			wp_send_json_success(
				array(
					'message'         => 'Notice dismissed until tomorrow',
					'dismissed_until' => $tomorrow,
				)
			);
		}

		wp_send_json_error( array( 'message' => 'Invalid action' ) );
	}
}

new Giftrocket_Campaign_Notice();
