<?php
// Ensure this file is not accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

?>

<div class="wrap">
    <div class="giftcard-dashboard">
        <div class="wallregi_giftcard__panel">
            <?php include_once WALLREGI_PLUGIN_DIR . 'backend/templates/sidebar/sidebar-menu.php'; ?>
            <div class="wallregi_giftcard__panel_content">
                <?php
                    // Ensure $tab is always defined with a default value
                    $tab = 'wallregi_dashboard';

                    if (isset($_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'wallregi_nonce_action')) {
                        $tab = isset($_GET['tab']) ? sanitize_text_field(wp_unslash($_GET['tab'])) : 'wallregi_dashboard';
                    }

                    // Define the allowed tabs and their corresponding file paths
                    $tabs = [
                        'wallregi_dashboard' => 'backend/templates/dashboard/dashboard.php',
                        'wallregi_scheduled_deliveries' => 'backend/templates/dashboard/scheduled-deliveries.php',
                        'new_giftcard'    => 'backend/templates/dashboard/manual-giftcards/manual-giftcards.php',
                        'wallregi_general'   => 'backend/templates/settings/unified-settings-hub.php',
                        'wallregi_form'      => 'backend/templates/settings/unified-settings-hub.php',
                        'wallregi_templates' => 'backend/templates/settings/unified-settings-hub.php',
                        'wallregi_email'     => 'backend/templates/settings/unified-settings-hub.php',
                        'wallregi_wallet'    => 'backend/templates/settings/unified-settings-hub.php',
                        'wallregi_status'    => 'backend/templates/settings/status-settings.php',
                        'wallregi_features'  => 'backend/templates/all_features/features.php',
                        'wallregi_support'   => 'backend/templates/support/support.php',
                    ];

                    $tabs = apply_filters( 'wallregi_admin_dashboard_tabs', $tabs );

                    require_once WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-admin-settings-persistence.php';
                    $wallregi_settings_hub_tabs = wallregi_admin_settings_hub_tab_keys();

                    // If the selected tab is not in the allowed list, default to 'wallregi_dashboard'

                    if ( $tab === 'wallregi_epasscard' ) {
                            do_action( 'wallregi_render_epasscard_tab', $tab );
                        } elseif ( in_array( $tab, $wallregi_settings_hub_tabs, true ) ) {
                            $wallregi_active_tab_key = $tab;
                            include_once WALLREGI_PLUGIN_DIR . 'backend/templates/settings/unified-settings-hub.php';
                        } else {
                            $wallregi_template_file = WALLREGI_PLUGIN_DIR . ($tabs[$tab] ?? $tabs['wallregi_dashboard']);
                            include_once $wallregi_template_file;
                        }
                ?>
            
            </div>
        </div>
    </div>
</div>

