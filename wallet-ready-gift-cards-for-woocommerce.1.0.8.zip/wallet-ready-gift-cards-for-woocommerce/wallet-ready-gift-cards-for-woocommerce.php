<?php 
/*
Plugin Name:        GiftRocket – Ultimate Gift Cards for WooCommerce
Description:        Unlock the full potential of gift cards with Wallet Ready Gift Cards for WooCommerce, a comprehensive plugin that enables you to create and manage gift card products, deliver PDFs via email, and facilitate seamless redemption at cart and checkout, including support for WooCommerce Cart and Checkout Blocks.
Author:             WebCartisan
Author URI:         https://webcartisan.com/
License:            GPL v3 or later
License URI:        https://www.gnu.org/licenses/gpl-3.0.html
Text Domain:        wallet-ready-gift-cards-for-woocommerce
Domain Path:        /languages
Requires at least:  6.5
Requires PHP:       8.1
Tested up to:       7.0
Version:            1.0.8
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'WALLREGI_PLUGIN_FILE' ) ) {
	define( 'WALLREGI_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'WALLREGI_VERSION' ) ) {
	define( 'WALLREGI_VERSION', '1.0.8' );
}

if ( ! defined( 'WALLREGI_PLUGIN_DIR' ) ) {
	define( 'WALLREGI_PLUGIN_DIR', plugin_dir_path( WALLREGI_PLUGIN_FILE ) );
}

if ( ! defined( 'WALLREGI_PLUGIN_URL' ) ) {
	define( 'WALLREGI_PLUGIN_URL', plugin_dir_url( WALLREGI_PLUGIN_FILE ) );
}

/**
 * Declare WooCommerce feature compatibility (HPOS + Cart/Checkout Blocks).
 */
add_action(
	'before_woocommerce_init',
	static function () {
		if ( ! class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			return;
		}
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WALLREGI_PLUGIN_FILE, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', WALLREGI_PLUGIN_FILE, true );
	}
);

require_once plugin_dir_path( __FILE__ ) . 'includes/wallregi-i18n.php';
wallregi_register_i18n();

require_once plugin_dir_path( __FILE__ ) . 'includes/wallregi-rtl.php';
wallregi_register_rtl();

// Include necessary files
require_once plugin_dir_path( __FILE__ ) . 'includes/database-functions.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/wallregi-sms-contract.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/wallregi-giftcard-phone.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/wallregi-admin-menu.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/wallregi-wallet-provider.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/wallregi-pro-capabilities.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-wallregi-pro-admin-placeholders.php';
WALLREGI_Pro_Admin_Placeholders::init();
require_once plugin_dir_path( __FILE__ ) . 'includes/wallregi-ai-hooks.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/wallregi-giftcard-code.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/wallregi-manual-giftcard-create.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/class-wallregi-bulk-import.php';
require_once plugin_dir_path( __FILE__ ) . 'backend/wallregi-welcome/giftrocket-welcome.php';
require_once plugin_dir_path( __FILE__ ) . 'backend/wallregi-welcome/giftrocket-notice.php';
require_once plugin_dir_path( __FILE__ ) . 'backend/wallregi-welcome/wallregi-setup-notice.php';

// === Activation Hook ===
register_activation_hook(__FILE__, 'wallregi_activation');
function wallregi_activation() {
    // Create required database tables
    wallregi_create_database_tables();
    // Flush permalinks so My Account gift card endpoints register.
    add_option( 'wallregi_flush_rewrite_rules', '1' );

    if ( ! get_option( 'wallregi_first_activated_time' ) ) {
        add_option( 'wallregi_first_activated_time', time() );
    }

    if ( get_option( 'wallregi_welcome_page_seen' ) ) {
        set_transient( 'wallregi_activation_redirect_target', 'dashboard', 60 );
    } else {
        update_option( 'wallregi_welcome_page_seen', '1' );
        set_transient( 'wallregi_activation_redirect_target', 'welcome', 60 );
    }
}

add_action( 'admin_init', 'wallregi_maybe_redirect_after_activation' );
function wallregi_maybe_redirect_after_activation() {
    $redirect_target = get_transient( 'wallregi_activation_redirect_target' );
    if ( ! $redirect_target ) {
        return;
    }

    delete_transient( 'wallregi_activation_redirect_target' );

    if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $redirect_url = 'welcome' === $redirect_target
        ? add_query_arg( array( 'page' => 'wallregi-welcome' ), admin_url( 'admin.php' ) )
        : wallregi_gift_cards_admin_url( array( 'tab' => 'wallregi_dashboard' ) );

    wp_safe_redirect( $redirect_url );
    exit;
}

// === Deactivation Hook ===
register_deactivation_hook(__FILE__, 'wallregi_deactivation');
function wallregi_deactivation() {
    // Clear scheduled cron event
    if (class_exists('WALLREGI_Cron_Schedule')) {
        WALLREGI_Cron_Schedule::deactivate_cron();
    }
}

/**
 * Check if WooCommerce is active (single-site + multisite).
 */
function wallregi_is_woocommerce_active() {
    if ( class_exists( 'WooCommerce' ) ) {
        return true;
    }
    $active_plugins = (array) get_option( 'active_plugins', [] );
    if ( in_array( 'woocommerce/woocommerce.php', $active_plugins, true ) ) {
        return true;
    }
    if ( is_multisite() ) {
        $network_active_plugins = array_keys( (array) get_site_option( 'active_sitewide_plugins', [] ) );
        if ( in_array( 'woocommerce/woocommerce.php', $network_active_plugins, true ) ) {
            return true;
        }
    }
    return false;
}
/**
 * Show admin notice when WooCommerce is missing.
 */
function wallregi_missing_woocommerce_notice() {
    if ( wallregi_is_woocommerce_active() ) {
        return;
    }
    if ( ! current_user_can( 'activate_plugins' ) ) {
        return;
    }
    echo '<div class="notice notice-warning"><p><strong>'
        . esc_html__( 'Wallet Ready Gift Cards requires WooCommerce to be installed and activated to use the plugin\'s full functionality.', 'wallet-ready-gift-cards-for-woocommerce' )
        . '</strong></p></div>';
}
add_action( 'admin_notices', 'wallregi_missing_woocommerce_notice' );

if ( wallregi_is_woocommerce_active() ) {

    require_once plugin_dir_path( __FILE__ ) . 'includes/initialize-giftcard.php';

    // Initialize Gift Card functionality
    if ( class_exists( 'WALLREGI_Initialize_Giftcard_Class' ) ) {
        new WALLREGI_Initialize_Giftcard_Class( plugin_dir_path( __FILE__ ), '1.0.3' );
    }

    add_action(
        'plugins_loaded',
        static function () {
            if ( class_exists( 'WALLREGI_Bulk_Import' ) ) {
                new WALLREGI_Bulk_Import();
            }
        },
        25
    );


    add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'wallregi_plugin_action_links' );
    function wallregi_plugin_action_links( $links ) {
        $action_links = array(
            'settings' => '<a href="' . esc_url( wallregi_gift_cards_admin_url( [ 'tab' => 'wallregi_dashboard' ] ) ) . '" aria-label="' . esc_attr__( 'View Gift Card Option Page Settings', 'wallet-ready-gift-cards-for-woocommerce' ) . '">' . esc_html__( 'Settings', 'wallet-ready-gift-cards-for-woocommerce' ) . '</a>',
        );

        return array_merge( $action_links, $links );
    }


    add_action('wp_footer', function() {
        $post_content      = get_post_field( 'post_content', get_queried_object_id() );
        $is_block_cart     = is_cart() && has_block( 'woocommerce/cart', $post_content );
        $is_block_checkout = is_checkout() && has_block( 'woocommerce/checkout', $post_content );

        if ( ! $is_block_cart && ! $is_block_checkout ) {
            return;
        }

        $wallregi_settings = get_option( 'wallregi_settings', [] );

        $wallregi_settings = wp_parse_args( $wallregi_settings, [
            'giftcard_edit_in_cart'         => 'yes',
            'giftcard_edit_in_checkout'     => 'no',
            'min_cprice'                    => 1,
            'max_cprice'                    => 9990,
            'manual_price_placeholder'      => 'Enter an amount',
            'name_label'                    => 'Receiver name',
            'email_label'                   => 'Receiver email',
            'greeting_label'                => 'Greeting/Message',
            'sender_label'                  => 'Sender name',
            'datepicker_label'              => 'Send at',
            'gallery_label'                 => __( 'Choose a picture', 'wallet-ready-gift-cards-for-woocommerce' ),
            'max_mgs_length'                => 250,
            'character_counts'              => 'yes',
        ] );

        $is_cart_edit_enabled = (bool) apply_filters(
            'wallregi_is_cart_edit_enabled',
            ( is_cart() && $wallregi_settings['giftcard_edit_in_cart'] === 'yes' ),
            $wallregi_settings
        );
        $is_checkout_edit_enabled = wallregi_checkout_giftcard_edit_is_enabled( $wallregi_settings );

        if ( $is_cart_edit_enabled || $is_checkout_edit_enabled ) :
                    

        ?>

        <div class="wallregi_edit_cart_modal_wrapper">
            <div class="wallregi_edit_cart_modal" id="wallregi_giftcard_edit_modal">
                <div class="wallregi_edit_modal_header">
                    <h3 class="wallregi_title edit_giftcard_heading">
                        <span class="edit_giftcard_heading_text"><?php esc_html_e('Edit Gift Card', 'wallet-ready-gift-cards-for-woocommerce'); ?></span>
                    </h3>

                    <span class="wallregi_edit_modal_close">&times;</span>
                </div>

                <form id="wallregi_edit_modal_form">
                    <div class="wallregi_form_price_edit_item">
                        <label class="wallregi_price_edit_heading">
                        <?php
                        esc_html_e('Giftcard Price', 'wallet-ready-gift-cards-for-woocommerce');
                        echo ' ( ' . esc_html(get_woocommerce_currency_symbol()). ') :';
                        ?>
                        </label>
                        <span id="edit_giftcard_price" > </span>
                    </div>
                    <div class="wallregi_form_item wallregi_custom_price_item" style="display: none;">
                        <div class="wallregi_price_item_wrap">
                            <ul class="wallregi_custom_price_options" id="wallregi_price_option_list">
                                <!-- Dynamic buttons will be injected here -->
                            </ul>
                            <div class="wallregi_manual_price_item" style="display: none;">
                                <div class="wallregi_custom_price_wraper">
                                    <input placeholder="<?php echo esc_attr('(' . get_woocommerce_currency_symbol() . ') ' . $wallregi_settings['manual_price_placeholder']); ?>" type="number" name="wallregi_custom_price[]" data-min="<?php echo esc_attr($wallregi_settings['min_cprice']); ?>" data-max="<?php echo esc_attr($wallregi_settings['max_cprice']); ?>" onclick="wallregiEditGiftCardManualPriceEnable(this)" onfocusout="wallregiEditGiftCardManualPriceFocusOut(this)" onkeyup="wallregiEditGiftCardManualPriceKeyUp(this)" class="wallregi_edit_input wallregi_cprice_input_field">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="wallregi_gallery_images_content_box">
                            <h4 class="wallregi_heading"><?php echo esc_html($wallregi_settings['gallery_label']); ?></h4>
                            <div class="wallregi_gallery_preview">
                                <figure class="wallregi_image_preview">
                                    <img id="edit_giftcard_image_preview" class="wallregi_image_thumb" src="" alt="Preview Image">
                                </figure>
                                <!-- Gallery will be injected here by JS -->
                                    <ul id="edit_giftcard_gallery" class="wallregi_images__gallery">
                                    </ul>
                            </div>
                    </div>           

                    <div class="wallregi_modal_form_contents">
                            <p class="woocommerce-info wallregi_edit_checkout_receiver_notice" style="display:none;" aria-live="polite"></p>
                            <div class="wallregi_edit_checkout_receiver_hidden_fields">
                            <div class="wallregi_modal_form_group">
                                <div class="wallregi_form_item">
                                    <label for="edit_receiver_name"><?php echo esc_html($wallregi_settings['name_label']); ?><span class="wallregi_field_required_mark">*</span></label>
                                    <input type="text" id="edit_receiver_name" name="receiver_name" class="wallregi_edit_input" required>
                                </div>
                                <div class="wallregi_form_item">
                                    <label for="edit_receiver_email"><?php echo esc_html($wallregi_settings['email_label']); ?><span class="wallregi_email_required_mark">*</span></label>
                                    <input type="email" id="edit_receiver_email" name="receiver_email" class="wallregi_edit_input" required>
                                </div>
                            </div>
                            <?php
                            if ( function_exists( 'wallregi_render_cart_edit_delivery_fields' ) ) {
                                wallregi_render_cart_edit_delivery_fields();
                            }
                            ?>
                
                        <?php
                        /** @see WALLREGI_Pro_Greeting_Presets */
                        do_action('wallregi_before_edit_greeting_textarea');
                        ?>
                        <div class="wallregi_form_item">
                            <label for="edit_receiver_message"><?php echo esc_html($wallregi_settings['greeting_label']); ?></label>
                            <textarea id="edit_receiver_message" name="receiver_message" class="wallregi_edit_textarea" maxlength="<?php echo esc_attr( (int) $wallregi_settings['max_mgs_length'] ); ?>" data-maxlength="<?php echo esc_attr( (int) $wallregi_settings['max_mgs_length'] ); ?>" onkeyup="wallregiGiftCardMessagePreview(this)" oninput="wallregiGiftCardMessagePreview(this)"></textarea>
                            <?php $wallregi_show_char_counts = ( ! isset( $wallregi_settings['character_counts'] ) || $wallregi_settings['character_counts'] === 'yes' ); ?>
                            <div id="edit_max_lenght" class="wallregi_edit_max_lenght" <?php echo $wallregi_show_char_counts ? 'style="display:block;"' : 'style="display:none;"'; ?>>
                                <div class="wallregi_charcter_count">
                                    <span><?php esc_html_e( 'Character count:', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span> 
                                    (<span class="charCount"><?php esc_html_e( '0', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>/<?php echo esc_html( (int) $wallregi_settings['max_mgs_length'] ); ?>)
                                </div>
                            </div>
                        </div>
                        <div class="wallregi_modal_form_group">
                            <div class="wallregi_form_item">
                                <label for="edit_sender_name"><?php echo esc_html($wallregi_settings['sender_label']); ?></label>
                                <input type="text" id="edit_sender_name" name="sender_name" class="wallregi_edit_input">
                            </div>
                            <div class="wallregi_form_item">
                                <label for="edit_email_schedule"><?php echo esc_html($wallregi_settings['datepicker_label']); ?></label>
                                <input type="text" id="edit_email_schedule" name="email_schedule" class="wallregi_edit_input wallregi_datetime_picker wallregi_datetime__field">
                            </div>
                        </div>
                        </div>

                    </div>
                    <div class="wallregi_form_button_items">
                    <button type="submit" class="button submit_btn"><?php esc_html_e('Update', 'wallet-ready-gift-cards-for-woocommerce'); ?></button>
                    <button type="button" class="button cancel_btn wallregi_edit_modal_close"><?php esc_html_e('Cancel', 'wallet-ready-gift-cards-for-woocommerce'); ?></button>
                </div>
                </form>
                
            </div>
        </div>

        <?php
        endif;
    });




    // Customize product data tabs
    add_filter('woocommerce_product_data_tabs', 'wallregi_giftcard_product_tabs', 99);
    function wallregi_giftcard_product_tabs($tabs) {
        // Hide all tabs except General
        $tabs_to_hide = [
            'inventory',
            'shipping',
            'linked_product',
            'attribute',
            'advanced',
            'variations',
            'custom_tab_name' // Add any other custom tabs you want to hide
        ];
        
        foreach ($tabs_to_hide as $tab_id) {
            if (isset($tabs[$tab_id])) {
                $tabs[$tab_id]['class'][] = 'hide_if_wxgiftcard';
            }
        }
        
        // Ensure General tab is visible
        if (isset($tabs['general'])) {
            //$tabs['general']['class'] = array_diff($tabs['general']['class'], ['hide_if_simple', 'hide_if_variable', 'hide_if_grouped']);
            //$tabs['general']['class'][] = 'show_if_wxgiftcard';
        }
        
        return $tabs;
    }

    // Force General tab to be active
    add_action('admin_footer', 'wallregi_force_general_tab_for_giftcard');
    function wallregi_force_general_tab_for_giftcard() {
        // Use WordPress inline scripts (instead of raw <script> tag output) for compatibility.
        wp_enqueue_script( 'jquery' );

        $inline_js = 'jQuery(document).ready(function($) {'
            . ' $(\'body\').on(\'woocommerce-product-type-change\', function(e, type) {'
            . ' if (type === \'wxgiftcard\') {'
            . ' $(\'.product_data_tabs .general_options\').addClass(\'active\').show();'
            . ' $(\'.product_data_tabs .marketplace-suggestions_options\').removeClass(\'active\');'
            . ' $(\'.options_group.pricing\').removeClass(\'hidden\').show();'
            . ' $(\'#_virtual\').parent().show();'
            . ' $(\'#general_product_data\').show();'
            . ' $(\'#_virtual\').attr(\'checked\', true);'
            . ' $(\'.woocommerce_options_panel\').not(\'#general_product_data\').hide();'
            . ' }'
            . ' });'
            . ' });';

        wp_add_inline_script( 'jquery', $inline_js );
    }


    /*******************
     * Start Add YouTube help link Function
     *******************/

    function wallregi_help_youtube_link($link){
        ?>
        <span class="wwallregi_youtube-link">
            <a href="<?php echo esc_attr($link); ?>"
            target="_blank"
            style="text-decoration: none;">
                <span class="dashicons dashicons-youtube" style="color: #FF0000;"></span>
            </a>
        </span>
        <?php
    }

    function wallregi_encrypt_password($password) {
        $iv = substr(AUTH_SALT, 0, 16);
        return base64_encode(openssl_encrypt($password, 'AES-256-CBC', AUTH_KEY, 0, $iv));
    }
    
    function wallregi_decrypt_password($encrypted) {
        $iv = substr(AUTH_SALT, 0, 16);
        return openssl_decrypt(base64_decode($encrypted), 'AES-256-CBC', AUTH_KEY, 0, $iv);
    }
    
    /*******************
     * End Add YouTube help link Function
     *******************/
} // End if ( wallregi_is_woocommerce_active() )



/**
 * Initialize the plugin tracker
 * @return  void
 */

function appsero_init_tracker_wallet_ready_gift_cards_for_woocommerce() {

    if ( ! class_exists( 'Appsero\Client' ) ) {
        $autoload = __DIR__ . '/vendor/autoload.php';
        if ( is_readable( $autoload ) ) {
            require_once $autoload;
        } else {
            require_once __DIR__ . '/vendor/appsero/client/src/Client.php';
        }
    }

    $client = new Appsero\Client( 'f81a45d0-0044-4e2d-baf8-68a40e870adc', '(GiftRocket) Wallet Ready Gift Cards for WooCommerce', __FILE__ );

    // Active insights
    $client->insights()->init();

}

appsero_init_tracker_wallet_ready_gift_cards_for_woocommerce();