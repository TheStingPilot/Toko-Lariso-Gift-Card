<?php
/**
 * Bulk gift card CSV import / migration (admin).
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$sample_url = isset( $wallregi_bulk_sample_url ) ? (string) $wallregi_bulk_sample_url : '';
$max_rows   = isset( $wallregi_bulk_max_rows ) ? (int) $wallregi_bulk_max_rows : 500;
$pro_cap    = ! empty( $wallregi_bulk_pro_high_cap );
$resume_job_id = isset( $wallregi_pro_bulk_resume_job_id ) ? (string) $wallregi_pro_bulk_resume_job_id : '';
$resume_job    = isset( $wallregi_pro_bulk_resume_job ) && is_array( $wallregi_pro_bulk_resume_job ) ? $wallregi_pro_bulk_resume_job : null;
?>
<div class="wrap wallregi-pro-bulk-import" id="wallregi-pro-bulk-wrap" data-resume-job-id="<?php echo esc_attr( $resume_job_id ); ?>">
	<h1><?php esc_html_e( 'Import gift cards (CSV)', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h1>

	<p class="description">
		<?php esc_html_e( 'Migrate from YITH Gift Cards, WP Swings Ultimate Gift Cards, PW Gift Cards, or any spreadsheet: export balances to CSV, map columns below, validate, then import in the background.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
	</p>

	<?php if ( $sample_url ) : ?>
		<p>
			<a class="button button-secondary" href="<?php echo esc_url( $sample_url ); ?>" download>
				<?php esc_html_e( 'Download sample CSV', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
			</a>
		</p>
	<?php endif; ?>

	<p class="description">
		<?php
		if ( $pro_cap ) {
			printf(
				/* translators: %d: maximum CSV data rows */
				esc_html__( 'Your site may import up to %d rows per file (GiftRocket Pro license active).', 'wallet-ready-gift-cards-for-woocommerce' ),
				(int) $max_rows
			);
		} else {
			printf(
				/* translators: %d: maximum CSV data rows */
				esc_html__( 'Free tier: up to %d rows per file. Activate GiftRocket Pro for up to 5,000 rows per import.', 'wallet-ready-gift-cards-for-woocommerce' ),
				(int) $max_rows
			);
		}
		?>
	</p>


	<hr />

	<h2><?php esc_html_e( 'CSV columns', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h2>
	<p class="description">
		<?php esc_html_e( 'First row must be a header. Column names are case-insensitive. Required: initial_amount, current_amount, expiry_period, recipient_name (or receipent_name), receipent_email, sender_name. Optional: giftcard_number (leave empty to auto-generate a code), message, product_id (wxgiftcard product ID or 0), preferred_date_time, giftcard_image.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
	</p>
	<p class="description">
		<strong><?php esc_html_e( 'expiry_period', 'wallet-ready-gift-cards-for-woocommerce' ); ?></strong>
		<?php esc_html_e( 'must be one of: 1 month, 3 months, 6 months, 1 year — or a fixed calendar date (YYYY-MM-DD).', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
	</p>
	<p class="description">
		<strong><?php esc_html_e( 'giftcard_number', 'wallet-ready-gift-cards-for-woocommerce' ); ?></strong>
		<?php esc_html_e( 'when set must be 5–19 characters with at least one letter and one digit (same rules as manual issuance). Duplicate codes in the file or already in the database are skipped and logged.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
	</p>

	<p class="description">
		<?php esc_html_e( 'If you start an import and reload this page, your in-progress job is restored automatically and polling continues until the job completes or fails.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
	</p>

	<hr />

	<form id="wallregi-pro-bulk-import-form" enctype="multipart/form-data" autocomplete="off">
		<?php wp_nonce_field( 'wallregi_pro_bulk_import', 'wallregi_pro_bulk_nonce' ); ?>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row">
					<label for="wallregi_pro_bulk_csv"><?php esc_html_e( 'CSV file', 'wallet-ready-gift-cards-for-woocommerce' ); ?></label>
				</th>
				<td>
					<input type="file" id="wallregi_pro_bulk_csv" name="csv" accept=".csv,text/csv" required />
					<p class="description">
						<?php
						printf(
							/* translators: 1: max rows, 2: max file size in MB */
							esc_html__( 'Maximum file size 5 MB; up to %1$d data rows per file.', 'wallet-ready-gift-cards-for-woocommerce' ),
							(int) $max_rows
						);
						?>
					</p>
				</td>
			</tr>
		</table>
		<p>
			<button type="button" class="button button-primary" id="wallregi-pro-bulk-validate">
				<?php esc_html_e( 'Validate CSV', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
			</button>
			<button type="button" class="button" id="wallregi-pro-bulk-queue" disabled>
				<?php esc_html_e( 'Start import (async)', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
			</button>
		</p>
	</form>

	<div id="wallregi-pro-bulk-messages" class="wallregi-pro-bulk-messages" aria-live="polite"></div>

	<h2><?php esc_html_e( 'Validation summary', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h2>
	<div id="wallregi-pro-bulk-validation-summary"></div>

	<h2><?php esc_html_e( 'Job status', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h2>
	<div id="wallregi-pro-bulk-job-status">
		<?php if ( $resume_job && '' !== $resume_job_id ) : ?>
			<table class="widefat">
				<tbody>
					<tr><th><?php esc_html_e( 'Status', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th><td><?php echo esc_html( isset( $resume_job['status'] ) ? (string) $resume_job['status'] : '' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Created', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th><td><?php echo esc_html( (string) ( $resume_job['inserted'] ?? 0 ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Skipped (duplicate)', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th><td><?php echo esc_html( (string) ( $resume_job['skipped_duplicate'] ?? 0 ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Failed', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th><td><?php echo esc_html( (string) ( $resume_job['failed'] ?? 0 ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Progress', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th><td><?php echo esc_html( (string) ( $resume_job['next_line_index'] ?? 0 ) . ' / ' . (string) ( $resume_job['total'] ?? 0 ) ); ?></td></tr>
					<?php if ( ! empty( $resume_job['last_message'] ) ) : ?>
						<tr><th><?php esc_html_e( 'Note', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th><td><?php echo esc_html( (string) $resume_job['last_message'] ); ?></td></tr>
					<?php endif; ?>
				</tbody>
			</table>
			<p class="description"><?php esc_html_e( 'This job is still running in the background. Counts refresh automatically every few seconds.', 'wallet-ready-gift-cards-for-woocommerce' ); ?></p>
		<?php endif; ?>
	</div>
</div>
