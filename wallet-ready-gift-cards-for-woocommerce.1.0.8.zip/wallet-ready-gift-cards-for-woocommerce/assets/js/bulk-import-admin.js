(function ($) {
	'use strict';

	var cfg = window.wallregiBulkImport || window.wallregiProBulkImport;

	var stagedToken = null;
	var jobId = null;
	var pollTimer = null;

	function escapeHtml(s) {
		return String(s)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function showMessage(html, type) {
		type = type || 'info';
		var cls = 'notice-info';
		if (type === 'error') {
			cls = 'notice-error';
		} else if (type === 'success') {
			cls = 'notice-success';
		}
		$('#wallregi-pro-bulk-messages').append(
			'<div class="notice ' + cls + ' is-dismissible"><p>' + html + '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss</span></button></div>'
		);
	}

	function renderValidation(data) {
		var $box = $('#wallregi-pro-bulk-validation-summary');
		$box.empty();
		if (!data) {
			return;
		}
		var html = '<p><strong>' + escapeHtml(String(data.row_count || 0)) + '</strong> rows ready to import.</p>';
		if (data.errors && data.errors.length) {
			html += '<h3>Validation issues</h3><table class="widefat striped"><thead><tr><th>CSV line</th><th>Message</th></tr></thead><tbody>';
			data.errors.forEach(function (e) {
				html += '<tr><td>' + escapeHtml(String(e.line || '')) + '</td><td>' + escapeHtml(String(e.message || '')) + '</td></tr>';
			});
			html += '</tbody></table>';
		}
		if (data.duplicates && data.duplicates.length) {
			html += '<p><strong>Duplicate codes in file:</strong> ' + escapeHtml(data.duplicates.join(', ')) + '</p>';
		}
		$box.html(html);
	}

	function renderJob(job) {
		var $box = $('#wallregi-pro-bulk-job-status');
		if (!job) {
			$box.empty();
			return;
		}
		var html = '<table class="widefat"><tbody>';
		html += '<tr><th>Status</th><td>' + escapeHtml(String(job.status || '')) + '</td></tr>';
		html += '<tr><th>Created</th><td>' + escapeHtml(String(job.inserted || 0)) + '</td></tr>';
		html += '<tr><th>Skipped (duplicate)</th><td>' + escapeHtml(String(job.skipped_duplicate || 0)) + '</td></tr>';
		html += '<tr><th>Failed</th><td>' + escapeHtml(String(job.failed || 0)) + '</td></tr>';
		html += '<tr><th>Progress</th><td>' + escapeHtml(String(job.next_line_index || 0)) + ' / ' + escapeHtml(String(job.total || 0)) + '</td></tr>';
		if (job.last_message) {
			html += '<tr><th>Note</th><td>' + escapeHtml(String(job.last_message)) + '</td></tr>';
		}
		html += '</tbody></table>';
		if (job.log && job.log.length) {
			html += '<h3>Recent log</h3><table class="widefat striped"><thead><tr><th>Line</th><th>Message</th></tr></thead><tbody>';
			job.log.forEach(function (e) {
				html += '<tr><td>' + escapeHtml(String(e.line || '')) + '</td><td>' + escapeHtml(String(e.message || '')) + '</td></tr>';
			});
			html += '</tbody></table>';
		}
		$box.html(html);
	}

	function stopPoll() {
		if (pollTimer) {
			window.clearInterval(pollTimer);
			pollTimer = null;
		}
	}

	function startPoll() {
		stopPoll();
		if (!jobId) {
			return;
		}
		pollTimer = window.setInterval(function () {
			$.post(
				cfg.ajaxUrl,
				{
					action: 'wallregi_pro_bulk_job_status',
					nonce: cfg.nonce,
					job_id: jobId,
				}
			)
				.done(function (res) {
					if (!res || !res.success || !res.data) {
						return;
					}
					renderJob(res.data);
					var st = String(res.data.status || '');
					if (st === 'completed' || st === 'failed') {
						stopPoll();
						if (st === 'completed') {
							showMessage('Import finished.', 'success');
						}
					}
				});
		}, 2000);
	}

	$(document).on('click', '#wallregi-pro-bulk-messages .notice-dismiss', function () {
		$(this).closest('.notice').remove();
	});

	function getBulkCsvFileInput() {
		var el = document.getElementById('wallregi_pro_bulk_csv');
		if (!el) {
			el = document.querySelector('#wallregi-pro-bulk-import-form input[type="file"][name="csv"]');
		}
		return el;
	}

	$('#wallregi-pro-bulk-validate').on('click', function () {
		if (typeof cfg === 'undefined') {
			return;
		}
		var fileInput = getBulkCsvFileInput();
		if (!fileInput || !fileInput.files || !fileInput.files.length) {
			window.alert(cfg.strings.pickFile);
			return;
		}

		var file = fileInput.files[0];
		var fd = new FormData();
		fd.append('action', 'wallregi_pro_bulk_validate_csv');
		fd.append('nonce', cfg.nonce);
		// Third argument helps some servers recognize the part as a file upload.
		fd.append('csv', file, file && file.name ? file.name : 'bulk-import.csv');

		stagedToken = null;
		jobId = null;
		stopPoll();
		$('#wallregi-pro-bulk-queue').prop('disabled', true);
		$('#wallregi-pro-bulk-validation-summary').empty();
		$('#wallregi-pro-bulk-job-status').empty();
		showMessage(cfg.strings.validating, 'info');

		$.ajax({
			url: cfg.ajaxUrl,
			type: 'POST',
			data: fd,
			processData: false,
			contentType: false,
		})
			.done(function (res) {
				$('#wallregi-pro-bulk-messages .notice').remove();
				if (!res || !res.success) {
					var err = res && res.data && res.data.message ? String(res.data.message) : 'Request failed.';
					showMessage(escapeHtml(err), 'error');
					return;
				}
				var d = res.data;
				renderValidation(d);
				if (!d.ok) {
					showMessage('Validation failed. Fix the CSV and try again.', 'error');
					return;
				}
				stagedToken = d.token;
				$('#wallregi-pro-bulk-queue').prop('disabled', false);
				showMessage('Validation passed. You can start the import.', 'success');
			})
			.fail(function () {
				$('#wallregi-pro-bulk-messages .notice').remove();
				showMessage('Network error during validation.', 'error');
			});
	});

	$('#wallregi-pro-bulk-queue').on('click', function () {
		if (typeof cfg === 'undefined') {
			return;
		}
		if (!stagedToken) {
			window.alert(cfg.strings.validateFirst);
			return;
		}
		showMessage(cfg.strings.queueing, 'info');
		$.post(cfg.ajaxUrl, {
			action: 'wallregi_pro_bulk_queue_import',
			nonce: cfg.nonce,
			token: stagedToken,
		})
			.done(function (res) {
				$('#wallregi-pro-bulk-messages .notice').remove();
				if (!res || !res.success || !res.data || !res.data.job_id) {
					var err = res && res.data && res.data.message ? String(res.data.message) : 'Could not queue import.';
					showMessage(escapeHtml(err), 'error');
					return;
				}
				jobId = res.data.job_id;
				stagedToken = null;
				$('#wallregi-pro-bulk-queue').prop('disabled', true);
				showMessage(escapeHtml(String(res.data.message || 'Queued.')), 'success');
				$.post(cfg.ajaxUrl, {
					action: 'wallregi_pro_bulk_job_status',
					nonce: cfg.nonce,
					job_id: jobId,
				}).done(function (r2) {
					if (r2 && r2.success && r2.data) {
						renderJob(r2.data);
					}
				});
				startPoll();
			})
			.fail(function () {
				$('#wallregi-pro-bulk-messages .notice').remove();
				showMessage('Network error while queueing.', 'error');
			});
	});

	$(function () {
		var rid = '';
		if (typeof cfg !== 'undefined' && cfg.resumeJobId) {
			rid = String(cfg.resumeJobId).trim();
		}
		if (!rid) {
			var $w = $('#wallregi-pro-bulk-wrap');
			if ($w.length) {
				rid = String($w.data('resumeJobId') || $w.attr('data-resume-job-id') || '').trim();
			}
		}
		if (!rid) {
			return;
		}
		if (typeof cfg === 'undefined') {
			return;
		}
		jobId = rid;
		var resumeMsg = cfg.strings && cfg.strings.resumed
			? cfg.strings.resumed
			: 'Resuming import progress.';
		showMessage(escapeHtml(resumeMsg), 'info');
		$.post(cfg.ajaxUrl, {
			action: 'wallregi_pro_bulk_job_status',
			nonce: cfg.nonce,
			job_id: jobId,
		}).done(function (r2) {
			if (r2 && r2.success && r2.data) {
				renderJob(r2.data);
				var st = String(r2.data.status || '');
				if (st !== 'completed' && st !== 'failed') {
					startPoll();
				}
			}
		});
	});
})(jQuery);
