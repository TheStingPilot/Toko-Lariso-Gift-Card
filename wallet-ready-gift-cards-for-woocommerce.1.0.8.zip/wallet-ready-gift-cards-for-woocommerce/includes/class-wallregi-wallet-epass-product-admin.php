<?php
/**
 * Admin: ePasscard template + field mapping on wxgiftcard products.
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WALLREGI_Wallet_Epass_Product_Admin.
 */
class WALLREGI_Wallet_Epass_Product_Admin {

	public const META_KEY = '_wallregi_epass_pass_config';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wallregi_after_giftcard_product_admin_fields', [ $this, 'render_section' ], 20, 1 );
		add_action( 'wallregi_save_giftcard_product_meta', [ $this, 'save_meta' ], 10, 1 );
		add_action( 'wp_ajax_wallregi_wallet_epass_get_templates', [ $this, 'ajax_get_templates' ] );
		add_action( 'wp_ajax_wallregi_wallet_epass_get_pass_fields', [ $this, 'ajax_get_pass_fields' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ], 25 );
	}

	/**
	 * Default gift element slugs and labels (filterable).
	 *
	 * @return array<string, string> slug => label
	 */
	public static function get_gift_element_labels() {
		$labels = [
			'receiver_name'    => __( 'Receiver name', 'wallet-ready-gift-cards-for-woocommerce' ),
			'receiver_email'   => __( 'Receiver email', 'wallet-ready-gift-cards-for-woocommerce' ),
			'receiver_message' => __( 'Greeting / message', 'wallet-ready-gift-cards-for-woocommerce' ),
			'sender_name'      => __( 'Sender name', 'wallet-ready-gift-cards-for-woocommerce' ),
			'giftcard_number'  => __( 'Gift card number', 'wallet-ready-gift-cards-for-woocommerce' ),
			'giftcard_image'   => __( 'Gift card image', 'wallet-ready-gift-cards-for-woocommerce' ),
			'initial_balance'  => __( 'Initial balance', 'wallet-ready-gift-cards-for-woocommerce' ),
			'current_balance'  => __( 'Current balance', 'wallet-ready-gift-cards-for-woocommerce' ),
			'used_balance'     => __( 'Used balance', 'wallet-ready-gift-cards-for-woocommerce' ),
			'expiry_date'      => __( 'Expiry date', 'wallet-ready-gift-cards-for-woocommerce' ),
		];

		/**
		 * Filter gift card data elements available for ePass field mapping.
		 *
		 * @param array<string, string> $labels slug => translated label.
		 */
		return (array) apply_filters( 'wallregi_epass_gift_element_map_keys', $labels );
	}

	/**
	 * @param WP_Post $post Product post.
	 */
	public function render_section( $post ) {
		if ( ! $post instanceof WP_Post || ! current_user_can( 'edit_product', $post->ID ) ) {
			return;
		}

		if ( ! function_exists( 'wc_get_product' ) ) {
			return;
		}

		$product = wc_get_product( $post->ID );
		if ( ! $product instanceof WC_Product || 'wxgiftcard' !== $product->get_type() ) {
			return;
		}

		if ( function_exists( 'wallregi_wallet_provider_is_gifttowallet' ) && wallregi_wallet_provider_is_gifttowallet() ) {
			return;
		}

		if ( ! function_exists( 'wallregi_wallet_epass_is_api_configured' ) ) {
			$api_file = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-public-api.php';
			if ( file_exists( $api_file ) ) {
				require_once $api_file;
			}
		}

		if ( ! function_exists( 'wallregi_wallet_epass_is_api_configured' ) || ! wallregi_wallet_epass_is_api_configured() ) {
			return;
		}

		$saved = get_post_meta( $post->ID, self::META_KEY, true );
		$saved = is_array( $saved ) ? $saved : [];

		echo '<div class="options_group wallregi-epass-pass-template" id="wallregi-epass-pass-config">';

		echo '<h3 style="padding: 12px 12px 0;">' . esc_html__( 'Google / Apple Wallet (ePasscard)', 'wallet-ready-gift-cards-for-woocommerce' ) . '</h3>';
		echo '<p class="form-field" style="padding: 0 12px; margin-top: 0;">';
		echo esc_html__( 'Choose a pass template and map gift card data to pass fields. Values are loaded from ePasscard using your connected API key.', 'wallet-ready-gift-cards-for-woocommerce' );
		echo '</p>';

		echo '<p class="form-field" id="wallregi_epass_templates_row">';
		echo '<label for="wallregi_epass_template_uid">' . esc_html__( 'Pass template', 'wallet-ready-gift-cards-for-woocommerce' ) . '</label>';
		echo '<select name="wallregi_epass_template_uid" id="wallregi_epass_template_uid" style="max-width: 28rem;">';
		echo '<option value="">' . esc_html__( '— Select —', 'wallet-ready-gift-cards-for-woocommerce' ) . '</option>';
		if ( ! empty( $saved['template_uid'] ) && is_string( $saved['template_uid'] ) ) {
			$uid   = esc_attr( $saved['template_uid'] );
			$tname = isset( $saved['template_name'] ) ? (string) $saved['template_name'] : $saved['template_uid'];
			echo '<option value="' . $uid . '" selected>' . esc_html( $tname ) . '</option>';
		}
		echo '</select>';
		echo '<span class="description wallregi-epass-template-status" style="display:block;margin-top:6px;"></span>';
		echo '</p>';

		echo '<input type="hidden" name="wallregi_epass_template_name" id="wallregi_epass_template_name" value="' . esc_attr( isset( $saved['template_name'] ) ? (string) $saved['template_name'] : '' ) . '" />';
		echo '<input type="hidden" name="wallregi_epass_template_id" id="wallregi_epass_template_id" value="' . esc_attr( isset( $saved['template_id'] ) ? (string) (int) $saved['template_id'] : '0' ) . '" />';

		echo '<div id="wallregi_epass_mapping_wrap" style="display:none;">';
		echo '<p class="form-field"><strong>' . esc_html__( 'Field mapping', 'wallet-ready-gift-cards-for-woocommerce' ) . '</strong></p>';
		echo '<div id="wallregi_epass_mapping_rows"></div>';
		echo '</div>';

		$snapshot = isset( $saved['pass_fields'] ) && is_array( $saved['pass_fields'] ) ? $saved['pass_fields'] : [];
		echo '<textarea name="wallregi_epass_pass_fields_json" id="wallregi_epass_pass_fields_json" style="display:none;">';
		echo esc_textarea( wp_json_encode( $snapshot, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) );
		echo '</textarea>';

		$stripe_saved = isset( $saved['stripe_image_url'] ) ? esc_url( (string) $saved['stripe_image_url'] ) : '';
		echo '<p class="form-field wallregi-epass-stripe-url-row">';
		echo '<label for="wallregi_epass_stripe_image_url">' . esc_html__( 'Wallet pass stripe image (optional)', 'wallet-ready-gift-cards-for-woocommerce' ) . '</label>';
		echo '<input type="url" name="wallregi_epass_stripe_image_url" id="wallregi_epass_stripe_image_url" class="long" style="max-width:40rem;" value="' . esc_attr( $stripe_saved ) . '" placeholder="https://..." />';
		echo '<span class="description" style="display:block;margin-top:6px;">' . esc_html__( 'Used when the gift card has no PDF thumbnail. Overrides the global wallet stripe fallback for cards linked to this product.', 'wallet-ready-gift-cards-for-woocommerce' ) . '</span>';
		echo '</p>';

		echo '</div>';
	}

	/**
	 * @param int $post_id Product ID.
	 */
	public function save_meta( $post_id ) {
		$post_id = absint( $post_id );
		if ( $post_id <= 0 || ! current_user_can( 'edit_product', $post_id ) ) {
			return;
		}

		$this->require_api();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified in wallregi_save_giftcard_settings_data.
		$ptype = isset( $_POST['product-type'] ) ? sanitize_key( wp_unslash( $_POST['product-type'] ) ) : '';
		if ( 'wxgiftcard' !== $ptype ) {
			return;
		}

		// Section omitted from HTML when wallet is not configured — do not wipe saved meta.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! isset( $_POST['wallregi_epass_template_uid'] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$raw_template = isset( $_POST['wallregi_epass_template_uid'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['wallregi_epass_template_uid'] ) ) : '';
		$template_uid = wallregi_wallet_epass_sanitize_template_uid( $raw_template );

		if ( false === $template_uid ) {
			delete_post_meta( $post_id, self::META_KEY );
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$template_name = isset( $_POST['wallregi_epass_template_name'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['wallregi_epass_template_name'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$template_id = isset( $_POST['wallregi_epass_template_id'] ) ? absint( wp_unslash( $_POST['wallregi_epass_template_id'] ) ) : 0;

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$snapshot_raw = isset( $_POST['wallregi_epass_pass_fields_json'] ) ? wp_unslash( (string) $_POST['wallregi_epass_pass_fields_json'] ) : '';
		$snapshot     = json_decode( $snapshot_raw, true );
		if ( ! is_array( $snapshot ) ) {
			$snapshot = [];
		}

		$allowed_uids = [];
		$clean_fields = [];
		foreach ( $snapshot as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$f_uid = isset( $row['uid'] ) ? wallregi_wallet_epass_sanitize_template_uid( (string) $row['uid'] ) : false;
			if ( false === $f_uid ) {
				continue;
			}
			$allowed_uids[]                   = $f_uid;
			$clean_fields[]                   = [
				'uid'        => $f_uid,
				'field_name' => isset( $row['field_name'] ) ? sanitize_text_field( (string) $row['field_name'] ) : '',
				'field_type' => isset( $row['field_type'] ) ? sanitize_key( (string) $row['field_type'] ) : '',
			];
		}
		$allowed_uids = array_values( array_unique( $allowed_uids ) );

		$labels  = self::get_gift_element_labels();
		$mapping = [];

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$posted_map = isset( $_POST['wallregi_epass_mapping'] ) && is_array( $_POST['wallregi_epass_mapping'] ) ? wp_unslash( $_POST['wallregi_epass_mapping'] ) : [];

		foreach ( array_keys( $labels ) as $slug ) {
			$slug = (string) $slug;
			if ( ! isset( $posted_map[ $slug ] ) ) {
				$mapping[ $slug ] = '';
				continue;
			}
			$val = sanitize_text_field( (string) $posted_map[ $slug ] );
			$val = wallregi_wallet_epass_sanitize_template_uid( $val );
			if ( false === $val ) {
				$mapping[ $slug ] = '';
				continue;
			}
			$mapping[ $slug ] = in_array( $val, $allowed_uids, true ) ? $val : '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$stripe_image_url = isset( $_POST['wallregi_epass_stripe_image_url'] )
			? esc_url_raw( trim( wp_unslash( (string) $_POST['wallregi_epass_stripe_image_url'] ) ) )
			: '';

		$config = [
			'template_uid'   => $template_uid,
			'template_name'  => $template_name,
			'template_id'    => $template_id,
			'pass_fields'    => $clean_fields,
			'mapping'        => $mapping,
			'schema_version' => 1,
			'stripe_image_url' => $stripe_image_url,
		];

		update_post_meta( $post_id, self::META_KEY, $config );
	}

	/**
	 * AJAX: list templates (page 1).
	 */
	public function ajax_get_templates() {
		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'wallet-ready-gift-cards-for-woocommerce' ) ], 403 );
		}

		check_ajax_referer( 'wallregi_epass_product', 'nonce' );

		$this->require_api();

		$result = wallregi_wallet_epass_get_templates_page1();
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( [ 'message' => $result->get_error_message() ], 400 );
		}

		wp_send_json_success(
			[
				'templates'       => $result['templates'],
				'total_templates' => $result['total_templates'],
			]
		);
	}

	/**
	 * AJAX: pass fields for template uid.
	 */
	public function ajax_get_pass_fields() {
		if ( ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'wallet-ready-gift-cards-for-woocommerce' ) ], 403 );
		}

		check_ajax_referer( 'wallregi_epass_product', 'nonce' );

		$this->require_api();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$uid = isset( $_POST['template_uid'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['template_uid'] ) ) : '';
		$result = wallregi_wallet_epass_get_pass_fields_for_template( $uid );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( [ 'message' => $result->get_error_message() ], 400 );
		}

		wp_send_json_success( [ 'passFields' => $result['passFields'] ] );
	}

	/**
	 * Enqueue product editor script.
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public function enqueue( $hook_suffix ) {
		if ( 'post.php' !== $hook_suffix && 'post-new.php' !== $hook_suffix ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'product' !== $screen->post_type ) {
			return;
		}

		if ( ! function_exists( 'wallregi_wallet_epass_is_api_configured' ) ) {
			$api_file = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-public-api.php';
			if ( file_exists( $api_file ) ) {
				require_once $api_file;
			}
		}

		if ( ! function_exists( 'wallregi_wallet_epass_is_api_configured' ) || ! wallregi_wallet_epass_is_api_configured() ) {
			return;
		}

		wp_enqueue_script(
			'wallregi-product-wallet-pass',
			WALLREGI_PLUGIN_URL . 'backend/assets/js/product-wallet-pass-config.js',
			[ 'jquery' ],
			WALLREGI_VERSION,
			true
		);

		$post_id = 'post-new.php' === $hook_suffix ? 0 : (int) get_the_ID();

		$saved = $post_id > 0 ? get_post_meta( $post_id, self::META_KEY, true ) : [];
		$saved = is_array( $saved ) ? $saved : [];

		$labels = self::get_gift_element_labels();
		$elements = [];
		foreach ( $labels as $slug => $label ) {
			$elements[] = [
				'slug'  => (string) $slug,
				'label' => (string) $label,
			];
		}

		wp_localize_script(
			'wallregi-product-wallet-pass',
			'wallregiEpassProduct',
			[
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'wallregi_epass_product' ),
				'giftElements' => $elements,
				'savedConfig'  => [
					'template_uid'  => isset( $saved['template_uid'] ) ? (string) $saved['template_uid'] : '',
					'template_name' => isset( $saved['template_name'] ) ? (string) $saved['template_name'] : '',
					'template_id'   => isset( $saved['template_id'] ) ? (int) $saved['template_id'] : 0,
					'mapping'       => isset( $saved['mapping'] ) && is_array( $saved['mapping'] ) ? $saved['mapping'] : [],
					'pass_fields'   => isset( $saved['pass_fields'] ) && is_array( $saved['pass_fields'] ) ? $saved['pass_fields'] : [],
					'stripe_image_url' => isset( $saved['stripe_image_url'] ) ? (string) $saved['stripe_image_url'] : '',
				],
				'strings'    => [
					'loadingTemplates' => __( 'Loading templates…', 'wallet-ready-gift-cards-for-woocommerce' ),
					'loadingFields'    => __( 'Loading pass fields…', 'wallet-ready-gift-cards-for-woocommerce' ),
					'loadFailed'       => __( 'Could not load data from ePasscard.', 'wallet-ready-gift-cards-for-woocommerce' ),
					'notMapped'        => __( '— Not mapped —', 'wallet-ready-gift-cards-for-woocommerce' ),
					'selectTemplate'   => __( '— Select —', 'wallet-ready-gift-cards-for-woocommerce' ),
				],
			]
		);
	}

	/**
	 * Load API helpers.
	 */
	private function require_api() {
		$api_file = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-public-api.php';
		if ( file_exists( $api_file ) ) {
			require_once $api_file;
		}
	}
}
