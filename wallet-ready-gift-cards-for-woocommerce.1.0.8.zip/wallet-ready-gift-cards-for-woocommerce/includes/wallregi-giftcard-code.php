<?php
/**
 * Gift card code length, format pattern, and generation helpers.
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Minimum random characters in an auto-generated gift card code.
 *
 * @return int
 */
function wallregi_giftcard_code_min_length() {
	return (int) apply_filters( 'wallregi_giftcard_code_min_length', 5 );
}

/**
 * Maximum random characters in an auto-generated gift card code.
 *
 * @return int
 */
function wallregi_giftcard_code_max_length() {
	return (int) apply_filters( 'wallregi_giftcard_code_max_length', 19 );
}

/**
 * Maximum total characters allowed for a manually entered gift card code (including separators).
 *
 * @return int
 */
function wallregi_giftcard_code_max_total_length() {
	return (int) apply_filters( 'wallregi_giftcard_code_max_total_length', 19 );
}

/**
 * Minimum total characters allowed for a manually entered gift card code.
 *
 * @return int
 */
function wallregi_giftcard_code_min_total_length() {
	return (int) apply_filters( 'wallregi_giftcard_code_min_total_length', 5 );
}

/**
 * Configured random-character length for auto-generated codes.
 *
 * @param array<string, mixed>|null $settings Optional merged wallregi_settings.
 * @return int
 */
function wallregi_giftcard_code_length( $settings = null ) {
	if ( ! is_array( $settings ) ) {
		$settings = get_option( 'wallregi_settings', [] );
	}

	$length = isset( $settings['giftcard_code_length'] )
		? absint( $settings['giftcard_code_length'] )
		: 0;

	if ( $length <= 0 ) {
		$pattern = isset( $settings['coupon_pattren'] )
			? wallregi_giftcard_code_normalize_pattern( $settings['coupon_pattren'] )
			: '';
		$inferred = wallregi_giftcard_code_pattern_random_char_count( $pattern );
		if ( $inferred >= wallregi_giftcard_code_min_length() && $inferred <= wallregi_giftcard_code_max_length() ) {
			$length = $inferred;
		} else {
			$length = 16;
		}
	}

	$min = wallregi_giftcard_code_min_length();
	$max = wallregi_giftcard_code_max_length();

	return max( $min, min( $max, $length ) );
}

/**
 * Normalize a gift card format pattern string.
 *
 * @param string $pattern Raw pattern.
 * @return string
 */
function wallregi_giftcard_code_normalize_pattern( $pattern ) {
	return strtoupper( trim( (string) $pattern ) );
}

/**
 * Count random placeholder characters (* and D) in a pattern.
 *
 * @param string $pattern Format pattern.
 * @return int
 */
function wallregi_giftcard_code_pattern_random_char_count( $pattern ) {
	$pattern = wallregi_giftcard_code_normalize_pattern( $pattern );
	if ( '' === $pattern ) {
		return 0;
	}

	return substr_count( $pattern, '*' ) + substr_count( $pattern, 'D' );
}

/**
 * Whether a format pattern only uses supported characters.
 *
 * @param string $pattern Format pattern.
 * @return bool
 */
function wallregi_giftcard_code_pattern_is_valid( $pattern ) {
	$pattern = wallregi_giftcard_code_normalize_pattern( $pattern );
	if ( '' === $pattern ) {
		return false;
	}

	return (bool) preg_match( '/^[\\*D\\-_]+$/', $pattern );
}

/**
 * Placeholder type used in a format pattern (*, D, or mixed).
 *
 * @param string $pattern Format pattern.
 * @return string One of *, D, or mixed.
 */
function wallregi_giftcard_code_pattern_placeholder_type( $pattern ) {
	$pattern  = wallregi_giftcard_code_normalize_pattern( $pattern );
	$has_star = false !== strpos( $pattern, '*' );
	$has_digit = false !== strpos( $pattern, 'D' );

	if ( $has_star && $has_digit ) {
		return 'mixed';
	}
	if ( $has_digit ) {
		return 'D';
	}

	return '*';
}

/**
 * Whether generated codes must include both a letter and a digit.
 *
 * @param string $pattern Format pattern.
 * @return bool
 */
function wallregi_giftcard_code_pattern_requires_mixed_alnum( $pattern ) {
	return '*' === wallregi_giftcard_code_pattern_placeholder_type( $pattern );
}

/**
 * Build a default grouped pattern from a random-character length.
 *
 * @param int    $length      Random characters (* or D placeholders).
 * @param int    $group       Characters per group before a dash separator.
 * @param string $placeholder Placeholder character (* or D).
 * @return string
 */
function wallregi_giftcard_code_build_pattern( $length, $group = 4, $placeholder = '*' ) {
	$length = max( wallregi_giftcard_code_min_length(), min( wallregi_giftcard_code_max_length(), absint( $length ) ) );
	$group  = max( 1, absint( $group ) );
	$placeholder = ( 'D' === $placeholder ) ? 'D' : '*';

	$chars = str_repeat( $placeholder, $length );
	if ( $length <= $group ) {
		return $chars;
	}

	return implode( '-', str_split( $chars, $group ) );
}

/**
 * Expand or rebuild a pattern so its * / D count matches the configured length.
 *
 * Supports shorthand patterns such as "D" (digits only) with length 6 → "DDDDDD".
 *
 * @param string $pattern Raw or stored format pattern.
 * @param int    $length  Configured random-character length.
 * @return string
 */
function wallregi_giftcard_code_align_pattern_to_length( $pattern, $length ) {
	$pattern = wallregi_giftcard_code_normalize_pattern( $pattern );
	$length  = max( wallregi_giftcard_code_min_length(), min( wallregi_giftcard_code_max_length(), absint( $length ) ) );

	if ( ! wallregi_giftcard_code_pattern_is_valid( $pattern ) ) {
		return wallregi_giftcard_code_build_pattern( $length );
	}

	$random_count = wallregi_giftcard_code_pattern_random_char_count( $pattern );
	if ( $random_count === $length ) {
		return $pattern;
	}

	$placeholder_type = wallregi_giftcard_code_pattern_placeholder_type( $pattern );
	if ( 'mixed' === $placeholder_type ) {
		return wallregi_giftcard_code_build_pattern( $length );
	}

	$placeholder = ( 'D' === $placeholder_type ) ? 'D' : '*';

	if ( ! preg_match( '/[-_]/', $pattern ) ) {
		return str_repeat( $placeholder, $length );
	}

	$segments = preg_split( '/[-_]+/', $pattern );
	$segments = array_values( array_filter( $segments, static function ( $segment ) {
		return '' !== $segment;
	} ) );

	if ( empty( $segments ) ) {
		return wallregi_giftcard_code_build_pattern( $length, 4, $placeholder );
	}

	$segment_counts = array_map( 'wallregi_giftcard_code_pattern_random_char_count', $segments );
	$segment_total  = array_sum( $segment_counts );
	if ( $segment_total <= 0 ) {
		return wallregi_giftcard_code_build_pattern( $length, 4, $placeholder );
	}

	// Shrinking a long grouped pattern (e.g. legacy 16-char default) — rebuild cleanly.
	if ( $random_count > $length && count( $segments ) >= 3 ) {
		$group_hint = max( 1, min( (int) $segment_counts[0], $length ) );
		return wallregi_giftcard_code_build_pattern( $length, $group_hint, $placeholder );
	}

	$separator = ( false !== strpos( $pattern, '_' ) ) ? '_' : '-';
	$new_segments = array();
	$remaining    = $length;

	foreach ( $segment_counts as $index => $segment_count ) {
		$is_last = ( $index === count( $segment_counts ) - 1 );
		if ( $is_last ) {
			$segment_length = max( 1, $remaining );
		} else {
			$segment_length = max( 1, (int) round( $length * ( $segment_count / $segment_total ) ) );
			$segment_length = min( $segment_length, $remaining - ( count( $segment_counts ) - $index - 1 ) );
			$remaining     -= $segment_length;
		}

		$new_segments[] = str_repeat( $placeholder, $segment_length );
	}

	return implode( $separator, $new_segments );
}

/**
 * Effective format pattern used when generating codes.
 *
 * @param array<string, mixed>|null $settings Optional merged wallregi_settings.
 * @return string
 */
function wallregi_giftcard_code_effective_pattern( $settings = null ) {
	if ( ! is_array( $settings ) ) {
		$settings = get_option( 'wallregi_settings', [] );
	}

	$length  = wallregi_giftcard_code_length( $settings );
	$pattern = isset( $settings['coupon_pattren'] )
		? wallregi_giftcard_code_normalize_pattern( $settings['coupon_pattren'] )
		: '';

	return wallregi_giftcard_code_align_pattern_to_length( $pattern, $length );
}

/**
 * Keep length and format pattern aligned when settings are saved.
 *
 * @param mixed $value New option value.
 * @return mixed
 */
function wallregi_giftcard_code_pre_update_settings( $value ) {
	if ( ! is_array( $value ) ) {
		return $value;
	}

	$value['giftcard_code_length'] = wallregi_giftcard_code_length( $value );

	$pattern = isset( $value['coupon_pattren'] ) ? wallregi_giftcard_code_normalize_pattern( $value['coupon_pattren'] ) : '';
	$value['coupon_pattren']       = wallregi_giftcard_code_align_pattern_to_length( $pattern, $value['giftcard_code_length'] );

	return $value;
}
add_filter( 'pre_update_option_wallregi_settings', 'wallregi_giftcard_code_pre_update_settings' );

/**
 * Fill a pattern with random characters.
 *
 * @param string $pattern Format pattern.
 * @return string
 */
function wallregi_giftcard_code_fill_pattern( $pattern ) {
	$pattern = wallregi_giftcard_code_normalize_pattern( $pattern );
	$letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
	$digits  = '0123456789';
	$filled  = '';

	for ( $i = 0, $len = strlen( $pattern ); $i < $len; $i++ ) {
		$char = $pattern[ $i ];
		if ( '*' === $char ) {
			$filled .= $letters[ random_int( 0, strlen( $letters ) - 1 ) ];
		} elseif ( 'D' === $char ) {
			$filled .= $digits[ random_int( 0, 9 ) ];
		} else {
			$filled .= $char;
		}
	}

	return strtoupper( $filled );
}

/**
 * Whether the configured gift card format is digits-only (D placeholders).
 *
 * @param array<string, mixed>|null $settings Optional merged wallregi_settings.
 * @return bool
 */
function wallregi_giftcard_code_format_is_digits_only( $settings = null ) {
	if ( ! is_array( $settings ) ) {
		$settings = get_option( 'wallregi_settings', [] );
	}

	$pattern = wallregi_giftcard_code_effective_pattern( $settings );

	return 'D' === wallregi_giftcard_code_pattern_placeholder_type( $pattern );
}

/**
 * Validate a gift card code against configured format rules.
 *
 * @param string                    $code     Raw code (normalized internally).
 * @param array<string, mixed>|null $settings Optional merged wallregi_settings.
 * @return bool
 */
function wallregi_giftcard_code_format_valid( $code, $settings = null ) {
	$code = strtoupper( str_replace( ' ', '-', trim( (string) $code ) ) );
	$min  = wallregi_giftcard_code_min_total_length();
	$max  = wallregi_giftcard_code_max_total_length();

	if ( wallregi_giftcard_code_format_is_digits_only( $settings ) ) {
		$valid = (bool) preg_match( '/^(?=.*\d)[0-9_-]{' . $min . ',' . $max . '}$/', $code );
	} else {
		$valid = (bool) preg_match( '/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z0-9_-]{' . $min . ',' . $max . '}$/', $code );
	}

	return (bool) apply_filters( 'wallregi_giftcard_code_format_valid', $valid, $code, $settings );
}

/**
 * Human-readable validation error for gift card codes.
 *
 * @param array<string, mixed>|null $settings Optional merged wallregi_settings.
 * @return string
 */
function wallregi_giftcard_code_format_error_message( $settings = null ) {
	$min = wallregi_giftcard_code_min_total_length();
	$max = wallregi_giftcard_code_max_total_length();

	if ( wallregi_giftcard_code_format_is_digits_only( $settings ) ) {
		return sprintf(
			/* translators: 1: minimum characters, 2: maximum characters */
			__( 'Coupon code must be %1$d–%2$d characters, digits only (hyphens (-) or underscores (_) optional).', 'wallet-ready-gift-cards-for-woocommerce' ),
			$min,
			$max
		);
	}

	return sprintf(
		/* translators: 1: minimum characters, 2: maximum characters */
		__( 'Coupon code must be %1$d–%2$d characters, include both letters and numbers required, (hyphens (-) or underscores (_) optional).', 'wallet-ready-gift-cards-for-woocommerce' ),
		$min,
		$max
	);
}

/**
 * Client-side format hint: digits or mixed alphanumeric.
 *
 * @param array<string, mixed>|null $settings Optional merged wallregi_settings.
 * @return string One of digits or mixed.
 */
function wallregi_giftcard_code_format_client_type( $settings = null ) {
	return wallregi_giftcard_code_format_is_digits_only( $settings ) ? 'digits' : 'mixed';
}

/**
 * Whether a generated code includes at least one letter and one digit.
 *
 * @param string $code Gift card code.
 * @return bool
 */
function wallregi_giftcard_code_has_letter_and_digit( $code ) {
	$code = strtoupper( str_replace( ' ', '-', trim( (string) $code ) ) );
	return (bool) preg_match( '/[A-Z]/', $code ) && (bool) preg_match( '/\d/', $code );
}

/**
 * Generate a unique gift card coupon code.
 *
 * @param string $prefix Optional prefix.
 * @param string $suffix Optional suffix.
 * @return string
 */
function wallregi_generate_giftcard_coupon_code( $prefix = '', $suffix = '' ) {
	$settings = get_option( 'wallregi_settings', [] );
	$pattern  = wallregi_giftcard_code_effective_pattern( $settings );
	$requires_mixed_alnum = wallregi_giftcard_code_pattern_requires_mixed_alnum( $pattern );
	$attempts = 0;

	do {
		$final_code = wallregi_giftcard_code_fill_pattern( $pattern );
		if ( ! empty( $prefix ) ) {
			$final_code = strtoupper( sanitize_text_field( (string) $prefix ) ) . '-' . $final_code;
		}
		if ( ! empty( $suffix ) ) {
			$final_code = $final_code . '-' . strtoupper( sanitize_text_field( (string) $suffix ) );
		}
		++$attempts;
	} while ( $attempts < 12 && $requires_mixed_alnum && ! wallregi_giftcard_code_has_letter_and_digit( $final_code ) );

	return strtoupper( $final_code );
}

/**
 * Generate a gift card code for manual admin / bulk import flows.
 *
 * @param string $prefix Optional prefix.
 * @param string $suffix Optional suffix.
 * @return string
 */
function wallregi_generate_manual_giftcard_coupon_code( $prefix = '', $suffix = '' ) {
	return wallregi_generate_giftcard_coupon_code( $prefix, $suffix );
}
