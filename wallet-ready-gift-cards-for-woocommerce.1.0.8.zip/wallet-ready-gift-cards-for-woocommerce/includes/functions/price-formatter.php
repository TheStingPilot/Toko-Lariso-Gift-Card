<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Format price with currency symbol for gift card display
 *
 * @param string $wallregi_price The price amount
 * @param string $symbol The currency symbol
 * @param string $position Currency symbol position (left, right, left_space, right_space)
 * @param string $currency_code Currency code (e.g. BDT, AFN)
 * @return string Formatted price with currency symbol
 */
function wallregi_format_price($wallregi_price, $symbol, $position, $currency_code = '') {
    // Use local SVG for BDT and AFN if available; otherwise default to font glyphs
    if ($currency_code === 'BDT') {
        $svg_url = WALLREGI_PLUGIN_URL . 'assets/imgs/currency-taka.svg';
        $symbol_html = '<span class="currency-symbol"><img src="' . esc_url($svg_url) . '" alt="৳" /></span>';
    } elseif ($currency_code === 'AFN') {
        $svg_url = WALLREGI_PLUGIN_URL . 'assets/imgs/currency-afn.svg';
        $symbol_html = '<span class="currency-symbol"><img src="' . esc_url($svg_url) . '" alt="؋" /></span>';
    } else {
        $symbol_html = '<span class="currency-symbol">' . esc_html($symbol) . '</span>';
    }
    
    switch ($position) {
        case 'left':
            return $symbol_html . $wallregi_price;
        case 'right':
            return $wallregi_price . $symbol_html;
        case 'left_space':
            return $symbol_html . ' ' . $wallregi_price;
        case 'right_space':
            return $wallregi_price . ' ' . $symbol_html;
        default:
            return $symbol_html . $wallregi_price;
    }
}