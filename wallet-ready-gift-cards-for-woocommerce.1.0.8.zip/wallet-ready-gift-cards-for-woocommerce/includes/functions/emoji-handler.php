<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Replaces emoji characters with Twemoji SVG images
 * 
 * This function converts Unicode emoji characters in the text to their 
 * corresponding Twemoji SVG image representations while preserving 
 * currency symbols and other text.
 * 
 * @param string $text The text containing emojis to be replaced
 * @return string Text with emoji characters replaced with Twemoji SVG images
 */
if (!function_exists('wallregi_replace_all_emojis_dynamic')) {
    function wallregi_replace_all_emojis_dynamic($text) {
        $plugin_main_file = dirname(__DIR__, 2) . '/wallet-ready-gift-cards-for-woocommerce.php';
        $twemoji_base_url = plugins_url('assets/twemoji/svg/', $plugin_main_file);
        $twemoji_base_dir = dirname(__DIR__, 2) . '/assets/twemoji/svg/';
        
        // Decode HTML entities first
        $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
        
        // Replace only emoji codepoints with Twemoji images (keep currency symbols/text)
        $emoji_regex = '/[\x{1F600}-\x{1F64F}\x{1F300}-\x{1F5FF}\x{1F680}-\x{1F6FF}\x{2600}-\x{26FF}\x{2700}-\x{27BF}\x{1F900}-\x{1F9FF}\x{1FA70}-\x{1FAFF}\x{1F1E6}-\x{1F1FF}]/u';
        $text = preg_replace_callback($emoji_regex, 
            function($matches) use ($twemoji_base_url, $twemoji_base_dir) {
                $char = $matches[0];
                $codePoint = mb_ord($char, 'UTF-8');
                
                if ($codePoint > 127) {
                    $code = dechex($codePoint);
                    $local_svg_path = $twemoji_base_dir . $code . '.svg';

                    // Keep the original character if local asset does not exist.
                    if (!file_exists($local_svg_path)) {
                        return $char;
                    }

                    return '<img src="' . esc_url($twemoji_base_url . $code . '.svg') . '" width="16" height="16" style="vertical-align: middle;">';
                }
                
                return $char;
            }, 
            $text);
        
        return $text;
    }
}