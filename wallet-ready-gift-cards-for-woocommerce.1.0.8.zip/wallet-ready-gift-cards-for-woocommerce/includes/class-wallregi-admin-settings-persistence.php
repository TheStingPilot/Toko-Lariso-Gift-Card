<?php
/**
 * Centralized load/save for plugin settings (classic POST + AJAX).
 *
 * @package Wallet_Ready_Gift_Cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tab keys handled by the unified settings hub (AJAX save + in-page navigation).
 *
 * @return string[]
 */
function wallregi_admin_settings_hub_tab_keys() {
	return apply_filters(
		'wallregi_settings_hub_tab_keys',
		[
			'wallregi_general',
			'wallregi_form',
			'wallregi_templates',
			'wallregi_email',
			'wallregi_wallet',
		]
	);
}

/**
 * Extra defaults merged after field-driven defaults (matches legacy settings-helper.php).
 *
 * @return array<string, mixed>
 */
function wallregi_admin_settings_special_defaults() {
	return [
		'image_cleanup_age' => WEEK_IN_SECONDS,
		'solid_color'       => '#f8fafb',
		'gradient_start'    => '#e7eff2',
		'gradient_middle'   => '#d7ebe7',
		'gradient_end'      => '#e7eff2',
		'bg_image_url'      => WALLREGI_PLUGIN_URL . 'frontend/assets/bg-image.png',
	];
}

/**
 * Bootstrap variables for a tab backed by partials/settings-data/*.php (same option: wallregi_settings).
 *
 * @param string $data_file_path Absolute path to a *-data.php file.
 * @return array<string, mixed> Keys: wallregi_input_fields, wallregi_select_fields, wallregi_defaults, wallregi_settings, wallregi_grouped_fields.
 */
function wallregi_admin_settings_bootstrap_from_data_file( $data_file_path ) {
	if ( ! is_string( $data_file_path ) || ! file_exists( $data_file_path ) ) {
		return [
			'wallregi_input_fields'   => [],
			'wallregi_select_fields'  => [],
			'wallregi_defaults'       => [],
			'wallregi_settings'       => [],
			'wallregi_grouped_fields' => [],
		];
	}

	// phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable -- intentional dynamic settings definition file.
	$wallregi_data          = require $data_file_path;
	$wallregi_input_fields  = $wallregi_data['input_fields'] ?? [];
	$wallregi_select_fields = $wallregi_data['select_fields'] ?? [];

	$wallregi_input_fields = apply_filters(
		'wallregi_settings_input_fields',
		$wallregi_input_fields,
		$data_file_path
	);
	$wallregi_select_fields = apply_filters(
		'wallregi_settings_select_fields',
		$wallregi_select_fields,
		$data_file_path
	);

	$wallregi_all_fields = array_merge( $wallregi_input_fields, $wallregi_select_fields );

	$wallregi_defaults = [];

	foreach ( $wallregi_all_fields as $wallregi_field ) {
		if ( ! empty( $wallregi_field['key'] ) && isset( $wallregi_field['default'] ) ) {
			$wallregi_defaults[ $wallregi_field['key'] ] = $wallregi_field['default'];
		}

		if ( ( $wallregi_field['type'] ?? '' ) === 'group' && ! empty( $wallregi_field['fields'] ) && ! empty( $wallregi_field['key'] ) ) {
			$wallregi_defaults[ $wallregi_field['key'] ] = [];
			foreach ( $wallregi_field['fields'] as $wallregi_subfield ) {
				if ( ! empty( $wallregi_subfield['key'] ) && isset( $wallregi_subfield['default'] ) ) {
					$wallregi_defaults[ $wallregi_field['key'] ][ $wallregi_subfield['key'] ] = $wallregi_subfield['default'];
				}
			}
		}
	}

	$wallregi_defaults = array_merge( $wallregi_defaults, wallregi_admin_settings_special_defaults() );

	$wallregi_saved_settings = get_option( 'wallregi_settings', [] );
	$wallregi_settings       = wp_parse_args( $wallregi_saved_settings, $wallregi_defaults );

	$wallregi_grouped_fields = [];
	foreach ( $wallregi_all_fields as $wallregi_field ) {
		$wallregi_section = $wallregi_field['sec_name'] ?? __( 'General', 'wallet-ready-gift-cards-for-woocommerce' );
		$wallregi_grouped_fields[ $wallregi_section ][] = $wallregi_field;
	}

	return [
		'wallregi_input_fields'   => $wallregi_input_fields,
		'wallregi_select_fields'  => $wallregi_select_fields,
		'wallregi_defaults'       => $wallregi_defaults,
		'wallregi_settings'       => $wallregi_settings,
		'wallregi_grouped_fields' => $wallregi_grouped_fields,
	];
}

/**
 * Persist one wallregi_settings tab from a request array (POST/AJAX).
 *
 * @param string               $data_file_path Absolute path to settings-data file for this tab.
 * @param array<string, mixed> $request        Raw request (typically wp_unslash'd $_POST).
 * @return true|\WP_Error
 */
function wallregi_admin_settings_save_from_request( $data_file_path, array $request ) {
	if ( ! is_string( $data_file_path ) || ! file_exists( $data_file_path ) ) {
		return new WP_Error( 'wallregi_settings_bad_file', __( 'Invalid settings definition.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$ctx                   = wallregi_admin_settings_bootstrap_from_data_file( $data_file_path );
	$wallregi_input_fields = $ctx['wallregi_input_fields'];
	$wallregi_select_fields = $ctx['wallregi_select_fields'];
	$wallregi_defaults     = $ctx['wallregi_defaults'];
	$wallregi_settings     = $ctx['wallregi_settings'];

	foreach ( $wallregi_input_fields as $wallregi_field ) {

		if ( ! empty( $wallregi_field['pro_placeholder'] ) ) {
			continue;
		}

		$wallregi_field_name = $wallregi_field['name'] ?? '';
		$wallregi_field_key  = $wallregi_field['key'] ?? '';
		$wallregi_field_type = $wallregi_field['type'] ?? '';

		if ( empty( $wallregi_field_key ) ) {
			continue;
		}

		if ( 'checkbox' === $wallregi_field_type ) {
			$wallregi_settings[ $wallregi_field_key ] = isset( $request[ $wallregi_field_name ] ) ? 'yes' : 'no';
		} elseif ( 'group' === $wallregi_field_type && ! empty( $wallregi_field['fields'] ) ) {
			$wallregi_settings[ $wallregi_field_key ] = [];
			$group_post_data                           = isset( $request[ $wallregi_field_key ] ) ? $request[ $wallregi_field_key ] : [];
			if ( ! is_array( $group_post_data ) ) {
				$group_post_data = [];
			}

			foreach ( $wallregi_field['fields'] as $wallregi_subfield ) {

				$wallregi_sub_key  = $wallregi_subfield['key'] ?? '';
				$wallregi_sub_type = $wallregi_subfield['type'] ?? '';
				$wallregi_sub_val  = $group_post_data[ $wallregi_sub_key ] ?? '';

				if ( 'color' === $wallregi_sub_type ) {
					$wallregi_settings[ $wallregi_field_key ][ $wallregi_sub_key ] = sanitize_hex_color( wp_unslash( (string) $wallregi_sub_val ) );
				} elseif ( 'number' === $wallregi_sub_type ) {
					$wallregi_settings[ $wallregi_field_key ][ $wallregi_sub_key ] = intval( $wallregi_sub_val );
				} else {
					$wallregi_settings[ $wallregi_field_key ][ $wallregi_sub_key ] = sanitize_text_field( wp_unslash( (string) $wallregi_sub_val ) );
				}
			}
		} elseif ( in_array( $wallregi_field_type, [ 'color', 'text', 'number', 'textarea', 'select', 'image_upload', 'editor' ], true ) ) {
			$wallregi_value = isset( $request[ $wallregi_field_name ] ) ? $request[ $wallregi_field_name ] : '';
			if ( 'color' === $wallregi_field_type ) {
				$wallregi_settings[ $wallregi_field_key ] = sanitize_hex_color( wp_unslash( (string) $wallregi_value ) );
			} elseif ( 'number' === $wallregi_field_type ) {
				$wallregi_settings[ $wallregi_field_key ] = intval( $wallregi_value );
			} elseif ( 'editor' === $wallregi_field_type ) {
				$wallregi_settings[ $wallregi_field_key ] = wp_kses_post( wp_unslash( (string) $wallregi_value ) );
			} elseif ( 'textarea' === $wallregi_field_type ) {
				if ( 'custom_pdf_css' === $wallregi_field_key ) {
					$wallregi_settings[ $wallregi_field_key ] = wp_strip_all_tags( wp_unslash( (string) $wallregi_value ) );
				} else {
					$wallregi_settings[ $wallregi_field_key ] = sanitize_textarea_field( wp_unslash( (string) $wallregi_value ) );
				}
			} elseif ( 'image_upload' === $wallregi_field_type ) {
				$wallregi_settings[ $wallregi_field_key ] = esc_url_raw( wp_unslash( (string) $wallregi_value ) );
			} else {
				$wallregi_settings[ $wallregi_field_key ] = sanitize_text_field( wp_unslash( (string) $wallregi_value ) );
			}
		}
	}

	foreach ( $wallregi_select_fields as $wallregi_field ) {
		$wallregi_name = $wallregi_field['name'] ?? '';
		$wallregi_key  = $wallregi_field['key'] ?? '';
		if ( ! empty( $wallregi_key ) ) {
			$wallregi_value                  = isset( $request[ $wallregi_name ] ) ? $request[ $wallregi_name ] : '';
			$wallregi_settings[ $wallregi_key ] = sanitize_text_field( wp_unslash( (string) $wallregi_value ) );
		}
	}

	if ( isset( $wallregi_settings['apply_giftcard_redirect_to'] ) && ! in_array( $wallregi_settings['apply_giftcard_redirect_to'], [ 'checkout', 'cart' ], true ) ) {
		$wallregi_settings['apply_giftcard_redirect_to'] = $wallregi_defaults['apply_giftcard_redirect_to'] ?? 'checkout';
	}

	$wallregi_background_style = $wallregi_settings['background_style'] ?? 'solid';

	if ( 'solid' === $wallregi_background_style ) {
		$wallregi_settings['solid_color'] = sanitize_hex_color( wp_unslash( (string) ( $request['wallregi_solid_color'] ?? $wallregi_defaults['solid_color'] ) ) );
	} elseif ( 'gradient' === $wallregi_background_style ) {
		$wallregi_settings['gradient_start']  = sanitize_hex_color( wp_unslash( (string) ( $request['wallregi_gradient_start'] ?? $wallregi_defaults['gradient_start'] ) ) );
		$wallregi_settings['gradient_middle'] = sanitize_hex_color( wp_unslash( (string) ( $request['wallregi_gradient_middle'] ?? $wallregi_defaults['gradient_middle'] ) ) );
		$wallregi_settings['gradient_end']    = sanitize_hex_color( wp_unslash( (string) ( $request['wallregi_gradient_end'] ?? $wallregi_defaults['gradient_end'] ) ) );
	} elseif ( 'image' === $wallregi_background_style ) {
		$wallregi_settings['bg_image_url'] = esc_url_raw( wp_unslash( (string) ( $request['wallregi_bg_image'] ?? $wallregi_defaults['bg_image_url'] ) ) );
	}

	if ( function_exists( 'wallregi_strip_pro_only_settings' ) ) {
		$wallregi_settings = wallregi_strip_pro_only_settings( $wallregi_settings );
	}

	update_option( 'wallregi_settings', $wallregi_settings );

	return true;
}

/**
 * Defaults for email settings option (legacy email-settings.php).
 *
 * @return array<string, mixed>
 */
function wallregi_admin_settings_email_defaults() {
	return [
		'email_subject'    => 'You’ve Been Sent a Gift Card Worth [giftcard_value] – Use Code: [giftcard_code]',
		'email_heading'    => 'Surprise! A Gift Card Is Waiting for You.',
		'email_body'       => 'Dear [receiver_name],

    [email_heading]

    We’re pleased to let you know that [sender_name] has sent you a gift card worth [giftcard_value].

    Your Gift Card Code: [giftcard_code]

    You can redeem this code during checkout. Please note that the card is valid until [expiry_date], so be sure to use it in time.

    If you have any questions or need assistance, feel free to contact us. This gift was sent to [receiver_email].

    Best regards,
    The Gift Card Team',
		'email_pdf_attach' => 'yes',
		'email_batch_size' => 5,
	];
}

/**
 * Bootstrap email tab ($wallregi_settings holds email option payload; $email_fields from email-data.php).
 *
 * @return array<string, mixed>
 */
function wallregi_admin_settings_bootstrap_email() {
	$saved             = get_option( 'wallregi_email_settings', [] );
	$wallregi_defaults = wallregi_admin_settings_email_defaults();
	$wallregi_settings = wp_parse_args( is_array( $saved ) ? $saved : [], $wallregi_defaults );

	$email_fields = [];
	$email_data   = WALLREGI_PLUGIN_DIR . 'backend/templates/settings/partials/settings-data/email-data.php';
	if ( file_exists( $email_data ) ) {
		// phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable
		require $email_data;
	}

	$email_fields = apply_filters( 'wallregi_email_settings_fields', $email_fields );

	return [
		'wallregi_settings' => $wallregi_settings,
		'email_fields'      => $email_fields,
	];
}

/**
 * Save email settings from request (legacy behavior).
 *
 * @param array<string, mixed> $request Raw request.
 * @return true|\WP_Error
 */
function wallregi_admin_settings_save_email_from_request( array $request ) {
	$defaults          = wallregi_admin_settings_email_defaults();
	$wallregi_settings = [
		'email_subject'    => sanitize_text_field( wp_unslash( (string) ( $request['wallregi_email_subject'] ?? $defaults['email_subject'] ) ) ),
		'email_heading'    => sanitize_text_field( wp_unslash( (string) ( $request['wallregi_email_heading'] ?? $defaults['email_heading'] ) ) ),
		'email_body'       => sanitize_textarea_field( wp_unslash( (string) ( $request['wallregi_email_body'] ?? $defaults['email_body'] ) ) ),
		'email_pdf_attach' => isset( $request['wallregi_email_pdf_attach'] ) ? 'yes' : 'no',
		'email_batch_size' => isset( $request['wallregi_email_batch_size'] ) ? absint( $request['wallregi_email_batch_size'] ) : 5,
	];

	update_option( 'wallregi_email_settings', $wallregi_settings );

	return true;
}

/**
 * Defaults for Google/Apple Wallet (ePasscard) option.
 *
 * @return array<string, mixed>
 */
function wallregi_admin_settings_wallet_defaults() {
	return [
		'wallet_provider'           => 'none',
		'epass_api_key'             => '', // Legacy plain key (migrated away on next Connect).
		'epass_api_key_encrypted'   => '',
		'epass_key_expires_utc'     => '',
		'epass_org_id'              => 0,
		'epass_global_pass_config'  => [],
		'epass_global_stripe_image_url' => '',
	];
}

/**
 * ePasscard public API: validate API key.
 *
 * @return string
 */
function wallregi_wallet_epass_validate_api_url() {
	return apply_filters(
		'wallregi_wallet_epass_validate_api_url',
		'https://api.epasscard.com/api/public/v1/validate-api-key'
	);
}

/**
 * Call ePasscard validate-api-key endpoint.
 *
 * @param string $api_key Plain API key.
 * @return array<string, mixed>|\WP_Error Parsed `data` on success.
 */
function wallregi_wallet_validate_epass_api_key_remote( $api_key ) {
	$api_key = trim( (string) $api_key );
	if ( '' === $api_key ) {
		return new WP_Error(
			'wallregi_wallet_empty_key',
			__( 'Please enter an API key.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$url      = wallregi_wallet_epass_validate_api_url();
	$response = wp_remote_post(
		$url,
		[
			'timeout' => 30,
			'headers' => [
				'Content-Type' => 'application/json',
			],
			'body'    => wp_json_encode(
				[
					'apiKey' => $api_key,
				]
			),
		]
	);

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$http_code = (int) wp_remote_retrieve_response_code( $response );
	if ( 200 !== $http_code ) {
		return new WP_Error(
			'wallregi_wallet_http',
			__( 'Could not reach the ePasscard validation service. Please try again later.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$raw_body = wp_remote_retrieve_body( $response );
	$body     = json_decode( $raw_body, true );
	if ( ! is_array( $body ) ) {
		return new WP_Error(
			'wallregi_wallet_bad_response',
			__( 'The ePasscard server returned an unexpected response. Please try again.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	if ( 200 !== (int) ( $body['status'] ?? 0 ) ) {
		$msg = isset( $body['message'] ) && is_string( $body['message'] )
			? sanitize_text_field( $body['message'] )
			: __( 'This API key could not be validated.', 'wallet-ready-gift-cards-for-woocommerce' );
		return new WP_Error( 'wallregi_wallet_invalid', $msg );
	}

	$data = $body['data'] ?? [];
	if ( empty( $data['valid'] ) || true !== $data['valid'] ) {
		return new WP_Error(
			'wallregi_wallet_invalid',
			__( 'This API key is not valid.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	if ( isset( $data['activeStatus'] ) && false === $data['activeStatus'] ) {
		return new WP_Error(
			'wallregi_wallet_inactive',
			__( 'This API key is not active.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	return $data;
}

/**
 * Format stored UTC `next_refresh` string for display in site timezone.
 *
 * @param string $utc_mysql_string e.g. "2029-11-30 09:25:00" (UTC).
 * @return string
 */
function wallregi_wallet_format_expiry_for_display( $utc_mysql_string ) {
	$utc_mysql_string = trim( (string) $utc_mysql_string );
	if ( '' === $utc_mysql_string ) {
		return '';
	}

	try {
		$dt = new DateTimeImmutable( $utc_mysql_string, new DateTimeZone( 'UTC' ) );
	} catch ( Exception $e ) {
		return '';
	}

	return wp_date(
		get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
		$dt->getTimestamp()
	);
}

/**
 * Decrypted ePasscard API key for internal use (never output to HTML).
 *
 * @return string
 */
function wallregi_wallet_get_decrypted_api_key() {
	if ( ! function_exists( 'wallregi_decrypt_password' ) ) {
		return '';
	}
	$saved = get_option( 'wallregi_wallet_settings', [] );
	if ( ! is_array( $saved ) ) {
		return '';
	}
	$enc = isset( $saved['epass_api_key_encrypted'] ) ? (string) $saved['epass_api_key_encrypted'] : '';
	if ( '' !== $enc ) {
		$plain = wallregi_decrypt_password( $enc );
		return is_string( $plain ) && '' !== $plain ? $plain : '';
	}
	// Legacy plain storage.
	$legacy = isset( $saved['epass_api_key'] ) ? (string) $saved['epass_api_key'] : '';
	return $legacy;
}

/**
 * Load wallet integration settings.
 *
 * @return array<string, mixed> Keys: wallregi_wallet_settings.
 */
function wallregi_admin_settings_bootstrap_wallet() {
	$saved             = get_option( 'wallregi_wallet_settings', [] );
	$wallregi_defaults = wallregi_admin_settings_wallet_defaults();
	$wallregi_settings = wp_parse_args( is_array( $saved ) ? $saved : [], $wallregi_defaults );

	return [
		'wallregi_wallet_settings' => $wallregi_settings,
	];
}

/**
 * Persist wallet settings from request (POST/AJAX).
 *
 * API credentials are written only after a successful Connect (validated remotely and encrypted).
 * This handler keeps other wallet options in sync when added later.
 *
 * @param array<string, mixed> $request Raw request.
 * @return true|\WP_Error
 */
function wallregi_admin_settings_save_wallet_from_request( array $request ) {
	$saved    = get_option( 'wallregi_wallet_settings', [] );
	$defaults = wallregi_admin_settings_wallet_defaults();
	$merged   = wp_parse_args( is_array( $saved ) ? $saved : [], $defaults );

	if ( isset( $request['wallregi_wallet_provider'] ) && function_exists( 'wallregi_sanitize_wallet_provider' ) ) {
		$merged['wallet_provider'] = wallregi_sanitize_wallet_provider(
			wp_unslash( (string) $request['wallregi_wallet_provider'] )
		);
	}

	$pa = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-product-admin.php';
	if ( file_exists( $pa ) ) {
		require_once $pa;
	}

	$global_file = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-global-settings.php';
	if ( file_exists( $global_file ) ) {
		require_once $global_file;
		$parsed = wallregi_wallet_parse_global_pass_config_from_request( $request );
		$merged = array_merge(
			$merged,
			[
				'epass_global_pass_config'      => $parsed['pass_config'],
				'epass_global_stripe_image_url' => $parsed['stripe_url'],
			]
		);
	}

	$wallregi_wallet_settings = apply_filters( 'wallregi_wallet_settings_before_save', $merged, $request );

	update_option( 'wallregi_wallet_settings', $wallregi_wallet_settings );

	return true;
}

/**
 * Persist validated ePasscard API key (encrypted) and UTC expiry from API `next_refresh`.
 *
 * @param string               $api_key       Plain API key.
 * @param array<string, mixed> $validated_data Response `data` from validate endpoint.
 * @return true|\WP_Error
 */
function wallregi_wallet_save_connected_epass_credentials( $api_key, array $validated_data ) {
	if ( ! function_exists( 'wallregi_encrypt_password' ) ) {
		return new WP_Error(
			'wallregi_wallet_no_encrypt',
			__( 'Encryption is not available on this site.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$encrypted = wallregi_encrypt_password( $api_key );
	if ( ! is_string( $encrypted ) || '' === $encrypted ) {
		return new WP_Error(
			'wallregi_wallet_encrypt_failed',
			__( 'Could not store the API key securely. Please try again.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$saved  = get_option( 'wallregi_wallet_settings', [] );
	$merged = wp_parse_args( is_array( $saved ) ? $saved : [], wallregi_admin_settings_wallet_defaults() );

	$next_refresh = isset( $validated_data['next_refresh'] ) ? sanitize_text_field( (string) $validated_data['next_refresh'] ) : '';

	$wallregi_wallet_settings = array_merge(
		$merged,
		[
			'epass_api_key_encrypted' => $encrypted,
			'epass_key_expires_utc'   => $next_refresh,
			'epass_org_id'            => isset( $validated_data['org_id'] ) ? absint( $validated_data['org_id'] ) : 0,
			'epass_api_key'           => '',
		]
	);

	$wallregi_wallet_settings = apply_filters( 'wallregi_wallet_settings_after_connect', $wallregi_wallet_settings, $validated_data );

	update_option( 'wallregi_wallet_settings', $wallregi_wallet_settings );

	return true;
}
