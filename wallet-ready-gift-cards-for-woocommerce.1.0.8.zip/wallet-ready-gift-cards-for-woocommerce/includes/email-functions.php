<?php
    if (!defined('ABSPATH')) {
        exit; // Exit if accessed directly
    }

    /**
     * Send gift card email function.
     * This is the global function hooked to 'wallregi_send_giftcard_email' action.
     *
     * @param string $giftcode Gift card coupon code.
     * @return void
     */

    function wallregi_send_giftcard_email_function($giftcode, $extra_data = []) {
        
        global $wpdb;

        // Fetch gift card data
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
        $giftcard_data = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM %i WHERE `giftcard_number` = %s',
                wallregi_giftcard_db_table_name(),
                $giftcode
            )
        );

        if (!$giftcard_data) {
            return;
        }


    
        // Load saved settings with default values
        $wallregi_settings = get_option('wallregi_email_settings', []);

        $wallregi_defaults = [
            'email_subject'    => 'You’ve Been Sent a Gift Card Worth [giftcard_value] – Use Code: [giftcard_code]',
            'email_heading'    => 'Surprise! A Gift Card Is Waiting for You.',
            'email_body'       => 'Dear [receiver_name],

        [email_heading]

        We’re pleased to let you know that [sender_name] has sent you a gift card worth [giftcard_value].

        Your Gift Card Code: [giftcard_code]

        You can redeem this code during checkout. Please note that the card is valid until [expiry_date], so be sure to use it in time.

        If you have any questions or need assistance, feel free to contact us. This gift was sent to [receiver_email].

        Best regards,
        The Gift Card Team',
            'email_pdf_attach' => 'no', // Default value for checkbox
        ];


        // Merge saved settings with defaults
        $wallregi_settings = wp_parse_args($wallregi_settings, $wallregi_defaults);

        $email_subject = $wallregi_settings['email_subject'] ?? $wallregi_defaults['email_subject'];
        $email_heading = $wallregi_settings['email_heading'] ?? $wallregi_defaults['email_heading'];
        $email_message = !empty($wallregi_settings['email_body']) ? nl2br($wallregi_settings['email_body']) : $wallregi_defaults['email_body'];
        $attach_pdf = !empty($wallregi_settings['email_pdf_attach']) && $wallregi_settings['email_pdf_attach'] === 'yes';
    

        // Prepare email content
        $recipient_email        = $giftcard_data->receipent_email;
        $giftcard_value         = $giftcard_data->current_amount;
        $sender_name            = $giftcard_data->sender_name;
        $receiver_name          = $giftcard_data->receipent_name;
        $giftcard_code          = $giftcard_data->giftcard_number;

        $wallregi_giftcard_create_date   = $giftcard_data->created_at; 
        $wallregi_expiry_period          = $giftcard_data->expiry_period; 
        $expiry_date_check      = $giftcard_data->expiry_date;

        $wallregi_calculated_expiry_date = '';

        if (!empty($wallregi_giftcard_create_date) && $wallregi_giftcard_create_date != "0000-00-00" && 'custom' !== (string) $wallregi_expiry_period) {
            try {
                $wallregi_create_date = new DateTime($wallregi_giftcard_create_date);
                $wallregi_create_date->modify("+$wallregi_expiry_period");
                $wallregi_calculated_expiry_date = $wallregi_create_date->format('Y-m-d');
            } catch (Exception $e) {
                $wallregi_calculated_expiry_date = 'Invalid date';
            }
        }

        $wallregi_expiry_date = '';

        if (empty($expiry_date_check) || $expiry_date_check === "0000-00-00") {
            $wallregi_expiry_date = $wallregi_calculated_expiry_date;
        } else {
            $wallregi_expiry_date = $expiry_date_check;
        }

        $sender_name = $giftcard_data->sender_name ?? 'Unknown Sender';
        $receipent_name = $giftcard_data->receipent_name ?? 'Unknown Recipient';
        $receipent_email = $giftcard_data->receipent_email ?? '';
        $item_id = $giftcard_data->item_id ?? '';
        
        // Validate recipient email
        if (empty($receipent_email) || !filter_var($receipent_email, FILTER_VALIDATE_EMAIL)) {
            return;
        }
    
        // Retrieve gift card message
        $giftcard_message = $giftcard_data->message ?? '';
        if ( '' === trim( (string) $giftcard_message ) && ! empty( $item_id ) && function_exists( 'wc_get_order_item_meta' ) ) {
            $meta_message = wc_get_order_item_meta( $item_id, 'giftcard_message', true );
            if ( ! empty( $meta_message ) ) {
                $giftcard_message = $meta_message;
            }
        }
        if ( '' === trim( (string) $giftcard_message ) && ! empty( $extra_data['message'] ) ) {
            $giftcard_message = $extra_data['message'];
        }

        $giftcard_message_formatted = ! empty( $giftcard_message ) ? nl2br( esc_html( (string) $giftcard_message ) ) : '';

        // Retrieve pass link
        $pass_link = function_exists( 'wallregi_giftcard_get_pass_link_for_row' )
            ? wallregi_giftcard_get_pass_link_for_row( $giftcard_data )
            : '';

        // Build placeholder replacement array
        $placeholders = [
            '[giftcard_code]'      => $giftcard_code,
            '[giftcard_value]'     => $giftcard_value,
            '[expiry_date]'        => $wallregi_expiry_date,
            '[sender_name]'        => $sender_name,
            '[receiver_name]'      => $receipent_name,
            '[receiver_email]'     => $receipent_email,
            '[email_heading]'      => $email_heading,
            '[gift_card_message]'  => $giftcard_message_formatted,
            '[giftcard_message]'   => $giftcard_message_formatted,
            '[pass_link]'          => $pass_link,
            '[wallet_pass_url]'    => $pass_link,
        ];

        /**
         * Filter gift card email merge-tag placeholders.
         *
         * @param array<string, string> $placeholders  Tag => value.
         * @param object                $giftcard_data Gift card DB row object.
         * @param array<string, mixed>  $extra_data    Context from the send action.
         */
        $placeholders = apply_filters( 'wallregi_giftcard_email_placeholders', $placeholders, $giftcard_data, is_array( $extra_data ) ? $extra_data : [] );

        // Replace in subject, heading, and message
        $subject = wp_strip_all_tags( str_replace(array_keys($placeholders), array_values($placeholders), $email_subject) );
        $heading = str_replace(array_keys($placeholders), array_values($placeholders), $email_heading);
        $body = str_replace(array_keys($placeholders), array_values($placeholders), $email_message);
        if ( function_exists( 'do_shortcode' ) ) {
            $body = do_shortcode( $body );
        }

        if ( function_exists( 'wallregi_wrap_email_html_for_locale' ) ) {
            $body = wallregi_wrap_email_html_for_locale( $body );
        }

        // Set email headers
        $headers = array('Content-Type: text/html; charset=UTF-8');
    
        $attachments = [];
        $pdf_path    = '';
        
        // Handle PDF attachment
        if ($attach_pdf) {
            $pdf_path = wallregi_generate_giftcard_pdf( base64_encode($giftcard_code), $attach_pdf);
            if (!empty($pdf_path) && file_exists($pdf_path)) {
                $attachments[] = $pdf_path;
            }
        }

        // Check if email should be sent conditionally.
        $extra_data       = is_array( $extra_data ) ? $extra_data : [];
        $force_resend     = ! empty( $extra_data['force_resend'] );
        $should_send_email = wallregi_giftcard_should_send_email_for_channel( $giftcard_data );

        /**
         * Filter whether this gift card email send attempt should proceed.
         *
         * @param bool                 $should_send_email Whether to send.
         * @param object               $giftcard_data     Gift card DB row.
         * @param array<string, mixed> $extra_data        Send context.
         */
        $should_send_email = (bool) apply_filters( 'wallregi_should_send_giftcard_email', $should_send_email, $giftcard_data, $extra_data );

        // Skip if already sent unless an admin explicitly requested a resend.
        if ( (int) $giftcard_data->email_status === 1 && ! $force_resend ) {
            $should_send_email = false;
        }

        // Send only if allowed.
        if ( $should_send_email ) {

            // Send the email with or without the PDF attachment.
            $mail_sent = ! empty( $attachments )
                ? wp_mail( $recipient_email, $subject, $body, $headers, $attachments )
                : wp_mail( $recipient_email, $subject, $body, $headers );

            if ( $mail_sent ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                $wpdb->update(
                    wallregi_giftcard_db_table_name(),
                    array(
                        'email_status' => 1,
                        'sent_at'      => current_time( 'mysql' ),
                    ),
                    array( 'giftcard_number' => $giftcard_code ),
                    array( '%d', '%s' ),
                    array( '%s' )
                );

                /**
                 * Fires after a gift card delivery email was sent successfully.
                 *
                 * @param string               $giftcard_code Gift card number.
                 * @param object               $giftcard_data Gift card DB row object.
                 * @param array<string, mixed> $extra_data    Context from the send action.
                 */
                do_action( 'wallregi_giftcard_email_sent', $giftcard_code, $giftcard_data, $extra_data );
            } elseif ( $force_resend || (int) $giftcard_data->email_status !== 1 ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                $wpdb->update(
                    wallregi_giftcard_db_table_name(),
                    array( 'email_status' => 2 ),
                    array( 'giftcard_number' => $giftcard_code ),
                    array( '%d' ),
                    array( '%s' )
                );
            }

            // Delete the PDF file after sending the email.
            if ( ! empty( $pdf_path ) && file_exists( $pdf_path ) ) {
                // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
                @unlink( $pdf_path );
            }
        }

    }

    /**
     * Register email action hook
     */
    add_action('wallregi_send_giftcard_email', 'wallregi_send_giftcard_email_function', 10, 2);
    
    // Hook for bulk email processing (already defined)
    add_action('wallregi_send_bulk_giftcard_emails', function($codes, $extra_data = []) {
        foreach ($codes as $code) {
            wallregi_send_giftcard_email_function($code, $extra_data);
        }
    }, 10, 2);

    /**
     * Shortcode callback for [gift_card_message] or [giftcard_message].
     *
     * Usage: [gift_card_message] or [gift_card_message code="WGC-XXXX"]
     *
     * @param array $atts Shortcode attributes.
     * @return string
     */
    function wallregi_gift_card_message_shortcode($atts = []) {
        global $wpdb;
        $atts = shortcode_atts([
            'code' => '',
        ], $atts, 'gift_card_message');

        $code = sanitize_text_field($atts['code'] ?? '');
        if (!empty($code) && function_exists('wallregi_giftcard_db_table_name')) {
            $table = wallregi_giftcard_db_table_name();
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $row = $wpdb->get_row($wpdb->prepare('SELECT message FROM %i WHERE `giftcard_number` = %s', $table, $code));
            if ($row && !empty($row->message)) {
                return nl2br(esc_html((string) $row->message));
            }
        }
        return '';
    }
    add_shortcode('gift_card_message', 'wallregi_gift_card_message_shortcode');
    add_shortcode('giftcard_message', 'wallregi_gift_card_message_shortcode');

    /**
     * Shortcode callback for [pass_link].
     *
     * Usage: [pass_link] or [pass_link code="WGC-XXXX"]
     *
     * @param array $atts Shortcode attributes.
     * @return string
     */
    function wallregi_gift_card_pass_link_shortcode($atts = []) {
        global $wpdb;
        $atts = shortcode_atts([
            'code' => '',
        ], $atts, 'pass_link');

        $code = sanitize_text_field($atts['code'] ?? '');
        if (!empty($code) && function_exists('wallregi_giftcard_db_table_name') && function_exists('wallregi_giftcard_get_pass_link_for_row')) {
            $table = wallregi_giftcard_db_table_name();
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE `giftcard_number` = %s', $table, $code));
            if ($row) {
                return esc_url(wallregi_giftcard_get_pass_link_for_row($row));
            }
        }
        return '';
    }
    add_shortcode('pass_link', 'wallregi_gift_card_pass_link_shortcode');

