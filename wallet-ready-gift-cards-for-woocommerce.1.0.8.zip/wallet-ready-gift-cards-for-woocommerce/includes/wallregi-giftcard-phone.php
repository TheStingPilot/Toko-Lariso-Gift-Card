<?php
/**
 * Gift card recipient phone validation rules and helpers.
 *
 * @package Wallet_Ready_Gift_Cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Store base country for phone examples (dynamically detects WooCommerce store base or customer country).
 *
 * @param string $override_country Optional ISO 3166-1 alpha-2 override.
 * @return string ISO 3166-1 alpha-2.
 */
function wallregi_giftcard_phone_store_country( $override_country = '' ) {
	if ( ! empty( $override_country ) && is_string( $override_country ) ) {
		return strtoupper( trim( $override_country ) );
	}

	$country = '';

	// 1. If customer has a selected billing or shipping country in WooCommerce session:
	if ( function_exists( 'WC' ) && WC() && isset( WC()->customer ) && is_object( WC()->customer ) ) {
		$customer_country = WC()->customer->get_billing_country();
		if ( empty( $customer_country ) ) {
			$customer_country = WC()->customer->get_shipping_country();
		}
		if ( ! empty( $customer_country ) && is_string( $customer_country ) ) {
			$country = strtoupper( trim( $customer_country ) );
		}
	}

	// 2. Base store country from WooCommerce settings:
	if ( empty( $country ) && function_exists( 'wc_get_base_location' ) ) {
		$base = wc_get_base_location();
		if ( ! empty( $base['country'] ) && is_string( $base['country'] ) ) {
			$country = strtoupper( trim( $base['country'] ) );
		}
	}

	// 3. WC_Countries base country:
	if ( empty( $country ) && function_exists( 'WC' ) && WC() && isset( WC()->countries ) && is_callable( array( WC()->countries, 'get_base_country' ) ) ) {
		$base_country = WC()->countries->get_base_country();
		if ( ! empty( $base_country ) && is_string( $base_country ) ) {
			$country = strtoupper( trim( $base_country ) );
		}
	}

	// 4. Raw woocommerce_default_country option fallback (e.g. "IS", "US:CA", "BD:BD-13"):
	if ( empty( $country ) ) {
		$raw = (string) get_option( 'woocommerce_default_country', '' );
		if ( '' !== $raw ) {
			$parts   = explode( ':', $raw );
			$country = strtoupper( trim( $parts[0] ) );
		}
	}

	if ( '' === $country ) {
		$country = 'US';
	}

	/**
	 * Filter WooCommerce store country for phone examples.
	 *
	 * @param string $country ISO 3166-1 alpha-2 country code.
	 */
	return (string) apply_filters( 'wallregi_giftcard_phone_store_country', $country );
}

/**
 * Calling code for a given ISO country code (derived dynamically from WooCommerce).
 *
 * @param string $country ISO 3166-1 alpha-2.
 * @return string Calling code prefixed with '+' (e.g. '+354', '+1'), or empty string.
 */
function wallregi_giftcard_phone_get_country_calling_code( $country = '' ) {
	if ( '' === $country ) {
		$country = wallregi_giftcard_phone_store_country();
	}
	$country      = strtoupper( trim( (string) $country ) );
	$calling_code = '';

	if ( function_exists( 'WC' ) && WC() && isset( WC()->countries ) && is_callable( array( WC()->countries, 'get_country_calling_code' ) ) ) {
		$code = WC()->countries->get_country_calling_code( $country );
		if ( is_array( $code ) ) {
			$code = ! empty( $code[0] ) ? $code[0] : '';
		}
		if ( is_string( $code ) && '' !== trim( $code ) ) {
			$calling_code = trim( $code );
		}
	}

	// Direct fallback from WooCommerce i18n phone table if available.
	if ( '' === $calling_code && function_exists( 'WC' ) && WC() && is_callable( array( WC(), 'plugin_path' ) ) ) {
		$phone_file = WC()->plugin_path() . '/i18n/phone.php';
		if ( file_exists( $phone_file ) ) {
			$codes = include $phone_file;
			if ( is_array( $codes ) && isset( $codes[ $country ] ) ) {
				$code = is_array( $codes[ $country ] ) ? $codes[ $country ][0] : $codes[ $country ];
				if ( is_string( $code ) ) {
					$calling_code = trim( $code );
				}
			}
		}
	}

	if ( '' !== $calling_code && '+' !== $calling_code[0] ) {
		$calling_code = '+' . ltrim( $calling_code, '+' );
	}

	/**
	 * Filter calling code for gift card phone validation and examples.
	 *
	 * @param string $calling_code e.g. '+354'.
	 * @param string $country      ISO country code.
	 */
	return (string) apply_filters( 'wallregi_giftcard_phone_country_calling_code', $calling_code, $country );
}

/**
 * Retrieve phone example (intl and local) dynamically for a country or store country.
 *
 * @param string $country ISO 3166-1 alpha-2 country code.
 * @return array{intl:string,local:string}
 */
function wallregi_giftcard_phone_example_for_country( $country = '' ) {
	if ( '' === $country ) {
		$country = wallregi_giftcard_phone_store_country();
	}
	$country = strtoupper( trim( (string) $country ) );

	// Dynamically build example from WooCommerce's calling code for this selected country.
	$calling_code = wallregi_giftcard_phone_get_country_calling_code( $country );
	if ( '' === $calling_code ) {
		$calling_code = '+1';
	}

	$digits       = preg_replace( '/\D/', '', $calling_code );
	$sample_local = '1234567';
	$sample_intl  = '+' . $digits . $sample_local;

	$example = array(
		'intl'  => $sample_intl,
		'local' => $sample_local,
	);

	/**
	 * Filter generated recipient phone example for store country.
	 *
	 * @param array{intl:string,local:string} $example Phone example.
	 * @param string                          $country ISO country code.
	 */
	return (array) apply_filters( 'wallregi_giftcard_phone_example_for_country', $example, $country );
}

/**
 * Admin + storefront phone validation configuration.
 *
 * @param string $country Optional ISO country code override.
 * @return array<string, mixed>
 */
function wallregi_get_giftcard_phone_validation_rules( $country = '' ) {
	if ( empty( $country ) ) {
		$country = wallregi_giftcard_phone_store_country();
	} else {
		$country = strtoupper( trim( (string) $country ) );
	}

	$defaults  = wallregi_giftcard_phone_example_for_country( $country );
	$require   = 'yes';
	$intl_ph   = (string) $defaults['intl'];
	$local_ph  = (string) $defaults['local'];

	if ( class_exists( 'WALLREGI_SMS_Provider_Registry' ) ) {
		$sms = WALLREGI_SMS_Provider_Registry::get_settings();
		$require = ( isset( $sms['phone_require_country_code'] ) && 'no' === $sms['phone_require_country_code'] ) ? 'no' : 'yes';

		if ( ! empty( $sms['phone_intl_placeholder'] ) ) {
			$intl_ph = sanitize_text_field( (string) $sms['phone_intl_placeholder'] );
		}
		if ( ! empty( $sms['phone_local_placeholder'] ) ) {
			$local_ph = sanitize_text_field( (string) $sms['phone_local_placeholder'] );
		}
	}

	if ( class_exists( 'WALLREGI_GTW_API_Client' ) && function_exists( 'wallregi_gtw_sms_delivery_is_active' ) && wallregi_gtw_sms_delivery_is_active() ) {
		$gtw = WALLREGI_GTW_API_Client::get_settings();
		if ( isset( $gtw['phone_require_country_code'] ) ) {
			$require = ( 'no' === $gtw['phone_require_country_code'] ) ? 'no' : 'yes';
		}
		if ( ! empty( $gtw['phone_intl_placeholder'] ) ) {
			$intl_ph = sanitize_text_field( (string) $gtw['phone_intl_placeholder'] );
		}
		if ( ! empty( $gtw['phone_local_placeholder'] ) ) {
			$local_ph = sanitize_text_field( (string) $gtw['phone_local_placeholder'] );
		}
	}

	$require_intl = ( 'yes' === $require );
	$active_ph    = $require_intl ? $intl_ph : $local_ph;
	$help_intl    = sprintf(
		/* translators: %s: example phone number with country code */
		__( 'Include country code. Example: %s', 'wallet-ready-gift-cards-for-woocommerce' ),
		$intl_ph
	);
	$help_local   = sprintf(
		/* translators: %s: example local phone number without country code */
		__( 'Enter number without country code. Example: %s', 'wallet-ready-gift-cards-for-woocommerce' ),
		$local_ph
	);

	$rules = array(
		'country'              => $country,
		'calling_code'         => wallregi_giftcard_phone_get_country_calling_code( $country ),
		'require_country_code' => $require,
		'placeholder'          => $intl_ph,
		'local_placeholder'    => $local_ph,
		'active_placeholder'   => $active_ph,
		'help_text_intl'       => $help_intl,
		'help_text_local'      => $help_local,
		'active_help_text'     => $require_intl ? $help_intl : $help_local,
		'min_digits'           => 7,
		'max_digits'           => 15,
		'min_intl_digits'      => 8,
		'max_intl_digits'      => 15,
		'messages'             => array(
			'required'      => __( 'Please enter a recipient phone number.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'invalid_intl'  => sprintf(
				/* translators: %s: example phone number with country code */
				__( 'Include country code (example: %s).', 'wallet-ready-gift-cards-for-woocommerce' ),
				$intl_ph
			),
			'invalid_local' => sprintf(
				/* translators: %s: example local phone number without country code */
				__( 'Enter a valid phone number without country code (example: %s).', 'wallet-ready-gift-cards-for-woocommerce' ),
				$local_ph
			),
		),
	);

	/**
	 * Filter recipient phone validation rules for admin and storefront.
	 *
	 * @param array<string, mixed> $rules Validation config.
	 */
	return (array) apply_filters( 'wallregi_giftcard_phone_validation_rules', $rules );
}

/**
 * Validate and normalize a recipient phone for SMS delivery.
 *
 * @param mixed  $raw      Raw input.
 * @param bool   $required Whether empty is an error.
 * @param string $country  Optional ISO country code override.
 * @return string|\WP_Error Sanitized phone or error.
 */
function wallregi_validate_giftcard_phone( $raw, $required = true, $country = '' ) {
	$clean = wallregi_sanitize_giftcard_phone( $raw );

	if ( '' === $clean ) {
		if ( $required ) {
			$rules = wallregi_get_giftcard_phone_validation_rules( $country );
			return new WP_Error(
				'wallregi_phone_required',
				$rules['messages']['required'] ?? __( 'Please enter a recipient phone number.', 'wallet-ready-gift-cards-for-woocommerce' )
			);
		}
		return '';
	}

	$rules         = wallregi_get_giftcard_phone_validation_rules( $country );
	$require_intl  = ( 'yes' === ( $rules['require_country_code'] ?? 'yes' ) );
	$min_local     = max( 1, (int) ( $rules['min_digits'] ?? 7 ) );
	$max_local     = max( $min_local, (int) ( $rules['max_digits'] ?? 15 ) );
	$min_intl      = max( 1, (int) ( $rules['min_intl_digits'] ?? 8 ) );
	$max_intl      = max( $min_intl, (int) ( $rules['max_intl_digits'] ?? 15 ) );

	if ( $require_intl ) {
		if ( '+' !== $clean[0] ) {
			return new WP_Error(
				'wallregi_phone_invalid_intl',
				$rules['messages']['invalid_intl'] ?? __( 'Include country code.', 'wallet-ready-gift-cards-for-woocommerce' )
			);
		}

		$digits = substr( $clean, 1 );
		if ( ! preg_match( '/^\d+$/', $digits ) ) {
			return new WP_Error(
				'wallregi_phone_invalid_intl',
				$rules['messages']['invalid_intl'] ?? __( 'Include country code.', 'wallet-ready-gift-cards-for-woocommerce' )
			);
		}

		$length = strlen( $digits );
		if ( $length < $min_intl || $length > $max_intl ) {
			return new WP_Error(
				'wallregi_phone_invalid_intl',
				$rules['messages']['invalid_intl'] ?? __( 'Include country code.', 'wallet-ready-gift-cards-for-woocommerce' )
			);
		}

		return '+' . $digits;
	}

	if ( '+' === $clean[0] ) {
		return new WP_Error(
			'wallregi_phone_invalid_local',
			$rules['messages']['invalid_local'] ?? __( 'Enter a valid phone number without country code.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	if ( ! preg_match( '/^\d+$/', $clean ) ) {
		return new WP_Error(
			'wallregi_phone_invalid_local',
			$rules['messages']['invalid_local'] ?? __( 'Enter a valid phone number without country code.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$length = strlen( $clean );
	if ( $length < $min_local || $length > $max_local ) {
		return new WP_Error(
			'wallregi_phone_invalid_local',
			$rules['messages']['invalid_local'] ?? __( 'Enter a valid phone number without country code.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	/**
	 * Filter validated local-format phone before persistence.
	 *
	 * @param string $clean Sanitized digits-only phone.
	 * @param mixed  $raw   Original input.
	 */
	return (string) apply_filters( 'wallregi_giftcard_recipient_phone_validated', $clean, $raw );
}
