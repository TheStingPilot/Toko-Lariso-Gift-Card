<?php
/**
 * Shared gift card redemption helpers for orders (checkout session + admin orders).
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gift card numbers and amounts stored on an order.
 *
 * @param WC_Order|null $order Order.
 * @return array<int, array{number: string, amount: float, fee_item_id: int}>
 */
function wallregi_order_get_wallet_redemptions( $order ) {
	if ( ! $order instanceof WC_Order ) {
		return array();
	}
	if ( 'yes' !== $order->get_meta( '_wallregi_giftcard_applied', true ) ) {
		return array();
	}

	$prefix = '_giftcard_discount_';
	$rows   = array();

	foreach ( $order->get_meta_data() as $meta_data ) {
		$data     = $meta_data->get_data();
		$meta_key = isset( $data['key'] ) ? (string) $data['key'] : '';
		if ( strpos( $meta_key, $prefix ) !== 0 ) {
			continue;
		}
		$number = substr( $meta_key, strlen( $prefix ) );
		$amount = isset( $data['value'] ) ? (float) $data['value'] : 0.0;
		if ( $amount <= 0 || '' === $number ) {
			continue;
		}
		$fee_id = (int) $order->get_meta( '_giftcard_fee_item_id_' . $number, true );
		$rows[] = array(
			'number'      => $number,
			'amount'      => $amount,
			'fee_item_id' => $fee_id,
		);
	}

	return $rows;
}

/**
 * Sum of gift card amounts already applied on this order.
 *
 * @param WC_Order $order Order.
 * @return float
 */
function wallregi_order_get_wallet_redemption_total( $order ) {
	$sum = 0.0;
	foreach ( wallregi_order_get_wallet_redemptions( $order ) as $row ) {
		$sum += (float) $row['amount'];
	}
	return $sum;
}

/**
 * Whether a gift card code is already on the order.
 *
 * @param WC_Order $order Order.
 * @param string   $code  Gift card number.
 * @return bool
 */
function wallregi_order_has_giftcard_code( $order, $code ) {
	$code = strtoupper( str_replace( ' ', '-', trim( (string) $code ) ) );
	foreach ( wallregi_order_get_wallet_redemptions( $order ) as $row ) {
		if ( $row['number'] === $code ) {
			return true;
		}
	}
	return false;
}

/**
 * Remaining order total that can still be paid with gift cards (after prior gift card fees).
 *
 * @param WC_Order $order Order.
 * @return float Non-negative amount in store currency units (integer-style amounts).
 */
function wallregi_order_get_remaining_giftcard_payable( $order ) {
	$remaining = (float) $order->get_total();
	return max( 0.0, $remaining );
}

/**
 * Deduct gift card balance and record a transaction for an order redemption.
 *
 * @param WC_Order $order           Order.
 * @param string   $giftcard_number Code.
 * @param int      $discount_amount Amount to deduct.
 * @param string   $context         Context string for hooks (e.g. admin_order, checkout_redeem).
 * @return true|WP_Error
 */
function wallregi_order_redeem_giftcard_balance( $order, $giftcard_number, $discount_amount, $context = 'order_redeem' ) {
	global $wpdb;

	if ( ! $order instanceof WC_Order ) {
		return new WP_Error( 'wallregi_order', __( 'Invalid order.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$discount_amount = max( 0, (int) $discount_amount );
	$giftcard_number = strtoupper( str_replace( ' ', '-', trim( (string) $giftcard_number ) ) );
	if ( '' === $giftcard_number || $discount_amount <= 0 ) {
		return new WP_Error( 'wallregi_amount', __( 'Invalid redemption amount.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$order_id = $order->get_id();

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->query(
		$wpdb->prepare(
			'UPDATE %i SET `current_amount` = GREATEST(0, `current_amount` - %d), `total_redeem` = `total_redeem` + %d WHERE `giftcard_number` = %s',
			wallregi_giftcard_db_table_name(),
			$discount_amount,
			$discount_amount,
			$giftcard_number
		)
	);

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$current_balance = $wpdb->get_var(
		$wpdb->prepare(
			'SELECT `current_amount` FROM %i WHERE `giftcard_number` = %s',
			wallregi_giftcard_db_table_name(),
			$giftcard_number
		)
	);

	if ( (int) $current_balance <= 0 ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				'UPDATE %i SET `status` = %s WHERE `giftcard_number` = %s',
				wallregi_giftcard_db_table_name(),
				'used',
				$giftcard_number
			)
		);
	}

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$giftcard_id = $wpdb->get_var(
		$wpdb->prepare(
			'SELECT `id` FROM %i WHERE `giftcard_number` = %s',
			wallregi_giftcard_db_table_name(),
			$giftcard_number
		)
	);
	$giftcard_id = $giftcard_id ? absint( $giftcard_id ) : 0;

	if ( $giftcard_id ) {
		$transaction_data = array(
			'giftcard_id' => $giftcard_id,
			'amount'      => $discount_amount,
			'order_id'    => (string) $order_id,
			'created_at'  => current_time( 'mysql' ),
			'updated_at'  => current_time( 'mysql' ),
			'created_by'  => get_current_user_id(),
			'updated_by'  => get_current_user_id(),
			'message'     => sprintf(
				/* translators: 1: gift card code, 2: order ID, 3: formatted amount */
				__( 'Gift card %1$s applied for order #%2$d. Discount: %3$s', 'wallet-ready-gift-cards-for-woocommerce' ),
				$giftcard_number,
				$order_id,
				wp_strip_all_tags( wc_price( $discount_amount ) )
			),
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert( wallregi_transaction_db_table_name(), $transaction_data );

		do_action(
			'wallregi_giftcard_balance_changed',
			$giftcard_id,
			array(
				'order_id'        => (int) $order_id,
				'coupon_code'     => $giftcard_number,
				'discount_amount' => $discount_amount,
				'context'         => $context,
			)
		);
	}

	return true;
}

/**
 * Restore gift card balance after admin removal or order cancel/refund.
 *
 * @param WC_Order $order           Order.
 * @param string   $giftcard_number Code.
 * @param int      $refund_amount   Amount to restore.
 * @param string   $context         Context for hooks.
 * @return true|WP_Error
 */
function wallregi_order_restore_giftcard_balance( $order, $giftcard_number, $refund_amount, $context = 'order_refund_restore' ) {
	global $wpdb;

	if ( ! $order instanceof WC_Order ) {
		return new WP_Error( 'wallregi_order', __( 'Invalid order.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$refund_amount   = max( 0, (int) $refund_amount );
	$giftcard_number = strtoupper( str_replace( ' ', '-', trim( (string) $giftcard_number ) ) );
	if ( '' === $giftcard_number || $refund_amount <= 0 ) {
		return new WP_Error( 'wallregi_amount', __( 'Invalid restore amount.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$order_id = $order->get_id();

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$giftcard_id = $wpdb->get_var(
		$wpdb->prepare(
			'SELECT `id` FROM %i WHERE `giftcard_number` = %s',
			wallregi_giftcard_db_table_name(),
			$giftcard_number
		)
	);

	if ( ! $giftcard_id ) {
		return new WP_Error( 'wallregi_giftcard_not_found', __( 'Gift card not found.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->query(
		$wpdb->prepare(
			'UPDATE %i SET `current_amount` = `current_amount` + %d, `total_redeem` = GREATEST(0, `total_redeem` - %d) WHERE `giftcard_number` = %s',
			wallregi_giftcard_db_table_name(),
			$refund_amount,
			$refund_amount,
			$giftcard_number
		)
	);

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$new_balance = $wpdb->get_var(
		$wpdb->prepare(
			'SELECT `current_amount` FROM %i WHERE `giftcard_number` = %s',
			wallregi_giftcard_db_table_name(),
			$giftcard_number
		)
	);

	if ( (int) $new_balance > 0 ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				'UPDATE %i SET `status` = %s WHERE `giftcard_number` = %s',
				wallregi_giftcard_db_table_name(),
				'active',
				$giftcard_number
			)
		);
	}

	$transaction_data = array(
		'giftcard_id' => (int) $giftcard_id,
		'amount'      => -$refund_amount,
		'order_id'    => (string) $order_id,
		'created_at'  => current_time( 'mysql' ),
		'updated_at'  => current_time( 'mysql' ),
		'created_by'  => get_current_user_id(),
		'updated_by'  => get_current_user_id(),
		'message'     => sprintf(
			/* translators: 1: gift card code, 2: order ID, 3: formatted amount */
			__( 'Gift card %1$s balance restored for order #%2$d. Amount: %3$s', 'wallet-ready-gift-cards-for-woocommerce' ),
			$giftcard_number,
			$order_id,
			wp_strip_all_tags( wc_price( $refund_amount ) )
		),
	);
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->insert( wallregi_transaction_db_table_name(), $transaction_data );

	do_action(
		'wallregi_giftcard_balance_changed',
		(int) $giftcard_id,
		array(
			'order_id'       => (int) $order_id,
			'giftcard_number' => $giftcard_number,
			'refund_amount'  => $refund_amount,
			'context'        => $context,
		)
	);

	return true;
}
