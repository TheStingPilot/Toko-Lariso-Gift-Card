<?php
/**
 * Checkout-based recipient (hide product-page receiver form).
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Product meta: '' (default), 'billing', or 'shipping'.
 *
 * @param int $product_id Product ID.
 * @return string
 */
function wallregi_get_product_checkout_receiver_source( $product_id ) {
	$product_id = absint( $product_id );
	if ( ! $product_id ) {
		return '';
	}
	$raw = get_post_meta( $product_id, '_wallregi_checkout_receiver_address', true );
	$raw = is_string( $raw ) ? strtolower( trim( $raw ) ) : '';
	if ( in_array( $raw, array( 'billing', 'shipping' ), true ) ) {
		return $raw;
	}
	return '';
}

/**
 * Read billing/shipping identity for gift card merge: order first, then checkout posted data,
 * session customer, then raw POST (classic checkout).
 *
 * @param WC_Order $order  Order being built.
 * @param string   $source 'billing' or 'shipping' (recipient); sender always uses billing (purchaser).
 * @return array{recipient_first:string,recipient_last:string,recipient_email:string,shipping_company:string,billing_first:string,billing_last:string,billing_email:string}
 */
function wallregi_get_checkout_identity_for_giftcard( WC_Order $order, $source ) {
	$source = ( 'shipping' === $source ) ? 'shipping' : 'billing';

	$b_first = '';
	$b_last  = '';
	$b_email = '';

	$s_first = '';
	$s_last  = '';
	$s_email = '';
	$s_co    = '';

	if ( $order instanceof WC_Order ) {
		$b_first = (string) $order->get_billing_first_name();
		$b_last  = (string) $order->get_billing_last_name();
		$b_email = (string) $order->get_billing_email();
		$s_first = (string) $order->get_shipping_first_name();
		$s_last  = (string) $order->get_shipping_last_name();
		$s_co    = (string) $order->get_shipping_company();
		if ( is_callable( array( $order, 'get_shipping_email' ) ) ) {
			$s_email = (string) $order->get_shipping_email();
		}
	}

	$posted = array();
	if ( function_exists( 'WC' ) && WC()->checkout() instanceof WC_Checkout ) {
		$posted = WC()->checkout()->get_posted_data();
		$posted = is_array( $posted ) ? $posted : array();
	}

	$pick = static function ( $key ) use ( &$posted ) {
		return isset( $posted[ $key ] ) && is_string( $posted[ $key ] ) ? $posted[ $key ] : '';
	};

	if ( '' === $b_first ) {
		$b_first = $pick( 'billing_first_name' );
	}
	if ( '' === $b_last ) {
		$b_last = $pick( 'billing_last_name' );
	}
	if ( '' === $b_email ) {
		$b_email = $pick( 'billing_email' );
	}
	if ( '' === $s_first ) {
		$s_first = $pick( 'shipping_first_name' );
	}
	if ( '' === $s_last ) {
		$s_last = $pick( 'shipping_last_name' );
	}
	if ( '' === $s_co ) {
		$s_co = $pick( 'shipping_company' );
	}
	if ( '' === $s_email ) {
		$s_email = $pick( 'shipping_email' );
	}

	if ( function_exists( 'WC' ) && WC()->customer instanceof WC_Customer ) {
		$c = WC()->customer;
		if ( '' === $b_first ) {
			$b_first = (string) $c->get_billing_first_name();
		}
		if ( '' === $b_last ) {
			$b_last = (string) $c->get_billing_last_name();
		}
		if ( '' === $b_email ) {
			$b_email = (string) $c->get_billing_email();
		}
		if ( '' === $s_first ) {
			$s_first = (string) $c->get_shipping_first_name();
		}
		if ( '' === $s_last ) {
			$s_last = (string) $c->get_shipping_last_name();
		}
	}

	if ( defined( 'WOOCOMMERCE_CHECKOUT' ) && WOOCOMMERCE_CHECKOUT && isset( $_POST['woocommerce-process-checkout-nonce'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( '' === $b_first && isset( $_POST['billing_first_name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$b_first = sanitize_text_field( wp_unslash( (string) $_POST['billing_first_name'] ) );
		}
		if ( '' === $b_last && isset( $_POST['billing_last_name'] ) ) {
			$b_last = sanitize_text_field( wp_unslash( (string) $_POST['billing_last_name'] ) );
		}
		if ( '' === $b_email && isset( $_POST['billing_email'] ) ) {
			$b_email = sanitize_email( wp_unslash( (string) $_POST['billing_email'] ) );
		}
		if ( '' === $s_first && isset( $_POST['shipping_first_name'] ) ) {
			$s_first = sanitize_text_field( wp_unslash( (string) $_POST['shipping_first_name'] ) );
		}
		if ( '' === $s_last && isset( $_POST['shipping_last_name'] ) ) {
			$s_last = sanitize_text_field( wp_unslash( (string) $_POST['shipping_last_name'] ) );
		}
		if ( '' === $s_co && isset( $_POST['shipping_company'] ) ) {
			$s_co = sanitize_text_field( wp_unslash( (string) $_POST['shipping_company'] ) );
		}
	}

	$b_email = sanitize_email( $b_email );
	if ( ! is_email( $b_email ) ) {
		$b_email = '';
	}
	$s_email = sanitize_email( $s_email );
	if ( ! is_email( $s_email ) ) {
		$s_email = '';
	}

	if ( 'billing' === $source ) {
		$r_first = $b_first;
		$r_last  = $b_last;
		$r_email = $b_email;
	} else {
		$r_first = $s_first;
		$r_last  = $s_last;
		$r_email = $s_email;
		if ( '' === $r_email && is_email( $b_email ) ) {
			$r_email = $b_email;
		}
	}

	return array(
		'recipient_first'   => $r_first,
		'recipient_last'    => $r_last,
		'recipient_email'   => $r_email,
		'shipping_company'  => $s_co,
		'billing_first'     => $b_first,
		'billing_last'      => $b_last,
		'billing_email'     => $b_email,
	);
}

/**
 * Fill receiver (and sender) fields from the order billing or shipping address.
 *
 * @param array    $giftcard_data Cart line gift card payload.
 * @param WC_Order $order         Order being created.
 * @param string   $source        'billing' or 'shipping'.
 * @return array
 */
function wallregi_merge_order_address_into_giftcard_data( array $giftcard_data, WC_Order $order, $source ) {
	$source = ( 'shipping' === $source ) ? 'shipping' : 'billing';

	$id = wallregi_get_checkout_identity_for_giftcard( $order, $source );

	$first = $id['recipient_first'];
	$last  = $id['recipient_last'];
	$email = $id['recipient_email'];

	$receiver_name = trim( preg_replace( '/\s+/', ' ', $first . ' ' . $last ) );
	if ( '' === $receiver_name && 'shipping' === $source ) {
		$receiver_name = trim( (string) $id['shipping_company'] );
	}
	if ( '' === $receiver_name ) {
		$receiver_name = trim( preg_replace( '/\s+/', ' ', $id['billing_first'] . ' ' . $id['billing_last'] ) );
	}
	if ( '' === $receiver_name ) {
		$receiver_name = (string) apply_filters(
			'wallregi_checkout_receiver_default_name',
			__( 'Recipient', 'wallet-ready-gift-cards-for-woocommerce' ),
			$order,
			$source,
			$giftcard_data
		);
	}

	$email = sanitize_email( $email );
	if ( ! is_email( $email ) ) {
		$email = sanitize_email( $id['billing_email'] );
	}
	if ( ! is_email( $email ) && $order instanceof WC_Order ) {
		$email = sanitize_email( (string) $order->get_billing_email() );
	}
	if ( ! is_email( $email ) ) {
		$email = '';
	}

	$sender_name = trim( preg_replace( '/\s+/', ' ', $id['billing_first'] . ' ' . $id['billing_last'] ) );
	if ( '' === $sender_name && $order instanceof WC_Order ) {
		$sender_name = trim( preg_replace( '/\s+/', ' ', $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) );
	}
	if ( '' === $sender_name ) {
		$sender_name = (string) apply_filters( 'wallregi_checkout_receiver_default_sender', $receiver_name, $order, $giftcard_data );
	}

	$giftcard_data['receiver_name']   = $receiver_name;
	$giftcard_data['receiver_email']  = $email;
	$giftcard_data['sender_name']     = $sender_name;

	unset( $giftcard_data['checkout_receiver_source'] );

	return (array) apply_filters( 'wallregi_giftcard_data_after_checkout_receiver_merge', $giftcard_data, $order, $source );
}

/**
 * Do not allow editing identity fields that are deferred to checkout.
 *
 * @param array  $fields         Editable field keys.
 * @param string $cart_item_key  Cart line key.
 * @param array  $giftcard_data  Line gift card data.
 * @param string $context        e.g. ajax, store_api.
 * @return array
 */
function wallregi_filter_editable_giftcard_fields_checkout_receiver( $fields, $cart_item_key, $giftcard_data, $context ) {
	unset( $cart_item_key, $context );
	if ( ! is_array( $fields ) || ! is_array( $giftcard_data ) ) {
		return $fields;
	}
	$src = isset( $giftcard_data['checkout_receiver_source'] ) ? $giftcard_data['checkout_receiver_source'] : '';
	if ( in_array( $src, array( 'billing', 'shipping' ), true ) ) {
		$strip = array( 'receiver_name', 'receiver_email', 'receiver_message', 'sender_name', 'email_schedule' );
		$fields = array_values( array_diff( $fields, $strip ) );
	}
	return $fields;
}

add_filter( 'wallregi_editable_giftcard_fields', 'wallregi_filter_editable_giftcard_fields_checkout_receiver', 10, 4 );
