<?php
/**
 * Bulk gift card CSV import / migration (validate, duplicate detection, async chunks).
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WALLREGI_Bulk_Import' ) ) {

	class WALLREGI_Bulk_Import {

		private const AJAX_NONCE_ACTION = 'wallregi_pro_bulk_import';

		private const MAX_FILE_BYTES = 5242880;

		private const DEFAULT_MAX_ROWS = 500;

		private const CHUNK_ROWS = 25;

		private const STAGED_TTL = 3600;

		public function __construct() {
			add_action( 'admin_menu', [ $this, 'wallregi_register_submenu' ], 60 );
			add_action( 'admin_enqueue_scripts', [ $this, 'wallregi_enqueue_admin' ] );
			add_action( 'wp_ajax_wallregi_pro_bulk_validate_csv', [ $this, 'wallregi_ajax_validate_csv' ] );
			add_action( 'wp_ajax_wallregi_pro_bulk_queue_import', [ $this, 'wallregi_ajax_queue_import' ] );
			add_action( 'wp_ajax_wallregi_pro_bulk_job_status', [ $this, 'wallregi_ajax_job_status' ] );
			add_action( 'wallregi_pro_bulk_import_process_chunk', [ $this, 'wallregi_run_chunk' ], 10, 1 );
		}

		/**
		 * Maximum data rows per CSV (free default 500; Pro license may raise via filter).
		 *
		 * @return int
		 */
		private function wallregi_get_max_rows() {
			$max = (int) apply_filters( 'wallregi_bulk_import_max_rows', self::DEFAULT_MAX_ROWS );

			return max( 1, min( 5000, $max ) );
		}

		/**
		 * Whether the current admin request is the bulk import screen.
		 */
		private function wallregi_is_bulk_import_admin_screen() {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen detection.
			if ( ! is_admin() || ! isset( $_GET['page'] ) ) {
				return false;
			}
			return 'wx-gift-cards-bulk' === sanitize_text_field( wp_unslash( (string) $_GET['page'] ) );
		}

		/**
		 * Job id stored for this user that is still in progress (option row exists, not terminal).
		 *
		 * @param int $uid User ID.
		 * @return string Job id or empty string.
		 */
		private function wallregi_get_resume_bulk_job_id_for_user( $uid ) {
			$uid = (int) $uid;
			if ( $uid <= 0 ) {
				return '';
			}
			$jid = get_user_meta( $uid, 'wallregi_pro_bulk_last_job_id', true );
			if ( ! is_scalar( $jid ) ) {
				return '';
			}
			$jid = trim( (string) $jid );
			if ( '' === $jid ) {
				return '';
			}
			$job = get_option( 'wallregi_pro_bulk_job_' . $jid, null );
			if ( ! is_array( $job ) ) {
				return '';
			}
			if ( (int) ( $job['queued_by'] ?? -1 ) !== $uid ) {
				return '';
			}
			$st = isset( $job['status'] ) ? (string) $job['status'] : '';
			if ( in_array( $st, [ 'completed', 'failed' ], true ) ) {
				return '';
			}
			return $jid;
		}

		/**
		 * @return string Absolute path to bulk working directory (uploads).
		 */
		private function wallregi_get_bulk_dir() {
			$upload = wp_upload_dir();
			if ( ! empty( $upload['error'] ) ) {
				return '';
			}
			$dir = trailingslashit( $upload['basedir'] ) . 'wallregi-bulk-import';
			if ( ! is_dir( $dir ) ) {
				wp_mkdir_p( $dir );
			}
			$ht = $dir . '/.htaccess';
			if ( ! file_exists( $ht ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				file_put_contents( $ht, "Deny from all\n" );
			}
			$idx = $dir . '/index.php';
			if ( ! file_exists( $idx ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				file_put_contents( $idx, "<?php\n// Silence is golden.\n" );
			}

			return $dir;
		}

		/**
		 * Human-readable message for PHP file upload error codes.
		 *
		 * @param int $code Value of $_FILES['csv']['error'].
		 * @return string
		 */
		private function wallregi_upload_err_message( $code ) {
			switch ( (int) $code ) {
				case UPLOAD_ERR_INI_SIZE:
				case UPLOAD_ERR_FORM_SIZE:
					return __( 'The CSV exceeds the server upload size limit. Increase upload_max_filesize / post_max_size in PHP or use a smaller file.', 'wallet-ready-gift-cards-for-woocommerce' );
				case UPLOAD_ERR_PARTIAL:
					return __( 'The file upload was interrupted. Try again.', 'wallet-ready-gift-cards-for-woocommerce' );
				case UPLOAD_ERR_NO_FILE:
					return __( 'No file uploaded.', 'wallet-ready-gift-cards-for-woocommerce' );
				case UPLOAD_ERR_NO_TMP_DIR:
					return __( 'Server is missing a temporary folder for uploads. Contact your host.', 'wallet-ready-gift-cards-for-woocommerce' );
				case UPLOAD_ERR_CANT_WRITE:
					return __( 'Could not write the uploaded file to disk.', 'wallet-ready-gift-cards-for-woocommerce' );
				case UPLOAD_ERR_EXTENSION:
					return __( 'A PHP extension blocked this upload.', 'wallet-ready-gift-cards-for-woocommerce' );
				default:
					return __( 'File upload failed.', 'wallet-ready-gift-cards-for-woocommerce' );
			}
		}

		public function wallregi_register_submenu() {
			$parent = function_exists( 'wallregi_gift_cards_parent_menu_slug' )
				? wallregi_gift_cards_parent_menu_slug()
				: 'edit.php?post_type=product';

			add_submenu_page(
				$parent,
				__( 'Import gift cards (CSV)', 'wallet-ready-gift-cards-for-woocommerce' ),
				__( 'Import / migrate (CSV)', 'wallet-ready-gift-cards-for-woocommerce' ),
				'manage_woocommerce',
				'wx-gift-cards-bulk',
				[ $this, 'wallregi_render_admin_page' ]
			);
		}

		public function wallregi_render_admin_page() {
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_die( esc_html__( 'You do not have permission to access this page.', 'wallet-ready-gift-cards-for-woocommerce' ) );
			}

			$wallregi_pro_bulk_resume_job_id = '';
			$wallregi_pro_bulk_resume_job     = null;
			$uid                              = get_current_user_id();
			if ( $uid > 0 ) {
				$wallregi_pro_bulk_resume_job_id = $this->wallregi_get_resume_bulk_job_id_for_user( $uid );
				if ( '' !== $wallregi_pro_bulk_resume_job_id ) {
					$wallregi_pro_bulk_resume_job = get_option( 'wallregi_pro_bulk_job_' . $wallregi_pro_bulk_resume_job_id, null );
					if ( ! is_array( $wallregi_pro_bulk_resume_job ) ) {
						$wallregi_pro_bulk_resume_job_id = '';
						$wallregi_pro_bulk_resume_job    = null;
					}
				}
			}

			$wallregi_bulk_sample_url    = WALLREGI_PLUGIN_URL . 'assets/samples/bulk-giftcards-sample.csv';
			$wallregi_bulk_max_rows      = $this->wallregi_get_max_rows();
			$wallregi_bulk_pro_high_cap  = function_exists( 'wallregi_pro_license_is_active' ) && wallregi_pro_license_is_active();
			$view                        = WALLREGI_PLUGIN_DIR . 'admin/views/bulk-import-page.php';
			if ( file_exists( $view ) ) {
				// phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable
				include $view;
			}
		}

		public function wallregi_enqueue_admin( $hook_suffix ) {
			if ( ! $this->wallregi_is_bulk_import_admin_screen() && false === strpos( (string) $hook_suffix, 'wx-gift-cards-bulk' ) ) {
				return;
			}

			$resume_job_id = '';
			$uid           = get_current_user_id();
			if ( $uid > 0 ) {
				$resume_job_id = $this->wallregi_get_resume_bulk_job_id_for_user( $uid );
			}

			wp_enqueue_script(
				'wallregi-bulk-import',
				WALLREGI_PLUGIN_URL . 'assets/js/bulk-import-admin.js',
				[ 'jquery' ],
				defined( 'WALLREGI_VERSION' ) ? WALLREGI_VERSION : '1.0.0',
				true
			);

			wp_localize_script(
				'wallregi-bulk-import',
				'wallregiBulkImport',
				[
					'maxRows' => $this->wallregi_get_max_rows(),
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( self::AJAX_NONCE_ACTION ),
					'strings' => [
						'validating' => __( 'Validating…', 'wallet-ready-gift-cards-for-woocommerce' ),
						'queueing'   => __( 'Queueing import…', 'wallet-ready-gift-cards-for-woocommerce' ),
						'polling'    => __( 'Processing…', 'wallet-ready-gift-cards-for-woocommerce' ),
						'pickFile'   => __( 'Please choose a CSV file first.', 'wallet-ready-gift-cards-for-woocommerce' ),
						'validateFirst' => __( 'Validate the CSV successfully before starting the import.', 'wallet-ready-gift-cards-for-woocommerce' ),
						'resumed'    => __( 'Resuming import progress for your last job.', 'wallet-ready-gift-cards-for-woocommerce' ),
					],
					'resumeJobId' => $resume_job_id,
				]
			);

			wp_add_inline_script(
				'wallregi-bulk-import',
				'window.wallregiProBulkImport = window.wallregiBulkImport;',
				'after'
			);

			wp_add_inline_style(
				'wp-admin',
				'.wallregi-pro-bulk-messages { margin: 1em 0; max-width: 960px; } .wallregi-pro-bulk-messages .notice { margin: 0.5em 0; } #wallregi-pro-bulk-validation-summary table.widefat { max-width: 960px; }'
			);
		}

		/**
		 * @return array{0: string, 1: string}|array{0: '', 1: string}
		 */
		private function wallregi_normalize_header_cell( $cell ) {
			$key = strtolower( trim( (string) $cell ) );
			$key = str_replace( [ "\xEF\xBB\xBF" ], '', $key );
			$map = [
				'recipient_name' => 'receipent_name',
				'email'          => 'receipent_email',
				'receiver_email' => 'receipent_email',
				'receiver_name'  => 'receipent_name',
			];
			if ( isset( $map[ $key ] ) ) {
				$key = $map[ $key ];
			}

			return [ $key, (string) $cell ];
		}

		/**
		 * Parse uploaded CSV into normalized row payloads (in-memory validation).
		 *
		 * @param string $path Absolute path to CSV file.
		 * @return array{rows: array<int, array<string, mixed>>, errors: array<int, array{line: int, message: string}>, duplicate_codes_in_file: string[]}
		 */
		private function wallregi_parse_csv_file( $path ) {
			$errors                  = [];
			$rows                    = [];
			$seen_codes              = [];
			$duplicate_codes_in_file = [];

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
			$h = fopen( $path, 'rb' );
			if ( ! $h ) {
				$errors[] = [ 'line' => 0, 'message' => __( 'Could not read the uploaded file.', 'wallet-ready-gift-cards-for-woocommerce' ) ];

				return compact( 'rows', 'errors', 'duplicate_codes_in_file' );
			}

			$bom = fread( $h, 3 );
			if ( $bom !== "\xEF\xBB\xBF" ) {
				rewind( $h );
			}

			$header_line = fgetcsv( $h );
			if ( ! is_array( $header_line ) || empty( $header_line ) ) {
				fclose( $h );
				$errors[] = [ 'line' => 1, 'message' => __( 'Missing or empty header row.', 'wallet-ready-gift-cards-for-woocommerce' ) ];

				return compact( 'rows', 'errors', 'duplicate_codes_in_file' );
			}

			$headers = [];
			foreach ( $header_line as $cell ) {
				list( $norm ) = $this->wallregi_normalize_header_cell( $cell );
				$headers[] = $norm;
			}

			$required = [ 'initial_amount', 'current_amount', 'expiry_period', 'receipent_name', 'receipent_email', 'sender_name' ];
			foreach ( $required as $req ) {
				if ( ! in_array( $req, $headers, true ) ) {
					$errors[] = [
						'line'    => 1,
						'message' => sprintf(
							/* translators: %s: column name */
							__( 'Missing required column: %s', 'wallet-ready-gift-cards-for-woocommerce' ),
							esc_html( $req )
						),
					];
				}
			}
			if ( ! empty( $errors ) ) {
				fclose( $h );

				return compact( 'rows', 'errors', 'duplicate_codes_in_file' );
			}

			$line_no = 1;
			while ( ( $data = fgetcsv( $h ) ) !== false ) {
				++$line_no;
				if ( $this->wallregi_csv_row_is_empty( $data ) ) {
					continue;
				}
				$max_rows = $this->wallregi_get_max_rows();
				if ( count( $rows ) >= $max_rows ) {
					$errors[] = [
						'line'    => $line_no,
						'message' => sprintf(
							/* translators: %d: max rows */
							__( 'Row limit exceeded (%d rows). Split into multiple files or upgrade to GiftRocket Pro for a higher limit.', 'wallet-ready-gift-cards-for-woocommerce' ),
							$max_rows
						),
					];
					break;
				}

				$row = [ 'line' => $line_no ];
				foreach ( $headers as $i => $key ) {
					$row[ $key ] = isset( $data[ $i ] ) ? (string) $data[ $i ] : '';
				}

				$row_err = $this->wallregi_validate_parsed_row( $row );
				if ( is_wp_error( $row_err ) ) {
					$errors[] = [ 'line' => $line_no, 'message' => $row_err->get_error_message() ];
					continue;
				}

				$code_raw = isset( $row['giftcard_number'] ) ? trim( (string) $row['giftcard_number'] ) : '';
				$auto     = ( '' === $code_raw );
				$row['auto_generate'] = $auto;
				if ( ! $auto ) {
					$norm = strtoupper( str_replace( ' ', '-', $code_raw ) );
					if ( isset( $seen_codes[ $norm ] ) ) {
						$duplicate_codes_in_file[] = $norm;
						$errors[]                = [
							'line'    => $line_no,
							'message' => sprintf(
								/* translators: %s: duplicate code */
								__( 'Duplicate gift card number in file: %s', 'wallet-ready-gift-cards-for-woocommerce' ),
								esc_html( $norm )
							),
						];
						continue;
					}
					$seen_codes[ $norm ] = true;
					$row['giftcard_number'] = $norm;
				} else {
					$row['giftcard_number'] = '';
				}

				$rows[] = $row;
			}

			fclose( $h );

			return compact( 'rows', 'errors', 'duplicate_codes_in_file' );
		}

		/**
		 * @param array<int, string|null|false> $data
		 */
		private function wallregi_csv_row_is_empty( $data ) {
			if ( ! is_array( $data ) ) {
				return true;
			}
			foreach ( $data as $cell ) {
				if ( null === $cell || false === $cell ) {
					continue;
				}
				if ( trim( (string) $cell ) !== '' ) {
					return false;
				}
			}

			return true;
		}

		/**
		 * @param array<string, mixed> $row
		 * @return true|\WP_Error
		 */
		private function wallregi_validate_parsed_row( array $row ) {
			$initial = isset( $row['initial_amount'] ) ? (int) $row['initial_amount'] : 0;
			$current = isset( $row['current_amount'] ) ? (int) $row['current_amount'] : 0;
			if ( $initial <= 0 || $current < 0 ) {
				return new WP_Error( 'amount', __( 'initial_amount must be a positive integer; current_amount must be zero or positive.', 'wallet-ready-gift-cards-for-woocommerce' ) );
			}

			$expiry = isset( $row['expiry_period'] ) ? trim( (string) $row['expiry_period'] ) : '';
			$expiry_ok = wallregi_resolve_manual_giftcard_expiry_input( $expiry );
			if ( is_wp_error( $expiry_ok ) ) {
				return new WP_Error( 'expiry', $expiry_ok->get_error_message() );
			}

			$name = isset( $row['receipent_name'] ) ? trim( (string) $row['receipent_name'] ) : '';
			if ( '' === $name ) {
				return new WP_Error( 'name', __( 'Recipient name is required.', 'wallet-ready-gift-cards-for-woocommerce' ) );
			}

			$email = isset( $row['receipent_email'] ) ? trim( (string) $row['receipent_email'] ) : '';
			if ( '' === $email || ! is_email( $email ) ) {
				return new WP_Error( 'email', __( 'A valid recipient email is required.', 'wallet-ready-gift-cards-for-woocommerce' ) );
			}

			$sender = isset( $row['sender_name'] ) ? trim( (string) $row['sender_name'] ) : '';
			if ( '' === $sender ) {
				return new WP_Error( 'sender', __( 'Sender name is required.', 'wallet-ready-gift-cards-for-woocommerce' ) );
			}

			$code = isset( $row['giftcard_number'] ) ? trim( (string) $row['giftcard_number'] ) : '';
			if ( '' !== $code && ! wallregi_manual_giftcard_code_format_valid( $code ) ) {
				return new WP_Error(
					'code',
					sprintf(
						/* translators: %s: validation rules summary */
						__( 'giftcard_number must be empty (auto) or match manual code rules: %s', 'wallet-ready-gift-cards-for-woocommerce' ),
						wallregi_giftcard_code_format_error_message()
					)
				);
			}

			$pid = isset( $row['product_id'] ) ? (int) $row['product_id'] : 0;
			if ( $pid > 0 ) {
				$p = wc_get_product( $pid );
				if ( ! $p || 'wxgiftcard' !== $p->get_type() ) {
					return new WP_Error( 'product', __( 'product_id must be 0 or a valid wxgiftcard product.', 'wallet-ready-gift-cards-for-woocommerce' ) );
				}
			}

			return true;
		}

		public function wallregi_ajax_validate_csv() {
			check_ajax_referer( self::AJAX_NONCE_ACTION, 'nonce' );
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_send_json_error( [ 'message' => __( 'Permission denied.', 'wallet-ready-gift-cards-for-woocommerce' ) ], 403 );
			}

			if ( ! apply_filters( 'wallregi_security_allow_pro_bulk_validate', true ) ) {
				$msg = function_exists( 'wallregi_security_rate_limit_message' )
					? wallregi_security_rate_limit_message()
					: __( 'Too many requests. Please try again later.', 'wallet-ready-gift-cards-for-woocommerce' );
				wp_send_json_error( [ 'message' => $msg ], 429 );
			}

			$file = isset( $_FILES['csv'] ) && is_array( $_FILES['csv'] ) ? $_FILES['csv'] : null;
			if ( null === $file ) {
				wp_send_json_error( [ 'message' => __( 'No file uploaded.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}

			$err = isset( $file['error'] ) ? (int) $file['error'] : UPLOAD_ERR_NO_FILE;
			if ( UPLOAD_ERR_OK !== $err ) {
				$msg = $this->wallregi_upload_err_message( $err );
				wp_send_json_error( [ 'message' => $msg ] );
			}

			// Do not use sanitize_text_field or wp_unslash on tmp_name: stripslashes() corrupts Windows paths (e.g. C:\temp\...).
			$tmp = isset( $file['tmp_name'] ) ? (string) $file['tmp_name'] : '';
			if ( '' === $tmp || ! is_uploaded_file( $tmp ) ) {
				wp_send_json_error( [ 'message' => __( 'Upload was not accepted by the server. Check PHP upload limits and try again.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}

			if ( ! is_readable( $tmp ) ) {
				wp_send_json_error( [ 'message' => __( 'Uploaded file is not readable.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}

			$size = isset( $file['size'] ) ? (int) $file['size'] : 0;
			if ( $size <= 0 || $size > self::MAX_FILE_BYTES ) {
				wp_send_json_error( [ 'message' => __( 'File is empty or larger than 5 MB.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}

			$parsed = $this->wallregi_parse_csv_file( $tmp );
			if ( empty( $parsed['rows'] ) ) {
				$errs = $parsed['errors'];
				if ( empty( $errs ) ) {
					$errs[] = [
						'line'    => 0,
						'message' => __( 'No valid data rows found. Add at least one row below the header.', 'wallet-ready-gift-cards-for-woocommerce' ),
					];
				}
				wp_send_json_success(
					[
						'ok'         => false,
						'errors'     => array_slice( $errs, 0, 100 ),
						'row_count'  => 0,
						'duplicates' => $parsed['duplicate_codes_in_file'],
					]
				);
			}

			$dir = $this->wallregi_get_bulk_dir();
			if ( '' === $dir ) {
				wp_send_json_error( [ 'message' => __( 'Upload directory is not available.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}

			$token = wp_generate_password( 32, false, false );
			$path  = $dir . '/staged-' . $token . '.jsonl';

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
			$out = fopen( $path, 'wb' );
			if ( ! $out ) {
				wp_send_json_error( [ 'message' => __( 'Could not write staging file.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}

			foreach ( $parsed['rows'] as $row ) {
				$payload = [
					'line'                => (int) ( $row['line'] ?? 0 ),
					'auto_generate'       => ! empty( $row['auto_generate'] ),
					'giftcard_number'     => (string) ( $row['giftcard_number'] ?? '' ),
					'initial_amount'      => (int) ( $row['initial_amount'] ?? 0 ),
					'current_amount'      => (int) ( $row['current_amount'] ?? 0 ),
					'expiry_period'       => trim( (string) ( $row['expiry_period'] ?? '' ) ),
					'receipent_name'      => trim( (string) ( $row['receipent_name'] ?? '' ) ),
					'receipent_email'     => trim( (string) ( $row['receipent_email'] ?? '' ) ),
					'sender_name'         => trim( (string) ( $row['sender_name'] ?? '' ) ),
					'message'             => isset( $row['message'] ) ? (string) $row['message'] : '',
					'product_id'          => isset( $row['product_id'] ) ? (int) $row['product_id'] : 0,
					'preferred_date_time' => isset( $row['preferred_date_time'] ) ? trim( (string) $row['preferred_date_time'] ) : '',
					'giftcard_image'      => isset( $row['giftcard_image'] ) ? trim( (string) $row['giftcard_image'] ) : '',
				];
				fwrite( $out, wp_json_encode( $payload, JSON_UNESCAPED_UNICODE ) . "\n" );
			}
			fclose( $out );

			set_transient(
				'wallregi_pro_bulk_staged_' . $token,
				[
					'path'      => $path,
					'user_id'   => get_current_user_id(),
					'row_count' => count( $parsed['rows'] ),
					'expires'   => time() + self::STAGED_TTL,
				],
				self::STAGED_TTL
			);

			wp_send_json_success(
				[
					'ok'         => true,
					'token'      => $token,
					'row_count'  => count( $parsed['rows'] ),
					'errors'     => array_slice( $parsed['errors'], 0, 100 ),
					'duplicates' => $parsed['duplicate_codes_in_file'],
				]
			);
		}

		public function wallregi_ajax_queue_import() {
			check_ajax_referer( self::AJAX_NONCE_ACTION, 'nonce' );
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_send_json_error( [ 'message' => __( 'Permission denied.', 'wallet-ready-gift-cards-for-woocommerce' ) ], 403 );
			}

			if ( ! apply_filters( 'wallregi_security_allow_pro_bulk_queue', true ) ) {
				$msg = function_exists( 'wallregi_security_rate_limit_message' )
					? wallregi_security_rate_limit_message()
					: __( 'Too many requests. Please try again later.', 'wallet-ready-gift-cards-for-woocommerce' );
				wp_send_json_error( [ 'message' => $msg ], 429 );
			}

			$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
			if ( '' === $token ) {
				wp_send_json_error( [ 'message' => __( 'Missing staging token. Validate the CSV again.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}

			$staged = get_transient( 'wallregi_pro_bulk_staged_' . $token );
			if ( ! is_array( $staged ) || empty( $staged['path'] ) ) {
				wp_send_json_error( [ 'message' => __( 'Staging data expired. Validate the CSV again.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}
			if ( (int) ( $staged['user_id'] ?? 0 ) !== (int) get_current_user_id() ) {
				wp_send_json_error( [ 'message' => __( 'Staging token does not belong to the current user.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}

			$src = (string) $staged['path'];
			if ( ! is_readable( $src ) ) {
				wp_send_json_error( [ 'message' => __( 'Staging file is missing.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}

			$job_id = function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : uniqid( 'wallregi_bulk_', true );
			$dir    = $this->wallregi_get_bulk_dir();
			$dest   = $dir . '/job-' . preg_replace( '/[^a-zA-Z0-9_-]/', '', $job_id ) . '.jsonl';

			if ( ! @rename( $src, $dest ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_read_write_copy
				if ( ! @copy( $src, $dest ) ) {
					wp_send_json_error( [ 'message' => __( 'Could not finalize import file.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
				}
				wp_delete_file( $src );
			}

			delete_transient( 'wallregi_pro_bulk_staged_' . $token );

			$job = [
				'status'            => 'queued',
				'file'              => $dest,
				'next_line_index'   => 0,
				'total'             => (int) ( $staged['row_count'] ?? 0 ),
				'queued_by'         => get_current_user_id(),
				'created_at'        => time(),
				'inserted'          => 0,
				'skipped_duplicate' => 0,
				'failed'            => 0,
				'log'               => [],
				'last_message'      => '',
			];

			update_option( 'wallregi_pro_bulk_job_' . $job_id, $job, false );

			$uid = get_current_user_id();
			if ( $uid > 0 ) {
				update_user_meta( $uid, 'wallregi_pro_bulk_last_job_id', (string) $job_id );
			}

			$this->wallregi_schedule_chunk( $job_id );

			wp_send_json_success(
				[
					'job_id' => $job_id,
					'message' => __( 'Import queued. Rows will be processed in the background.', 'wallet-ready-gift-cards-for-woocommerce' ),
				]
			);
		}

		public function wallregi_ajax_job_status() {
			check_ajax_referer( self::AJAX_NONCE_ACTION, 'nonce' );
			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_send_json_error( [ 'message' => __( 'Permission denied.', 'wallet-ready-gift-cards-for-woocommerce' ) ], 403 );
			}

			if ( ! apply_filters( 'wallregi_security_allow_pro_bulk_status', true ) ) {
				$msg = function_exists( 'wallregi_security_rate_limit_message' )
					? wallregi_security_rate_limit_message()
					: __( 'Too many requests. Please try again later.', 'wallet-ready-gift-cards-for-woocommerce' );
				wp_send_json_error( [ 'message' => $msg ], 429 );
			}

			$job_id = isset( $_POST['job_id'] ) ? sanitize_text_field( wp_unslash( $_POST['job_id'] ) ) : '';
			if ( '' === $job_id ) {
				wp_send_json_error( [ 'message' => __( 'Missing job id.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}

			$job = get_option( 'wallregi_pro_bulk_job_' . $job_id, null );
			if ( ! is_array( $job ) ) {
				wp_send_json_error( [ 'message' => __( 'Job not found.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}
			if ( (int) ( $job['queued_by'] ?? 0 ) !== (int) get_current_user_id() ) {
				wp_send_json_error( [ 'message' => __( 'You cannot view this job.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
			}

			wp_send_json_success( $job );
		}

		private function wallregi_schedule_chunk( $job_id ) {
			if ( function_exists( 'as_schedule_single_action' ) ) {
				as_schedule_single_action( time() + 1, 'wallregi_pro_bulk_import_process_chunk', [ $job_id ], 'wallregi-pro-bulk' );
			} else {
				wp_schedule_single_event( time() + 2, 'wallregi_pro_bulk_import_process_chunk', [ $job_id ] );
			}
		}

		/**
		 * Queue ePass issuance outside the bulk chunk request (avoids many synchronous HTTP calls timing out).
		 *
		 * @param int $giftcard_id wx_gift_cards.id.
		 * @param int $wave_index  Used to spread scheduled times (e.g. inserted count).
		 */
		private function wallregi_schedule_epass_for_imported_giftcard( $giftcard_id, $wave_index ) {
			$giftcard_id = absint( $giftcard_id );
			if ( $giftcard_id <= 0 ) {
				return;
			}
			$wave_index = absint( $wave_index );
			$delay      = 2 + ( $wave_index % 30 ) * 2;

			/**
			 * Action Scheduler returns 0 if the data store is not initialized yet or scheduling failed.
			 * In that case we must not assume WP-Cron was used (the old code only fell back when AS
			 * functions were missing), or bulk imports would enqueue no ePass work at all.
			 */
			$action_id = 0;
			if ( function_exists( 'as_enqueue_async_action' ) ) {
				$action_id = (int) as_enqueue_async_action(
					'wallregi_epass_deferred_issue_pass',
					array( $giftcard_id ),
					'wallregi-pro-bulk-epass'
				);
			}
			if ( $action_id <= 0 && function_exists( 'as_schedule_single_action' ) ) {
				$action_id = (int) as_schedule_single_action(
					time() + $delay,
					'wallregi_epass_deferred_issue_pass',
					array( $giftcard_id ),
					'wallregi-pro-bulk-epass'
				);
			}
			if ( $action_id > 0 ) {
				return;
			}
			if ( function_exists( 'wallregi_epass_try_issue_pass_for_giftcard' ) ) {
				wallregi_epass_try_issue_pass_for_giftcard( $giftcard_id );
				return;
			}
			wp_schedule_single_event( time() + $delay, 'wallregi_epass_deferred_issue_pass', array( $giftcard_id ) );
		}

		/**
		 * @param string $job_id Job identifier.
		 */
		public function wallregi_run_chunk( $job_id ) {
			$job_id = sanitize_text_field( (string) $job_id );
			if ( '' === $job_id ) {
				return;
			}

			$lock_key = 'wallregi_pro_bulk_lock_' . md5( $job_id );
			if ( get_transient( $lock_key ) ) {
				$this->wallregi_schedule_chunk( $job_id );
				return;
			}
			set_transient( $lock_key, 1, 300 );

			$key = 'wallregi_pro_bulk_job_' . $job_id;
			$job = get_option( $key, null );
			if ( ! is_array( $job ) || empty( $job['file'] ) || ! is_readable( $job['file'] ) ) {
				delete_transient( $lock_key );
				if ( is_array( $job ) ) {
					$job['status']       = 'failed';
					$job['last_message'] = __( 'Job file is missing or unreadable.', 'wallet-ready-gift-cards-for-woocommerce' );
					update_option( $key, $job, false );
					$this->wallregi_clear_last_job_meta_if_match( $job_id, $job );
				}
				return;
			}

			if ( in_array( (string) ( $job['status'] ?? '' ), [ 'completed', 'failed' ], true ) ) {
				delete_transient( $lock_key );
				return;
			}

			$job['status'] = 'running';
			update_option( $key, $job, false );

			$file            = (string) $job['file'];
			$next_line_index = (int) ( $job['next_line_index'] ?? 0 );
			$owner           = (int) ( $job['queued_by'] ?? 0 );
			$total           = (int) ( $job['total'] ?? 0 );

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
			$h = fopen( $file, 'rb' );
			if ( ! $h ) {
				$job['status']       = 'failed';
				$job['last_message'] = __( 'Could not read job file.', 'wallet-ready-gift-cards-for-woocommerce' );
				update_option( $key, $job, false );
				$this->wallregi_clear_last_job_meta_if_match( $job_id, $job );
				delete_transient( $lock_key );

				return;
			}

			for ( $skip = 0; $skip < $next_line_index; $skip++ ) {
				if ( false === fgets( $h ) ) {
					break;
				}
			}

			$lines_read = 0;
			while ( $lines_read < self::CHUNK_ROWS ) {
				$line = fgets( $h );
				if ( false === $line ) {
					break;
				}
				++$lines_read;

				$line = trim( (string) $line );
				if ( '' === $line ) {
					continue;
				}

				$row = json_decode( $line, true );
				if ( ! is_array( $row ) ) {
					++$job['failed'];
					$this->wallregi_job_push_log(
						$job,
						[
							'line'    => $next_line_index + $lines_read,
							'message' => __( 'Invalid JSON line.', 'wallet-ready-gift-cards-for-woocommerce' ),
						]
					);
					continue;
				}

				$insert_args = [
					'auto_generate'         => ! empty( $row['auto_generate'] ),
					'giftcard_number'       => (string) ( $row['giftcard_number'] ?? '' ),
					'initial_amount'        => (int) ( $row['initial_amount'] ?? 0 ),
					'current_amount'        => (int) ( $row['current_amount'] ?? 0 ),
					'expiry_period'         => (string) ( $row['expiry_period'] ?? '' ),
					'receipent_name'        => (string) ( $row['receipent_name'] ?? '' ),
					'receipent_email'       => (string) ( $row['receipent_email'] ?? '' ),
					'sender_name'           => (string) ( $row['sender_name'] ?? '' ),
					'message'               => (string) ( $row['message'] ?? '' ),
					'order_id'              => 0,
					'item_id'               => 0,
					'product_id'            => (int) ( $row['product_id'] ?? 0 ),
					'giftcard_image'        => (string) ( $row['giftcard_image'] ?? '' ),
					'preferred_date_time'   => (string) ( $row['preferred_date_time'] ?? '' ),
					'created_by_override'   => $owner > 0 ? $owner : 0,
				];

				/**
				 * Filter or short-circuit a bulk-import row before insert.
				 *
				 * @param array    $insert_args Arguments for `wallregi_insert_manual_giftcard`.
				 * @param array    $row       Original JSONL row.
				 * @param string   $job_id    Job ID.
				 * @return array|\WP_Error Return modified `$insert_args`, or WP_Error to skip as failed with that message.
				 */
				$filtered = apply_filters( 'wallregi_bulk_import_row_before_insert', $insert_args, $row, $job_id );
				$filtered = apply_filters( 'wallregi_pro_bulk_import_row_before_insert', $filtered, $row, $job_id );
				if ( is_wp_error( $filtered ) ) {
					++$job['failed'];
					$this->wallregi_job_push_log( $job, [ 'line' => (int) ( $row['line'] ?? 0 ), 'message' => $filtered->get_error_message() ] );
					continue;
				}
				if ( is_array( $filtered ) ) {
					$insert_args = $filtered;
				}

				$res = wallregi_insert_manual_giftcard(
					array_merge(
						$insert_args,
						[ 'fire_created_hooks' => false ]
					)
				);
				if ( is_wp_error( $res ) ) {
					if ( 'wallregi_giftcard_duplicate' === $res->get_error_code() ) {
						++$job['skipped_duplicate'];
						$this->wallregi_job_push_log(
							$job,
							[
								'line'    => (int) ( $row['line'] ?? 0 ),
								'message' => __( 'Skipped: code already exists.', 'wallet-ready-gift-cards-for-woocommerce' ),
							]
						);
					} else {
						++$job['failed'];
						$this->wallregi_job_push_log( $job, [ 'line' => (int) ( $row['line'] ?? 0 ), 'message' => $res->get_error_message() ] );
					}
				} else {
					++$job['inserted'];
					$this->wallregi_schedule_epass_for_imported_giftcard( (int) $res, (int) $job['inserted'] );
					do_action( 'wallregi_bulk_giftcard_imported', (int) $res, $row, $job_id );
					do_action( 'wallregi_pro_bulk_giftcard_imported', (int) $res, $row, $job_id );
				}
			}

			fclose( $h );

			$job['next_line_index'] = $next_line_index + $lines_read;
			$early_stop             = '';
			if ( 0 === $lines_read && $job['next_line_index'] < $total ) {
				$job['next_line_index'] = $total;
				$early_stop             = ' ' . __( '(Stopped: import file ended before all expected rows.)', 'wallet-ready-gift-cards-for-woocommerce' );
			}

			$job['last_message'] = sprintf(
				/* translators: 1: inserted count, 2: skipped, 3: failed */
				__( 'Progress: %1$d created, %2$d skipped (duplicate), %3$d failed.', 'wallet-ready-gift-cards-for-woocommerce' ),
				(int) $job['inserted'],
				(int) $job['skipped_duplicate'],
				(int) $job['failed']
			) . $early_stop;
			if ( $job['next_line_index'] < $total ) {
				update_option( $key, $job, false );
				$this->wallregi_schedule_chunk( $job_id );
			} else {
				$job['status'] = 'completed';
				update_option( $key, $job, false );
				$this->wallregi_clear_last_job_meta_if_match( $job_id, $job );
				if ( is_string( $file ) && file_exists( $file ) ) {
					wp_delete_file( $file );
				}
			}

			delete_transient( $lock_key );
		}

		private function wallregi_clear_last_job_meta_if_match( $job_id, array $job ) {
			$qb = (int) ( $job['queued_by'] ?? 0 );
			if ( $qb <= 0 ) {
				return;
			}
			$last = get_user_meta( $qb, 'wallregi_pro_bulk_last_job_id', true );
			if ( (string) $last === (string) $job_id ) {
				delete_user_meta( $qb, 'wallregi_pro_bulk_last_job_id' );
			}
		}

		/**
		 * @param array<string, mixed> $job Job option (by ref).
		 * @param array{line?: int, message: string} $entry Log entry.
		 */
		private function wallregi_job_push_log( array &$job, array $entry ) {
			if ( ! isset( $job['log'] ) || ! is_array( $job['log'] ) ) {
				$job['log'] = [];
			}
			$job['log'][] = $entry;
			if ( count( $job['log'] ) > 40 ) {
				$job['log'] = array_slice( $job['log'], -40 );
			}
		}
	}
}
