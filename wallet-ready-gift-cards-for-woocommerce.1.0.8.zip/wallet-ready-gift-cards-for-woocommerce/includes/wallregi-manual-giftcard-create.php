<?php
/**
 * Shared manual gift card creation (admin / bulk import).
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether a manual gift card code matches storefront/admin rules (5–19 chars, letter + digit, A–Z 0-9 _ -).
 *
 * @param string $code Raw code (will be normalized: spaces to hyphens, uppercased).
 * @return bool
 */
function wallregi_manual_giftcard_code_format_valid( $code ) {
	$valid = wallregi_giftcard_code_format_valid( $code );

	return (bool) apply_filters( 'wallregi_manual_giftcard_code_format_valid', $valid, $code );
}

/**
 * Allowed relative expiry strings (same as storefront product presets for manual UI).
 *
 * @return array<int, string>
 */
function wallregi_manual_giftcard_allowed_expiry_periods() {
	return array( '1 month', '3 months', '6 months', '1 year' );
}

/**
 * Resolve admin / bulk `expiry_period` field: either a relative period or a fixed calendar date (Y-m-d).
 *
 * Store `expiry_period` as the canonical period string, or the literal `custom` when a fixed date was chosen
 * (so DateTime::modify("+…") fallbacks are not used with arbitrary strings).
 *
 * @param string $input Raw value from POST or CSV (e.g. "1 year" or "2026-12-31").
 * @return array{expiry_date: string, expiry_period: string}|\WP_Error expiry_date is Y-m-d.
 */
function wallregi_resolve_manual_giftcard_expiry_input( $input ) {
	$raw = trim( (string) $input );
	if ( '' === $raw ) {
		return new WP_Error(
			'wallregi_giftcard_expiry_required',
			__( 'Expiry date or period is required.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$allowed = wallregi_manual_giftcard_allowed_expiry_periods();
	foreach ( $allowed as $p ) {
		if ( 0 === strcasecmp( $raw, $p ) ) {
			$raw = $p;
			break;
		}
	}

	if ( in_array( $raw, $allowed, true ) ) {
		// phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date -- Match legacy storefront + admin manual calculation.
		$current_date       = strtotime( date( 'd-m-Y' ) );
		$wallregi_expiry_date = date( 'Y-m-d', strtotime( $raw, $current_date ) );

		return array(
			'expiry_date'   => $wallregi_expiry_date,
			'expiry_period' => $raw,
		);
	}

	if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $raw, $m ) ) {
		$y  = (int) $m[1];
		$mo = (int) $m[2];
		$d  = (int) $m[3];
		if ( checkdate( $mo, $d, $y ) ) {
			return array(
				'expiry_date'   => sprintf( '%04d-%02d-%02d', $y, $mo, $d ),
				'expiry_period' => 'custom',
			);
		}
	}

	$ts = strtotime( $raw );
	if ( false === $ts ) {
		return new WP_Error(
			'wallregi_giftcard_expiry_invalid',
			__( 'Enter a valid expiry date (YYYY-MM-DD), or a period: 1 month, 3 months, 6 months, 1 year.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$wallregi_expiry_date = function_exists( 'wp_date' )
		? wp_date( 'Y-m-d', $ts )
		: date_i18n( 'Y-m-d', $ts );

	return array(
		'expiry_date'   => $wallregi_expiry_date,
		'expiry_period' => 'custom',
	);
}

/**
 * Insert a manually issued gift card and its initial transaction row.
 *
 * Mirrors the admin "create gift card" flow (AJAX) so bulk import and UI stay consistent.
 *
 * @param array $args {
 *     @type bool   $auto_generate       When true (create flow), a new code is generated; `giftcard_number` is ignored.
 *     @type string $giftcard_number     Required when `auto_generate` is false. Uppercased; spaces become hyphens.
 *     @type string $prefix              Optional prefix for generator (same as `wallregi_generate_manual_giftcard_coupon_code`).
 *     @type string $suffix              Optional suffix for generator.
 *     @type int    $initial_amount      Initial balance (integer, >= 0).
 *     @type int    $current_amount      Current balance (integer, >= 0).
 *     @type string $expiry_period       Relative: 1 month, 3 months, 6 months, 1 year; or a fixed date (e.g. Y-m-d from admin date picker). Stored as `custom` when fixed.
 *     @type string $preferred_date_time Preferred send datetime; empty or invalid uses {@see wallregi_normalize_giftcard_preferred_datetime()}.
 *     @type string $receipent_name      Recipient display name (DB column spelling).
 *     @type string $receipent_email     Recipient email.
 *     @type string $receipent_phone     Recipient phone (SMS / both).
 *     @type string $delivery_channel    email|sms|both|none.
 *     @type string $sender_name         Sender display name.
 *     @type string $message             Greeting / message body.
 *     @type int    $order_id            Optional order link (default 0).
 *     @type int    $item_id             Optional order item link (default 0).
 *     @type int    $product_id          Optional wxgiftcard product ID (default 0); validated when > 0.
 *     @type string $giftcard_image      Optional image URL for PDF/email.
 *     @type int    $created_by_override Optional user ID for `created_by` (e.g. bulk jobs via cron where no user is loaded).
 *     @type bool   $fire_created_hooks  When true (default), fires `wallregi_giftcard_created_by_admin`. Set false for bulk/async callers that issue passes separately (avoids many sync HTTP calls in one request).
 * }
 * @return int|\WP_Error New gift card row ID, or WP_Error.
 */
function wallregi_insert_manual_giftcard( array $args ) {
	global $wpdb;

	$defaults = array(
		'created_by_override'   => 0,
		'auto_generate'         => false,
		'giftcard_number'       => '',
		'prefix'                => '',
		'suffix'                => '',
		'initial_amount'        => 0,
		'current_amount'        => 0,
		'expiry_period'         => '1 year',
		'preferred_date_time'   => '',
		'receipent_name'        => '',
		'receipent_email'       => '',
		'receipent_phone'       => '',
		'delivery_channel'      => WALLREGI_DELIVERY_CHANNEL_EMAIL,
		'sender_name'           => '',
		'message'               => '',
		'order_id'              => 0,
		'item_id'               => 0,
		'product_id'            => 0,
		'giftcard_image'        => '',
		'fire_created_hooks'    => true,
	);
	$args = wp_parse_args( $args, $defaults );

	$created_by = get_current_user_id();
	if ( ! empty( $args['created_by_override'] ) ) {
		$created_by = (int) $args['created_by_override'];
	}

	$auto_generate   = ! empty( $args['auto_generate'] );
	$giftcard_number = is_string( $args['giftcard_number'] ) ? trim( $args['giftcard_number'] ) : '';
	$giftcard_number = strtoupper( str_replace( ' ', '-', $giftcard_number ) );

	if ( $auto_generate ) {
		$attempts = 0;
		do {
			$giftcard_number = wallregi_generate_manual_giftcard_coupon_code(
				sanitize_text_field( (string) $args['prefix'] ),
				sanitize_text_field( (string) $args['suffix'] )
			);
			if ( ! wallregi_get_giftcard_by_number( $giftcard_number ) ) {
				break;
			}
			++$attempts;
		} while ( $attempts < 15 );

		if ( wallregi_get_giftcard_by_number( $giftcard_number ) ) {
			return new WP_Error(
				'wallregi_giftcard_code_collision',
				__( 'Could not generate a unique gift card code. Please try again.', 'wallet-ready-gift-cards-for-woocommerce' )
			);
		}
	} else {
		if ( '' === $giftcard_number ) {
			return new WP_Error(
				'wallregi_giftcard_code_required',
				__( 'Gift card number is required unless auto-generate is enabled.', 'wallet-ready-gift-cards-for-woocommerce' )
			);
		}
		if ( ! wallregi_manual_giftcard_code_format_valid( $giftcard_number ) ) {
			return new WP_Error(
				'wallregi_giftcard_code_invalid',
				wallregi_giftcard_code_format_error_message()
			);
		}
		if ( wallregi_get_giftcard_by_number( $giftcard_number ) ) {
			return new WP_Error(
				'wallregi_giftcard_duplicate',
				sprintf(
					/* translators: %s: gift card code */
					__( 'Gift card number "%s" already exists.', 'wallet-ready-gift-cards-for-woocommerce' ),
					$giftcard_number
				)
			);
		}
	}

	$initial_amount = (int) $args['initial_amount'];
	$current_amount = (int) $args['current_amount'];
	if ( $initial_amount < 0 || $current_amount < 0 ) {
		return new WP_Error(
			'wallregi_giftcard_amount',
			__( 'Initial amount and current balance must not be negative.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$expiry_resolved = wallregi_resolve_manual_giftcard_expiry_input( (string) $args['expiry_period'] );
	if ( is_wp_error( $expiry_resolved ) ) {
		return $expiry_resolved;
	}
	$wallregi_expiry_date = $expiry_resolved['expiry_date'];
	$expiry_period        = $expiry_resolved['expiry_period'];

	$receipent_name  = sanitize_text_field( (string) $args['receipent_name'] );
	$receipent_email = sanitize_email( (string) $args['receipent_email'] );
	$receipent_phone = function_exists( 'wallregi_sanitize_giftcard_phone' )
		? wallregi_sanitize_giftcard_phone( $args['receipent_phone'] ?? '' )
		: '';
	$delivery_channel = function_exists( 'wallregi_sanitize_delivery_channel' )
		? wallregi_sanitize_delivery_channel( $args['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL )
		: WALLREGI_DELIVERY_CHANNEL_EMAIL;
	$sender_name     = sanitize_text_field( (string) $args['sender_name'] );
	$message         = sanitize_textarea_field( (string) $args['message'] );

	if ( '' === $receipent_name ) {
		return new WP_Error( 'wallregi_receiver_name', __( 'Recipient name is required.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$needs_email = in_array( $delivery_channel, array( WALLREGI_DELIVERY_CHANNEL_EMAIL, WALLREGI_DELIVERY_CHANNEL_BOTH ), true );
	if ( $needs_email && ( '' === $receipent_email || ! is_email( $receipent_email ) ) ) {
		return new WP_Error( 'wallregi_receiver_email', __( 'A valid recipient email is required for the selected delivery method.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$needs_sms_phone = in_array( $delivery_channel, array( WALLREGI_DELIVERY_CHANNEL_SMS, WALLREGI_DELIVERY_CHANNEL_BOTH ), true );
	if ( $needs_sms_phone && function_exists( 'wallregi_validate_giftcard_phone' ) ) {
		$validated_phone = wallregi_validate_giftcard_phone( $receipent_phone, true );
		if ( is_wp_error( $validated_phone ) ) {
			return $validated_phone;
		}
		$receipent_phone = $validated_phone;
	} elseif ( ! $needs_sms_phone ) {
		$receipent_phone = '';
	}

	if ( '' === $sender_name ) {
		return new WP_Error( 'wallregi_sender_name', __( 'Sender name is required.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$preferred_date_time = wallregi_normalize_giftcard_preferred_datetime( $args['preferred_date_time'] ?? '' );

	$product_id = (int) $args['product_id'];
	if ( $product_id > 0 ) {
		$product = wc_get_product( $product_id );
		if ( ! $product || 'wxgiftcard' !== $product->get_type() ) {
			return new WP_Error(
				'wallregi_product',
				__( 'Linked product must be a gift card (wxgiftcard) product.', 'wallet-ready-gift-cards-for-woocommerce' )
			);
		}
	}

	$wallregi_giftcard_table     = wallregi_giftcard_db_table_name();
	$wallregi_transaction_table = wallregi_transaction_db_table_name();

	$wallregi_giftcard_table_data = array(
		'order_id'            => (int) $args['order_id'],
		'item_id'             => (int) $args['item_id'],
		'product_id'          => $product_id,
		'initial_amount'      => $initial_amount,
		'current_amount'      => $current_amount,
		'giftcard_number'     => $giftcard_number,
		'expiry_date'         => $wallregi_expiry_date,
		'expiry_period'       => $expiry_period,
		'total_redeem'        => 0,
		'receipent_name'      => $receipent_name,
		'receipent_email'     => $receipent_email,
		'receipent_phone'     => $receipent_phone,
		'delivery_channel'    => $delivery_channel,
		'email_status'        => 0,
		'sms_status'          => 0,
		'sender_name'         => $sender_name,
		'message'             => $message,
		'send_date_time'      => current_time( 'mysql' ),
		'preferred_date_time' => $preferred_date_time,
		'giftcard_image'      => sanitize_text_field( (string) $args['giftcard_image'] ),
		'created_by'          => $created_by,
		'status'              => 'active',
	);

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Manual issuance insert.
	$inserted = $wpdb->insert( $wallregi_giftcard_table, $wallregi_giftcard_table_data );

	if ( false === $inserted ) {
		return new WP_Error( 'wallregi_db_insert', __( 'Failed to create gift card record.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$giftcard_id = (int) $wpdb->insert_id;

	$transaction_table_data = array(
		'giftcard_id' => $giftcard_id,
		'amount'      => $current_amount,
		'order_id'    => (string) (int) $args['order_id'],
		'created_by'  => $created_by,
		'reconciled'  => 0,
		'message'     => 'The initial gift card is ready for use.',
	);

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Initial ledger row.
	$inserted_transaction = $wpdb->insert( $wallregi_transaction_table, $transaction_table_data );

	if ( false === $inserted_transaction ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Roll back orphan gift card row.
		$wpdb->delete( $wallregi_giftcard_table, array( 'id' => $giftcard_id ), array( '%d' ) );

		return new WP_Error(
			'wallregi_transaction_insert',
			__( 'Failed to process Gift Card transaction.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	if ( ! empty( $args['fire_created_hooks'] ) ) {
		do_action( 'wallregi_giftcard_created_by_admin', $giftcard_id, 'create_giftcard' );
	}

	return $giftcard_id;
}
