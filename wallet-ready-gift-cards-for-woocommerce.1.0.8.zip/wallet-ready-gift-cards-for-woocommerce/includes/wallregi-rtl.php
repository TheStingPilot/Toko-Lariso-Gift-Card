<?php
/**
 * Right-to-left (RTL) stylesheet support for GiftRocket.
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register RTL hooks.
 */
function wallregi_register_rtl() {
	if ( ! is_admin() ) {
		add_filter( 'body_class', 'wallregi_rtl_body_class' );
		add_action( 'wp_enqueue_scripts', 'wallregi_enqueue_frontend_rtl_styles', 120 );
	}
	add_action( 'admin_enqueue_scripts', 'wallregi_enqueue_admin_rtl_styles', 120 );
	add_filter( 'wallregi_rtl_style_handles', 'wallregi_default_rtl_style_handles' );
}

/**
 * Add body class when the site locale is RTL.
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function wallregi_rtl_body_class( $classes ) {
	if ( is_rtl() ) {
		$classes[] = 'wallregi-rtl';
	}
	return $classes;
}

/**
 * Default style handles that receive WordPress RTL companion stylesheets.
 *
 * @param string[] $handles Style handles.
 * @return string[]
 */
function wallregi_default_rtl_style_handles( $handles ) {
	$handles = is_array( $handles ) ? $handles : [];

	$frontend = [
		'wallregi_frontend_style',
		'wallregi_responsive_css',
		'wallregi_blocks_integration',
	];

	$admin = [
		'wallregi_wp_admin_style',
		'wallregi_dashboard_option_style',
		'wallregi_features_style',
	];

	if ( is_admin() ) {
		return array_merge( $handles, $admin );
	}

	return array_merge( $handles, $frontend );
}

/**
 * Mark registered styles so WordPress loads the matching *-rtl.css file.
 *
 * @param string[]|null $handles Optional list of handles; uses filter when null.
 */
function wallregi_attach_rtl_styles( $handles = null ) {
	if ( ! is_rtl() ) {
		return;
	}

	if ( null === $handles ) {
		$handles = apply_filters( 'wallregi_rtl_style_handles', [] );
	}

	foreach ( array_unique( array_filter( (array) $handles ) ) as $handle ) {
		if ( wp_style_is( $handle, 'registered' ) || wp_style_is( $handle, 'enqueued' ) ) {
			wp_style_add_data( $handle, 'rtl', 'replace' );
		}
	}
}

/**
 * Attach RTL companions to frontend styles after they are enqueued.
 */
function wallregi_enqueue_frontend_rtl_styles() {
	wallregi_attach_rtl_styles();
}

/**
 * Attach RTL companions to admin styles after they are enqueued.
 */
function wallregi_enqueue_admin_rtl_styles() {
	wallregi_attach_rtl_styles();
}

/**
 * Pro plugin: register Pro-only RTL style handles on the shared filter.
 */
function wallregi_pro_register_rtl_handles() {
	add_filter(
		'wallregi_rtl_style_handles',
		static function ( $handles ) {
			$handles[] = 'wallregi_pro_image_upload_css';
			$handles[] = 'wallregi-pro-greeting-presets';
			return $handles;
		}
	);
}

/**
 * Whether GiftRocket should use RTL layout (UI, PDF, email).
 *
 * @return bool
 */
function wallregi_should_use_rtl_layout() {
	return (bool) apply_filters( 'wallregi_use_rtl_layout', is_rtl() );
}

/**
 * HTML dir/lang attributes for PDF and email wrappers.
 *
 * @return string Safe attribute fragment, e.g. dir="rtl" lang="ar".
 */
function wallregi_get_document_direction_attrs() {
	$dir  = wallregi_should_use_rtl_layout() ? 'rtl' : 'ltr';
	$lang = str_replace( '_', '-', determine_locale() );

	return sprintf(
		'dir="%s" lang="%s"',
		esc_attr( $dir ),
		esc_attr( $lang )
	);
}

/**
 * Wrap HTML email body for RTL locales when no dir attribute is present.
 *
 * @param string $body Email HTML.
 * @return string
 */
function wallregi_wrap_email_html_for_locale( $body ) {
	if ( ! wallregi_should_use_rtl_layout() ) {
		return $body;
	}

	if ( preg_match( '/\bdir\s*=\s*["\']?rtl/i', $body ) ) {
		return $body;
	}

	return '<div dir="rtl" style="direction:rtl;text-align:right;unicode-bidi:embed;">' . $body . '</div>';
}

/**
 * Additional CSS appended to gift card PDF output for RTL locales.
 *
 * @return string
 */
function wallregi_get_giftcard_pdf_rtl_css() {
	if ( ! wallregi_should_use_rtl_layout() ) {
		return '';
	}

	$css  = "html, body {\n";
	$css .= "    direction: rtl;\n";
	$css .= "    unicode-bidi: embed;\n";
	$css .= "}\n";
	$css .= ".pdf_extra_info,\n";
	$css .= ".pdf_preview_mgs,\n";
	$css .= ".pdf_footer {\n";
	$css .= "    text-align: right;\n";
	$css .= "}\n";
	$css .= ".pdf_heading,\n";
	$css .= ".pdf_price {\n";
	$css .= "    unicode-bidi: plaintext;\n";
	$css .= "}\n";

	return apply_filters( 'wallregi_giftcard_pdf_rtl_css', $css );
}
