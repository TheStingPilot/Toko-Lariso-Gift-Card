<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class WALLREGI_Initialize_Giftcard_Class.
 *
 * @since 1.0.0
 */
class WALLREGI_Initialize_Giftcard_Class {

    /**
     * Plugin file path.
     *
     * @var string
     */
    private string $wallregi_file;

    /**
     * Plugin version.
     *
     * @var string
     */
    private string $version;

    /**
     * Constructor.
     *
     * @param string $wallregi_file Plugin file path.
     * @param string $version Plugin version.
     */
    public function __construct(string $wallregi_file, string $version = '1.0.0') {
        $this->wallregi_file = $wallregi_file;
        $this->version = $version;

        $this->wallregi_define_constants();
        $this->wallregi_init_hooks();
        $this->wallregi_include_files();
    }

    /**
     * Define Constants.
     */
    private function wallregi_define_constants() {
        if ( ! defined( 'WALLREGI_VERSION' ) ) {
            define( 'WALLREGI_VERSION', $this->version );
        }
        if ( ! defined( 'WALLREGI_PLUGIN_DIR' ) ) {
            define( 'WALLREGI_PLUGIN_DIR', $this->wallregi_file );
        }
        if ( ! defined( 'WALLREGI_PLUGIN_URL' ) ) {
            define( 'WALLREGI_PLUGIN_URL', plugin_dir_url( WALLREGI_PLUGIN_FILE ) );
        }
    }

    /**
     * Initialize Hooks.
     */
    private function wallregi_init_hooks() {
        add_action('admin_notices', [$this, 'wallregi_admin_notices']);
    }

    /**
     * Include required files.
     */
    private function wallregi_include_files() {
        $include_files = [
            'includes/wallregi-checkout-receiver.php',
            'includes/wallregi-fraud-safeguards.php',
            'includes/class-wallregi-wallet-epass-public-api.php',
            'includes/class-wallregi-wallet-epass-global-settings.php',
            'includes/class-wallregi-wallet-epass-product-admin.php',
            'includes/class-wallregi-wallet-epass-issuance.php',
            'backend/backend.php',
            'frontend/frontend.php',
            'frontend/coupon-integration.php',
            'includes/wallregi-order-giftcard-redeem.php',
            'includes/class-wallregi-admin-order-giftcard.php',
            'frontend/blocks/class-wallregi-blocks-integration.php',
            'frontend/my-account-gift-cards.php',
            'includes/templates/giftcard-pdf.php',
            'includes/email-functions.php',
            'includes/class-giftcard-cron.php',
        ];

        foreach ($include_files as $wallregi_file) {
            $full_path = WALLREGI_PLUGIN_DIR . $wallregi_file;
            if (file_exists($full_path)) {
                include_once $full_path;
            }
        }

        if ( class_exists( 'WALLREGI_Wallet_Epass_Product_Admin' ) ) {
            new WALLREGI_Wallet_Epass_Product_Admin();
        }

        if ( class_exists( 'WALLREGI_Admin_Order_Giftcard' ) ) {
            new WALLREGI_Admin_Order_Giftcard();
        }

    }

    /**
     * Initialize WALLREGI plugin hooks.
     */
    public function wallregi_admin_notices() {
        add_action('wallregi_display_admin_notice', [$this, 'wallregi_apply_admin_notice']);
    }

    
    public function wallregi_apply_admin_notice() {
        ?>
        <div class="notice is-dismissible updated wallregi_giftcard_notice" style="display:none;">
            <p></p>
            <button type="button" class="notice-dismiss">
                <span class="dashicons dashicons-no-alt"></span>
                <span class="screen-reader-text">Dismiss this notice.</span>
            </button>
        </div>
        <?php
    }
}


