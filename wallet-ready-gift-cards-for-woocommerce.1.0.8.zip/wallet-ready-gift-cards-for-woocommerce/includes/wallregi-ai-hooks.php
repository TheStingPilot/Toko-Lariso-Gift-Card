<?php
/**
 * AI integration hooks (free plugin).
 *
 * Pro registers providers and maps saved settings onto these filters.
 * Extensions can force-disable AI or gate storefront usage without editing Pro.
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether site-wide AI features are enabled (admin + optional storefront).
 *
 * @return bool
 */
function wallregi_ai_is_enabled() {
	return (bool) apply_filters( 'wallregi_ai_enabled', false );
}

/**
 * Whether buyer-facing AI (greeting suggest/improve) is enabled.
 *
 * @return bool
 */
function wallregi_ai_storefront_is_enabled() {
	if ( ! wallregi_ai_is_enabled() ) {
		return false;
	}

	return (bool) apply_filters( 'wallregi_ai_storefront_enabled', false );
}

/**
 * Whether buyer-facing AI translation is enabled.
 *
 * @return bool
 */
function wallregi_ai_translate_storefront_is_enabled() {
	if ( ! wallregi_ai_is_enabled() ) {
		return false;
	}

	return (bool) apply_filters( 'wallregi_ai_translate_storefront_enabled', false );
}
