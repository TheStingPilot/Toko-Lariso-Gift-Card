<?php
/**
 * Issue ePasscard wallet passes when gift cards are created; expose “Add to Wallet” links.
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bootstrap hooks.
 */
function wallregi_wallet_epass_issuance_init() {
	add_action( 'wallregi_giftcard_created', 'wallregi_epass_try_issue_pass_for_giftcard', 15, 2 );
	add_action( 'wallregi_giftcard_created_by_admin', 'wallregi_epass_try_issue_pass_for_giftcard', 15, 2 );
	/** Async / bulk: Action Scheduler or WP-Cron calls this with one gift card id. */
	add_action( 'wallregi_epass_deferred_issue_pass', 'wallregi_epass_try_issue_pass_for_giftcard', 10, 1 );
	add_action( 'wallregi_epass_generate_button', 'wallregi_epass_render_dashboard_wallet_button', 10, 2 );
	add_action( 'wallregi_giftcard_updated_by_admin', 'wallregi_epass_on_giftcard_updated_by_admin', 25, 2 );
	add_action( 'wallregi_giftcard_balance_changed', 'wallregi_epass_on_giftcard_balance_changed', 25, 2 );
}

/**
 * Dashboard: show “Add to Google / Apple Wallet” when a pass link exists.
 *
 * @param string $pass_link Pass URL from epass_data.
 * @param int    $giftcard_id Gift card row ID.
 */
function wallregi_epass_render_dashboard_wallet_button( $pass_link, $giftcard_id ) {
	$pass_link = is_string( $pass_link ) ? trim( $pass_link ) : '';
	if ( '' === $pass_link ) {
		return;
	}
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	wallregi_epass_print_wallet_anchor( $pass_link, [ 'class' => 'wallregi-epass-wallet-link wallregi-epass-wallet-link--dashboard' ] );
}

/**
 * URL for the frontend “Add to Wallet” badge image, or empty if missing.
 *
 * @return string
 */
function wallregi_epass_get_add_to_wallet_badge_url() {
	if ( ! defined( 'WALLREGI_PLUGIN_DIR' ) || ! defined( 'WALLREGI_PLUGIN_URL' ) ) {
		return '';
	}

	$relative = 'assets/imgs/add-to-wallet.png';
	$path     = WALLREGI_PLUGIN_DIR . $relative;

	if ( ! is_readable( $path ) ) {
		return '';
	}

	return WALLREGI_PLUGIN_URL . $relative;
}

/**
 * Print wallet CTA anchor (shared markup).
 *
 * @param string               $pass_link HTTPS URL from ePasscard.
 * @param array<string, mixed> $attrs     Optional HTML attributes (href/target/rel/class merged).
 */
function wallregi_epass_print_wallet_anchor( $pass_link, array $attrs = [] ) {
	$pass_link = esc_url( $pass_link );
	if ( '' === $pass_link ) {
		return;
	}
	$defaults = [
		'href'   => $pass_link,
		'target' => '_blank',
		'rel'    => 'noopener noreferrer',
		'class'  => 'wallregi-epass-wallet-link',
	];
	$attr = array_merge( $defaults, $attrs );

	$use_badge_image = ! is_admin();
	$badge_url       = $use_badge_image ? wallregi_epass_get_add_to_wallet_badge_url() : '';
	if ( '' !== $badge_url ) {
		$attr['class'] = trim( (string) ( $attr['class'] ?? '' ) . ' wallregi-epass-wallet-link--image' );
	}

	$title = esc_attr__( 'Add to Google / Apple Wallet', 'wallet-ready-gift-cards-for-woocommerce' );

	$html = '<a';
	foreach ( $attr as $k => $v ) {
		$name = strtolower( (string) $k );
		if ( 'href' === $name ) {
			$html .= ' href="' . esc_url( (string) $v ) . '"';
		} else {
			$html .= ' ' . esc_attr( (string) $k ) . '="' . esc_attr( (string) $v ) . '"';
		}
	}
	$html .= ' title="' . $title . '">';

	if ( '' !== $badge_url ) {
		$html .= '<img src="' . esc_url( $badge_url ) . '" alt="' . $title . '" class="wallregi-epass-wallet-badge" width="120" height="40" loading="lazy" decoding="async" />';
	} else {
		$html .= '<span class="dashicons dashicons-smartphone"></span>';
	}

	$html .= '</a>';
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Attributes escaped above.
	echo $html;
}

/**
 * Get wallet pass URL for a WooCommerce order line item (gift card row).
 *
 * @param int $order_item_id Order item ID.
 * @return string
 */
function wallregi_epass_get_pass_link_for_order_item( $order_item_id ) {
	global $wpdb;

	$order_item_id = absint( $order_item_id );
	if ( $order_item_id <= 0 ) {
		return '';
	}

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Single-row lookup.
	$epass_json = $wpdb->get_var(
		$wpdb->prepare(
			'SELECT `epass_data` FROM %i WHERE `item_id` = %d LIMIT 1',
			wallregi_giftcard_db_table_name(),
			$order_item_id
		)
	);

	if ( ! is_string( $epass_json ) || '' === $epass_json ) {
		return '';
	}

	$data = json_decode( $epass_json, true );
	if ( ! is_array( $data ) || empty( $data['passLink'] ) ) {
		return '';
	}

	return is_string( $data['passLink'] ) ? trim( $data['passLink'] ) : '';
}

/**
 * Raw gift card value for a mapping slug (DB row as associative array).
 *
 * @param string               $slug Mapping slug (e.g. receiver_name).
 * @param array<string, mixed> $row  wx_gift_cards row.
 * @return string
 */
function wallregi_epass_gift_value_for_slug( $slug, array $row ) {
	switch ( (string) $slug ) {
		case 'receiver_name':
			return isset( $row['receipent_name'] ) ? (string) $row['receipent_name'] : '';
		case 'receiver_email':
			return isset( $row['receipent_email'] ) ? (string) $row['receipent_email'] : '';
		case 'receiver_message':
			return isset( $row['message'] ) ? (string) $row['message'] : '';
		case 'sender_name':
			return isset( $row['sender_name'] ) ? (string) $row['sender_name'] : '';
		case 'giftcard_number':
			return isset( $row['giftcard_number'] ) ? (string) $row['giftcard_number'] : '';
		case 'giftcard_image':
			if ( ! function_exists( 'wallregi_wallet_resolve_epass_stripe_image_url' ) ) {
				$gf = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-global-settings.php';
				if ( file_exists( $gf ) ) {
					require_once $gf;
				}
			}
			return function_exists( 'wallregi_wallet_resolve_epass_stripe_image_url' )
				? (string) wallregi_wallet_resolve_epass_stripe_image_url( $row )
				: '';
		case 'initial_balance':
			return isset( $row['initial_amount'] ) ? (string) $row['initial_amount'] : '';
		case 'current_balance':
			return isset( $row['current_amount'] ) ? (string) $row['current_amount'] : '';
		case 'used_balance':
			$init = isset( $row['initial_amount'] ) ? (float) $row['initial_amount'] : 0;
			$cur  = isset( $row['current_amount'] ) ? (float) $row['current_amount'] : 0;
			$used = max( 0, (int) round( $init - $cur ) );
			return (string) $used;
		case 'expiry_date':
			return isset( $row['expiry_date'] ) ? (string) $row['expiry_date'] : '';
		default:
			/**
			 * Filter raw field value for an ePass mapping slug not handled by core.
			 *
			 * @param string               $value Empty string default.
			 * @param string               $slug  Mapping slug.
			 * @param array<string, mixed> $row   Gift card DB row.
			 */
			return (string) apply_filters( 'wallregi_epass_gift_value_for_slug', '', $slug, $row );
	}
}

/**
 * Format value for ePass additionalFieldsValue (dates as Y-m-d when required).
 *
 * @param string $slug        Mapping slug.
 * @param string $raw         Raw string from gift row.
 * @param string $field_type  Pass field type from template snapshot (optional).
 */
function wallregi_epass_format_mapped_value( $slug, $raw, $field_type = '' ) {
	$raw         = is_string( $raw ) ? trim( $raw ) : '';
	$field_type  = is_string( $field_type ) ? strtolower( trim( $field_type ) ) : '';
	$needs_ymd   = ( 'expiry_date' === (string) $slug )
		|| ( '' !== $field_type && ( false !== strpos( $field_type, 'date' ) ) );

	if ( $needs_ymd && '' !== $raw ) {
		$ts = strtotime( $raw );
		if ( false !== $ts ) {
			return wp_date( 'Y-m-d', $ts );
		}
	}

	return $raw;
}

/**
 * Build additionalFieldsValue payload from product config + gift card row.
 *
 * @param array<string, mixed> $config Product _wallregi_epass_pass_config.
 * @param array<string, mixed> $row    Gift card row.
 * @return array<int, array{uid: string, fieldValue: string}>
 */
function wallregi_epass_build_additional_fields_payload( array $config, array $row ) {
	$mapping     = isset( $config['mapping'] ) && is_array( $config['mapping'] ) ? $config['mapping'] : [];
	$pass_fields = isset( $config['pass_fields'] ) && is_array( $config['pass_fields'] ) ? $config['pass_fields'] : [];

	$by_uid = [];
	foreach ( $pass_fields as $pf ) {
		if ( ! is_array( $pf ) || empty( $pf['uid'] ) ) {
			continue;
		}
		$u = wallregi_wallet_epass_sanitize_template_uid( (string) $pf['uid'] );
		if ( false !== $u ) {
			$by_uid[ $u ] = $pf;
		}
	}

	$out = [];
	foreach ( $mapping as $slug => $field_uid ) {
		$field_uid = wallregi_wallet_epass_sanitize_template_uid( (string) $field_uid );
		if ( false === $field_uid ) {
			continue;
		}
		$ftype = isset( $by_uid[ $field_uid ]['field_type'] ) ? (string) $by_uid[ $field_uid ]['field_type'] : '';
		$raw   = wallregi_epass_gift_value_for_slug( (string) $slug, $row );
		$val   = wallregi_epass_format_mapped_value( (string) $slug, $raw, $ftype );
		$out[] = [
			'uid'        => $field_uid,
			'fieldValue' => (string) $val,
		];
	}

	/**
	 * Filter payload sent to create-single-pass.
	 *
	 * @param array<int, array{uid: string, fieldValue: string}> $out    Built rows.
	 * @param array<string, mixed>                                $config Product pass config.
	 * @param array<string, mixed>                                $row    Gift card DB row.
	 */
	return (array) apply_filters( 'wallregi_epass_additional_fields_value', $out, $config, $row );
}

/**
 * Map create-single-pass rows (fieldValue) to update-single-pass rows (field_value).
 *
 * @param array<int, array{uid: string, fieldValue: string}> $additional Rows from wallregi_epass_build_additional_fields_payload().
 * @return array<int, array{uid: string, field_value: string}>
 */
function wallregi_epass_additional_fields_to_update_fields( array $additional ) {
	$out = [];
	foreach ( $additional as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$uid = isset( $row['uid'] ) ? wallregi_wallet_epass_sanitize_template_uid( (string) $row['uid'] ) : false;
		if ( false === $uid ) {
			continue;
		}
		$val = isset( $row['fieldValue'] ) ? (string) $row['fieldValue'] : '';
		$out[] = [
			'uid'          => $uid,
			'field_value'  => $val,
		];
	}
	return $out;
}

/**
 * Push current gift card values to ePasscard for an existing pass (PUT update-single-pass).
 *
 * No-op when API is not configured, row missing, no passUid, or no mapped fields.
 * Logs failures; does not throw (safe from checkout / admin AJAX).
 *
 * @param int $giftcard_id wx_gift_cards.id.
 * @return void
 */
function wallregi_epass_sync_pass_for_giftcard_row( $giftcard_id ) {
	$giftcard_id = absint( $giftcard_id );
	if ( $giftcard_id <= 0 ) {
		return;
	}

	if ( function_exists( 'wallregi_wallet_should_use_epasscard' ) && ! wallregi_wallet_should_use_epasscard() ) {
		return;
	}

	if ( ! function_exists( 'wallregi_wallet_epass_is_api_configured' ) ) {
		$api = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-public-api.php';
		if ( file_exists( $api ) ) {
			require_once $api;
		}
	}
	if ( ! function_exists( 'wallregi_wallet_epass_send_update_single_pass_request' ) || ! wallregi_wallet_epass_is_api_configured() ) {
		return;
	}

	global $wpdb;

	$table = wallregi_giftcard_db_table_name();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Single gift card row.
	$row = $wpdb->get_row(
		$wpdb->prepare(
			'SELECT * FROM %i WHERE `id` = %d LIMIT 1',
			$table,
			$giftcard_id
		),
		ARRAY_A
	);

	if ( ! is_array( $row ) ) {
		return;
	}

	$existing = [];
	if ( ! empty( $row['epass_data'] ) && is_string( $row['epass_data'] ) ) {
		$decoded = json_decode( $row['epass_data'], true );
		if ( is_array( $decoded ) ) {
			$existing = $decoded;
		}
	}
	$pass_uid_raw = isset( $existing['passUid'] ) ? (string) $existing['passUid'] : '';
	$pass_uid     = wallregi_wallet_epass_sanitize_template_uid( $pass_uid_raw );
	if ( false === $pass_uid || '' === $pass_uid ) {
		return;
	}

	$product_id = isset( $row['product_id'] ) ? absint( $row['product_id'] ) : 0;

	if ( ! function_exists( 'wallregi_wallet_get_effective_epass_pass_config' ) ) {
		$gf = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-global-settings.php';
		if ( file_exists( $gf ) ) {
			require_once $gf;
		}
	}

	// product_id may be 0 (manual card with no linked product); effective config still uses global wallet template.
	$config = wallregi_wallet_get_effective_epass_pass_config( $product_id );
	if ( empty( $config['template_uid'] ) ) {
		return;
	}

	$additional = wallregi_epass_build_additional_fields_payload( $config, $row );
	if ( empty( $additional ) ) {
		return;
	}

	$fields = wallregi_epass_additional_fields_to_update_fields( $additional );
	if ( empty( $fields ) ) {
		return;
	}

	$body = [
		'passUid' => $pass_uid,
		'fields'  => $fields,
	];

	/**
	 * Filter JSON body for update-single-pass before the HTTP request.
	 *
	 * @param array<string, mixed>  $body         Keys passUid, fields (field_value per row).
	 * @param int                   $giftcard_id  wx_gift_cards.id.
	 * @param array<string, mixed> $row          Gift card row.
	 * @param array<string, mixed> $config       Effective pass config.
	 */
	$body = (array) apply_filters( 'wallregi_wallet_epass_update_single_pass_body', $body, $giftcard_id, $row, $config );

	$result = wallregi_wallet_epass_send_update_single_pass_request( $body );
	if ( is_wp_error( $result ) ) {
		/**
		 * ePass update-single-pass failed (HTTP, auth, or API status).
		 *
		 * @param int                   $giftcard_id wx_gift_cards.id.
		 * @param WP_Error              $error       Error object.
		 * @param array<string, mixed>  $context     passUid, fields_count.
		 */
		do_action(
			'wallregi_epass_pass_update_failed',
			$giftcard_id,
			$result,
			[
				'passUid'      => $pass_uid,
				'fields_count' => count( $fields ),
			]
		);
		return;
	}

	do_action( 'wallregi_epass_pass_updated', $giftcard_id, $result, $row );
}

/**
 * Sync ePass after admin manual gift card save.
 *
 * @param int    $giftcard_id wx_gift_cards.id (first argument from wallregi_giftcard_updated_by_admin).
 * @param string $_identifier Optional identifier from admin save.
 */
function wallregi_epass_on_giftcard_updated_by_admin( $giftcard_id, $_identifier = '' ) {
	wallregi_epass_sync_pass_for_giftcard_row( $giftcard_id );
}

/**
 * After balance changes at checkout or refund (or Pro extensions).
 *
 * @param int                  $giftcard_id wx_gift_cards.id.
 * @param array<string, mixed> $_context     Optional: e.g. order_id, source.
 */
function wallregi_epass_on_giftcard_balance_changed( $giftcard_id, $_context = [] ) {
	wallregi_epass_sync_pass_for_giftcard_row( $giftcard_id );
}

/**
 * Issue pass and persist epass_data (+ optional order line item meta).
 *
 * @param int                                                                 $giftcard_id wx_gift_cards.id.
 * @param array<string, mixed>|string|null                                    $context      Optional. When an array with `allow_empty_additional` true, create-single-pass is still called if the mapped payload is empty (admin “generate pass” and similar). Hook second arguments (e.g. string identifiers) are ignored.
 * @return true|\WP_Error|false True when a new pass was created and saved; WP_Error when the API call failed; false for any other no-op.
 */
function wallregi_epass_try_issue_pass_for_giftcard( $giftcard_id, $context = null ) {
	$giftcard_id = absint( $giftcard_id );
	if ( $giftcard_id <= 0 ) {
		return false;
	}

	if ( function_exists( 'wallregi_wallet_should_use_epasscard' ) && ! wallregi_wallet_should_use_epasscard() ) {
		return false;
	}

	if ( ! function_exists( 'wallregi_wallet_epass_create_single_pass' ) ) {
		$api = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-public-api.php';
		if ( file_exists( $api ) ) {
			require_once $api;
		}
	}
	if ( ! function_exists( 'wallregi_wallet_epass_create_single_pass' ) || ! wallregi_wallet_epass_is_api_configured() ) {
		return false;
	}

	global $wpdb;

	$table = wallregi_giftcard_db_table_name();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Single gift card row.
	$row = $wpdb->get_row(
		$wpdb->prepare(
			'SELECT * FROM %i WHERE `id` = %d LIMIT 1',
			$table,
			$giftcard_id
		),
		ARRAY_A
	);

	if ( ! is_array( $row ) ) {
		return false;
	}

	$existing = [];
	if ( ! empty( $row['epass_data'] ) && is_string( $row['epass_data'] ) ) {
		$decoded = json_decode( $row['epass_data'], true );
		if ( is_array( $decoded ) ) {
			$existing = $decoded;
		}
	}
	if ( ! empty( $existing['passUid'] ) ) {
		return false;
	}

	$product_id = isset( $row['product_id'] ) ? absint( $row['product_id'] ) : 0;

	if ( ! function_exists( 'wallregi_wallet_get_effective_epass_pass_config' ) ) {
		$gf = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-global-settings.php';
		if ( file_exists( $gf ) ) {
			require_once $gf;
		}
	}

	// product_id may be 0 (manual card with no linked product); effective config still uses global wallet template.
	$config = wallregi_wallet_get_effective_epass_pass_config( $product_id );
	if ( empty( $config['template_uid'] ) ) {
		return false;
	}

	$template_uid = wallregi_wallet_epass_sanitize_template_uid( (string) $config['template_uid'] );
	if ( false === $template_uid ) {
		return false;
	}

	$additional = wallregi_epass_build_additional_fields_payload( $config, $row );
	$ctx        = is_array( $context ) ? $context : [];
	$allow_empty_additional = ! empty( $ctx['allow_empty_additional'] );
	if ( empty( $additional ) && ! $allow_empty_additional ) {
		return false;
	}

	$result = wallregi_wallet_epass_create_single_pass( $template_uid, $additional );
	if ( is_wp_error( $result ) ) {
		/**
		 * Log or handle failed pass issuance.
		 *
		 * @param int       $giftcard_id Gift card row ID.
		 * @param WP_Error  $error       Error object.
		 * @param array     $context     Includes template_uid, additional field count.
		 */
		do_action(
			'wallregi_epass_pass_issue_failed',
			$giftcard_id,
			$result,
			[
				'template_uid' => $template_uid,
				'fields_count' => count( $additional ),
			]
		);
		return $result;
	}

	$payload = [
		'passUid'   => $result['passUid'],
		'passLink'  => $result['passLink'],
		'issued_at' => current_time( 'mysql', true ),
	];

	$json = wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Persist pass metadata.
	$wpdb->update(
		$table,
		[ 'epass_data' => $json ],
		[ 'id' => $giftcard_id ],
		[ '%s' ],
		[ '%d' ]
	);

	$order_id = isset( $row['order_id'] ) ? absint( $row['order_id'] ) : 0;
	$item_id  = isset( $row['item_id'] ) ? absint( $row['item_id'] ) : 0;
	if ( $order_id > 0 && $item_id > 0 && function_exists( 'wc_get_order' ) ) {
		$order = wc_get_order( $order_id );
		if ( $order ) {
			$item = $order->get_item( $item_id );
			if ( $item instanceof WC_Order_Item_Product ) {
				$item->update_meta_data( '_wallregi_epass_pass_uid', $result['passUid'] );
				$item->update_meta_data( '_wallregi_epass_pass_link', $result['passLink'] );
				$item->save();
			}
		}
	}

	do_action( 'wallregi_epass_pass_issued', $giftcard_id, $result, $row );

	return true;
}

wallregi_wallet_epass_issuance_init();
