<?php
/**
 * Pro feature gates (free plugin — checkout edit and related settings require licensed Pro).
 *
 * @package Wallet_Ready_Gift_Cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether GiftRocket Pro is installed and has a valid license.
 */
function wallregi_pro_is_licensed() {
	return function_exists( 'wallregi_pro_license_is_active' ) && wallregi_pro_license_is_active();
}

/**
 * Whether gift card editing on checkout is enabled for the current request.
 *
 * Default is false; Pro hooks wallregi_is_checkout_edit_enabled when licensed.
 *
 * @param array<string, mixed>|null $settings wallregi_settings (optional).
 */
function wallregi_checkout_giftcard_edit_is_enabled( $settings = null ) {
	if ( null === $settings ) {
		$settings = wp_parse_args(
			get_option( 'wallregi_settings', [] ),
			[
				'giftcard_edit_in_checkout' => 'no',
			]
		);
	} elseif ( ! is_array( $settings ) ) {
		$settings = [];
	}

	return (bool) apply_filters( 'wallregi_is_checkout_edit_enabled', false, $settings );
}

/**
 * Setting keys stored in wallregi_settings that require licensed Pro to take effect.
 *
 * @return string[]
 */
function wallregi_pro_only_settings_keys() {
	return (array) apply_filters(
		'wallregi_pro_only_settings_keys',
		[
			'giftcard_edit_in_checkout',
			'pro_max_giftcards_per_order',
			'pro_min_giftcard_redemption_total_order',
			'pro_max_giftcard_redemption_total_order',
			'pro_enable_buyer_upload_image',
			'pro_enable_clamav_scan',
			'pro_upload_max_size_mb',
			'pro_upload_daily_global_limit',
			'pro_upload_cleanup_age_hours',
			'pro_upload_allowed_types',
			'pro_upload_allowed_for',
		]
	);
}

/**
 * Clear Pro-only settings when Pro is not licensed (keeps cart edit and free features intact).
 *
 * @param array<string, mixed> $settings Settings about to be saved or loaded.
 * @return array<string, mixed>
 */
function wallregi_strip_pro_only_settings( array $settings ) {
	if ( wallregi_pro_is_licensed() ) {
		return $settings;
	}

	foreach ( wallregi_pro_only_settings_keys() as $key ) {
		unset( $settings[ $key ] );
	}

	$settings['giftcard_edit_in_checkout'] = 'no';

	return $settings;
}

/**
 * One-time normalize: turn off checkout edit if Pro is not licensed (stale DB from a prior Pro install).
 */
function wallregi_maybe_normalize_pro_settings_option() {
	if ( wallregi_pro_is_licensed() ) {
		return;
	}

	$settings = get_option( 'wallregi_settings', [] );
	if ( ! is_array( $settings ) ) {
		return;
	}

	if ( 'yes' !== ( $settings['giftcard_edit_in_checkout'] ?? 'no' ) ) {
		return;
	}

	$settings = wallregi_strip_pro_only_settings( $settings );
	update_option( 'wallregi_settings', $settings, false );
}
add_action( 'init', 'wallregi_maybe_normalize_pro_settings_option', 5 );
