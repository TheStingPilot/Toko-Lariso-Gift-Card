<?php
/**
 * Apply gift cards when creating or editing orders in wp-admin.
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WALLREGI_Admin_Order_Giftcard' ) ) {

	/**
	 * Admin order gift card UI and AJAX handlers.
	 */
	class WALLREGI_Admin_Order_Giftcard {

		private const AJAX_NONCE_ACTION = 'wallregi_admin_order_giftcard';

		public function __construct() {
			add_action( 'woocommerce_admin_order_totals_after_discount', array( $this, 'wallregi_render_order_totals_section' ), 15 );
			add_action( 'admin_enqueue_scripts', array( $this, 'wallregi_enqueue_admin_scripts' ) );
			add_action( 'wp_ajax_wallregi_admin_order_apply_giftcard', array( $this, 'wallregi_ajax_apply_giftcard' ) );
			add_action( 'wp_ajax_wallregi_admin_order_remove_giftcard', array( $this, 'wallregi_ajax_remove_giftcard' ) );
		}

		/**
		 * @return bool
		 */
		private function wallregi_is_order_edit_screen() {
			if ( ! is_admin() || ! function_exists( 'get_current_screen' ) ) {
				return false;
			}
			$screen = get_current_screen();
			if ( ! $screen ) {
				return false;
			}
			$ids = array( 'shop_order', 'woocommerce_page_wc-orders' );
			if ( ! in_array( $screen->id, $ids, true ) ) {
				return false;
			}
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return isset( $_GET['action'] ) && 'edit' === sanitize_text_field( wp_unslash( (string) $_GET['action'] ) )
				|| 'shop_order' === $screen->id;
		}

		/**
		 * @param int $order_id Order ID.
		 */
		public function wallregi_enqueue_admin_scripts( $hook_suffix ) {
			if ( ! $this->wallregi_is_order_edit_screen() ) {
				return;
			}

			wp_enqueue_script(
				'wallregi-admin-order-giftcard',
				WALLREGI_PLUGIN_URL . 'backend/assets/js/admin-order-giftcard.js',
				array( 'jquery' ),
				defined( 'WALLREGI_VERSION' ) ? WALLREGI_VERSION : '1.0.0',
				true
			);

			$buyer_ui = (bool) apply_filters( 'wallregi_is_buyer_giftcard_redeem_amount_ui_enabled', false );

			wp_localize_script(
				'wallregi-admin-order-giftcard',
				'wallregiAdminOrderGiftcard',
				array(
					'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
					'nonce'    => wp_create_nonce( self::AJAX_NONCE_ACTION ),
					'buyerUi'  => $buyer_ui,
					'strings'  => array(
						'apply'         => __( 'Apply gift card', 'wallet-ready-gift-cards-for-woocommerce' ),
						'remove'        => __( 'Remove', 'wallet-ready-gift-cards-for-woocommerce' ),
						'codeRequired'  => __( 'Enter a gift card code.', 'wallet-ready-gift-cards-for-woocommerce' ),
						'amountInvalid' => __( 'Enter a valid amount to redeem.', 'wallet-ready-gift-cards-for-woocommerce' ),
						'working'       => __( 'Please wait…', 'wallet-ready-gift-cards-for-woocommerce' ),
						'reloadHint'    => __( 'Gift card updated. The order totals will refresh.', 'wallet-ready-gift-cards-for-woocommerce' ),
					),
				)
			);

			wp_add_inline_style(
				'woocommerce_admin_styles',
				'.wallregi-admin-order-giftcard-wrap { margin: 8px 0; padding: 10px 12px; background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 4px; }'
				. '.wallregi-admin-order-giftcard-wrap .wallregi-admin-order-giftcard-form { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-top: 8px; }'
				. '.wallregi-admin-order-giftcard-wrap input[type="text"] { min-width: 160px; }'
				. '.wallregi-admin-order-giftcard-applied { margin: 0; padding: 0; list-style: none; }'
				. '.wallregi-admin-order-giftcard-applied li { display: flex; justify-content: space-between; align-items: center; padding: 4px 0; border-bottom: 1px solid #e0e0e0; }'
				. '.wallregi-admin-order-giftcard-applied li:last-child { border-bottom: 0; }'
				. '.wallregi-admin-order-giftcard-msg { margin-top: 8px; }'
			);
		}

		/**
		 * @param int $order_id Order ID.
		 */
		public function wallregi_render_order_totals_section( $order_id ) {
			$order = wc_get_order( $order_id );
			if ( ! $order instanceof WC_Order ) {
				return;
			}

			if ( ! current_user_can( 'edit_shop_orders' ) && ! current_user_can( 'manage_woocommerce' ) ) {
				return;
			}

			$rows       = wallregi_order_get_wallet_redemptions( $order );
			$editable   = $order->is_editable();
			$buyer_ui   = (bool) apply_filters( 'wallregi_is_buyer_giftcard_redeem_amount_ui_enabled', false );
			$order_curr = $order->get_currency();
			?>
			<tr class="wallregi-admin-order-giftcard-row">
				<td colspan="3">
					<div class="wallregi-admin-order-giftcard-wrap" data-order-id="<?php echo esc_attr( (string) $order_id ); ?>" data-editable="<?php echo $editable ? '1' : '0'; ?>">
						<strong><?php esc_html_e( 'GiftRocket — gift card', 'wallet-ready-gift-cards-for-woocommerce' ); ?></strong>
						<?php if ( ! empty( $rows ) ) : ?>
							<ul class="wallregi-admin-order-giftcard-applied">
								<?php foreach ( $rows as $row ) : ?>
									<li data-code="<?php echo esc_attr( $row['number'] ); ?>">
										<span>
											<code><?php echo esc_html( $row['number'] ); ?></code>
											&mdash;
											<?php echo wp_kses_post( wc_price( $row['amount'], array( 'currency' => $order_curr ) ) ); ?>
										</span>
										<?php if ( $editable ) : ?>
											<button type="button" class="button button-small wallregi-admin-order-remove-giftcard" data-code="<?php echo esc_attr( $row['number'] ); ?>">
												<?php esc_html_e( 'Remove', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
											</button>
										<?php endif; ?>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php else : ?>
							<p class="description" style="margin:6px 0 0;">
								<?php esc_html_e( 'No gift card applied to this order yet.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
							</p>
						<?php endif; ?>

						<?php if ( $editable ) : ?>
							<div class="wallregi-admin-order-giftcard-form">
								<input type="text" class="wallregi-admin-order-giftcard-code" placeholder="<?php esc_attr_e( 'Gift card code', 'wallet-ready-gift-cards-for-woocommerce' ); ?>" autocomplete="off" />
								<?php if ( $buyer_ui ) : ?>
									<input type="text" class="wallregi-admin-order-giftcard-amount" placeholder="<?php esc_attr_e( 'Amount (optional)', 'wallet-ready-gift-cards-for-woocommerce' ); ?>" autocomplete="off" />
								<?php endif; ?>
								<button type="button" class="button button-primary wallregi-admin-order-apply-giftcard">
									<?php esc_html_e( 'Apply gift card', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
								</button>
							</div>
							<p class="description" style="margin:6px 0 0;">
								<?php esc_html_e( 'Applies balance to this order (negative fee) and updates the gift card ledger immediately.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
							</p>
						<?php else : ?>
							<p class="description" style="margin:6px 0 0;">
								<?php esc_html_e( 'This order can no longer be edited. Gift card changes are disabled.', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
							</p>
						<?php endif; ?>
						<div class="wallregi-admin-order-giftcard-msg" aria-live="polite"></div>
					</div>
				</td>
			</tr>
			<?php
		}

		/**
		 * Calculate discount amount for admin order apply.
		 *
		 * @param WC_Order $order    Order.
		 * @param object   $giftcard DB row.
		 * @param int|null $requested Optional requested amount (Pro partial redeem).
		 * @return int|WP_Error
		 */
		private function wallregi_calculate_discount_for_order( $order, $giftcard, $requested = null ) {
			$remaining = wallregi_order_get_remaining_giftcard_payable( $order );
			if ( $remaining <= 0 ) {
				return new WP_Error(
					'wallregi_order_total',
					__( 'Order total is already zero; no remaining amount for a gift card.', 'wallet-ready-gift-cards-for-woocommerce' )
				);
			}

			$balance = (int) $giftcard->current_amount;
			if ( $balance <= 0 ) {
				return new WP_Error(
					'wallregi_no_balance',
					__( 'This gift card has no remaining balance.', 'wallet-ready-gift-cards-for-woocommerce' )
				);
			}

			$buyer_ui = (bool) apply_filters( 'wallregi_is_buyer_giftcard_redeem_amount_ui_enabled', false );
			if ( $buyer_ui && null !== $requested && $requested > 0 ) {
				$discount = min( (int) $requested, $balance, (int) round( $remaining ) );
				$check    = apply_filters( 'wallregi_validate_buyer_redeem_amount_for_apply', true, $giftcard->giftcard_number, $discount, $giftcard );
				if ( is_wp_error( $check ) ) {
					return $check;
				}
			} else {
				$discount = min( $balance, (int) round( $remaining ) );
			}

			$already = wallregi_order_get_wallet_redemption_total( $order );
			$max_combined = apply_filters( 'wallregi_admin_order_max_combined_giftcard_discount', null, $order );
			if ( is_numeric( $max_combined ) && (float) $max_combined > 0 ) {
				$cap = (float) $max_combined - $already;
				if ( $cap <= 0 ) {
					return new WP_Error(
						'wallregi_combined_cap',
						__( 'Maximum combined gift card redemption for this order has been reached.', 'wallet-ready-gift-cards-for-woocommerce' )
					);
				}
				$discount = min( $discount, max( 0, (int) round( $cap ) ) );
			}

			if ( $discount <= 0 ) {
				return new WP_Error(
					'wallregi_discount_zero',
					__( 'Could not apply a gift card discount to this order.', 'wallet-ready-gift-cards-for-woocommerce' )
				);
			}

			return $discount;
		}

		/**
		 * @param int    $order_id Order ID.
		 * @param string $code     Gift card code.
		 * @param int|null $requested_amount Optional amount.
		 * @return true|WP_Error
		 */
		public function wallregi_apply_giftcard_to_order( $order_id, $code, $requested_amount = null ) {
			$order = wc_get_order( $order_id );
			if ( ! $order instanceof WC_Order ) {
				return new WP_Error( 'wallregi_order', __( 'Order not found.', 'wallet-ready-gift-cards-for-woocommerce' ) );
			}

			if ( ! $order->is_editable() ) {
				return new WP_Error(
					'wallregi_not_editable',
					__( 'This order cannot be edited.', 'wallet-ready-gift-cards-for-woocommerce' )
				);
			}

			$code = strtoupper( str_replace( ' ', '-', trim( (string) $code ) ) );
			if ( '' === $code ) {
				return new WP_Error( 'wallregi_code', __( 'Gift card code is required.', 'wallet-ready-gift-cards-for-woocommerce' ) );
			}

			if ( wallregi_order_has_giftcard_code( $order, $code ) ) {
				return new WP_Error(
					'wallregi_duplicate',
					__( 'This gift card is already applied to the order.', 'wallet-ready-gift-cards-for-woocommerce' )
				);
			}

			$valid = wallregi_validate_giftcard_for_session_apply( $code );
			if ( is_wp_error( $valid ) ) {
				return $valid;
			}

			$giftcard = wallregi_get_giftcard_by_number( $code );
			if ( ! $giftcard ) {
				return new WP_Error(
					'wallregi_giftcard_not_found',
					__( 'Gift card not found.', 'wallet-ready-gift-cards-for-woocommerce' )
				);
			}

			$existing   = count( wallregi_order_get_wallet_redemptions( $order ) );
			$max_cards  = (int) apply_filters( 'wallregi_admin_order_max_giftcards_count', 0, $order );
			if ( $max_cards > 0 && $existing >= $max_cards ) {
				return new WP_Error(
					'giftcard_order_limit',
					sprintf(
						/* translators: %d: maximum gift cards per order */
						__( 'You can apply at most %d gift cards to a single order.', 'wallet-ready-gift-cards-for-woocommerce' ),
						$max_cards
					)
				);
			}

			$limits = apply_filters(
				'wallregi_validate_admin_order_giftcard_limits_before_apply',
				true,
				$code,
				$giftcard,
				$order,
				$existing
			);
			if ( is_wp_error( $limits ) ) {
				return $limits;
			}

			$discount = $this->wallregi_calculate_discount_for_order( $order, $giftcard, $requested_amount );
			if ( is_wp_error( $discount ) ) {
				return $discount;
			}

			$redeem = wallregi_order_redeem_giftcard_balance( $order, $code, $discount, 'admin_order_redeem' );
			if ( is_wp_error( $redeem ) ) {
				return $redeem;
			}

			$fee_name = sprintf(
				/* translators: %s: gift card code */
				__( 'Gift card: %s', 'wallet-ready-gift-cards-for-woocommerce' ),
				$code
			);

			$item = new WC_Order_Item_Fee();
			$item->set_name( $fee_name );
			$item->set_amount( -$discount );
			$item->set_total( -$discount );
			$item->set_tax_status( 'none' );
			$item->add_meta_data( '_wallregi_giftcard_number', $code, true );

			$order->add_item( $item );
			$order->save();
			$fee_item_id = $item->get_id();

			$order->update_meta_data( '_wallregi_giftcard_applied', 'yes' );
			$order->update_meta_data( '_giftcard_discount_' . $code, $discount );
			$order->update_meta_data( '_giftcard_fee_item_id_' . $code, $fee_item_id );

			$order->calculate_totals( true );
			$order->save();

			if ( function_exists( 'wallregi_security_should_log_success' ) && wallregi_security_should_log_success() ) {
				wallregi_security_audit_log(
					'admin_order_apply_giftcard',
					'success',
					array(
						'identifier' => function_exists( 'wallregi_security_redact_code' ) ? wallregi_security_redact_code( $code ) : '',
						'detail'     => 'order_id=' . (int) $order_id . ';amount=' . (int) $discount,
					)
				);
			}

			return true;
		}

		/**
		 * @param int    $order_id Order ID.
		 * @param string $code     Gift card code.
		 * @return true|WP_Error
		 */
		public function wallregi_remove_giftcard_from_order( $order_id, $code ) {
			$order = wc_get_order( $order_id );
			if ( ! $order instanceof WC_Order ) {
				return new WP_Error( 'wallregi_order', __( 'Order not found.', 'wallet-ready-gift-cards-for-woocommerce' ) );
			}

			if ( ! $order->is_editable() ) {
				return new WP_Error(
					'wallregi_not_editable',
					__( 'This order cannot be edited.', 'wallet-ready-gift-cards-for-woocommerce' )
				);
			}

			$code = strtoupper( str_replace( ' ', '-', trim( (string) $code ) ) );
			$amount = (int) $order->get_meta( '_giftcard_discount_' . $code, true );
			if ( $amount <= 0 ) {
				return new WP_Error(
					'wallregi_not_applied',
					__( 'This gift card is not applied to the order.', 'wallet-ready-gift-cards-for-woocommerce' )
				);
			}

			$restore = wallregi_order_restore_giftcard_balance( $order, $code, $amount, 'admin_order_remove' );
			if ( is_wp_error( $restore ) ) {
				return $restore;
			}

			$fee_item_id = (int) $order->get_meta( '_giftcard_fee_item_id_' . $code, true );
			if ( $fee_item_id > 0 ) {
				$fee_item = $order->get_item( $fee_item_id );
				if ( $fee_item ) {
					$order->remove_item( $fee_item_id );
				}
			} else {
				foreach ( $order->get_items( 'fee' ) as $item_id => $item ) {
					if ( ! $item instanceof WC_Order_Item_Fee ) {
						continue;
					}
					$num = $item->get_meta( '_wallregi_giftcard_number', true );
					if ( (string) $num === $code ) {
						$order->remove_item( $item_id );
						break;
					}
				}
			}

			$order->delete_meta_data( '_giftcard_discount_' . $code );
			$order->delete_meta_data( '_giftcard_fee_item_id_' . $code );

			if ( empty( wallregi_order_get_wallet_redemptions( $order ) ) ) {
				$order->delete_meta_data( '_wallregi_giftcard_applied' );
			}

			$order->calculate_totals( true );
			$order->save();

			return true;
		}

		public function wallregi_ajax_apply_giftcard() {
			check_ajax_referer( self::AJAX_NONCE_ACTION, 'nonce' );

			if ( ! current_user_can( 'edit_shop_orders' ) && ! current_user_can( 'manage_woocommerce' ) ) {
				wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wallet-ready-gift-cards-for-woocommerce' ) ), 403 );
			}

			$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
			$code     = isset( $_POST['giftcard_code'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['giftcard_code'] ) ) : '';

			if ( ! apply_filters(
				'wallregi_security_allow_admin_order_apply_giftcard',
				true,
				array(
					'order_id'      => $order_id,
					'giftcard_code' => $code,
				)
			) ) {
				$msg = function_exists( 'wallregi_security_rate_limit_message' )
					? wallregi_security_rate_limit_message()
					: __( 'Too many requests. Please try again later.', 'wallet-ready-gift-cards-for-woocommerce' );
				wp_send_json_error( array( 'message' => $msg ), 429 );
			}

			$requested = null;
			if ( isset( $_POST['redeem_amount'] ) && '' !== trim( (string) $_POST['redeem_amount'] ) ) {
				$raw = wp_unslash( (string) $_POST['redeem_amount'] );
				if ( function_exists( 'wc_format_decimal' ) && function_exists( 'wc_get_price_decimals' ) ) {
					$parsed = wc_format_decimal( $raw, wc_get_price_decimals() );
					if ( is_numeric( $parsed ) ) {
						$requested = max( 0, (int) round( (float) $parsed ) );
					}
				}
			}

			$result = $this->wallregi_apply_giftcard_to_order( $order_id, $code, $requested );
			if ( is_wp_error( $result ) ) {
				wp_send_json_error( array( 'message' => $result->get_error_message() ) );
			}

			wp_send_json_success(
				array(
					'message'  => __( 'Gift card applied. Reloading order…', 'wallet-ready-gift-cards-for-woocommerce' ),
					'reload'   => true,
				)
			);
		}

		public function wallregi_ajax_remove_giftcard() {
			check_ajax_referer( self::AJAX_NONCE_ACTION, 'nonce' );

			if ( ! current_user_can( 'edit_shop_orders' ) && ! current_user_can( 'manage_woocommerce' ) ) {
				wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wallet-ready-gift-cards-for-woocommerce' ) ), 403 );
			}

			$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
			$code     = isset( $_POST['giftcard_code'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['giftcard_code'] ) ) : '';

			$result = $this->wallregi_remove_giftcard_from_order( $order_id, $code );
			if ( is_wp_error( $result ) ) {
				wp_send_json_error( array( 'message' => $result->get_error_message() ) );
			}

			wp_send_json_success(
				array(
					'message' => __( 'Gift card removed. Reloading order…', 'wallet-ready-gift-cards-for-woocommerce' ),
					'reload'  => true,
				)
			);
		}
	}
}
