<?php
/**
 * SMS extension contract — hooks and helpers (free plugin).
 *
 * The GiftRocket SMS add-on (`wallet-ready-gift-cards-sms`) implements delivery
 * without changing default email-only behaviour when the extension is inactive.
 *
 * @package Wallet_Ready_Gift_Cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var string Email delivery only (default). */
const WALLREGI_DELIVERY_CHANNEL_EMAIL = 'email';

/** @var string SMS delivery only. */
const WALLREGI_DELIVERY_CHANNEL_SMS = 'sms';

/** @var string Email and SMS. */
const WALLREGI_DELIVERY_CHANNEL_BOTH = 'both';

/** @var string No automated delivery (merchant handles manually). */
const WALLREGI_DELIVERY_CHANNEL_NONE = 'none';

/**
 * Whether the GiftRocket SMS extension is loaded.
 *
 * @return bool
 */
function wallregi_sms_extension_is_active() {
	return defined( 'WALLREGI_SMS_VERSION' ) && class_exists( 'WALLREGI_SMS_Bootstrap' );
}

/**
 * Whether any automated SMS delivery path is available (native extension or GiftToWallet).
 *
 * @return bool
 */
function wallregi_giftcard_sms_delivery_available() {
	if ( function_exists( 'wallregi_gtw_sms_delivery_is_active' ) && wallregi_gtw_sms_delivery_is_active() ) {
		return true;
	}

	return wallregi_sms_extension_is_active();
}

/**
 * Human-readable label for a stored delivery channel slug.
 *
 * @param mixed $channel Raw channel value.
 * @return string
 */
function wallregi_giftcard_delivery_channel_label( $channel ) {
	$channel = wallregi_normalize_delivery_channel( $channel );
	$choices = wallregi_giftcard_delivery_channel_choices();

	if ( isset( $choices[ $channel ] ) ) {
		return (string) $choices[ $channel ];
	}

	$labels = array(
		WALLREGI_DELIVERY_CHANNEL_EMAIL => __( 'Email only', 'wallet-ready-gift-cards-for-woocommerce' ),
		WALLREGI_DELIVERY_CHANNEL_SMS   => __( 'SMS only', 'wallet-ready-gift-cards-for-woocommerce' ),
		WALLREGI_DELIVERY_CHANNEL_BOTH  => __( 'Email and SMS', 'wallet-ready-gift-cards-for-woocommerce' ),
		WALLREGI_DELIVERY_CHANNEL_NONE  => __( 'No automatic delivery', 'wallet-ready-gift-cards-for-woocommerce' ),
	);

	return $labels[ $channel ] ?? __( 'Email only', 'wallet-ready-gift-cards-for-woocommerce' );
}

/**
 * Whether GiftToWallet (not the native SMS extension) is the active SMS provider.
 *
 * @return bool
 */
function wallregi_gtw_sms_delivery_is_active() {
	return class_exists( 'WALLREGI_GTW_Delivery' ) && WALLREGI_GTW_Delivery::sms_delivery_is_active();
}

/**
 * Delivery channel choices for storefront (extension may filter).
 *
 * @return array<string, string> slug => label.
 */
function wallregi_giftcard_delivery_channel_choices() {
	$choices = array(
		WALLREGI_DELIVERY_CHANNEL_EMAIL => __( 'Email only', 'wallet-ready-gift-cards-for-woocommerce' ),
	);

	if ( wallregi_sms_extension_is_active() ) {
		$choices[ WALLREGI_DELIVERY_CHANNEL_SMS ]   = __( 'SMS only', 'wallet-ready-gift-cards-for-woocommerce' );
		$choices[ WALLREGI_DELIVERY_CHANNEL_BOTH ]  = __( 'Email and SMS', 'wallet-ready-gift-cards-for-woocommerce' );
		$choices[ WALLREGI_DELIVERY_CHANNEL_NONE ]  = __( 'No automatic delivery', 'wallet-ready-gift-cards-for-woocommerce' );
	}

	/**
	 * Filter delivery channel choices shown to buyers.
	 *
	 * @param array<string, string> $choices slug => label.
	 */
	return (array) apply_filters( 'wallregi_giftcard_delivery_channel_choices', $choices );
}

/**
 * Sanitize a delivery channel slug.
 *
 * @param mixed $raw Raw value.
 * @return string
 */
function wallregi_sanitize_delivery_channel( $raw ) {
	$channel = sanitize_key( (string) $raw );
	$choices = wallregi_giftcard_delivery_channel_choices();

	if ( ! array_key_exists( $channel, $choices ) ) {
		return WALLREGI_DELIVERY_CHANNEL_EMAIL;
	}

	/**
	 * Filter sanitized delivery channel before persistence.
	 *
	 * @param string $channel Sanitized slug.
	 * @param mixed  $raw     Original input.
	 */
	return (string) apply_filters( 'wallregi_giftcard_delivery_channel', $channel, $raw );
}

/**
 * Normalize stored delivery channel (legacy rows default to email).
 *
 * @param mixed $channel DB or cart value.
 * @return string
 */
function wallregi_normalize_delivery_channel( $channel ) {
	$channel = sanitize_key( (string) $channel );
	if ( '' === $channel ) {
		return WALLREGI_DELIVERY_CHANNEL_EMAIL;
	}

	$allowed = array(
		WALLREGI_DELIVERY_CHANNEL_EMAIL,
		WALLREGI_DELIVERY_CHANNEL_SMS,
		WALLREGI_DELIVERY_CHANNEL_BOTH,
		WALLREGI_DELIVERY_CHANNEL_NONE,
	);

	if ( ! in_array( $channel, $allowed, true ) ) {
		return WALLREGI_DELIVERY_CHANNEL_EMAIL;
	}

	if ( ! wallregi_sms_extension_is_active() && WALLREGI_DELIVERY_CHANNEL_EMAIL !== $channel ) {
		return WALLREGI_DELIVERY_CHANNEL_EMAIL;
	}

	return $channel;
}

/**
 * Whether automated email delivery should run for this gift card row.
 *
 * @param object|array $giftcard_data Gift card DB row or array.
 * @return bool
 */
function wallregi_giftcard_should_send_email_for_channel( $giftcard_data ) {
	$channel = is_array( $giftcard_data )
		? ( $giftcard_data['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL )
		: ( $giftcard_data->delivery_channel ?? WALLREGI_DELIVERY_CHANNEL_EMAIL );

	$channel = wallregi_normalize_delivery_channel( $channel );
	$send    = in_array( $channel, array( WALLREGI_DELIVERY_CHANNEL_EMAIL, WALLREGI_DELIVERY_CHANNEL_BOTH ), true );

	/**
	 * Filter whether email delivery is allowed for this gift card.
	 *
	 * @param bool         $send          Whether email should be sent.
	 * @param string       $channel       Normalized delivery channel.
	 * @param object|array $giftcard_data Gift card row.
	 */
	return (bool) apply_filters( 'wallregi_giftcard_should_send_email', $send, $channel, $giftcard_data );
}

/**
 * Whether automated SMS delivery should run for this gift card row.
 *
 * @param object|array $giftcard_data Gift card DB row or array.
 * @return bool
 */
function wallregi_giftcard_should_send_sms_for_channel( $giftcard_data ) {
	if ( function_exists( 'wallregi_gtw_sms_delivery_is_active' ) && wallregi_gtw_sms_delivery_is_active() ) {
		return false;
	}

	if ( ! wallregi_sms_extension_is_active() ) {
		return false;
	}

	$channel = is_array( $giftcard_data )
		? ( $giftcard_data['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL )
		: ( $giftcard_data->delivery_channel ?? WALLREGI_DELIVERY_CHANNEL_EMAIL );

	$channel = wallregi_normalize_delivery_channel( $channel );
	$send    = in_array( $channel, array( WALLREGI_DELIVERY_CHANNEL_SMS, WALLREGI_DELIVERY_CHANNEL_BOTH ), true );

	/**
	 * Filter whether SMS delivery is allowed for this gift card.
	 *
	 * @param bool         $send          Whether SMS should be sent.
	 * @param string       $channel       Normalized delivery channel.
	 * @param object|array $giftcard_data Gift card row.
	 */
	return (bool) apply_filters( 'wallregi_giftcard_should_send_sms', $send, $channel, $giftcard_data );
}

/**
 * Sanitize E.164-ish phone for storage (extension may refine).
 *
 * @param mixed $raw Raw phone input.
 * @return string
 */
function wallregi_sanitize_giftcard_phone( $raw ) {
	$raw = is_string( $raw ) ? trim( $raw ) : '';
	if ( '' === $raw ) {
		return '';
	}

	$clean = preg_replace( '/[^\d+]/', '', $raw );
	if ( ! is_string( $clean ) || '' === $clean ) {
		return '';
	}

	/**
	 * Filter sanitized recipient phone before DB persistence.
	 *
	 * @param string $clean Sanitized phone.
	 * @param string $raw   Original input.
	 */
	return (string) apply_filters( 'wallregi_giftcard_recipient_phone', $clean, $raw );
}

/**
 * SMS status label (mirrors email_status).
 *
 * @param int|string $status 0 pending, 1 sent, 2 failed.
 * @return string
 */
function wallregi_giftcard_sms_status_label( $status ) {
	switch ( (int) $status ) {
		case 1:
			return __( 'Sent', 'wallet-ready-gift-cards-for-woocommerce' );
		case 2:
			return __( 'Failed', 'wallet-ready-gift-cards-for-woocommerce' );
		default:
			return __( 'Pending', 'wallet-ready-gift-cards-for-woocommerce' );
	}
}

/**
 * Wallet pass URL for a gift card row (epass_data or order item meta).
 *
 * @param object|array $giftcard_data Gift card DB row.
 * @return string
 */
function wallregi_giftcard_get_pass_link_for_row( $giftcard_data ) {
	$pass_link  = '';
	$epass_json = is_array( $giftcard_data )
		? (string) ( $giftcard_data['epass_data'] ?? '' )
		: (string) ( $giftcard_data->epass_data ?? '' );

	if ( '' !== $epass_json ) {
		$decoded = json_decode( $epass_json, true );
		if ( is_array( $decoded ) && ! empty( $decoded['passLink'] ) && is_string( $decoded['passLink'] ) ) {
			$pass_link = trim( $decoded['passLink'] );
		}
	}

	if ( '' === $pass_link ) {
		$item_id = is_array( $giftcard_data )
			? absint( $giftcard_data['item_id'] ?? 0 )
			: absint( $giftcard_data->item_id ?? 0 );

		if ( $item_id > 0 && function_exists( 'wallregi_epass_get_pass_link_for_order_item' ) ) {
			$pass_link = wallregi_epass_get_pass_link_for_order_item( $item_id );
		} elseif ( $item_id > 0 && function_exists( 'wc_get_order_item_meta' ) ) {
			$meta = wc_get_order_item_meta( $item_id, '_wallregi_epass_pass_link', true );
			if ( '' === trim( (string) $meta ) ) {
				$meta = wc_get_order_item_meta( $item_id, '_wallregi_gtw_pass_link', true );
			}
			$pass_link = is_string( $meta ) ? trim( $meta ) : '';
		}
	}

	/**
	 * Filter wallet pass URL resolved for merge tags (SMS, email, etc.).
	 *
	 * @param string       $pass_link     Pass URL or empty when not issued.
	 * @param object|array $giftcard_data Gift card row.
	 */
	return (string) apply_filters( 'wallregi_giftcard_pass_link_for_row', $pass_link, $giftcard_data );
}

/**
 * Storefront apply-gift-card URL for a gift card row.
 *
 * @param object|array $giftcard_data Gift card DB row.
 * @return string
 */
function wallregi_giftcard_get_apply_link_for_row( $giftcard_data ) {
	$giftcard_number = is_array( $giftcard_data )
		? (string) ( $giftcard_data['giftcard_number'] ?? '' )
		: (string) ( $giftcard_data->giftcard_number ?? '' );

	if ( '' === $giftcard_number ) {
		return '';
	}

	if ( ! function_exists( 'wallregi_giftcard_get_apply_checkout_url' ) && defined( 'WALLREGI_PLUGIN_DIR' ) ) {
		require_once WALLREGI_PLUGIN_DIR . 'includes/wallregi-pdf-codes.php';
	}

	$url = function_exists( 'wallregi_giftcard_get_apply_checkout_url' )
		? wallregi_giftcard_get_apply_checkout_url( $giftcard_number )
		: '';

	/**
	 * Filter apply-gift-card URL resolved for merge tags (SMS, email, etc.).
	 *
	 * @param string       $url           Checkout/cart deep link.
	 * @param object|array $giftcard_data Gift card row.
	 */
	return (string) apply_filters( 'wallregi_giftcard_apply_link_for_row', $url, $giftcard_data );
}

/**
 * Whether GiftToWallet SMS and the native SMS extension are both enabled.
 *
 * @return bool
 */
function wallregi_dual_sms_providers_active() {
	if ( ! function_exists( 'wallregi_gtw_sms_delivery_is_active' ) || ! wallregi_gtw_sms_delivery_is_active() ) {
		return false;
	}

	return class_exists( 'WALLREGI_SMS_Provider_Registry' ) && WALLREGI_SMS_Provider_Registry::is_enabled();
}

/**
 * Admin notice: GTW SMS takes priority over the native SMS extension (no double texts).
 *
 * @return void
 */
function wallregi_admin_notice_sms_provider_priority() {
	if ( ! is_admin() || ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}

	if ( ! wallregi_dual_sms_providers_active() ) {
		return;
	}

	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || false === strpos( (string) $screen->id, 'wx-gift-cards' ) ) {
		return;
	}

	$gtw_settings_url = admin_url( 'admin.php?page=wx-gift-cards-gtw' );
	$sms_settings_url = admin_url( 'admin.php?page=wx-gift-cards-sms' );

	echo '<div class="notice notice-warning is-dismissible"><p>'
		. wp_kses_post(
			sprintf(
				/* translators: 1: GiftToWallet settings URL, 2: native SMS settings URL */
				__(
					'<strong>SMS delivery:</strong> GiftToWallet SMS and the native SMS extension are both enabled. GiftToWallet sends all automated gift card texts; the native provider (Twilio, Vonage, Plivo, etc.) stays disabled so recipients are not texted twice. To use the native SMS extension instead, turn off <a href="%1$s">SMS via GiftToWallet</a>. To rely on GiftToWallet only, disable the provider under <a href="%2$s">SMS delivery</a>.',
					'wallet-ready-gift-cards-for-woocommerce'
				),
				esc_url( $gtw_settings_url ),
				esc_url( $sms_settings_url )
			)
		)
		. '</p></div>';
}

add_action( 'admin_notices', 'wallregi_admin_notice_sms_provider_priority' );

/**
 * Whether delivery method / phone fields should appear in cart edit UI.
 *
 * @return bool
 */
function wallregi_cart_edit_delivery_is_available() {
	if ( ! wallregi_sms_extension_is_active() ) {
		return false;
	}

	if ( class_exists( 'WALLREGI_SMS_Provider_Registry' ) && ! WALLREGI_SMS_Provider_Registry::is_enabled() ) {
		return false;
	}

	$choices = wallregi_giftcard_delivery_channel_choices();

	return count( $choices ) >= 2;
}

/**
 * Validate and normalize recipient email/phone for a delivery channel.
 * Optional contact values are kept when provided; required fields still enforced.
 *
 * @param string $channel   Delivery channel slug.
 * @param mixed  $email_raw Raw email input.
 * @param mixed  $phone_raw Raw phone input.
 * @return array{receiver_email:string,receiver_phone:string}|\WP_Error
 */
function wallregi_normalize_giftcard_delivery_contacts( $channel, $email_raw, $phone_raw ) {
	$channel = wallregi_normalize_delivery_channel( $channel );
	$email   = sanitize_email( (string) $email_raw );
	$phone   = function_exists( 'wallregi_sanitize_giftcard_phone' )
		? wallregi_sanitize_giftcard_phone( $phone_raw )
		: sanitize_text_field( (string) $phone_raw );

	$needs_email = in_array( $channel, array( WALLREGI_DELIVERY_CHANNEL_EMAIL, WALLREGI_DELIVERY_CHANNEL_BOTH ), true );
	$needs_phone = in_array( $channel, array( WALLREGI_DELIVERY_CHANNEL_SMS, WALLREGI_DELIVERY_CHANNEL_BOTH ), true );

	if ( $needs_email && ( '' === $email || ! is_email( $email ) ) ) {
		return new WP_Error(
			'wallregi_delivery_email_required',
			__( 'Please enter a valid recipient email for the selected delivery method.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	if ( ! $needs_email && '' !== $email && ! is_email( $email ) ) {
		return new WP_Error(
			'wallregi_delivery_email_invalid',
			__( 'Please enter a valid recipient email address.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	if ( $needs_phone ) {
		if ( ! function_exists( 'wallregi_validate_giftcard_phone' ) ) {
			return new WP_Error(
				'wallregi_delivery_phone_required',
				__( 'Please enter a recipient phone number for SMS delivery.', 'wallet-ready-gift-cards-for-woocommerce' )
			);
		}

		$validated_phone = wallregi_validate_giftcard_phone( $phone, true );
		if ( is_wp_error( $validated_phone ) ) {
			return $validated_phone;
		}
		$phone = $validated_phone;
	} elseif ( '' !== $phone && function_exists( 'wallregi_validate_giftcard_phone' ) ) {
		$validated_phone = wallregi_validate_giftcard_phone( $phone, false );
		if ( is_wp_error( $validated_phone ) ) {
			return $validated_phone;
		}
		$phone = $validated_phone;
	}

	return array(
		'receiver_email' => $email,
		'receiver_phone' => $phone,
	);
}

/**
 * Apply normalized delivery contacts to cart line giftcard_data.
 *
 * @param array<string, mixed> $giftcard_data Cart line data.
 * @param array<string, mixed> $giftcard      Raw form payload (unused).
 * @return array<string, mixed>
 */
function wallregi_apply_delivery_contacts_to_cart_item_data( array $giftcard_data, $giftcard ) {
	unset( $giftcard );

	if ( ! wallregi_giftcard_sms_delivery_available() ) {
		return $giftcard_data;
	}

	$channel = wallregi_normalize_delivery_channel( $giftcard_data['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL );
	$normalized = wallregi_normalize_giftcard_delivery_contacts(
		$channel,
		$giftcard_data['receiver_email'] ?? '',
		$giftcard_data['receiver_phone'] ?? ''
	);

	if ( is_wp_error( $normalized ) ) {
		return $giftcard_data;
	}

	$giftcard_data['delivery_channel'] = $channel;
	$giftcard_data['receiver_email']   = $normalized['receiver_email'];
	$giftcard_data['receiver_phone']   = $normalized['receiver_phone'];

	return $giftcard_data;
}
add_filter( 'wallregi_giftcard_cart_item_data', 'wallregi_apply_delivery_contacts_to_cart_item_data', 20, 2 );

/**
 * Validate delivery channel + contact fields on cart edit save.
 *
 * @param array<string, mixed> $giftcard_data Cart line giftcard_data.
 * @return array<string, mixed>|\WP_Error
 */
function wallregi_validate_giftcard_cart_edit_delivery( array $giftcard_data ) {
	$checkout_src = isset( $giftcard_data['checkout_receiver_source'] ) ? (string) $giftcard_data['checkout_receiver_source'] : '';
	if ( in_array( $checkout_src, array( 'billing', 'shipping' ), true ) ) {
		return $giftcard_data;
	}

	$name = trim( (string) ( $giftcard_data['receiver_name'] ?? '' ) );
	if ( '' === $name ) {
		return new WP_Error(
			'wallregi_cart_edit_name_required',
			__( 'Please enter the recipient name.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	if ( ! wallregi_cart_edit_delivery_is_available() ) {
		$email = sanitize_email( (string) ( $giftcard_data['receiver_email'] ?? '' ) );
		if ( '' === $email || ! is_email( $email ) ) {
			return new WP_Error(
				'wallregi_cart_edit_email_required',
				__( 'Please enter a valid recipient email for the selected delivery method.', 'wallet-ready-gift-cards-for-woocommerce' )
			);
		}
		$giftcard_data['receiver_email'] = $email;

		return $giftcard_data;
	}

	$channel = wallregi_normalize_delivery_channel( $giftcard_data['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL );
	$giftcard_data['delivery_channel'] = $channel;

	$normalized = wallregi_normalize_giftcard_delivery_contacts(
		$channel,
		$giftcard_data['receiver_email'] ?? '',
		$giftcard_data['receiver_phone'] ?? ''
	);

	if ( is_wp_error( $normalized ) ) {
		return $normalized;
	}

	$giftcard_data['receiver_email'] = $normalized['receiver_email'];
	$giftcard_data['receiver_phone'] = $normalized['receiver_phone'];

	return $giftcard_data;
}

/**
 * Output delivery method + phone fields in the cart/checkout edit modal.
 *
 * @param array<string, mixed> $giftcard_data Existing cart line values.
 * @return void
 */
function wallregi_render_cart_edit_delivery_fields( array $giftcard_data = array() ) {
	if ( ! wallregi_cart_edit_delivery_is_available() ) {
		return;
	}

	$choices = wallregi_giftcard_delivery_channel_choices();
	$current = wallregi_normalize_delivery_channel( $giftcard_data['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL );
	$phone   = isset( $giftcard_data['receiver_phone'] ) ? (string) $giftcard_data['receiver_phone'] : '';
	$phone_rules = function_exists( 'wallregi_get_giftcard_phone_validation_rules' )
		? wallregi_get_giftcard_phone_validation_rules()
		: array();
	$phone_help  = isset( $phone_rules['active_help_text'] ) ? (string) $phone_rules['active_help_text'] : '';
	$needs_phone = in_array( $current, array( WALLREGI_DELIVERY_CHANNEL_SMS, WALLREGI_DELIVERY_CHANNEL_BOTH ), true );
	?>
	<div class="wallregi_modal_form_group wallregi_edit_delivery_fields">
		<div class="wallregi_form_item wallregi_edit_delivery_channel_item wallregi_delivery_channel_item">
			<div class="wallregi_input_box wallregi_input_box--select">
				<span class="wallregi_placeholder__text wallregi_delivery_channel_label wallregi_label_floated"><?php esc_html_e( 'Delivery method', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
				<select
					id="edit_delivery_channel"
					name="delivery_channel"
					class="wallregi_edit_input wallregi_input__field wallregi_delivery_channel_select wallregi_edit_delivery_channel_select"
				>
					<?php foreach ( $choices as $slug => $label ) : ?>
						<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $slug, $current ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<div class="wallregi_form_item wallregi_edit_recipient_phone_item wallregi_recipient_phone_item" style="<?php echo $needs_phone ? '' : 'display:none;'; ?>">
			<div class="wallregi_input_box">
				<span class="wallregi_placeholder__text wallregi_receiver_phone_label<?php echo ( '' !== $phone || $needs_phone ) ? ' wallregi_label_floated' : ''; ?>"><?php esc_html_e( 'Recipient phone', 'wallet-ready-gift-cards-for-woocommerce' ); ?><span class="wallregi_phone_required_mark" style="<?php echo $needs_phone ? '' : 'display:none;'; ?>">*</span></span>
				<input
					type="tel"
					id="edit_receiver_phone"
					name="receiver_phone"
					class="wallregi_edit_input wallregi_input__field wallregi_receiver_phone_field wallregi_edit_receiver_phone_field"
					value="<?php echo esc_attr( $phone ); ?>"
					autocomplete="tel"
					inputmode="tel"
					onfocus="typeof wallregiHandleInputFocus === 'function' && wallregiHandleInputFocus(this)"
					onblur="typeof wallregiHandleInputBlur === 'function' && wallregiHandleInputBlur(this)"
				/>
			</div>
			<?php if ( '' !== $phone_help ) : ?>
				<p class="wallregi_field_help wallregi_receiver_phone_help"><?php echo esc_html( $phone_help ); ?></p>
			<?php endif; ?>
			<?php do_action( 'wallregi_after_receiver_phone_field', (int) $product_id ); ?>
		</div>
	</div>
	<?php
}

/**
 * Append delivery fields to cart edit save allowlist.
 *
 * @param string[]             $fields        Editable field keys.
 * @param string               $cart_item_key Cart line key.
 * @param array<string, mixed> $giftcard_data Cart giftcard_data.
 * @param string               $context       ajax|store_api.
 * @return string[]
 */
function wallregi_append_cart_edit_delivery_fields( $fields, $cart_item_key, $giftcard_data, $context ) {
	unset( $cart_item_key, $context );

	if ( ! wallregi_cart_edit_delivery_is_available() ) {
		return $fields;
	}

	$checkout_src = isset( $giftcard_data['checkout_receiver_source'] ) ? (string) $giftcard_data['checkout_receiver_source'] : '';
	if ( in_array( $checkout_src, array( 'billing', 'shipping' ), true ) ) {
		return $fields;
	}

	$fields[] = 'delivery_channel';
	$fields[] = 'receiver_phone';

	return $fields;
}
add_filter( 'wallregi_editable_giftcard_fields', 'wallregi_append_cart_edit_delivery_fields', 10, 4 );

/**
 * Localize delivery channel + phone rules for cart edit JS.
 *
 * @param array<string, mixed> $object   Localized ajax object.
 * @param array<string, mixed> $settings Plugin settings.
 * @return array<string, mixed>
 */
function wallregi_localize_cart_edit_delivery_ajax( $object, $settings ) {
	unset( $settings );

	if ( ! wallregi_cart_edit_delivery_is_available() ) {
		return $object;
	}

	$object['cart_edit_delivery'] = array(
		'available'  => true,
		'channels'   => array(
			'email' => WALLREGI_DELIVERY_CHANNEL_EMAIL,
			'sms'   => WALLREGI_DELIVERY_CHANNEL_SMS,
			'both'  => WALLREGI_DELIVERY_CHANNEL_BOTH,
			'none'  => WALLREGI_DELIVERY_CHANNEL_NONE,
		),
		'phoneRules' => function_exists( 'wallregi_get_giftcard_phone_validation_rules' )
			? wallregi_get_giftcard_phone_validation_rules()
			: array(),
		'messages'   => array(
			'nameRequired'  => __( 'Please enter the recipient name.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'emailRequired' => __( 'Please enter a valid recipient email for the selected delivery method.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'invalidEmail'  => __( 'Please enter a valid recipient email address.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'phoneRequired' => __( 'Please enter a recipient phone number for SMS delivery.', 'wallet-ready-gift-cards-for-woocommerce' ),
		),
	);

	return $object;
}
add_filter( 'wallregi_frontend_ajax_object', 'wallregi_localize_cart_edit_delivery_ajax', 10, 2 );

/**
 * Enqueue SMS delivery field styles on cart/checkout edit modal.
 *
 * @return void
 */
function wallregi_enqueue_cart_edit_delivery_styles() {
	if ( ! is_cart() && ! is_checkout() ) {
		return;
	}

	if ( ! wallregi_cart_edit_delivery_is_available() ) {
		return;
	}

	if ( defined( 'WALLREGI_SMS_PLUGIN_URL' ) && defined( 'WALLREGI_SMS_VERSION' ) ) {
		wp_enqueue_style(
			'wallregi_sms_storefront',
			WALLREGI_SMS_PLUGIN_URL . 'assets/css/storefront-delivery.css',
			array( 'wallregi_frontend_style' ),
			WALLREGI_SMS_VERSION
		);
	}
}
add_action( 'wp_enqueue_scripts', 'wallregi_enqueue_cart_edit_delivery_styles', 25 );
