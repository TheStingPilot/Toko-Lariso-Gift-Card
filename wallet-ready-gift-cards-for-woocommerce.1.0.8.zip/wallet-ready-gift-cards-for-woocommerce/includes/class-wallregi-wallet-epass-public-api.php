<?php
/**
 * ePasscard public HTTP API (templates, pass fields). Uses stored API key server-side only.
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filterable base URL for ePasscard public v1 API (no trailing slash).
 *
 * @return string
 */
function wallregi_wallet_epass_public_api_base() {
	return (string) apply_filters(
		'wallregi_wallet_epass_public_api_base',
		'https://api.epasscard.com/api/public/v1'
	);
}

/**
 * Whether outbound ePasscard calls can be made (decrypted or legacy key available).
 *
 * @return bool
 */
function wallregi_wallet_epass_is_api_configured() {
	if ( ! function_exists( 'wallregi_wallet_get_decrypted_api_key' ) ) {
		$persistence = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-admin-settings-persistence.php';
		if ( file_exists( $persistence ) ) {
			require_once $persistence;
		}
	}
	if ( ! function_exists( 'wallregi_wallet_get_decrypted_api_key' ) ) {
		return false;
	}
	return '' !== trim( (string) wallregi_wallet_get_decrypted_api_key() );
}

/**
 * Validate template UID for URL path (UUID, lowercase hex and hyphens).
 *
 * @param string $uid Raw UID.
 * @return string|false Normalized UID or false.
 */
function wallregi_wallet_epass_sanitize_template_uid( $uid ) {
	$uid = strtolower( trim( (string) $uid ) );
	if ( ! preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', $uid ) ) {
		return false;
	}
	return $uid;
}

/**
 * GET request to ePasscard public API with X-Api-Key.
 *
 * @param string $path_with_query Path after v1/ (e.g. get-pass-templates?page=1).
 * @return array<string,mixed>|\WP_Error Decoded JSON array on success.
 */
function wallregi_wallet_epass_public_request( $path_with_query ) {
	if ( ! wallregi_wallet_epass_is_api_configured() ) {
		return new WP_Error(
			'wallregi_epass_no_key',
			__( 'Wallet API key is not configured.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$api_key = wallregi_wallet_get_decrypted_api_key();
	$base    = rtrim( wallregi_wallet_epass_public_api_base(), '/' );
	$path    = ltrim( (string) $path_with_query, '/' );
	$url     = $base . '/' . $path;

	$response = wp_remote_get(
		$url,
		[
			'timeout' => 30,
			'headers' => [
				'X-Api-Key' => $api_key,
			],
		]
	);

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( 200 !== $code ) {
		return new WP_Error(
			'wallregi_epass_http',
			__( 'The ePasscard API returned an error. Please try again later.', 'wallet-ready-gift-cards-for-woocommerce' ),
			[ 'status' => $code ]
		);
	}

	$raw = wp_remote_retrieve_body( $response );
	$body = json_decode( $raw, true );
	if ( ! is_array( $body ) ) {
		return new WP_Error(
			'wallregi_epass_bad_json',
			__( 'The ePasscard server returned an unexpected response.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	return $body;
}

/**
 * POST JSON body to ePasscard public API with X-Api-Key.
 *
 * @param string               $path Path after v1/ (no leading slash).
 * @param array<string, mixed> $body Request body (will be JSON-encoded).
 * @return array<string,mixed>|\WP_Error Decoded JSON array on success.
 */
function wallregi_wallet_epass_public_request_json_post( $path, array $body ) {
	if ( ! wallregi_wallet_epass_is_api_configured() ) {
		return new WP_Error(
			'wallregi_epass_no_key',
			__( 'Wallet API key is not configured.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$api_key = wallregi_wallet_get_decrypted_api_key();
	$base    = rtrim( wallregi_wallet_epass_public_api_base(), '/' );
	$path    = ltrim( (string) $path, '/' );
	$url     = $base . '/' . $path;

	$response = wp_remote_post(
		$url,
		[
			'timeout' => 30,
			'headers' => [
				'X-Api-Key'     => $api_key,
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			],
			'body'    => wp_json_encode( $body ),
		]
	);

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( $code < 200 || $code >= 300 ) {
		return new WP_Error(
			'wallregi_epass_http',
			__( 'The ePasscard API returned an error. Please try again later.', 'wallet-ready-gift-cards-for-woocommerce' ),
			[ 'status' => $code, 'body' => wp_remote_retrieve_body( $response ) ]
		);
	}

	$raw  = wp_remote_retrieve_body( $response );
	$data = json_decode( $raw, true );
	if ( ! is_array( $data ) ) {
		return new WP_Error(
			'wallregi_epass_bad_json',
			__( 'The ePasscard server returned an unexpected response.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	return $data;
}

/**
 * PUT JSON body to ePasscard public API with X-Api-Key.
 *
 * @param string               $path Path after v1/ (no leading slash).
 * @param array<string, mixed> $body Request body (will be JSON-encoded).
 * @return array<string,mixed>|\WP_Error Decoded JSON array on success.
 */
function wallregi_wallet_epass_public_request_json_put( $path, array $body ) {
	if ( ! wallregi_wallet_epass_is_api_configured() ) {
		return new WP_Error(
			'wallregi_epass_no_key',
			__( 'Wallet API key is not configured.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$api_key = wallregi_wallet_get_decrypted_api_key();
	$base    = rtrim( wallregi_wallet_epass_public_api_base(), '/' );
	$path    = ltrim( (string) $path, '/' );
	$url     = $base . '/' . $path;

	$response = wp_remote_request(
		$url,
		[
			'method'  => 'PUT',
			'timeout' => 30,
			'headers' => [
				'X-Api-Key'    => $api_key,
				'Content-Type' => 'application/json',
				'Accept'       => 'application/json',
			],
			'body'    => wp_json_encode( $body ),
		]
	);

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( $code < 200 || $code >= 300 ) {
		return new WP_Error(
			'wallregi_epass_http',
			__( 'The ePasscard API returned an error. Please try again later.', 'wallet-ready-gift-cards-for-woocommerce' ),
			[ 'status' => $code, 'body' => wp_remote_retrieve_body( $response ) ]
		);
	}

	$raw  = wp_remote_retrieve_body( $response );
	$data = json_decode( $raw, true );
	if ( ! is_array( $data ) ) {
		return new WP_Error(
			'wallregi_epass_bad_json',
			__( 'The ePasscard server returned an unexpected response.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	return $data;
}

/**
 * PUT update-single-pass with a full request body (after caller filters).
 *
 * @param array<string, mixed> $body Must include passUid and fields.
 * @return array<string,mixed>|\WP_Error Decoded JSON on success.
 */
function wallregi_wallet_epass_send_update_single_pass_request( array $body ) {
	$pass_raw = isset( $body['passUid'] ) ? (string) $body['passUid'] : '';
	$san      = wallregi_wallet_epass_sanitize_template_uid( $pass_raw );
	if ( false === $san ) {
		return new WP_Error(
			'wallregi_epass_bad_uid',
			__( 'Invalid pass identifier.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}
	$body['passUid'] = $san;
	if ( empty( $body['fields'] ) || ! is_array( $body['fields'] ) ) {
		return new WP_Error(
			'wallregi_epass_update_no_fields',
			__( 'No pass fields to update.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}
	$body['fields'] = array_values( $body['fields'] );

	$result = wallregi_wallet_epass_public_request_json_put( 'update-single-pass', $body );
	if ( is_wp_error( $result ) ) {
		return $result;
	}

	$status = isset( $result['status'] ) ? (int) $result['status'] : 0;
	if ( 200 !== $status && 0 !== $status ) {
		$msg = isset( $result['message'] ) && is_string( $result['message'] )
			? sanitize_text_field( $result['message'] )
			: __( 'Pass could not be updated.', 'wallet-ready-gift-cards-for-woocommerce' );
		return new WP_Error( 'wallregi_epass_update_failed', $msg, $result );
	}

	return $result;
}

/**
 * Update an existing pass field values (PUT update-single-pass).
 *
 * @param string              $pass_uid Pass UUID from create response / epass_data.
 * @param array<int, array{uid: string, field_value: string}> $fields Rows for API body `fields`.
 * @return array<string,mixed>|\WP_Error Decoded JSON on success.
 */
function wallregi_wallet_epass_update_single_pass( $pass_uid, array $fields ) {
	return wallregi_wallet_epass_send_update_single_pass_request(
		[
			'passUid' => $pass_uid,
			'fields'  => $fields,
		]
	);
}

/**
 * Create a single wallet pass for a template.
 *
 * @param string              $template_uid Template UUID.
 * @param array<int, array{uid: string, fieldValue: string}> $additional_fields_value Mapped field UIDs and values.
 * @return array{passUid: string, passLink: string}|\WP_Error
 */
function wallregi_wallet_epass_create_single_pass( $template_uid, array $additional_fields_value ) {
	$san = wallregi_wallet_epass_sanitize_template_uid( $template_uid );
	if ( false === $san ) {
		return new WP_Error(
			'wallregi_epass_bad_uid',
			__( 'Invalid template identifier.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$path = 'create-single-pass/' . rawurlencode( $san );
	$body = wallregi_wallet_epass_public_request_json_post(
		$path,
		[
			'additionalFieldsValue' => array_values( $additional_fields_value ),
		]
	);

	if ( is_wp_error( $body ) ) {
		return $body;
	}

	$status = isset( $body['status'] ) ? (int) $body['status'] : 0;
	if ( 200 !== $status ) {
		$msg = isset( $body['message'] ) && is_string( $body['message'] )
			? sanitize_text_field( $body['message'] )
			: __( 'Pass could not be created.', 'wallet-ready-gift-cards-for-woocommerce' );
		return new WP_Error( 'wallregi_epass_create_failed', $msg, $body );
	}

	$pass_uid  = isset( $body['passUid'] ) ? (string) $body['passUid'] : '';
	$pass_link = isset( $body['passLink'] ) ? (string) $body['passLink'] : '';

	if ( '' === $pass_uid || '' === $pass_link ) {
		return new WP_Error(
			'wallregi_epass_create_incomplete',
			__( 'The ePasscard response did not include pass details.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	return [
		'passUid'  => $pass_uid,
		'passLink' => $pass_link,
	];
}

/**
 * Fetch pass templates (first page only).
 *
 * @return array{templates: array<int, array<string,mixed>>, total_templates: int}|\WP_Error
 */
function wallregi_wallet_epass_get_templates_page1() {
	$body = wallregi_wallet_epass_public_request( 'get-pass-templates?page=1' );
	if ( is_wp_error( $body ) ) {
		return $body;
	}

	$templates = [];
	if ( isset( $body['templates'] ) && is_array( $body['templates'] ) ) {
		$templates = $body['templates'];
	} elseif ( isset( $body['data']['templates'] ) && is_array( $body['data']['templates'] ) ) {
		$templates = $body['data']['templates'];
	}

	$total = 0;
	if ( isset( $body['total']['total_templates'] ) ) {
		$total = absint( $body['total']['total_templates'] );
	} elseif ( isset( $body['data']['total']['total_templates'] ) ) {
		$total = absint( $body['data']['total']['total_templates'] );
	}

	return [
		'templates'       => array_values( $templates ),
		'total_templates' => $total,
	];
}

/**
 * Fetch pass field definitions for a template.
 *
 * @param string $template_uid Template UUID.
 * @return array{passFields: array<int, array<string,mixed>>}|\WP_Error
 */
function wallregi_wallet_epass_get_pass_fields_for_template( $template_uid ) {
	$san = wallregi_wallet_epass_sanitize_template_uid( $template_uid );
	if ( false === $san ) {
		return new WP_Error(
			'wallregi_epass_bad_uid',
			__( 'Invalid template identifier.', 'wallet-ready-gift-cards-for-woocommerce' )
		);
	}

	$path = 'pass-fields/' . rawurlencode( $san );
	$body = wallregi_wallet_epass_public_request( $path );
	if ( is_wp_error( $body ) ) {
		return $body;
	}

	$fields = [];
	if ( isset( $body['passFields'] ) && is_array( $body['passFields'] ) ) {
		$fields = $body['passFields'];
	} elseif ( isset( $body['data']['passFields'] ) && is_array( $body['data']['passFields'] ) ) {
		$fields = $body['data']['passFields'];
	}

	return [
		'passFields' => array_values( $fields ),
	];
}
