<?php
/**
 * Internationalization (i18n) for GiftRocket (free plugin).
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Text domain for translatable strings in the free plugin.
 */
const WALLREGI_TEXT_DOMAIN = 'wallet-ready-gift-cards-for-woocommerce';

/**
 * Register text domain loading on init (WordPress 6.7+ recommendation).
 */
function wallregi_register_i18n() {
	add_action( 'init', 'wallregi_load_textdomain', 0 );
}

/**
 * Load plugin translations from the languages directory.
 *
 * Looks for: wp-content/plugins/{plugin}/languages/{domain}-{locale}.mo
 */
function wallregi_load_textdomain() {
	if ( ! defined( 'WALLREGI_PLUGIN_FILE' ) ) {
		return;
	}

	load_plugin_textdomain(
		WALLREGI_TEXT_DOMAIN,
		false,
		dirname( plugin_basename( WALLREGI_PLUGIN_FILE ) ) . '/languages'
	);
}

/**
 * Translate a string (shortcut for extensions).
 *
 * @param string $text Text to translate.
 * @return string
 */
function wallregi_translate( $text ) {
	return __( $text, WALLREGI_TEXT_DOMAIN );
}
