<?php
/**
 * Fraud & abuse safeguards: rate limits and security audit log (free UI + Pro integration hooks).
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default values for security-related keys in wallregi_settings.
 *
 * @return array<string, mixed>
 */
function wallregi_security_default_settings() {
	return array(
		'security_enabled'                 => 'yes',
		'security_audit_log_success'       => 'no',
		'security_audit_retention_days'    => 90,
		'security_rate_limit_message'      => __( 'Too many attempts from this location. Please wait a few minutes and try again.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'rate_apply_coupon_max'            => 40,
		'rate_apply_coupon_window'         => 3600,
		'rate_apply_query_max'             => 20,
		'rate_apply_query_window'          => 3600,
		'rate_giftcard_form_max'           => 40,
		'rate_giftcard_form_window'        => 3600,
		'rate_giftcard_form_email_max'     => 15,
		'rate_giftcard_form_email_window'  => 3600,
		'rate_cart_update_max'             => 120,
		'rate_cart_update_window'          => 3600,
		'rate_admin_check_code_max'        => 60,
		'rate_admin_check_code_window'     => 300,
		'rate_admin_manual_save_max'       => 30,
		'rate_admin_manual_save_window'    => 600,
		'rate_admin_order_apply_max'       => 40,
		'rate_admin_order_apply_window'    => 600,
		// Wallet Ready Pro (wc/v3 gift cards, bulk CSV, buyer uploads, cleanup, public unsubscribe).
		'rate_pro_rest_giftcard_max'       => 120,
		'rate_pro_rest_giftcard_window'    => 3600,
		'rate_pro_bulk_validate_max'       => 30,
		'rate_pro_bulk_validate_window'    => 600,
		'rate_pro_bulk_queue_max'          => 15,
		'rate_pro_bulk_queue_window'       => 600,
		'rate_pro_bulk_status_max'         => 200,
		'rate_pro_bulk_status_window'      => 300,
		'rate_pro_upload_ip_max'           => 25,
		'rate_pro_upload_ip_window'        => 3600,
		'rate_pro_upload_uid_max'          => 40,
		'rate_pro_upload_uid_window'       => 3600,
		'rate_pro_image_cleanup_max'       => 12,
		'rate_pro_image_cleanup_window'    => 600,
		'rate_pro_expiry_unsub_ip_max'     => 60,
		'rate_pro_expiry_unsub_ip_window'  => 3600,
		'rate_pro_ai_ip_max'               => 40,
		'rate_pro_ai_ip_window'            => 3600,
		'rate_pro_ai_admin_uid_max'        => 60,
		'rate_pro_ai_admin_uid_window'     => 3600,
		'rate_pro_topup_lookup_max'        => 30,
		'rate_pro_topup_lookup_window'     => 600,
	);
}

/**
 * Whether safeguards are enabled.
 *
 * @return bool
 */
function wallregi_security_is_enabled() {
	$settings = wp_parse_args( (array) get_option( 'wallregi_settings', array() ), wallregi_security_default_settings() );

	return isset( $settings['security_enabled'] ) && 'yes' === $settings['security_enabled'];
}

/**
 * Message shown when a rate limit blocks a request.
 *
 * @return string
 */
function wallregi_security_rate_limit_message() {
	$settings = wp_parse_args( (array) get_option( 'wallregi_settings', array() ), wallregi_security_default_settings() );
	$msg      = isset( $settings['security_rate_limit_message'] ) ? (string) $settings['security_rate_limit_message'] : '';

	return '' !== $msg ? $msg : wallregi_security_default_settings()['security_rate_limit_message'];
}

/**
 * Whether to log successful high-volume actions (apply coupon, add to cart).
 *
 * @return bool
 */
function wallregi_security_should_log_success() {
	$settings = wp_parse_args( (array) get_option( 'wallregi_settings', array() ), wallregi_security_default_settings() );

	return isset( $settings['security_audit_log_success'] ) && 'yes' === $settings['security_audit_log_success'];
}

/**
 * Client IP for rate limiting (filterable for proxies).
 *
 * @return string
 */
function wallregi_security_get_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : '';

	return (string) apply_filters( 'wallregi_security_client_ip', $ip );
}

/**
 * Redact a gift card / coupon code for logs (never store full secrets by default).
 *
 * @param string $code Raw code.
 * @return string
 */
function wallregi_security_redact_code( $code ) {
	$code = (string) $code;
	$len  = strlen( $code );
	if ( $len <= 4 ) {
		return '****';
	}

	return substr( $code, 0, 2 ) . str_repeat( '*', max( 2, $len - 4 ) ) . substr( $code, -2 );
}

/**
 * Fixed-window rate limit using a transient counter.
 *
 * @param string $bucket Logical bucket name (short).
 * @param string $id     Stable id (IP hash, user id, email hash, etc.).
 * @param int    $max    Max allowed requests per window (>=1).
 * @param int    $window Window length in seconds (>=1).
 * @return bool True if request is allowed; false if limit exceeded.
 */
function wallregi_security_rate_consume( $bucket, $id, $max, $window ) {
	if ( ! wallregi_security_is_enabled() ) {
		return true;
	}
	$max    = max( 1, (int) $max );
	$window = max( 1, (int) $window );
	$id     = (string) $id;
	if ( '' === $id ) {
		$id = 'unknown';
	}

	$key  = 'wallregi_rl_' . md5( $bucket . '|' . $id );
	$now  = time();
	$data = get_transient( $key );
	if ( ! is_array( $data ) || ! isset( $data['window_start'], $data['count'] ) ) {
		$data = array(
			'window_start' => $now,
			'count'        => 0,
		);
	}

	if ( $now - (int) $data['window_start'] >= $window ) {
		$data = array(
			'window_start' => $now,
			'count'        => 0,
		);
	}

	$new_count = (int) $data['count'] + 1;
	if ( $new_count > $max ) {
		set_transient( $key, $data, $window + 10 );

		return false;
	}

	$data['count'] = $new_count;
	$ttl           = max( 30, $window - ( $now - (int) $data['window_start'] ) + 10 );
	set_transient( $key, $data, $ttl );

	return true;
}

/**
 * Insert one audit row.
 *
 * @param string               $action Action key (e.g. apply_giftcard_coupon_ajax).
 * @param string               $result success|failure|blocked.
 * @param array<string, mixed> $extra  Optional: detail, identifier, user_id override.
 * @return void
 */
function wallregi_security_audit_log( $action, $result, $extra = array() ) {
	if ( ! wallregi_security_is_enabled() ) {
		return;
	}

	global $wpdb;

	$action = sanitize_key( (string) $action );
	$result = sanitize_key( (string) $result );
	if ( strlen( $result ) > 16 ) {
		$result = substr( $result, 0, 16 );
	}
	if ( strlen( $action ) > 64 ) {
		$action = substr( $action, 0, 64 );
	}

	$ip         = isset( $extra['ip'] ) ? (string) $extra['ip'] : wallregi_security_get_ip();
	$ip         = substr( sanitize_text_field( $ip ), 0, 45 );
	$identifier = isset( $extra['identifier'] ) ? substr( sanitize_text_field( (string) $extra['identifier'] ), 0, 191 ) : '';
	$user_id = isset( $extra['user_id'] ) ? (int) $extra['user_id'] : get_current_user_id();
	if ( $user_id < 0 ) {
		$user_id = 0;
	}
	$user_id = $user_id > 0 ? $user_id : 0;
	$detail = isset( $extra['detail'] ) ? substr( sanitize_text_field( (string) $extra['detail'] ), 0, 500 ) : '';

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Plugin audit table insert.
	$wpdb->insert(
		wallregi_security_audit_db_table_name(),
		array(
			'created_at'  => current_time( 'mysql' ),
			'action'      => $action,
			'result'      => $result,
			'ip'          => $ip,
			'identifier'  => $identifier,
			'user_id'     => $user_id,
			'detail'      => $detail,
		),
		array( '%s', '%s', '%s', '%s', '%s', '%d', '%s' )
	);

	do_action( 'wallregi_security_audit_logged', $action, $result, $extra );
}

/**
 * Delete old audit rows (retention).
 *
 * @return void
 */
function wallregi_security_prune_audit_log() {
	$settings = wp_parse_args( (array) get_option( 'wallregi_settings', array() ), wallregi_security_default_settings() );
	$days     = max( 0, (int) ( $settings['security_audit_retention_days'] ?? 90 ) );
	if ( $days < 1 ) {
		return;
	}

	global $wpdb;
	$table  = wallregi_security_audit_db_table_name();
	$cutoff = date( 'Y-m-d H:i:s', current_time( 'timestamp' ) - ( $days * DAY_IN_SECONDS ) );

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Scheduled retention cleanup.
	$wpdb->query(
		$wpdb->prepare(
			'DELETE FROM %i WHERE `created_at` < %s',
			$table,
			$cutoff
		)
	);
}

/**
 * Read numeric rate settings with sane floors.
 *
 * @param string $key Setting key.
 * @param int    $fallback Default from wallregi_security_default_settings().
 * @return int
 */
function wallregi_security_rate_setting( $key, $fallback ) {
	$settings = wp_parse_args( (array) get_option( 'wallregi_settings', array() ), wallregi_security_default_settings() );

	return max( 1, (int) ( $settings[ $key ] ?? $fallback ) );
}

/**
 * Collect normalized receiver emails from decoded giftcards payload (product form).
 *
 * @param array<int, array<string, mixed>> $giftcards Decoded gift cards array.
 * @return string[]
 */
function wallregi_security_collect_receiver_emails_from_giftcards( $giftcards ) {
	$out = array();
	if ( ! is_array( $giftcards ) ) {
		return $out;
	}
	foreach ( $giftcards as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$email = isset( $row['receiverEmail'] ) ? sanitize_email( (string) $row['receiverEmail'] ) : '';
		if ( $email && is_email( $email ) ) {
			$out[] = strtolower( $email );
		}
	}

	return array_values( array_unique( $out ) );
}

/**
 * Append General settings fields for security (only when general-data.php is loaded).
 *
 * @param array<int, array<string, mixed>> $fields       Input fields.
 * @param string                           $data_file    Absolute path to data file.
 * @return array<int, array<string, mixed>>
 */
function wallregi_security_filter_settings_input_fields( $fields, $data_file ) {
	if ( false === strpos( (string) $data_file, 'general-data.php' ) ) {
		return $fields;
	}

	$sec_name = __( 'Fraud & abuse safeguards', 'wallet-ready-gift-cards-for-woocommerce' );
	$sec_key  = 'security_settings';

	$extra = array(
		array(
			'name'        => 'wallregi_security_enabled',
			'key'         => 'security_enabled',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Enable rate limits and security audit log', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'When enabled, the plugin will temporarily slow down repeated requests that look like “too many attempts” (from the same IP, user, or recipient email). It also keeps a simple Security log in your database so you can see when actions were blocked. Example: if someone tries 100 gift card codes in a few minutes, most attempts will be blocked.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'checkbox',
			'default'     => 'yes',
		),
		array(
			'name'        => 'wallregi_security_audit_log_success',
			'key'         => 'security_audit_log_success',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Log successful apply / add-to-cart events', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'Optional. If enabled, the Security log will also record “successful” actions (not only blocks). This can grow the log quickly on busy stores. Recommended: keep OFF unless you are investigating an issue. Blocks are always logged.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'checkbox',
			'default'     => 'no',
		),
		array(
			'name'        => 'wallregi_security_audit_retention_days',
			'key'         => 'security_audit_retention_days',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Audit log retention (days)', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'How long to keep the Security log entries before deleting old ones. This cleanup runs automatically once per day (along with gift card expiry checks). Example: 90 means “keep last 90 days”. Use 0 to keep forever (usually not recommended).', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 90,
		),
		array(
			'name'        => 'wallregi_security_rate_limit_message',
			'key'         => 'security_rate_limit_message',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Message when rate limited', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'This is the message shown to a shopper when the store temporarily blocks requests due to a limit. Keep it friendly and clear. Example: “Too many attempts. Please wait 5 minutes and try again.”', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'textarea',
			'default'     => wallregi_security_default_settings()['security_rate_limit_message'],
			'rows'        => 3,
		),
		array(
			'name'        => 'wallregi_rate_apply_coupon_max',
			'key'         => 'rate_apply_coupon_max',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Apply code (cart/checkout AJAX) — max requests per IP per window', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'Limits how many times someone can try applying gift card codes on cart/checkout within the time window (below). This protects against “guessing” many codes quickly. Applies by IP address and also by logged-in user. Example: max 40 per 1 hour means the 41st attempt is blocked until the window passes.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 40,
		),
		array(
			'name'        => 'wallregi_rate_apply_coupon_window',
			'key'         => 'rate_apply_coupon_window',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Apply code (AJAX) — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'The time period used for the “Apply code” limit above. 3600 seconds = 1 hour. Tip: if you increase the max, consider increasing the window too.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 3600,
		),
		array(
			'name'        => 'wallregi_rate_apply_query_max',
			'key'         => 'rate_apply_query_max',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Apply from QR / link (?wallregi_apply_giftcard=) — max per IP per window', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'Limits how many times a visitor can open a gift card “apply link” (usually from a QR code on the PDF) within the window. This protects against bots repeatedly hitting the link. Example: if max is 20 per hour, the 21st visit will be blocked until later.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 20,
		),
		array(
			'name'        => 'wallregi_rate_apply_query_window',
			'key'         => 'rate_apply_query_window',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Apply from query — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'The time period used for the QR/link limit above. 3600 seconds = 1 hour.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 3600,
		),
		array(
			'name'        => 'wallregi_rate_giftcard_form_max',
			'key'         => 'rate_giftcard_form_max',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Gift card product form (add to cart) — max per IP per window', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'Limits how many gift card form submissions can be made from the same IP in the window. This helps prevent spammy add-to-cart automation. Example: max 40 per hour means a bot cannot add hundreds of gift cards in minutes.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 40,
		),
		array(
			'name'        => 'wallregi_rate_giftcard_form_window',
			'key'         => 'rate_giftcard_form_window',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Gift card form — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'The time period used for the gift card form limit above. 3600 seconds = 1 hour.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 3600,
		),
		array(
			'name'        => 'wallregi_rate_giftcard_form_email_max',
			'key'         => 'rate_giftcard_form_email_max',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Gift card form — max per recipient email per window', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'Limits how many gift cards can be created to the same recipient email within the window. This helps prevent someone spamming a victim’s inbox. Example: if max is 15 per hour, the 16th gift card to the same email will be blocked.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 15,
		),
		array(
			'name'        => 'wallregi_rate_giftcard_form_email_window',
			'key'         => 'rate_giftcard_form_email_window',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Gift card form (email) — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'The time period used for the recipient email limit above. 3600 seconds = 1 hour.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 3600,
		),
		array(
			'name'        => 'wallregi_rate_cart_update_max',
			'key'         => 'rate_cart_update_max',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Cart gift card edit (AJAX) — max per IP per window', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'Limits how many times gift card details can be edited in the cart/checkout from the same IP within the window. Also applies a second limit when a recipient email is present (so one email address can’t be updated endlessly). Example: prevents automated scripts from hammering the edit endpoint.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 120,
		),
		array(
			'name'        => 'wallregi_rate_cart_update_window',
			'key'         => 'rate_cart_update_window',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Cart edit — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'The time period used for cart edit limits above. 3600 seconds = 1 hour.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 3600,
		),
		array(
			'name'        => 'wallregi_rate_admin_check_code_max',
			'key'         => 'rate_admin_check_code_max',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Admin: check gift card number exists — max per user per window', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'Limits how often an admin user can run the “check if code exists” action (used in manual creation UI). This prevents accidental loops or aggressive scripts in the admin area.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 60,
		),
		array(
			'name'        => 'wallregi_rate_admin_check_code_window',
			'key'         => 'rate_admin_check_code_window',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Admin: check code — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'The time period used for the admin “check code” limit above. 300 seconds = 5 minutes.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 300,
		),
		array(
			'name'        => 'wallregi_rate_admin_manual_save_max',
			'key'         => 'rate_admin_manual_save_max',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Admin: manual create/update gift card — max per user per window', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'Limits how many manual gift cards an admin can create/update in the window. This helps prevent mistakes (e.g. double-clicking or an integration submitting repeatedly). Example: max 30 per 10 minutes.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 30,
		),
		array(
			'name'        => 'wallregi_rate_admin_manual_save_window',
			'key'         => 'rate_admin_manual_save_window',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Admin: manual save — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'The time period used for the manual create/update limit above. 600 seconds = 10 minutes.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 600,
		),
		array(
			'name'        => 'wallregi_rate_admin_order_apply_max',
			'key'         => 'rate_admin_order_apply_max',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Admin: apply gift card on order — max per user per window', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'Limits how often a staff member can apply a gift card when creating or editing an order in wp-admin.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 40,
		),
		array(
			'name'        => 'wallregi_rate_admin_order_apply_window',
			'key'         => 'rate_admin_order_apply_window',
			'sec_name'    => $sec_name,
			'sec_key'     => $sec_key,
			'label'       => __( 'Admin: apply gift card on order — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
			'description' => __( 'The time period used for the admin order gift card apply limit above. 600 seconds = 10 minutes.', 'wallet-ready-gift-cards-for-woocommerce' ),
			'type'        => 'number',
			'default'     => 600,
		),
	);

	$pro_sec_name = __( 'Pro integrations (Wallet Ready Pro)', 'wallet-ready-gift-cards-for-woocommerce' );
	$pro_sec_key  = 'security_pro_settings';

	$extra[] = array(
		'name'        => 'wallregi_rate_pro_rest_giftcard_max',
		'key'         => 'rate_pro_rest_giftcard_max',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: WooCommerce REST gift card reads — max per IP per window', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'For stores using the Pro REST API (wc/v3), this limits how many gift card lookups/reads can be made from the same IP in the window. Useful to reduce API abuse if keys are leaked or misused. Example: 120 per hour per IP.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 120,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_rest_giftcard_window',
		'key'         => 'rate_pro_rest_giftcard_window',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: REST reads — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'The time period used for the Pro REST limit above. 3600 seconds = 1 hour.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 3600,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_bulk_validate_max',
		'key'         => 'rate_pro_bulk_validate_max',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: bulk CSV validate — max per admin user per window', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'Limits how many times an admin can run “Validate CSV” in the window. This prevents repeated heavy validations (especially on large CSV files).', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 30,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_bulk_validate_window',
		'key'         => 'rate_pro_bulk_validate_window',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: bulk validate — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'The time period used for bulk validate limit above. 600 seconds = 10 minutes.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 600,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_bulk_queue_max',
		'key'         => 'rate_pro_bulk_queue_max',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: bulk CSV queue import — max per admin user per window', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'Limits how often an admin can click “Start import / Queue import” in the window. This helps prevent duplicate import jobs if someone double-clicks or refreshes.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 15,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_bulk_queue_window',
		'key'         => 'rate_pro_bulk_queue_window',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: bulk queue — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'The time period used for bulk queue limit above. 600 seconds = 10 minutes.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 600,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_bulk_status_max',
		'key'         => 'rate_pro_bulk_status_max',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: bulk job status polling — max per admin user per window', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'While an import is running, the browser checks progress repeatedly. This limit prevents extremely frequent polling (which can slow down your admin). If you see “rate limited” during import, increase this slightly.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 200,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_bulk_status_window',
		'key'         => 'rate_pro_bulk_status_window',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: bulk status — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'The time period used for bulk status polling limit above. 300 seconds = 5 minutes.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 300,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_upload_ip_max',
		'key'         => 'rate_pro_upload_ip_max',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: buyer image upload — max per IP per window', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'Limits how many image uploads can be attempted from the same IP in the window. This reduces upload abuse and server load. Example: if set to 25 per hour, the 26th upload attempt is blocked.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 25,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_upload_ip_window',
		'key'         => 'rate_pro_upload_ip_window',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: buyer upload (IP) — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'The time period used for the buyer upload IP limit above. 3600 seconds = 1 hour.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 3600,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_upload_uid_max',
		'key'         => 'rate_pro_upload_uid_max',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: buyer image upload — max per logged-in user per window', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'Limits uploads per logged-in customer in the window (in addition to the IP limit). Guests are not counted here. Helpful if many people share an IP (e.g. office/VPN), but you still want to limit each account.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 40,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_upload_uid_window',
		'key'         => 'rate_pro_upload_uid_window',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: buyer upload (user) — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'The time period used for the buyer upload user limit above. 3600 seconds = 1 hour.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 3600,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_image_cleanup_max',
		'key'         => 'rate_pro_image_cleanup_max',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: manual orphan image cleanup — max per admin user per window', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'Limits how often an admin can run the “cleanup uploads now” button in the window. This avoids repeated heavy cleanup runs.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 12,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_image_cleanup_window',
		'key'         => 'rate_pro_image_cleanup_window',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: image cleanup — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'The time period used for manual cleanup limit above. 600 seconds = 10 minutes.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 600,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_expiry_unsub_ip_max',
		'key'         => 'rate_pro_expiry_unsub_ip_max',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: expiry reminder unsubscribe link — max per IP per window', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'Limits how many times the public “unsubscribe from reminders” link can be opened from the same IP in the window. This protects the endpoint from being spammed. Example: 60 per hour per IP.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 60,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_expiry_unsub_ip_window',
		'key'         => 'rate_pro_expiry_unsub_ip_window',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: expiry unsubscribe — window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'The time period used for the unsubscribe link limit above. 3600 seconds = 1 hour.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 3600,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_ai_ip_max',
		'key'         => 'rate_pro_ai_ip_max',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: AI generate — max per IP per window', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'Limits AI greeting and email copy AJAX requests from the same IP (storefront and admin). Works alongside Pro daily credit limits.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 40,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_ai_ip_window',
		'key'         => 'rate_pro_ai_ip_window',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: AI generate — IP window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'The time period used for the AI IP limit above. 3600 seconds = 1 hour.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 3600,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_ai_admin_uid_max',
		'key'         => 'rate_pro_ai_admin_uid_max',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: AI generate (admin) — max per user per window', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'Extra limit for logged-in admins generating email copy in settings. Example: 60 per hour per user.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 60,
	);
	$extra[] = array(
		'name'        => 'wallregi_rate_pro_ai_admin_uid_window',
		'key'         => 'rate_pro_ai_admin_uid_window',
		'sec_name'    => $pro_sec_name,
		'sec_key'     => $pro_sec_key,
		'label'       => __( 'Pro: AI generate (admin) — user window (seconds)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'description' => __( 'The time period used for the admin AI user limit above.', 'wallet-ready-gift-cards-for-woocommerce' ),
		'type'        => 'number',
		'default'     => 3600,
	);

	return array_merge( $fields, $extra );
}

/**
 * Register admin tab + sidebar + cron prune.
 *
 * @param array<string, string> $tabs Tab slug => template path relative to plugin dir.
 * @return array<string, string>
 */
function wallregi_security_filter_admin_dashboard_tabs( $tabs ) {
	if ( ! is_array( $tabs ) ) {
		$tabs = array();
	}
	$tabs['wallregi_security'] = 'backend/templates/security/audit-log.php';

	return $tabs;
}

/**
 * Sidebar link for audit log.
 *
 * @param array<int, array<string, mixed>> $menus Menus.
 * @return array<int, array<string, mixed>>
 */
function wallregi_security_filter_sidebar_menu_items( $menus ) {
	if ( ! is_array( $menus ) ) {
		return $menus;
	}
	$insert = array(
		'type'  => 'link',
		'tab'   => 'wallregi_security',
		'icon'  => 'dashicons-shield',
		'label' => __( 'Security log', 'wallet-ready-gift-cards-for-woocommerce' ),
	);
	$out    = array();
	foreach ( $menus as $m ) {
		$out[] = $m;
		if ( isset( $m['type'], $m['tab'] ) && 'link' === $m['type'] && 'wallregi_dashboard' === $m['tab'] ) {
			$out[] = $insert;
		}
	}

	return $out;
}

// --- Rate limit filters (return false to block) ---

/**
 * @param bool  $allow Default true.
 * @param array $ctx   Keys: code.
 */
function wallregi_security_allow_apply_giftcard_coupon_ajax( $allow, $ctx ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_apply_coupon_max', (int) $d['rate_apply_coupon_max'] );
	$win = wallregi_security_rate_setting( 'rate_apply_coupon_window', (int) $d['rate_apply_coupon_window'] );
	$ip  = wallregi_security_get_ip();

	if ( ! wallregi_security_rate_consume( 'apply_coupon_ip', $ip, $max, $win ) ) {
		wallregi_security_audit_log(
			'apply_giftcard_coupon_ajax',
			'blocked',
			array(
				'detail'     => 'rate_limit_ip',
				'identifier' => wallregi_security_redact_code( (string) ( $ctx['code'] ?? '' ) ),
			)
		);

		return false;
	}

	if ( is_user_logged_in() ) {
		$uid = (string) get_current_user_id();
		if ( ! wallregi_security_rate_consume( 'apply_coupon_uid', $uid, $max, $win ) ) {
			wallregi_security_audit_log(
				'apply_giftcard_coupon_ajax',
				'blocked',
				array(
					'detail'     => 'rate_limit_user',
					'identifier' => wallregi_security_redact_code( (string) ( $ctx['code'] ?? '' ) ),
				)
			);

			return false;
		}
	}

	return true;
}

/**
 * @param bool  $allow Default true.
 * @param array $ctx   Keys: code.
 */
function wallregi_security_allow_apply_giftcard_from_query( $allow, $ctx ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_apply_query_max', (int) $d['rate_apply_query_max'] );
	$win = wallregi_security_rate_setting( 'rate_apply_query_window', (int) $d['rate_apply_query_window'] );
	$ip  = wallregi_security_get_ip();

	if ( ! wallregi_security_rate_consume( 'apply_query_ip', $ip, $max, $win ) ) {
		wallregi_security_audit_log(
			'apply_giftcard_coupon_query',
			'blocked',
			array(
				'detail'     => 'rate_limit_ip',
				'identifier' => wallregi_security_redact_code( (string) ( $ctx['code'] ?? '' ) ),
			)
		);

		return false;
	}

	return true;
}

/**
 * @param bool  $allow Default true.
 * @param array $ctx   Keys: giftcards (decoded array).
 */
function wallregi_security_allow_giftcard_form_submit( $allow, $ctx ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d        = wallregi_security_default_settings();
	$max_ip   = wallregi_security_rate_setting( 'rate_giftcard_form_max', (int) $d['rate_giftcard_form_max'] );
	$win_ip   = wallregi_security_rate_setting( 'rate_giftcard_form_window', (int) $d['rate_giftcard_form_window'] );
	$max_em   = wallregi_security_rate_setting( 'rate_giftcard_form_email_max', (int) $d['rate_giftcard_form_email_max'] );
	$win_em   = wallregi_security_rate_setting( 'rate_giftcard_form_email_window', (int) $d['rate_giftcard_form_email_window'] );
	$ip       = wallregi_security_get_ip();
	$giftcards = isset( $ctx['giftcards'] ) && is_array( $ctx['giftcards'] ) ? $ctx['giftcards'] : array();

	if ( ! wallregi_security_rate_consume( 'giftcard_form_ip', $ip, $max_ip, $win_ip ) ) {
		wallregi_security_audit_log(
			'giftcard_form_add_to_cart',
			'blocked',
			array( 'detail' => 'rate_limit_ip' )
		);

		return false;
	}

	foreach ( wallregi_security_collect_receiver_emails_from_giftcards( $giftcards ) as $email ) {
		if ( ! wallregi_security_rate_consume( 'giftcard_form_email', $email, $max_em, $win_em ) ) {
			wallregi_security_audit_log(
				'giftcard_form_add_to_cart',
				'blocked',
				array(
					'detail'     => 'rate_limit_email',
					'identifier' => $email,
				)
			);

			return false;
		}
	}

	return true;
}

/**
 * @param bool  $allow Default true.
 * @param array $ctx   Keys: receiver_email (optional).
 */
function wallregi_security_allow_cart_giftcard_update( $allow, $ctx ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_cart_update_max', (int) $d['rate_cart_update_max'] );
	$win = wallregi_security_rate_setting( 'rate_cart_update_window', (int) $d['rate_cart_update_window'] );
	$ip  = wallregi_security_get_ip();

	if ( ! wallregi_security_rate_consume( 'cart_update_ip', $ip, $max, $win ) ) {
		wallregi_security_audit_log( 'giftcard_cart_update', 'blocked', array( 'detail' => 'rate_limit_ip' ) );

		return false;
	}

	$email = isset( $ctx['receiver_email'] ) ? sanitize_email( (string) $ctx['receiver_email'] ) : '';
	if ( $email && is_email( $email ) ) {
		if ( ! wallregi_security_rate_consume( 'cart_update_email', strtolower( $email ), $max, $win ) ) {
			wallregi_security_audit_log(
				'giftcard_cart_update',
				'blocked',
				array(
					'detail'     => 'rate_limit_email',
					'identifier' => strtolower( $email ),
				)
			);

			return false;
		}
	}

	return true;
}

/**
 * @param bool $allow Default true.
 */
function wallregi_security_allow_admin_check_code( $allow ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_admin_check_code_max', (int) $d['rate_admin_check_code_max'] );
	$win = wallregi_security_rate_setting( 'rate_admin_check_code_window', (int) $d['rate_admin_check_code_window'] );
	$uid = (string) get_current_user_id();

	if ( ! wallregi_security_rate_consume( 'admin_check_code', $uid, $max, $win ) ) {
		wallregi_security_audit_log(
			'admin_check_giftcard_exists',
			'blocked',
			array( 'detail' => 'rate_limit_user' )
		);

		return false;
	}

	return true;
}

/**
 * @param bool $allow Default true.
 */
function wallregi_security_allow_admin_manual_save( $allow ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_admin_manual_save_max', (int) $d['rate_admin_manual_save_max'] );
	$win = wallregi_security_rate_setting( 'rate_admin_manual_save_window', (int) $d['rate_admin_manual_save_window'] );
	$uid = (string) get_current_user_id();

	if ( ! wallregi_security_rate_consume( 'admin_manual_save', $uid, $max, $win ) ) {
		wallregi_security_audit_log(
			'admin_manual_giftcard_save',
			'blocked',
			array( 'detail' => 'rate_limit_user' )
		);

		return false;
	}

	return true;
}

/**
 * Admin: apply gift card when editing an order in wp-admin.
 *
 * @param bool  $allow Default true.
 * @param array $ctx   Keys: order_id (optional), giftcard_code (optional).
 */
function wallregi_security_allow_admin_order_apply_giftcard( $allow, $ctx ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_admin_order_apply_max', (int) $d['rate_admin_order_apply_max'] );
	$win = wallregi_security_rate_setting( 'rate_admin_order_apply_window', (int) $d['rate_admin_order_apply_window'] );
	$uid = (string) get_current_user_id();

	if ( ! wallregi_security_rate_consume( 'admin_order_apply_gc', $uid, $max, $win ) ) {
		wallregi_security_audit_log(
			'admin_order_apply_giftcard',
			'blocked',
			array(
				'detail'     => 'rate_limit_user',
				'order_id'   => isset( $ctx['order_id'] ) ? absint( $ctx['order_id'] ) : 0,
				'identifier' => wallregi_security_redact_code( (string) ( $ctx['giftcard_code'] ?? '' ) ),
			)
		);

		return false;
	}

	return true;
}

/**
 * Pro: WooCommerce REST wc/v3 gift card read endpoints (per IP, shared quota).
 *
 * @param bool  $allow Default true.
 * @param array $ctx   Keys: route (lookup|transactions), giftcard_number (optional).
 */
function wallregi_security_allow_pro_rest_giftcard_read( $allow, $ctx ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_pro_rest_giftcard_max', (int) $d['rate_pro_rest_giftcard_max'] );
	$win = wallregi_security_rate_setting( 'rate_pro_rest_giftcard_window', (int) $d['rate_pro_rest_giftcard_window'] );
	$ip  = wallregi_security_get_ip();

	if ( ! wallregi_security_rate_consume( 'pro_rest_gc_ip', $ip, $max, $win ) ) {
		$route = isset( $ctx['route'] ) ? sanitize_key( (string) $ctx['route'] ) : 'read';
		wallregi_security_audit_log(
			'pro_rest_giftcard_' . $route,
			'blocked',
			array(
				'detail'     => 'rate_limit_ip',
				'identifier' => wallregi_security_redact_code( (string) ( $ctx['giftcard_number'] ?? '' ) ),
			)
		);

		return false;
	}

	return true;
}

/**
 * @param bool $allow Default true.
 */
function wallregi_security_allow_pro_bulk_validate( $allow ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_pro_bulk_validate_max', (int) $d['rate_pro_bulk_validate_max'] );
	$win = wallregi_security_rate_setting( 'rate_pro_bulk_validate_window', (int) $d['rate_pro_bulk_validate_window'] );
	$uid = (string) get_current_user_id();

	if ( ! wallregi_security_rate_consume( 'pro_bulk_validate', $uid, $max, $win ) ) {
		wallregi_security_audit_log( 'pro_bulk_csv_validate', 'blocked', array( 'detail' => 'rate_limit_user' ) );

		return false;
	}

	return true;
}

/**
 * @param bool $allow Default true.
 */
function wallregi_security_allow_pro_bulk_queue( $allow ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_pro_bulk_queue_max', (int) $d['rate_pro_bulk_queue_max'] );
	$win = wallregi_security_rate_setting( 'rate_pro_bulk_queue_window', (int) $d['rate_pro_bulk_queue_window'] );
	$uid = (string) get_current_user_id();

	if ( ! wallregi_security_rate_consume( 'pro_bulk_queue', $uid, $max, $win ) ) {
		wallregi_security_audit_log( 'pro_bulk_csv_queue', 'blocked', array( 'detail' => 'rate_limit_user' ) );

		return false;
	}

	return true;
}

/**
 * @param bool $allow Default true.
 */
function wallregi_security_allow_pro_bulk_status( $allow ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_pro_bulk_status_max', (int) $d['rate_pro_bulk_status_max'] );
	$win = wallregi_security_rate_setting( 'rate_pro_bulk_status_window', (int) $d['rate_pro_bulk_status_window'] );
	$uid = (string) get_current_user_id();

	if ( ! wallregi_security_rate_consume( 'pro_bulk_status', $uid, $max, $win ) ) {
		wallregi_security_audit_log( 'pro_bulk_csv_status', 'blocked', array( 'detail' => 'rate_limit_user' ) );

		return false;
	}

	return true;
}

/**
 * Pro: buyer AJAX image upload (IP; extra user bucket when logged in).
 *
 * @param bool  $allow Default true.
 * @param array $ctx   Keys: user_logged_in (bool).
 */
function wallregi_security_allow_pro_buyer_image_upload( $allow, $ctx ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d       = wallregi_security_default_settings();
	$max_ip  = wallregi_security_rate_setting( 'rate_pro_upload_ip_max', (int) $d['rate_pro_upload_ip_max'] );
	$win_ip  = wallregi_security_rate_setting( 'rate_pro_upload_ip_window', (int) $d['rate_pro_upload_ip_window'] );
	$ip      = wallregi_security_get_ip();
	$logged  = ! empty( $ctx['user_logged_in'] );

	if ( ! wallregi_security_rate_consume( 'pro_upload_ip', $ip, $max_ip, $win_ip ) ) {
		wallregi_security_audit_log( 'pro_buyer_image_upload', 'blocked', array( 'detail' => 'rate_limit_ip' ) );

		return false;
	}

	if ( $logged ) {
		$max_u = wallregi_security_rate_setting( 'rate_pro_upload_uid_max', (int) $d['rate_pro_upload_uid_max'] );
		$win_u = wallregi_security_rate_setting( 'rate_pro_upload_uid_window', (int) $d['rate_pro_upload_uid_window'] );
		$uid   = (string) get_current_user_id();
		if ( $uid && ! wallregi_security_rate_consume( 'pro_upload_uid', $uid, $max_u, $win_u ) ) {
			wallregi_security_audit_log( 'pro_buyer_image_upload', 'blocked', array( 'detail' => 'rate_limit_user' ) );

			return false;
		}
	}

	return true;
}

/**
 * @param bool $allow Default true.
 */
function wallregi_security_allow_pro_image_cleanup_ajax( $allow ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_pro_image_cleanup_max', (int) $d['rate_pro_image_cleanup_max'] );
	$win = wallregi_security_rate_setting( 'rate_pro_image_cleanup_window', (int) $d['rate_pro_image_cleanup_window'] );
	$uid = (string) get_current_user_id();

	if ( ! wallregi_security_rate_consume( 'pro_image_cleanup', $uid, $max, $win ) ) {
		wallregi_security_audit_log( 'pro_image_cleanup_manual', 'blocked', array( 'detail' => 'rate_limit_user' ) );

		return false;
	}

	return true;
}

/**
 * Pro: AI generate AJAX (greeting + email copy).
 *
 * @param bool  $allow Default true.
 * @param array $ctx   Keys: context (storefront|admin), task (optional).
 */
function wallregi_security_allow_pro_ai_generate( $allow, $ctx ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d      = wallregi_security_default_settings();
	$max_ip = wallregi_security_rate_setting( 'rate_pro_ai_ip_max', (int) $d['rate_pro_ai_ip_max'] );
	$win_ip = wallregi_security_rate_setting( 'rate_pro_ai_ip_window', (int) $d['rate_pro_ai_ip_window'] );
	$ip     = wallregi_security_get_ip();

	if ( ! wallregi_security_rate_consume( 'pro_ai_ip', $ip, $max_ip, $win_ip ) ) {
		wallregi_security_audit_log(
			'pro_ai_generate',
			'blocked',
			array(
				'detail'  => 'rate_limit_ip',
				'context' => sanitize_key( (string) ( $ctx['context'] ?? '' ) ),
				'task'    => sanitize_key( (string) ( $ctx['task'] ?? '' ) ),
			)
		);

		return false;
	}

	$context = sanitize_key( (string) ( $ctx['context'] ?? 'storefront' ) );
	if ( 'admin' === $context && is_user_logged_in() ) {
		$max_u = wallregi_security_rate_setting( 'rate_pro_ai_admin_uid_max', (int) $d['rate_pro_ai_admin_uid_max'] );
		$win_u = wallregi_security_rate_setting( 'rate_pro_ai_admin_uid_window', (int) $d['rate_pro_ai_admin_uid_window'] );
		$uid   = (string) get_current_user_id();
		if ( $uid && ! wallregi_security_rate_consume( 'pro_ai_admin_uid', $uid, $max_u, $win_u ) ) {
			wallregi_security_audit_log(
				'pro_ai_generate',
				'blocked',
				array(
					'detail'  => 'rate_limit_user',
					'context' => 'admin',
					'task'    => sanitize_key( (string) ( $ctx['task'] ?? '' ) ),
				)
			);

			return false;
		}
	}

	return true;
}

/**
 * Pro: gift card top-up lookup / add-to-cart (per IP).
 *
 * @param bool  $allow Default true.
 * @param array $ctx   Context.
 */
function wallregi_security_allow_pro_topup_lookup( $allow, $ctx ) {
	unset( $ctx );
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_pro_topup_lookup_max', (int) $d['rate_pro_topup_lookup_max'] );
	$win = wallregi_security_rate_setting( 'rate_pro_topup_lookup_window', (int) $d['rate_pro_topup_lookup_window'] );
	$ip  = wallregi_security_get_ip();

	if ( ! wallregi_security_rate_consume( 'pro_topup_ip', $ip, $max, $win ) ) {
		wallregi_security_audit_log(
			'pro_topup_lookup',
			'blocked',
			array(
				'detail' => 'rate_limit_ip',
			)
		);

		return false;
	}

	return true;
}

/**
 * Pro: public expiry reminder unsubscribe link (per IP).
 *
 * @param bool  $allow Default true.
 * @param array $ctx   Unused; reserved for extensions.
 */
function wallregi_security_allow_pro_expiry_unsubscribe( $allow, $ctx ) {
	if ( ! $allow || ! wallregi_security_is_enabled() ) {
		return (bool) $allow;
	}

	$d   = wallregi_security_default_settings();
	$max = wallregi_security_rate_setting( 'rate_pro_expiry_unsub_ip_max', (int) $d['rate_pro_expiry_unsub_ip_max'] );
	$win = wallregi_security_rate_setting( 'rate_pro_expiry_unsub_ip_window', (int) $d['rate_pro_expiry_unsub_ip_window'] );
	$ip  = wallregi_security_get_ip();

	if ( ! wallregi_security_rate_consume( 'pro_expiry_unsub_ip', $ip, $max, $win ) ) {
		wallregi_security_audit_log( 'pro_expiry_unsubscribe', 'blocked', array( 'detail' => 'rate_limit_ip' ) );

		return false;
	}

	return true;
}

add_filter( 'wallregi_settings_input_fields', 'wallregi_security_filter_settings_input_fields', 20, 2 );
add_filter( 'wallregi_admin_dashboard_tabs', 'wallregi_security_filter_admin_dashboard_tabs' );
add_filter( 'wallregi_sidebar_menu_items', 'wallregi_security_filter_sidebar_menu_items', 15 );

add_filter( 'wallregi_security_allow_apply_giftcard_coupon_ajax', 'wallregi_security_allow_apply_giftcard_coupon_ajax', 10, 2 );
add_filter( 'wallregi_security_allow_apply_giftcard_from_query', 'wallregi_security_allow_apply_giftcard_from_query', 10, 2 );
add_filter( 'wallregi_security_allow_giftcard_form_submit', 'wallregi_security_allow_giftcard_form_submit', 10, 2 );
add_filter( 'wallregi_security_allow_cart_giftcard_update', 'wallregi_security_allow_cart_giftcard_update', 10, 2 );
add_filter( 'wallregi_security_allow_admin_check_code', 'wallregi_security_allow_admin_check_code', 10, 1 );
add_filter( 'wallregi_security_allow_admin_manual_save', 'wallregi_security_allow_admin_manual_save', 10, 1 );
add_filter( 'wallregi_security_allow_admin_order_apply_giftcard', 'wallregi_security_allow_admin_order_apply_giftcard', 10, 2 );

add_filter( 'wallregi_security_allow_pro_rest_giftcard_read', 'wallregi_security_allow_pro_rest_giftcard_read', 10, 2 );
add_filter( 'wallregi_security_allow_pro_bulk_validate', 'wallregi_security_allow_pro_bulk_validate', 10, 1 );
add_filter( 'wallregi_security_allow_pro_bulk_queue', 'wallregi_security_allow_pro_bulk_queue', 10, 1 );
add_filter( 'wallregi_security_allow_pro_bulk_status', 'wallregi_security_allow_pro_bulk_status', 10, 1 );
add_filter( 'wallregi_security_allow_pro_buyer_image_upload', 'wallregi_security_allow_pro_buyer_image_upload', 10, 2 );
add_filter( 'wallregi_security_allow_pro_image_cleanup_ajax', 'wallregi_security_allow_pro_image_cleanup_ajax', 10, 1 );
add_filter( 'wallregi_security_allow_pro_expiry_unsubscribe', 'wallregi_security_allow_pro_expiry_unsubscribe', 10, 2 );
add_filter( 'wallregi_security_allow_pro_ai_generate', 'wallregi_security_allow_pro_ai_generate', 10, 2 );
add_filter( 'wallregi_security_allow_pro_topup_lookup', 'wallregi_security_allow_pro_topup_lookup', 10, 2 );

add_action( 'wallregi_after_expire_giftcards_cron', 'wallregi_security_prune_audit_log' );

/**
 * Ensure audit table exists on upgrades (activation already runs dbDelta).
 *
 * @return void
 */
function wallregi_security_ensure_audit_table() {
	global $wpdb;

	$candidate = wallregi_security_audit_db_table_name();
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time table presence check.
	$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $candidate ) );
	if ( $found === $candidate ) {
		return;
	}
	if ( function_exists( 'wallregi_create_database_tables' ) ) {
		wallregi_create_database_tables();
	}
}

add_action( 'plugins_loaded', 'wallregi_security_ensure_audit_table', 1 );
