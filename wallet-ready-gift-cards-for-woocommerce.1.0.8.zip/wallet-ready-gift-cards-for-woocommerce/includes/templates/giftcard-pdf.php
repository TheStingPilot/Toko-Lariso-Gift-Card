<?php
if (!defined('ABSPATH')) {
    exit;
}
// Include the DOMPDF library using the correct path to autoload
require_once WALLREGI_PLUGIN_DIR . 'vendor/autoload.php';
require_once WALLREGI_PLUGIN_DIR . 'includes/wallregi-pdf-codes.php';

// Start DOMPDF
use Dompdf\Dompdf;
use Dompdf\Options;

if (!function_exists('wallregi_sanitize_css_declaration_block')) {
    /**
     * Sanitize CSS declaration fragments for server-side PDF output.
     *
     * We avoid safecss_filter_attr() here: it is tuned for inline HTML style attributes and
     * strips or rewrites many valid rules (e.g. border-top/bottom, dashed/solid), which breaks
     * Dompdf rendering vs. backend settings. Instead we strip tags, control characters, and
     * known dangerous patterns only.
     *
     * @param mixed $declaration Raw declaration string.
     * @return string
     */
    function wallregi_sanitize_css_declaration_block($declaration)
    {
        if (!is_string($declaration)) {
            return '';
        }

        $declaration = wp_strip_all_tags($declaration);
        $declaration = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $declaration);

        $dangerous = array(
            '/expression\s*\(/i',
            '/@import\b/i',
            '/@charset\b/i',
            '/@namespace\b/i',
            '/<\/style/i',
            '/<script/i',
            '/javascript\s*:/i',
            '/-moz-binding\s*:/i',
            '/behavior\s*:/i',
            '/binding\s*:/i',
            '/url\s*\(\s*[\'"]?\s*javascript:/i',
            '/url\s*\(\s*[\'"]?\s*data\s*:\s*text\/html/i',
        );
        foreach ($dangerous as $pattern) {
            $declaration = preg_replace($pattern, '', $declaration);
        }

        $declaration = is_string($declaration) ? trim($declaration) : '';
        $max_len = 200000;
        if (strlen($declaration) > $max_len) {
            $declaration = substr($declaration, 0, $max_len);
        }

        return $declaration;
    }
}

/**
 * Build the CSS used for the gift card PDF.
 *
 * This keeps the CSS generation in a dedicated function instead of inside
 * the HTML string, which is preferred for code clarity and reviews.
 *
 * Note: WordPress style enqueue functions such as wp_register_style() or
 * wp_add_inline_style() are designed for browser output and are not
 * executed when Dompdf renders this standalone HTML for the PDF. For that
 * reason we generate the stylesheet here and inject it into the PDF HTML.
 *
 * @param string $wallregi_pdf_header_style_border_css
 * @param string $wallregi_pdf_header_style_padding_css
 * @param string $wallregi_pdf_header_style_margin_css
 * @param string $wallregi_pdf_header_box_shadow_css
 * @param string $wallregi_pdf_content_style_border_css
 * @param string $wallregi_pdf_content_style_padding_css
 * @param string $wallregi_pdf_content_style_margin_css
 * @param array  $wallregi_pdf_title_text_style_group
 * @param string $wallregi_pdf_title_text_style_margin_css
 * @param array  $wallregi_pdf_giftcard_price_style_group
 * @param string $wallregi_pdf_giftcard_price_style_border_css
 * @param string $wallregi_pdf_giftcard_price_style_padding_css
 * @param string $wallregi_pdf_giftcard_price_style_margin_css
 * @param array  $wallregi_pdf_preview_mgs_style_group
 * @param string $wallregi_pdf_preview_mgs_style_border_css
 * @param string $wallregi_pdf_preview_mgs_style_padding_css
 * @param string $wallregi_pdf_preview_mgs_style_margin_css
 * @param array  $wallregi_pdf_footer_styles_group
 * @param string $wallregi_pdf_footer_border_css
 * @param string $wallregi_pdf_footer_padding_css
 * @param string $wallregi_pdf_footer_margin_css
 * @param string $wallregi_pdf_scannable_code_type none|barcode|qr|pdf417 — .pdf_preview_mgs height: none 400px, barcode 350px, pdf417 310px, qr 270px.
 *
 * @return string
 */
function wallregi_get_giftcard_pdf_inline_css(
    $wallregi_pdf_header_style_border_css,
    $wallregi_pdf_header_style_padding_css,
    $wallregi_pdf_header_style_margin_css,
    $wallregi_pdf_header_box_shadow_css,
    $wallregi_pdf_content_style_border_css,
    $wallregi_pdf_content_style_padding_css,
    $wallregi_pdf_content_style_margin_css,
    $wallregi_pdf_title_text_style_group,
    $wallregi_pdf_title_text_style_margin_css,
    $wallregi_pdf_giftcard_price_style_group,
    $wallregi_pdf_giftcard_price_style_border_css,
    $wallregi_pdf_giftcard_price_style_padding_css,
    $wallregi_pdf_giftcard_price_style_margin_css,
    $wallregi_pdf_preview_mgs_style_group,
    $wallregi_pdf_preview_mgs_style_border_css,
    $wallregi_pdf_preview_mgs_style_padding_css,
    $wallregi_pdf_preview_mgs_style_margin_css,
    $wallregi_pdf_footer_styles_group,
    $wallregi_pdf_footer_border_css,
    $wallregi_pdf_footer_padding_css,
    $wallregi_pdf_footer_margin_css,
    $wallregi_pdf_scannable_code_type = 'none'
) {
    $wallregi_pdf_header_style_border_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_header_style_border_css);
    $wallregi_pdf_header_style_padding_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_header_style_padding_css);
    $wallregi_pdf_header_style_margin_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_header_style_margin_css);
    $wallregi_pdf_header_box_shadow_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_header_box_shadow_css);
    $wallregi_pdf_content_style_border_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_content_style_border_css);
    $wallregi_pdf_content_style_padding_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_content_style_padding_css);
    $wallregi_pdf_content_style_margin_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_content_style_margin_css);
    $wallregi_pdf_title_text_style_margin_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_title_text_style_margin_css);
    $wallregi_pdf_giftcard_price_style_border_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_giftcard_price_style_border_css);
    $wallregi_pdf_giftcard_price_style_padding_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_giftcard_price_style_padding_css);
    $wallregi_pdf_giftcard_price_style_margin_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_giftcard_price_style_margin_css);
    $wallregi_pdf_preview_mgs_style_border_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_preview_mgs_style_border_css);
    $wallregi_pdf_preview_mgs_style_padding_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_preview_mgs_style_padding_css);
    $wallregi_pdf_preview_mgs_style_margin_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_preview_mgs_style_margin_css);
    $wallregi_pdf_footer_border_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_footer_border_css);
    $wallregi_pdf_footer_padding_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_footer_padding_css);
    $wallregi_pdf_footer_margin_css = wallregi_sanitize_css_declaration_block($wallregi_pdf_footer_margin_css);

    $wallregi_pdf_scannable_code_type = sanitize_text_field((string) $wallregi_pdf_scannable_code_type);
    if ('qr' === $wallregi_pdf_scannable_code_type) {
        $pdf_preview_mgs_height_px = 270;
    } elseif ('barcode' === $wallregi_pdf_scannable_code_type) {
        $pdf_preview_mgs_height_px = 350;
    } elseif ('pdf417' === $wallregi_pdf_scannable_code_type) {
        $pdf_preview_mgs_height_px = 310;
    } elseif ('barcode_qr' === $wallregi_pdf_scannable_code_type) {
        $pdf_preview_mgs_height_px = 240;
    } else {
        $pdf_preview_mgs_height_px = 400;
    }

    $css = "@page {\n";
    $css .= "    margin: 0;\n";
    $css .= "    size: A4;\n";
    $css .= "}\n";
    $css .= "body {\n";
    $css .= "    margin: 0;\n";
    $css .= "    font-family: 'DejaVu Sans', sans-serif;\n";
    $css .= "    word-wrap: break-word;\n";
    $css .= "    overflow-wrap: break-word;\n";
    $css .= "    word-break: break-word;\n";
    $css .= "}\n";
    $css .= "table.table_wrap, .table_wrap, .wallregi_giftcard__card {\n";
    $css .= "    width: 100%;\n";
    $css .= "    border-collapse: collapse;\n";
    $css .= "}\n";
    $css .= ".wallregi_pdf_container {\n";
    $css .= "    width: 100%;\n";
    $css .= "    page-break-inside: auto;\n";
    $css .= "    break-inside: auto;\n";
    $css .= "}\n";

    $css .= ".image-container, .wallregi_card__header {\n";
    $css .= "    display: block;\n";
    $css .= "    page-break-inside: avoid;\n";
    $css .= "    break-inside: avoid;\n";
    $css .= '    ' . $wallregi_pdf_header_style_border_css . "\n";
    $css .= '    ' . $wallregi_pdf_header_style_padding_css . "\n";
    $css .= '    ' . $wallregi_pdf_header_style_margin_css . "\n";
    $css .= '    ' . $wallregi_pdf_header_box_shadow_css . "\n";
    $css .= "}\n";

    $css .= ".image-container img, .wallregi_card__header img {\n";
    $css .= "    width: 100%;\n";
    $css .= "    margin: 0 auto;\n";
    $css .= "    max-height: 400px;\n";
    $css .= "    display: block;\n";
    $css .= "}\n";

    $css .= ".pdf_content_body, .wallregi_card__body, .content_box {\n";
    $css .= "    display: block;\n";
    $css .= "    width: 100%;\n";
    $css .= "    page-break-inside: auto;\n";
    $css .= "    break-inside: auto;\n";
    $css .= '    ' . $wallregi_pdf_content_style_border_css . "\n";
    $css .= '    ' . $wallregi_pdf_content_style_padding_css . "\n";
    $css .= '    ' . $wallregi_pdf_content_style_margin_css . "\n";
    $css .= "}\n";

    $css .= ".pdf_heading, .wallregi_title {\n";
    $css .= '    color: ' . esc_attr($wallregi_pdf_title_text_style_group['pdf_title_text_style_text_color'] ?? '#333333') . ";\n";
    $css .= '    font-size: ' . intval($wallregi_pdf_title_text_style_group['pdf_title_text_style_font_size'] ?? 24) . "px;\n";
    $css .= '    font-weight: ' . esc_attr($wallregi_pdf_title_text_style_group['pdf_title_text_style_font_weight'] ?? 'bold') . ";\n";
    $css .= '    text-align: ' . esc_attr($wallregi_pdf_title_text_style_group['pdf_title_text_style_text_align'] ?? 'center') . ";\n";
    $css .= '    text-transform: ' . esc_attr($wallregi_pdf_title_text_style_group['pdf_title_text_style_text_transform'] ?? 'none') . ";\n";
    $css .= "    word-wrap: break-word;\n";
    $css .= "    overflow-wrap: break-word;\n";
    $css .= "    word-break: break-word;\n";
    $css .= "    word-break: break-all;\n";
    $css .= "    page-break-inside: avoid;\n";
    $css .= "    break-inside: avoid;\n";
    $css .= '    ' . $wallregi_pdf_title_text_style_margin_css . "\n";
    $css .= "}\n";

    $css .= ".pdf_price, .wallregi_price {\n";
    $css .= '    color: ' . esc_attr($wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_text_color'] ?? '#333333') . ";\n";
    $css .= '    font-size: ' . intval($wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_font_size'] ?? 20) . "px;\n";
    $css .= '    font-weight: ' . esc_attr($wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_font_weight'] ?? 'bold') . ";\n";
    $css .= '    text-align: ' . esc_attr($wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_text_align'] ?? 'center') . ";\n";
    $css .= "    page-break-inside: avoid;\n";
    $css .= "    break-inside: avoid;\n";
    $css .= '    ' . $wallregi_pdf_giftcard_price_style_border_css . "\n";
    $css .= '    ' . $wallregi_pdf_giftcard_price_style_padding_css . "\n";
    $css .= '    ' . $wallregi_pdf_giftcard_price_style_margin_css . "\n";
    $css .= "    display: inline-block;\n";
    $css .= "}\n";

    $css .= ".pdf_price_wrap, .wallregi_card__price {\n";
    $css .= "    page-break-inside: avoid;\n";
    $css .= "    break-inside: avoid;\n";
    $css .= "}\n";

    $css .= ".currency-symbol {\n";
    $css .= "    font-family: 'DejaVu Sans', 'Noto Sans Symbols', sans-serif;\n";
    $css .= "}\n";
    $css .= ".currency-symbol img {\n";
    $css .= "    height: 1em;\n";
    $css .= "    width: auto;\n";
    $css .= "    vertical-align: -0.125em;\n";
    $css .= "    display: inline-block;\n";
    $css .= "}\n";

    $css .= ".pdf_extra_info {\n";
    $css .= "    text-align: center;\n";
    $css .= "    font-size: 14px;\n";
    $css .= "    margin-bottom: 5px;\n";
    $css .= "    word-wrap: break-word;\n";
    $css .= "    overflow-wrap: break-word;\n";
    $css .= "    word-break: break-word;\n";
    $css .= "    word-break: break-all;\n";
    $css .= "    page-break-inside: avoid;\n";
    $css .= "    break-inside: avoid;\n";
    $css .= "}\n";
    $css .= ".pdf_extra_info .label_text {\n";
    $css .= "    color: #909090;\n";
    $css .= "}\n";
    $css .= ".pdf_extra_info .dynamic_value {\n";
    $css .= "    color: #333333;\n";
    $css .= "    font-weight: 600;\n";
    $css .= "}\n";

    $css .= ".pdf_preview_mgs, .wallregi_preview__mgs {\n";
    $css .= "    min-height: 40px;\n";
    $css .= "    height: auto;\n";
    $css .= '    color: ' . esc_attr($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_text_color'] ?? '#333333') . ";\n";
    $css .= '    font-size: ' . intval($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_font_size'] ?? 16) . "px;\n";
    $css .= '    font-weight: ' . esc_attr($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_font_weight'] ?? 'normal') . ";\n";
    $css .= '    text-align: ' . esc_attr($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_text_align'] ?? 'center') . ";\n";
    $css .= '    text-transform: ' . esc_attr($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_text_transform'] ?? 'none') . ";\n";
    $css .= "    word-wrap: break-word;\n";
    $css .= "    overflow-wrap: break-word;\n";
    $css .= "    word-break: break-word;\n";
    $css .= '    word-break: ' . esc_attr($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_word_break'] ?? 'break-all') . ";\n";
    $css .= "    page-break-inside: auto;\n";
    $css .= "    break-inside: auto;\n";
    $css .= '    ' . $wallregi_pdf_preview_mgs_style_border_css . "\n";
    $css .= '    ' . $wallregi_pdf_preview_mgs_style_padding_css . "\n";
    $css .= '    ' . $wallregi_pdf_preview_mgs_style_margin_css . "\n";
    $css .= "}\n";

    $css .= ".pdf_footer, .wallregi_giftcard_footer {\n";
    $css .= '    color: ' . esc_attr($wallregi_pdf_footer_styles_group['pdf_footer_text_color'] ?? '#333333') . ";\n";
    $css .= '    font-size: ' . intval($wallregi_pdf_footer_styles_group['pdf_footer_font_size'] ?? 14) . "px;\n";
    $css .= '    font-weight: ' . esc_attr($wallregi_pdf_footer_styles_group['pdf_footer_font_weight'] ?? 'normal') . ";\n";
    $css .= '    text-align: ' . esc_attr($wallregi_pdf_footer_styles_group['pdf_footer_text_align'] ?? 'center') . ";\n";
    $css .= '    text-transform: ' . esc_attr($wallregi_pdf_footer_styles_group['pdf_footer_text_transform'] ?? 'none') . ";\n";
    $css .= "    word-wrap: break-word;\n";
    $css .= "    overflow-wrap: break-word;\n";
    $css .= "    word-break: break-word;\n";
    $css .= "    word-break: break-all;\n";
    $css .= "    page-break-inside: avoid;\n";
    $css .= "    break-inside: avoid;\n";
    $css .= '    ' . $wallregi_pdf_footer_border_css . "\n";
    $css .= '    ' . $wallregi_pdf_footer_padding_css . "\n";
    $css .= '    ' . $wallregi_pdf_footer_margin_css . "\n";
    $css .= "}\n";

    $css .= ".wallregi-pdf-scannable, .wallregi-preview-scannable {\n";
    $css .= "    text-align: center;\n";
    $css .= "    margin-top: 12px;\n";
    $css .= "    margin-bottom: 8px;\n";
    $css .= "    page-break-inside: avoid;\n";
    $css .= "    break-inside: avoid;\n";
    $css .= "}\n";
    $css .= ".wallregi-pdf-scannable img, .wallregi-preview-scannable img {\n";
    $css .= "    page-break-inside: avoid;\n";
    $css .= "    break-inside: avoid;\n";
    $css .= "}\n";
    $css .= ".wallregi-pdf-scannable--barcode img {\n";
    $css .= "    display: block;\n";
    $css .= "    margin-left: auto;\n";
    $css .= "    margin-right: auto;\n";
    $css .= "    max-width: 250px;\n";
    $css .= "    width: auto;\n";
    $css .= "    max-height: 50px;\n";
    $css .= "    height: 48px;\n";
    $css .= "    object-fit: contain;\n";
    $css .= "}\n";
    $css .= ".wallregi-pdf-scannable--qr img {\n";
    $css .= "    display: block;\n";
    $css .= "    margin-left: auto;\n";
    $css .= "    margin-right: auto;\n";
    $css .= "    width: 120px;\n";
    $css .= "    height: 120px;\n";
    $css .= "    max-width: 120px;\n";
    $css .= "    max-height: 120px;\n";
    $css .= "    object-fit: contain;\n";
    $css .= "}\n";
    $css .= ".wallregi-pdf-scannable--pdf417 img {\n";
    $css .= "    display: block;\n";
    $css .= "    margin-left: auto;\n";
    $css .= "    margin-right: auto;\n";
    $css .= "    max-width: 260px;\n";
    $css .= "    width: auto;\n";
    $css .= "    max-height: 88px;\n";
    $css .= "    height: auto;\n";
    $css .= "    object-fit: contain;\n";
    $css .= "}\n";

    /* Gift Card Logo — PDF styling matching frontend .wallregi_card__logo */
    $css .= ".wallregi_card__logo, .wallregi_card__logo-wrap {\n";
    $css .= "    padding: 15px 10px;\n";
    $css .= "    line-height: 1;\n";
    $css .= "    page-break-inside: avoid;\n";
    $css .= "    break-inside: avoid;\n";
    $css .= "}\n";
    $css .= ".wallregi_card__logo img {\n";
    $css .= "    max-height: 50px;\n";
    $css .= "    max-width: 140px;\n";
    $css .= "    width: auto;\n";
    $css .= "    height: auto;\n";
    $css .= "    display: inline-block;\n";
    $css .= "    object-fit: contain;\n";
    $css .= "}\n";

    /* Gift Card Date — PDF styling matching frontend .wallregi_card__date */
    $css .= ".wallregi_card__date, .wallregi_card__date-wrap {\n";
    $css .= "    font-size: 12px;\n";
    $css .= "    padding: 4px 8px 2px;\n";
    $css .= "    line-height: 1.4;\n";
    $css .= "    page-break-inside: avoid;\n";
    $css .= "    break-inside: avoid;\n";
    $css .= "}\n";
    $css .= ".wallregi_card__date .wallregi_date_label {\n";
    $css .= "    color: #888;\n";
    $css .= "}\n";
    $css .= ".wallregi_card__date .wallregi_date_value {\n";
    $css .= "    color: #333;\n";
    $css .= "    font-weight: 600;\n";
    $css .= "}\n";

    /* Scannable Both (Barcode + QR) — PDF layout compatible with Dompdf */
    $css .= ".wallregi-preview-scannable--both, .wallregi-preview-scannable--both {\n";
    $css .= "    display: flex;\n";
    $css .= "    flex-direction: column;\n";
    $css .= "    align-items: center;\n";
    $css .= "    justify-content: center;\n";
    $css .= "    gap: 15px;\n";
    $css .= "    flex-wrap: wrap;\n";
    $css .= "    margin-bottom: 8px;\n";
    $css .= "    page-break-inside: avoid;\n";
    $css .= "    break-inside: avoid;\n";
    $css .= "}\n";

    /**
     * Filter the inline CSS used for the gift card PDF HTML before it is
     * passed to Dompdf.
     *
     * @param string $css The complete CSS string.
     */
    if (function_exists('wallregi_get_giftcard_pdf_rtl_css')) {
        $css .= wallregi_get_giftcard_pdf_rtl_css();
    }

    return apply_filters('wallregi_giftcard_pdf_inline_css', wp_strip_all_tags($css));
}

add_action('init', 'wallregi_check_woocommerce_active', 20);

function wallregi_check_woocommerce_active()
{
    // Check if WooCommerce is active
    if (!class_exists('WooCommerce')) {
        return;
    }
    // Verify nonce

    // If WooCommerce is active, call the function to generate the gift card PDF
    if (isset($_GET['noncekey']) && isset($_GET['giftcode'])) {
        // Verify the nonce

        check_ajax_referer('gcpdf_nonce', 'noncekey');
        $giftcode = sanitize_text_field(wp_unslash($_GET['giftcode']));

        if (!empty($giftcode)) {
            wallregi_generate_giftcard_pdf($giftcode, null);
        }
    }
}

function wallregi_getImageDataUri($url)
{
    // Check if it's local file
    $upload_dir = wp_upload_dir();
    $local_path = str_replace(home_url(), ABSPATH, $url);

    if (file_exists($local_path)) {
        // Local file - read directly
        $type = wp_check_filetype($local_path);
        $data = file_get_contents($local_path);
        return 'data:' . $type['type'] . ';base64,' . base64_encode($data);
    }

    // External URL - fetch with WordPress HTTP API (safe, follows redirects)
    $response = wp_remote_get($url, array(
        'timeout' => 10,
        'limit_response_size' => 5 * 1024 * 1024,  // 5MB max
        'sslverify' => true
    ));

    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
        $data = wp_remote_retrieve_body($response);
        $content_type = wp_remote_retrieve_header($response, 'content-type');
        return 'data:' . $content_type . ';base64,' . base64_encode($data);
    }

    return false;
}

/**
 * Render custom PDF body by replacing dynamic placeholder tags.
 *
 * @param string               $custom_html Custom HTML markup.
 * @param array<string, mixed> $context     Dynamic gift card data.
 * @return string
 */
if (!function_exists('wallregi_render_custom_pdf_body')) {
    function wallregi_render_custom_pdf_body($custom_html, array $context)
    {
        $replacements = [
            '[giftcard_title]' => $context['heading'] ?? '',
            '{{title}}' => $context['heading'] ?? '',
            '{{giftcard_title}}' => $context['heading'] ?? '',
            '[giftcard_price]' => $context['formatted_price'] ?? '',
            '{{price}}' => $context['formatted_price'] ?? '',
            '{{giftcard_price}}' => $context['formatted_price'] ?? '',
            '[giftcard_code]' => $context['gift_code'] ?? '',
            '{{code}}' => $context['gift_code'] ?? '',
            '{{giftcard_code}}' => $context['gift_code'] ?? '',
            '{{card_number}}' => $context['gift_code'] ?? '',
            '[giftcard_image]' => $context['image_html'] ?? '',
            '{{image}}' => $context['image_html'] ?? '',
            '{{giftcard_image}}' => $context['image_html'] ?? '',
            '[giftcard_image_url]' => $context['image_url'] ?? '',
            '{{image_url}}' => $context['image_url'] ?? '',
            '[giftcard_logo]' => $context['logo_html'] ?? '',
            '{{logo}}' => $context['logo_html'] ?? '',
            '{{giftcard_logo}}' => $context['logo_html'] ?? '',
            '[giftcard_scannable]' => $context['scannable_html'] ?? '',
            '{{scannable}}' => $context['scannable_html'] ?? '',
            '[giftcard_qrcode]' => $context['qrcode_html'] ?? '',
            '{{qrcode}}' => $context['qrcode_html'] ?? '',
            '[giftcard_barcode]' => $context['barcode_html'] ?? '',
            '{{barcode}}' => $context['barcode_html'] ?? '',
            '[giftcard_expiry]' => $context['expiry_date'] ?? '',
            '{{expiry}}' => $context['expiry_date'] ?? '',
            '{{expiry_date}}' => $context['expiry_date'] ?? '',
            '[giftcard_date]' => $context['date_html'] ?? '',
            '{{date}}' => $context['date_html'] ?? '',
            '[giftcard_message]' => $context['message'] ?? '',
            '{{message}}' => $context['message'] ?? '',
            '[giftcard_footer]' => $context['short_description'] ?? '',
            '{{footer}}' => $context['short_description'] ?? '',
            '[recipient_name]' => $context['recipient_name'] ?? '',
            '{{recipient_name}}' => $context['recipient_name'] ?? '',
            '[recipient_email]' => $context['recipient_email'] ?? '',
            '{{recipient_email}}' => $context['recipient_email'] ?? '',
            '[sender_name]' => $context['sender_name'] ?? '',
            '{{sender_name}}' => $context['sender_name'] ?? '',
            '[site_title]' => $context['site_title'] ?? '',
            '{{site_title}}' => $context['site_title'] ?? '',
            '[site_url]' => $context['site_url'] ?? '',
            '{{site_url}}' => $context['site_url'] ?? '',
            '[apply_url]' => $context['apply_url'] ?? '',
            '{{apply_url}}' => $context['apply_url'] ?? '',
        ];

        return strtr($custom_html, $replacements);
    }
}

function wallregi_generate_giftcard_pdf($giftcode, $attach_pdf = null)
{
    ob_start();  // Start output buffering

    $gift_code = sanitize_text_field((string) base64_decode($giftcode));

    global $wpdb;

    // Query the gift card data
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
    $giftcard_data = $wpdb->get_row(
        $wpdb->prepare(
            'SELECT * FROM %i WHERE `giftcard_number` = %s',
            wallregi_giftcard_db_table_name(),
            $gift_code
        )
    );

    if (empty($giftcard_data)) {
        return;
    }

    // Extract basic gift card info
    $receiver_name = $giftcard_data->receipent_name ?? '';
    $receiver_email = $giftcard_data->receipent_email ?? '';
    $sender_name = $giftcard_data->sender_name ?? '';
    $giftcard_price = $giftcard_data->current_amount ?? '';
    $giftcard_image_url = $giftcard_data->giftcard_image ?? '';
    $wallregi_expiry_raw = isset($giftcard_data->expiry_date) ? (string) $giftcard_data->expiry_date : '';
    $wallregi_expiry_date = '';
    if ('' !== $wallregi_expiry_raw && '0000-00-00' !== $wallregi_expiry_raw) {
        $wallregi_expiry_ts = strtotime($wallregi_expiry_raw . ' 00:00:00');
        if (false !== $wallregi_expiry_ts) {
            $wallregi_expiry_date = function_exists('wp_date')
                ? wp_date(get_option('date_format'), $wallregi_expiry_ts)
                : date_i18n(get_option('date_format'), $wallregi_expiry_ts);
        }
    }
    $giftcard_message = $giftcard_data->message ?? '';
    $item_id = $giftcard_data->item_id ?? 0;

    $giftcard_heading = '';
    $short_description = '';

    $product_id        = 0;

    if ($item_id > 0) {
        $order_item = new WC_Order_Item_Product($item_id);
        $product_id = $order_item->get_product_id();
        $meta_data  = $order_item->get_meta('_wallregi_giftcard_data');

        if (!empty($meta_data) && is_array($meta_data)) {
            $giftcard_heading = !empty($meta_data['giftcard_heading'])
                ? $meta_data['giftcard_heading']
                : apply_filters('wallregi_default_giftcard_heading', false, $gift_code);

            $short_description = !empty($meta_data['giftcard_short_desc'])
                ? $meta_data['giftcard_short_desc']
                : apply_filters('wallregi_default_giftcard_description', false, $gift_code);
        }
    } else {
        $giftcard_heading = apply_filters('wallregi_default_giftcard_heading', false, $gift_code);
        $short_description = apply_filters('wallregi_default_giftcard_description', false, $gift_code);
    }

    // Currency data
    $currency_position = get_option('woocommerce_currency_pos');  // e.g. left, right
    $wallregi_currency_symbol = get_woocommerce_currency_symbol();
    $currency_code = get_woocommerce_currency();

    $formatted_price = wallregi_format_price($giftcard_price, $wallregi_currency_symbol, $currency_position, $currency_code);

    // Set default values to avoid undefined index warnings
    $wallregi_defaults = [];

    $wallregi_default_files = [
        '../../frontend/default-settings/default-form-settings.php',
        '../../frontend/default-settings/default-pdf-settings.php',
        '../../frontend/default-settings/default-genral-settings.php',
    ];

    foreach ($wallregi_default_files as $wallregi_default_file) {
        $default_file = plugin_dir_path(__FILE__) . $wallregi_default_file;
        if (file_exists($default_file)) {
            $default_values = include $default_file;
            if (is_array($default_values)) {
                $wallregi_defaults = array_merge($wallregi_defaults, $default_values);
            }
        }
    }

    // Get settings options
    $wallregi_settings = get_option('wallregi_settings');
    // Merge saved settings with defaults
    $wallregi_settings = wp_parse_args($wallregi_settings, $wallregi_defaults);

    $wallregi_generate_css_files = [
        'variables' => '../../frontend/dynamic-css/generate-css-variables.php',
        'functions' => '../../frontend/dynamic-css/generate-css-functions.php',
        'spacing' => '../../frontend/dynamic-css/generate-css-spacing.php',
    ];

    foreach ($wallregi_generate_css_files as $wallregi_key => $wallregi_file) {
        // include files
        if (file_exists(plugin_dir_path(__FILE__) . $wallregi_file)) {
            include_once plugin_dir_path(__FILE__) . $wallregi_file;
        }
    }

    $safe_image_url = wallregi_getImageDataUri($giftcard_image_url);
    $safe_heading = esc_html($giftcard_heading);
    $safe_gift_code = esc_html($gift_code);
    $safe_expiry_date = esc_html($wallregi_expiry_date);
    $safe_message = esc_html($giftcard_message);
    $safe_short_description = esc_html($short_description);

    $image = '<img src="' . $safe_image_url . '" alt="' . esc_attr__('Gift card image', 'wallet-ready-gift-cards-for-woocommerce') . '" style="max-height: 400px;"/>';

    $pdf_scannable_code_type = isset($wallregi_settings['pdf_scannable_code_type']) ? sanitize_text_field((string) $wallregi_settings['pdf_scannable_code_type']) : 'none';
    $pdf_barcode_symbology = isset($wallregi_settings['pdf_barcode_symbology']) ? sanitize_text_field((string) $wallregi_settings['pdf_barcode_symbology']) : 'C128';

    // --- Gift Card Logo for PDF ---
    $wallregi_show_logo = ($wallregi_settings['show_card_logo'] ?? 'no') === 'yes';
    $wallregi_logo_align = esc_attr($wallregi_settings['card_logo_position'] ?? 'center');
    $wallregi_pdf_logo_html = '';
    if ($wallregi_show_logo && !empty($wallregi_settings['card_custom_logo'])) {
        // Only render logo in PDF if a custom logo has been explicitly uploaded
        $wallregi_pdf_logo_url = $wallregi_settings['card_custom_logo'];
        $wallregi_safe_logo = wallregi_getImageDataUri($wallregi_pdf_logo_url);
        if ($wallregi_safe_logo) {
            $wallregi_pdf_logo_html =
                '<div class="wallregi_card__logo" style="text-align:' . $wallregi_logo_align . ';">'
                . '<img src="' . esc_attr($wallregi_safe_logo) . '" alt="Logo" />'
                . '</div>';
        }
    }

    // --- Current Date for PDF ---
    $wallregi_show_date = ($wallregi_settings['show_card_date'] ?? 'no') === 'yes';
    $wallregi_date_align = esc_attr($wallregi_settings['card_date_position'] ?? 'left');
    $wallregi_date_label = esc_html($wallregi_settings['card_date_label'] ?? 'Date:');
    $wallregi_pdf_date_html = '';
    if ($wallregi_show_date) {
        $wallregi_pdf_date_html =
            '<div class="wallregi_card__date" style="text-align:' . $wallregi_date_align . ';">'
            . '<span class="wallregi_date_label">' . $wallregi_date_label . ' </span>'
            . '<span class="wallregi_date_value">' . esc_html(date_i18n('d-m-Y')) . '</span>'
            . '</div>';
    }
    $wallregi_pdf_scannable_html = '';
    if ('barcode' === $pdf_scannable_code_type) {
        $bc_uri = wallregi_giftcard_pdf_barcode_data_uri($gift_code, $pdf_barcode_symbology);
        if ('' !== $bc_uri) {
            $wallregi_pdf_scannable_html = '<div class="wallregi-pdf-scannable wallregi-pdf-scannable--barcode"><img src="' . esc_attr($bc_uri) . '" alt="' . esc_attr__('Gift card barcode', 'wallet-ready-gift-cards-for-woocommerce') . '" /></div>';
        }
    } elseif ('qr' === $pdf_scannable_code_type) {
        $apply_url = '';
        if (!empty($giftcard_data->epass_data) && is_string($giftcard_data->epass_data)) {
            $wallregi_epass_decoded = json_decode($giftcard_data->epass_data, true);
            if (is_array($wallregi_epass_decoded) && !empty($wallregi_epass_decoded['passLink'])) {
                $apply_url = trim((string) $wallregi_epass_decoded['passLink']);
            }
        }
        if ('' === $apply_url) {
            $apply_url = wallregi_giftcard_get_apply_checkout_url($gift_code);
        }

        /**
         * Filter QR code target URL on gift card PDFs (e.g. wallet pass link).
         *
         * @param string   $apply_url     Default apply-at-checkout URL.
         * @param string   $gift_code     Gift card number.
         * @param object   $giftcard_data Gift card DB row object.
         */
        $apply_url = apply_filters('wallregi_giftcard_pdf_qr_target_url', $apply_url, $gift_code, $giftcard_data);
        $qr_uri = wallregi_giftcard_pdf_qrcode_data_uri($apply_url);
        if ('' !== $qr_uri) {
            $wallregi_pdf_scannable_html = '<div class="wallregi-pdf-scannable wallregi-pdf-scannable--qr"><img src="' . esc_attr($qr_uri) . '" width="120" height="120" alt="' . esc_attr__('Gift card QR code', 'wallet-ready-gift-cards-for-woocommerce') . '" /></div>';
        }
    } elseif ('pdf417' === $pdf_scannable_code_type) {
        $pdf417_uri = wallregi_giftcard_pdf_pdf417_data_uri($gift_code);
        if ('' !== $pdf417_uri) {
            $wallregi_pdf_scannable_html = '<div class="wallregi-pdf-scannable wallregi-pdf-scannable--pdf417"><img src="' . esc_attr($pdf417_uri) . '" alt="' . esc_attr__('Gift card PDF417', 'wallet-ready-gift-cards-for-woocommerce') . '" /></div>';
        }
    } elseif ('barcode_qr' === $pdf_scannable_code_type) {
        $bc_uri = wallregi_giftcard_pdf_barcode_data_uri($gift_code, $pdf_barcode_symbology);
        $apply_url = '';
        if (!empty($giftcard_data->epass_data) && is_string($giftcard_data->epass_data)) {
            $wallregi_epass_decoded = json_decode($giftcard_data->epass_data, true);
            if (is_array($wallregi_epass_decoded) && !empty($wallregi_epass_decoded['passLink'])) {
                $apply_url = trim((string) $wallregi_epass_decoded['passLink']);
            }
        }
        if ('' === $apply_url) {
            $apply_url = wallregi_giftcard_get_apply_checkout_url($gift_code);
        }
        $apply_url = apply_filters('wallregi_giftcard_pdf_qr_target_url', $apply_url, $gift_code, $giftcard_data);
        $qr_uri = wallregi_giftcard_pdf_qrcode_data_uri($apply_url);
        if ('' !== $bc_uri || '' !== $qr_uri) {
            $wallregi_pdf_scannable_html = '<div class="wallregi-preview-scannable wallregi-preview-scannable--both" style="text-align: center; margin-top: 12px; margin-bottom: 8px;">';
            if ('' !== $qr_uri) {
                $wallregi_pdf_scannable_html .= '<div style="text-align: center;">';
                $wallregi_pdf_scannable_html .= '<img src="' . esc_attr($qr_uri) . '" alt="' . esc_attr__('Gift card QR code', 'wallet-ready-gift-cards-for-woocommerce') . '" width="90" height="90" style="display: inline-block; margin: 0 auto;" />';
                $wallregi_pdf_scannable_html .= '</div>';
            }
            if ('' !== $bc_uri) {
                $wallregi_pdf_scannable_html .= '<div style="text-align: center; margin-bottom: 10px;">';
                $wallregi_pdf_scannable_html .= '<img src="' . esc_attr($bc_uri) . '" alt="' . esc_attr__('Gift card barcode', 'wallet-ready-gift-cards-for-woocommerce') . '" width="200" height="45" style="display: inline-block; margin: 0 auto;" />';
                $wallregi_pdf_scannable_html .= '</div>';
            }
            $wallregi_pdf_scannable_html .= '</div>';
        }
    }

    $global_enable_custom_pdf = ($wallregi_settings['enable_custom_pdf_layout'] ?? 'no') === 'yes';
    $enable_custom_pdf        = false;
    $custom_pdf_html          = '';
    $custom_pdf_css           = '';

    // Check product-specific custom layout (requires global setting to be enabled)
    if ($global_enable_custom_pdf && $product_id > 0) {
        $prod_enable = get_post_meta($product_id, '_wallregi_enable_custom_pdf_layout', true);
        $prod_html   = get_post_meta($product_id, '_wallregi_custom_pdf_html', true);
        $prod_css    = get_post_meta($product_id, '_wallregi_custom_pdf_css', true);

        if ('yes' === $prod_enable && !empty(trim((string) $prod_html))) {
            $enable_custom_pdf = true;
            $custom_pdf_html   = trim((string) $prod_html);
            $custom_pdf_css    = trim((string) $prod_css);
        }
    }

    if ($enable_custom_pdf && !empty($custom_pdf_html)) {
        $meta_data_array = (!empty($meta_data) && is_array($meta_data)) ? $meta_data : [];

        $pdf_context_data = [
            'gift_code' => $safe_gift_code,
            'heading' => $safe_heading,
            'formatted_price' => $formatted_price,
            'expiry_date' => $safe_expiry_date,
            'message' => $safe_message,
            'short_description' => $safe_short_description,
            'image_url' => $safe_image_url,
            'image_html' => $image,
            'logo_html' => $wallregi_pdf_logo_html,
            'date_html' => $wallregi_pdf_date_html ? $wallregi_pdf_date_html : date_i18n('d-m-Y'),
            'scannable_html' => $wallregi_pdf_scannable_html,
            'barcode_html' => !empty($bc_uri) ? '<div class="wallregi-pdf-scannable wallregi-pdf-scannable--barcode"><img src="' . esc_attr($bc_uri) . '" alt="' . esc_attr__('Gift card barcode', 'wallet-ready-gift-cards-for-woocommerce') . '" /></div>' : '',
            'qrcode_html' => !empty($qr_uri) ? '<div class="wallregi-pdf-scannable wallregi-pdf-scannable--qr"><img src="' . esc_attr($qr_uri) . '" width="120" height="120" alt="' . esc_attr__('Gift card QR code', 'wallet-ready-gift-cards-for-woocommerce') . '" /></div>' : '',
            'apply_url' => home_url('/?wallregi_apply_giftcard=' . $safe_gift_code),
            'sender_name' => esc_html($meta_data_array['sender_name'] ?? ''),
            'recipient_name' => esc_html($meta_data_array['recipient_name'] ?? ''),
            'recipient_email' => esc_html($meta_data_array['recipient_email'] ?? ''),
            'site_title' => esc_html(get_bloginfo('name')),
            'site_url' => esc_url(home_url()),
        ];

        $pdfBody = wallregi_render_custom_pdf_body($custom_pdf_html, $pdf_context_data);
    } else {
        $pdfBody = '<div class="wallregi_giftcard__card table_wrap">
            ' . ($wallregi_pdf_logo_html ? $wallregi_pdf_logo_html : '') . '
            <div class="image-container wallregi_card__header">
                ' . $image . '
            </div>
            <div class="wallregi_card__body content_box pdf_content_body">
                ' . ($wallregi_pdf_date_html ? $wallregi_pdf_date_html : '') . '
                ' . ($safe_heading ? '<div class="pdf_heading wallregi_title">' . $safe_heading . '</div>' : '') . '
                <div class="pdf_price_wrap wallregi_card__price" style="text-align: center;">
                    <div class="pdf_price wallregi_price">' . $formatted_price . '</div>
                </div>
                <div class="pdf_extra_info">
                    <div class="pdf_gift_code">
                        <span class="label_text">' . esc_html__('Gift card number:', 'wallet-ready-gift-cards-for-woocommerce') . '</span>
                        <span class="dynamic_value"><a href="' . home_url() . '/?wallregi_apply_giftcard=' . $safe_gift_code . '">' . $safe_gift_code . '</a></span>
                    </div>
                    <div class="pdf_gift_expried">
                        <span class="label_text">' . esc_html__('Expiry date:', 'wallet-ready-gift-cards-for-woocommerce') . '</span>
                        <span class="dynamic_value">' . $safe_expiry_date . '</span>
                    </div>
                </div>
                ' . $wallregi_pdf_scannable_html . '
                ' . ($safe_message ? '<div class="pdf_preview_mgs wallregi_preview__mgs">' . $safe_message . '</div>' : '') . '
                ' . ($safe_short_description ? '<div class="pdf_footer wallregi_giftcard_footer">' . $safe_short_description . '</div>' : '') . '
            </div>
        </div>';
    }

    $wallregi_options = new Options();
    $wallregi_options->set('isHtml5ParserEnabled', true);
    $wallregi_options->set('isRemoteEnabled', false);
    $wallregi_options->set('defaultPaperSize', 'A4');
    $wallregi_options->set('defaultFont', 'DejaVu Sans');

    // Set margins in centimeters (1cm = 10mm)
    $wallregi_options->set('margin', '1.5cm');  // 1.5cm = 15mm

    // Create mPDF instance
    $pdf = new Dompdf($wallregi_options);

    // Build inline CSS for the PDF HTML using a dedicated function.
    $wallregi_inline_css = wallregi_get_giftcard_pdf_inline_css(
        $wallregi_pdf_header_style_border_css,
        $wallregi_pdf_header_style_padding_css,
        $wallregi_pdf_header_style_margin_css,
        $wallregi_pdf_header_box_shadow_css,
        $wallregi_pdf_content_style_border_css,
        $wallregi_pdf_content_style_padding_css,
        $wallregi_pdf_content_style_margin_css,
        $wallregi_pdf_title_text_style_group,
        $wallregi_pdf_title_text_style_margin_css,
        $wallregi_pdf_giftcard_price_style_group,
        $wallregi_pdf_giftcard_price_style_border_css,
        $wallregi_pdf_giftcard_price_style_padding_css,
        $wallregi_pdf_giftcard_price_style_margin_css,
        $wallregi_pdf_preview_mgs_style_group,
        $wallregi_pdf_preview_mgs_style_border_css,
        $wallregi_pdf_preview_mgs_style_padding_css,
        $wallregi_pdf_preview_mgs_style_margin_css,
        $wallregi_pdf_footer_styles_group,
        $wallregi_pdf_footer_border_css,
        $wallregi_pdf_footer_padding_css,
        $wallregi_pdf_footer_margin_css,
        $pdf_scannable_code_type
    );
    $wallregi_pdf_style_handle = 'wallregi_frontend_style';
    if (!wp_style_is($wallregi_pdf_style_handle, 'registered')) {
        wp_register_style($wallregi_pdf_style_handle, false, array(), WALLREGI_VERSION);
    }
    wp_enqueue_style($wallregi_pdf_style_handle);
    if (is_string($wallregi_inline_css)) {
        $wallregi_inline_css = wp_strip_all_tags($wallregi_inline_css);
        $wallregi_inline_css = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $wallregi_inline_css);
    } else {
        $wallregi_inline_css = '';
    }
    wp_add_inline_style($wallregi_pdf_style_handle, $wallregi_inline_css);
    ob_start();
    wp_print_styles($wallregi_pdf_style_handle);
    $wallregi_pdf_head_styles = ob_get_clean();

    if ($enable_custom_pdf && !empty($custom_pdf_html) && !empty($custom_pdf_css)) {
        $wallregi_pdf_head_styles .= "\n<style type=\"text/css\">\n" . wp_strip_all_tags($custom_pdf_css) . "\n</style>\n";
    }
    $wallregi_pdf_doc_attrs = function_exists('wallregi_get_document_direction_attrs')
        ? wallregi_get_document_direction_attrs()
        : 'dir="ltr" lang="en"';

    $html = '<!DOCTYPE html>
    <html ' . $wallregi_pdf_doc_attrs . ' style="margin: 0; padding: 0; box-sizing: border-box;">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>' . esc_html__('Gift Card PDF', 'wallet-ready-gift-cards-for-woocommerce') . '</title>
        ' . $wallregi_pdf_head_styles . '
    </head>
    <body>
    <div class="wallregi_pdf_container" style="' . $wallregi_pdf_template_container_margin_css . ' 
                ' . $wallregi_pdf_template_container_border_css . '
                ' . $wallregi_pdf_template_container_radius_css . '">
    ' . $pdfBody . '
    </div>
    </body>
    </html>';

    ob_clean();  // Clean any previous output
    // Include emoji handler
    require_once WALLREGI_PLUGIN_DIR . 'includes/functions/emoji-handler.php';
    $html = wallregi_replace_all_emojis_dynamic($html);

    // Load HTML into DOMPDF
    $pdf->loadHtml($html);
    $pdf->render();

    $upload_dir = wp_upload_dir();
    $pdf_path = $upload_dir['basedir'] . '/giftcards/';

    if (!file_exists($pdf_path)) {
        wp_mkdir_p($pdf_path);
    }

    // Save the PDF if $attach_pdf is true
    if ($attach_pdf) {
        $pdf_file_name = $pdf_path . $item_id . '-giftcard.pdf';
        file_put_contents($pdf_file_name, $pdf->Output());
        return $pdf_file_name;
    } else {
        $pdf->stream('giftcard-' . $gift_code . '.pdf', array('Attachment' => 1));
        exit();
    }
}

// Include price formatter
require_once WALLREGI_PLUGIN_DIR . 'includes/functions/price-formatter.php';
