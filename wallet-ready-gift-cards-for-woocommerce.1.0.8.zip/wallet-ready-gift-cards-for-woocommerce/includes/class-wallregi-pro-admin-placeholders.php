<?php
/**
 * Admin-only Pro feature placeholders (discovery UI — no Pro functionality in free plugin).
 *
 * @package Wallet_Ready_Gift_Cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WALLREGI_Pro_Admin_Placeholders' ) ) {

	/**
	 * Renders disabled “Pro” controls in the free plugin admin when Pro is not licensed.
	 */
	class WALLREGI_Pro_Admin_Placeholders {

		/**
		 * Bootstrap hooks.
		 */
		public static function init() {
			if ( ! is_admin() ) {
				return;
			}

			add_filter( 'wallregi_settings_input_fields', array( __CLASS__, 'wallregi_filter_settings_input_fields' ), 50, 2 );
			add_filter( 'wallregi_email_settings_fields', array( __CLASS__, 'wallregi_filter_email_fields' ), 50 );
			add_action( 'admin_menu', array( __CLASS__, 'wallregi_register_wp_admin_submenus' ), 25 );
			add_action( 'admin_menu', array( __CLASS__, 'wallregi_style_wp_admin_submenu_labels' ), 999 );
			add_action( 'wallregi_after_giftcard_product_admin_fields', array( __CLASS__, 'wallregi_render_product_fields' ), 5 );
			add_action( 'admin_enqueue_scripts', array( __CLASS__, 'wallregi_enqueue_styles' ) );
		}

		/**
		 * Pro plugin installed, active, and licensed for this site.
		 *
		 * @return bool
		 */
		public static function wallregi_is_pro_available() {
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			if ( ! is_plugin_active( 'wallet-ready-gift-cards-for-woocommerce-pro/wallet-ready-gift-cards-for-woocommerce-pro.php' ) ) {
				return false;
			}

			return function_exists( 'wallregi_pro_license_is_active' ) && wallregi_pro_license_is_active();
		}

		/**
		 * @return bool
		 */
		public static function wallregi_should_show_placeholders() {
			return ! self::wallregi_is_pro_available();
		}

		/**
		 * @return string
		 */
		public static function wallregi_get_purchase_url() {
			return apply_filters(
				'wallregi_pro_purchase_url',
				'https://www.webcartisan.com/products/gift-card-for-woocommerce/'
			);
		}

		/**
		 * CTA when Pro is not available on this site.
		 *
		 * @return string
		 */
		public static function wallregi_get_cta_url() {
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			if ( is_plugin_active( 'wallet-ready-gift-cards-for-woocommerce-pro/wallet-ready-gift-cards-for-woocommerce-pro.php' ) ) {
				return admin_url( 'admin.php?page=wx-gift-cards-pro-license' );
			}

			return wallregi_gift_cards_admin_url(
				array(
					'tab'      => 'wallregi_features',
					'_wpnonce' => wp_create_nonce( 'wallregi_nonce_action' ),
				)
			);
		}

		/**
		 * @return string
		 */
		public static function wallregi_get_cta_link_html() {
			$url = esc_url( self::wallregi_get_cta_url() );

			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			if ( is_plugin_active( 'wallet-ready-gift-cards-for-woocommerce-pro/wallet-ready-gift-cards-for-woocommerce-pro.php' ) ) {
				$label = __( 'Activate your Pro license', 'wallet-ready-gift-cards-for-woocommerce' );
			} else {
				$label = __( 'Get GiftRocket Pro', 'wallet-ready-gift-cards-for-woocommerce' );
			}

			return '<a href="' . $url . '">' . esc_html( $label ) . '</a>';
		}

		/**
		 * @param string $description Field description.
		 * @return string
		 */
		private static function wallregi_disabled_note( $description ) {
			return wp_kses_post(
				$description . ' <span class="wallregi-pro-placeholder-cta">' . self::wallregi_get_cta_link_html() . '</span>'
			);
		}

		/**
		 * @param string $basename settings-data filename e.g. general-data.php.
		 * @return array<int, array<string, mixed>>
		 */
		private static function wallregi_get_fields_for_data_file( $basename ) {
			$section_checkout = __( 'Pro — checkout & redemption', 'wallet-ready-gift-cards-for-woocommerce' );
			$section_form     = __( 'Pro — gift card form', 'wallet-ready-gift-cards-for-woocommerce' );
			$section_ai       = __( 'Pro — AI assistant', 'wallet-ready-gift-cards-for-woocommerce' );

			$map = array(
				'general-data.php' => array(
					array(
						'name'            => 'wallregi_pro_ph_checkout_edit',
						'key'             => '',
						'pro_placeholder' => true,
						'type'            => 'checkbox',
						'label'           => __( 'Edit gift cards at checkout', 'wallet-ready-gift-cards-for-woocommerce' ),
						'description'     => __( 'Let buyers change recipient details on the checkout page (shortcode and Checkout block).', 'wallet-ready-gift-cards-for-woocommerce' ),
						'sec_name'        => $section_checkout,
						'sec_key'         => 'wallregi_pro_placeholders_checkout',
						'disabled'        => true,
						'default'         => 'no',
					),
					array(
						'name'            => 'wallregi_pro_ph_partial_redeem',
						'key'             => '',
						'pro_placeholder' => true,
						'type'            => 'checkbox',
						'label'           => __( 'Buyer partial redemption amount', 'wallet-ready-gift-cards-for-woocommerce' ),
						'description'     => __( 'Shoppers choose how much gift card balance to apply before checkout.', 'wallet-ready-gift-cards-for-woocommerce' ),
						'sec_name'        => $section_checkout,
						'sec_key'         => 'wallregi_pro_placeholders_checkout',
						'disabled'        => true,
						'default'         => 'no',
					),
					array(
						'name'            => 'wallregi_pro_ph_rest_api',
						'key'             => '',
						'pro_placeholder' => true,
						'type'            => 'checkbox',
						'label'           => __( 'WooCommerce REST API for gift cards', 'wallet-ready-gift-cards-for-woocommerce' ),
						'description'     => __( 'Lookup cards and transaction history via wc/v3/wallregi-giftcards endpoints.', 'wallet-ready-gift-cards-for-woocommerce' ),
						'sec_name'        => $section_checkout,
						'sec_key'         => 'wallregi_pro_placeholders_checkout',
						'disabled'        => true,
						'default'         => 'no',
					),
				),
				'form-data.php'    => array(
					array(
						'name'            => 'wallregi_pro_ph_greeting_presets',
						'key'             => '',
						'pro_placeholder' => true,
						'type'            => 'checkbox',
						'label'           => __( 'Greeting message presets', 'wallet-ready-gift-cards-for-woocommerce' ),
						'description'     => __( 'Quick-pick chips for common greeting lines on the gift card form.', 'wallet-ready-gift-cards-for-woocommerce' ),
						'sec_name'        => $section_form,
						'sec_key'         => 'wallregi_pro_placeholders_form',
						'disabled'        => true,
						'default'         => 'no',
					),
					array(
						'name'            => 'wallregi_pro_ph_buyer_ai',
						'key'             => '',
						'pro_placeholder' => true,
						'type'            => 'checkbox',
						'label'           => __( 'AI greeting assist for shoppers', 'wallet-ready-gift-cards-for-woocommerce' ),
						'description'     => __( 'Suggest, improve, and translate personal messages using your API key (storefront; off by default).', 'wallet-ready-gift-cards-for-woocommerce' ),
						'sec_name'        => $section_form,
						'sec_key'         => 'wallregi_pro_placeholders_form',
						'disabled'        => true,
						'default'         => 'no',
					),
				),
				'pdf-data.php'     => array(
					array(
						'name'            => 'wallregi_pro_ph_ai_staff',
						'key'             => '',
						'pro_placeholder' => true,
						'type'            => 'checkbox',
						'label'           => __( 'AI assist for PDF & email copy', 'wallet-ready-gift-cards-for-woocommerce' ),
						'description'     => __( 'Staff-side AI for headings, footers, and template wording (your API key under GiftRocket → AI).', 'wallet-ready-gift-cards-for-woocommerce' ),
						'sec_name'        => $section_ai,
						'sec_key'         => 'wallregi_pro_placeholders_ai',
						'disabled'        => true,
						'default'         => 'no',
					),
				),
			);

			$fields = $map[ $basename ] ?? array();

			return apply_filters( 'wallregi_pro_admin_placeholder_fields', $fields, $basename );
		}

		/**
		 * @return array<int, array<string, mixed>>
		 */
		private static function wallregi_get_email_placeholder_fields() {
			$fields = array(
				array(
					'name'            => 'wallregi_pro_ph_expiry_reminders',
					'key'             => '',
					'pro_placeholder' => true,
					'type'            => 'pro_notice',
					'label'           => __( 'Expiry reminder emails', 'wallet-ready-gift-cards-for-woocommerce' ),
					'description'     => __( 'Automated reminders before gift cards expire, with scheduling and send logs.', 'wallet-ready-gift-cards-for-woocommerce' ),
				),
				array(
					'name'            => 'wallregi_pro_ph_email_ai',
					'key'             => '',
					'pro_placeholder' => true,
					'type'            => 'pro_notice',
					'label'           => __( 'AI delivery email assistant', 'wallet-ready-gift-cards-for-woocommerce' ),
					'description'     => __( 'Generate and refine gift card email subject and body with your connected AI provider.', 'wallet-ready-gift-cards-for-woocommerce' ),
				),
			);

			return apply_filters( 'wallregi_pro_admin_placeholder_email_fields', $fields );
		}

		/**
		 * @param array<int, array<string, mixed>> $fields Field definitions.
		 * @return array<int, array<string, mixed>>
		 */
		private static function wallregi_prepare_fields( array $fields ) {
			foreach ( $fields as $idx => $field ) {
				$fields[ $idx ]['disabled']       = true;
				$fields[ $idx ]['pro_placeholder'] = true;
				if ( ! empty( $field['description'] ) ) {
					$fields[ $idx ]['disabled_note'] = self::wallregi_disabled_note( (string) $field['description'] );
					unset( $fields[ $idx ]['description'] );
				}
			}
			return $fields;
		}

		/**
		 * WordPress admin submenu entries (under GiftRocket) when Pro is unavailable.
		 *
		 * @return array<int, array{slug:string,menu_title:string,page_title:string,description:string}>
		 */
		public static function wallregi_get_wp_admin_submenu_items() {
			if ( ! function_exists( 'is_plugin_active' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			$items = array();

			if ( ! is_plugin_active( 'wallet-ready-gift-cards-for-woocommerce-pro/wallet-ready-gift-cards-for-woocommerce-pro.php' ) ) {
				$items[] = array(
					'slug'        => 'wx-gift-cards-pro-license',
					'menu_title'  => __( 'Pro license', 'wallet-ready-gift-cards-for-woocommerce' ),
					'page_title'  => __( 'GiftRocket Pro — License', 'wallet-ready-gift-cards-for-woocommerce' ),
					'description' => __( 'Enter your license key to unlock Pro features on this site.', 'wallet-ready-gift-cards-for-woocommerce' ),
				);
			}

			$items = array_merge(
				$items,
				array(
					array(
						'slug'        => 'wx-gift-cards-ai',
						'menu_title'  => __( 'AI', 'wallet-ready-gift-cards-for-woocommerce' ),
						'page_title'  => __( 'GiftRocket Pro — AI assistant', 'wallet-ready-gift-cards-for-woocommerce' ),
						'description' => __( 'Connect OpenAI, OpenRouter, Gemini, or Claude for shopper and staff writing assist.', 'wallet-ready-gift-cards-for-woocommerce' ),
					),
					array(
						'slug'        => 'wx-gift-cards-expiry-reminders',
						'menu_title'  => __( 'Expiry reminders', 'wallet-ready-gift-cards-for-woocommerce' ),
						'page_title'  => __( 'GiftRocket Pro — Expiry reminders', 'wallet-ready-gift-cards-for-woocommerce' ),
						'description' => __( 'Send automated emails before gift cards expire, with templates and a send log.', 'wallet-ready-gift-cards-for-woocommerce' ),
					),
					array(
						'slug'        => 'wx-gift-cards-outstanding-balance-export',
						'menu_title'  => __( 'Outstanding balance exports', 'wallet-ready-gift-cards-for-woocommerce' ),
						'page_title'  => __( 'GiftRocket Pro — Outstanding balance export', 'wallet-ready-gift-cards-for-woocommerce' ),
						'description' => __( 'Export outstanding gift card liability for accounting and reporting.', 'wallet-ready-gift-cards-for-woocommerce' ),
					),
				)
			);

			return apply_filters( 'wallregi_pro_admin_placeholder_wp_submenu_items', $items );
		}

		/**
		 * Register placeholder items on the native WP admin GiftRocket menu.
		 */
		public static function wallregi_register_wp_admin_submenus() {
			if ( ! self::wallregi_should_show_placeholders() ) {
				return;
			}

			$parent = function_exists( 'wallregi_gift_cards_parent_menu_slug' )
				? wallregi_gift_cards_parent_menu_slug()
				: 'wx-gift-cards';

			foreach ( self::wallregi_get_wp_admin_submenu_items() as $item ) {
				add_submenu_page(
					$parent,
					$item['page_title'],
					$item['menu_title'],
					function_exists( 'wallregi_admin_capability' ) ? wallregi_admin_capability() : 'manage_woocommerce',
					$item['slug'],
					array( __CLASS__, 'wallregi_render_placeholder_admin_page' )
				);
			}
		}

		/**
		 * Append purple Pro badge to placeholder submenu labels in the left admin menu.
		 */
		public static function wallregi_style_wp_admin_submenu_labels() {
			if ( ! self::wallregi_should_show_placeholders() ) {
				return;
			}

			global $submenu;

			$parent = function_exists( 'wallregi_gift_cards_parent_menu_slug' )
				? wallregi_gift_cards_parent_menu_slug()
				: 'wx-gift-cards';

			if ( empty( $submenu[ $parent ] ) || ! is_array( $submenu[ $parent ] ) ) {
				return;
			}

			$slugs = array();
			foreach ( self::wallregi_get_wp_admin_submenu_items() as $item ) {
				$slugs[] = $item['slug'];
			}

			$badge = ' <span class="wallregi-pro-menu-badge">' . esc_html__( 'Pro', 'wallet-ready-gift-cards-for-woocommerce' ) . '</span>';

			foreach ( $submenu[ $parent ] as $idx => $entry ) {
				if ( ! is_array( $entry ) || empty( $entry[2] ) ) {
					continue;
				}
				if ( in_array( (string) $entry[2], $slugs, true ) && false === strpos( (string) $entry[0], 'wallregi-pro-menu-badge' ) ) {
					$submenu[ $parent ][ $idx ][0] .= $badge;
				}
			}
		}

		/**
		 * Render placeholder screen for a Pro submenu slug.
		 */
		public static function wallregi_render_placeholder_admin_page() {
			$capability = function_exists( 'wallregi_admin_capability' ) ? wallregi_admin_capability() : 'manage_woocommerce';
			if ( ! current_user_can( $capability ) ) {
				wp_die( esc_html__( 'You do not have permission to access this page.', 'wallet-ready-gift-cards-for-woocommerce' ) );
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen routing.
			$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( (string) $_GET['page'] ) ) : '';

			$wallregi_pro_placeholder_title       = __( 'GiftRocket Pro', 'wallet-ready-gift-cards-for-woocommerce' );
			$wallregi_pro_placeholder_description = '';

			foreach ( self::wallregi_get_wp_admin_submenu_items() as $item ) {
				if ( $item['slug'] === $page ) {
					$wallregi_pro_placeholder_title       = $item['page_title'];
					$wallregi_pro_placeholder_description = $item['description'];
					break;
				}
			}

			require WALLREGI_PLUGIN_DIR . 'backend/templates/pro/placeholder-page.php';
		}

		/**
		 * @param array<int, array<string, mixed>> $fields       Input fields.
		 * @param string                           $data_file_path Absolute path to *-data.php.
		 * @return array<int, array<string, mixed>>
		 */
		public static function wallregi_filter_settings_input_fields( $fields, $data_file_path ) {
			if ( ! self::wallregi_should_show_placeholders() || ! is_string( $data_file_path ) ) {
				return $fields;
			}

			$basename = basename( $data_file_path );
			$extra    = self::wallregi_get_fields_for_data_file( $basename );
			if ( empty( $extra ) ) {
				return $fields;
			}

			return array_merge( $fields, self::wallregi_prepare_fields( $extra ) );
		}

		/**
		 * @param array<int, array<string, mixed>> $fields Email fields.
		 * @return array<int, array<string, mixed>>
		 */
		public static function wallregi_filter_email_fields( $fields ) {
			if ( ! self::wallregi_should_show_placeholders() ) {
				return $fields;
			}

			return array_merge( $fields, self::wallregi_prepare_fields( self::wallregi_get_email_placeholder_fields() ) );
		}

		/**
		 * @param WP_Post $post Product post.
		 */
		public static function wallregi_render_product_fields( $post ) {
			unset( $post );
			if ( ! self::wallregi_should_show_placeholders() ) {
				return;
			}
			?>
			<div class="options_group wallregi-pro-product-placeholders">
				<p class="form-field">
					<label>
						<?php esc_html_e( 'Buyer image upload', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
						<span class="wallregi-label pro"><?php esc_html_e( 'Pro', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
					</label>
					<span class="description">
						<?php
						echo wp_kses_post(
							self::wallregi_disabled_note(
								__( 'Allow shoppers to upload a custom image on this gift card product.', 'wallet-ready-gift-cards-for-woocommerce' )
							)
						);
						?>
					</span>
				</p>
			</div>
			<?php
		}

		/**
		 * @param string $hook Admin hook suffix.
		 */
		public static function wallregi_enqueue_styles( $hook ) {
			unset( $hook );
			if ( ! self::wallregi_should_show_placeholders() ) {
				return;
			}
			wp_enqueue_style(
				'wallregi_pro_admin_placeholders',
				WALLREGI_PLUGIN_URL . 'backend/assets/css/pro-admin-placeholders.css',
				array(),
				WALLREGI_VERSION
			);
		}
	}
}
