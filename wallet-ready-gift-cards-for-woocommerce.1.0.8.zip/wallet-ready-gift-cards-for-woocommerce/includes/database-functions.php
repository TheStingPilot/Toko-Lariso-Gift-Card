<?php
if (!defined('ABSPATH')) {
    exit;  // Exit if accessed directly
}

/**
 * Normalize preferred send / scheduled datetime for `wx_gift_cards.preferred_date_time`
 * and storefront `email_schedule` payloads before DB or order meta persistence.
 *
 * Empty, whitespace-only, or unparseable values use the current site time (MySQL format).
 * Parsed values are stored as UTC `Y-m-d H:i:s` (same as checkout order flow).
 *
 * @param mixed $raw Datetime string from CSV, REST, admin form, cart, etc.
 * @return string MySQL datetime `Y-m-d H:i:s`.
 */

/**
 * Human-readable label for wx_gift_cards.email_status.
 *
 * @param int|string $status 0 = pending, 1 = sent, 2 = failed.
 * @return string
 */
function wallregi_giftcard_email_status_label($status)
{
    switch ((int) $status) {
        case 1:
            return __('Sent', 'wallet-ready-gift-cards-for-woocommerce');
        case 2:
            return __('Failed', 'wallet-ready-gift-cards-for-woocommerce');
        default:
            return __('Pending', 'wallet-ready-gift-cards-for-woocommerce');
    }
}

/**
 * HTML status badge for wx_gift_cards.email_status.
 *
 * @param int|string $status Email status value.
 * @return string
 */
function wallregi_giftcard_email_status_badge_html($status)
{
    $status = (int) $status;
    $class = 'status-pending';
    if (1 === $status) {
        $class = 'status-email-sent';
    } elseif (2 === $status) {
        $class = 'status-email-failed';
    }

    return sprintf(
        '<span class="status-label %1$s">%2$s</span>',
        esc_attr($class),
        esc_html(wallregi_giftcard_email_status_label($status))
    );
}

/**
 * HTML status badge for wx_gift_cards.sms_status.
 *
 * @param int|string $status SMS status value.
 * @return string
 */
function wallregi_giftcard_sms_status_badge_html($status)
{
    $status = (int) $status;
    $class = 'status-pending';
    if (1 === $status) {
        $class = 'status-sms-sent';
    } elseif (2 === $status) {
        $class = 'status-sms-failed';
    }

    return sprintf(
        '<span class="status-label %1$s">%2$s</span>',
        esc_attr($class),
        esc_html(wallregi_giftcard_sms_status_label($status))
    );
}

/**
 * Base SQL WHERE fragment for scheduled delivery admin lists.
 *
 * @return string
 */
function wallregi_giftcard_scheduled_delivery_base_where_sql()
{
    return "COALESCE( NULLIF( `delivery_channel`, '' ), 'email' ) != 'none'
        AND (
            ( COALESCE( NULLIF( `delivery_channel`, '' ), 'email' ) IN ( 'email', 'both' ) AND `receipent_email` != '' )
            OR ( COALESCE( NULLIF( `delivery_channel`, '' ), 'email' ) IN ( 'sms', 'both' ) AND `receipent_phone` != '' )
        )";
}

/**
 * SQL WHERE fragment for scheduled delivery status filter.
 *
 * @param string $filter pending|sent|failed.
 * @return string
 */
function wallregi_giftcard_scheduled_delivery_status_where_sql($filter)
{
    $channel_expr = "COALESCE( NULLIF( `delivery_channel`, '' ), 'email' )";

    switch (sanitize_key($filter)) {
        case 'sent':
            return "(
                ( {$channel_expr} IN ( 'email', 'both' ) AND `email_status` = 1 )
                OR {$channel_expr} NOT IN ( 'email', 'both' )
            )
            AND (
                ( {$channel_expr} IN ( 'sms', 'both' ) AND `sms_status` = 1 )
                OR {$channel_expr} NOT IN ( 'sms', 'both' )
            )";
        case 'failed':
            return "(
                ( {$channel_expr} IN ( 'email', 'both' ) AND `email_status` = 2 )
                OR ( {$channel_expr} IN ( 'sms', 'both' ) AND `sms_status` = 2 )
            )";
        case 'pending':
        default:
            return "(
                ( {$channel_expr} = 'email' AND `email_status` = 0 )
                OR ( {$channel_expr} = 'sms' AND `sms_status` = 0 )
                OR ( {$channel_expr} = 'both' AND ( `email_status` = 0 OR `sms_status` = 0 ) )
            )";
    }
}

/**
 * Format a gift card datetime for admin lists.
 *
 * @param string $mysql_datetime Stored datetime.
 * @return string
 */
function wallregi_format_giftcard_admin_datetime($mysql_datetime)
{
    $mysql_datetime = is_string($mysql_datetime) ? trim($mysql_datetime) : '';
    if ('' === $mysql_datetime || '0000-00-00 00:00:00' === $mysql_datetime) {
        return '—';
    }

    $timestamp = strtotime($mysql_datetime);
    if (false === $timestamp) {
        return $mysql_datetime;
    }

    return wp_date(
        get_option('date_format') . ' ' . get_option('time_format'),
        $timestamp
    );
}

function wallregi_normalize_giftcard_preferred_datetime($raw)
{
    $raw = is_string($raw) ? trim($raw) : '';
    if ('' === $raw) {
        return current_time('mysql');
    }
    $sanitized = sanitize_text_field($raw);
    $ts = strtotime($sanitized);
    if (false === $ts || $ts < 86400) {
        return current_time('mysql');
    }
    return gmdate('Y-m-d H:i:s', $ts);
}

/**
 * Canonical whitelist of wx_gift_cards columns (must match wallregi_create_database_tables()).
 *
 * @return string[]
 */
function wallregi_get_giftcard_table_column_names()
{
    return array(
        'id',
        'order_id',
        'item_id',
        'product_id',
        'initial_amount',
        'current_amount',
        'giftcard_number',
        'expiry_date',
        'expiry_period',
        'total_redeem',
        'receipent_name',
        'receipent_email',
        'sender_name',
        'message',
        'send_date_time',
        'preferred_date_time',
        'giftcard_image',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
        'send_mail_time',
        'sent_at',
        'email_status',
        'delivery_channel',
        'receipent_phone',
        'sms_status',
        'sms_sent_at',
        'status',
        'epass_data',
    );
}

/**
 * Gift card table name including $wpdb->prefix (not escaped; use for $wpdb->* APIs).
 *
 * @return string
 */
function wallregi_giftcard_db_table_name()
{
    global $wpdb;

    return $wpdb->prefix . 'wx_gift_cards';
}

/**
 * Table reference for raw SQL fragments: `tablename` with identifier escaping.
 * Build outside wpdb::prepare(); only values belong in prepare().
 *
 * @return string
 */
function wallregi_giftcard_db_table_sql()
{
    return '`' . esc_sql(wallregi_giftcard_db_table_name()) . '`';
}

/**
 * Check whether a column exists in the gift card table.
 *
 * @param string $column_name Column name.
 * @return bool
 */
function wallregi_giftcard_table_has_column($column_name)
{
    global $wpdb;

    $column_name = is_string($column_name) ? trim($column_name) : '';
    if ('' === $column_name) {
        return false;
    }

    $table = wallregi_giftcard_db_table_name();
    if ('' === $table) {
        return false;
    }

    $escaped_table = esc_sql($table);
    $escaped_column = esc_sql($column_name);

    $columns = $wpdb->get_col("SHOW COLUMNS FROM `{$escaped_table}` LIKE '{$escaped_column}'");

    return !empty($columns);
}

/**
 * Transaction table name including prefix (for $wpdb->insert/update/delete).
 *
 * @return string
 */
function wallregi_transaction_db_table_name()
{
    global $wpdb;

    return $wpdb->prefix . 'wx_giftcard_transaction';
}

/**
 * Quoted transaction table for raw SQL fragments.
 *
 * @return string
 */
function wallregi_transaction_db_table_sql()
{
    return '`' . esc_sql(wallregi_transaction_db_table_name()) . '`';
}

/**
 * Gift card image upload table name including prefix.
 *
 * @return string
 */
function wallregi_image_upload_db_table_name()
{
    global $wpdb;

    return $wpdb->prefix . 'wx_giftcard_image_upload';
}

/**
 * Quoted image upload table for raw SQL fragments.
 *
 * @return string
 */
function wallregi_image_upload_db_table_sql()
{
    return '`' . esc_sql(wallregi_image_upload_db_table_name()) . '`';
}

/**
 * Security / fraud audit log table name including prefix.
 *
 * @return string
 */
function wallregi_security_audit_db_table_name()
{
    global $wpdb;

    return $wpdb->prefix . 'wallregi_security_audit';
}

/**
 * Quoted security audit table for raw SQL fragments.
 *
 * @return string
 */
function wallregi_security_audit_db_table_sql()
{
    return '`' . esc_sql(wallregi_security_audit_db_table_name()) . '`';
}

/**
 * Canonical gift card number for comparisons and session storage (case- and spacing-insensitive).
 *
 * @param string $giftcard_number Raw code from user input.
 * @return string Normalized code or empty string.
 */
function wallregi_normalize_giftcard_number($giftcard_number)
{
    $code = sanitize_text_field((string) $giftcard_number);
    if ('' === $code) {
        return '';
    }

    return strtoupper(str_replace(' ', '-', trim($code)));
}

/**
 * Preferred session / DB key for a gift card (DB value when found).
 *
 * @param string      $giftcard_number Raw or normalized code.
 * @param object|null $giftcard_row    Optional row from wallregi_get_giftcard_by_number().
 * @return string
 */
function wallregi_get_canonical_giftcard_number($giftcard_number, $giftcard_row = null)
{
    if (null === $giftcard_row) {
        $giftcard_row = wallregi_get_giftcard_by_number($giftcard_number);
    }

    if ($giftcard_row && !empty($giftcard_row->giftcard_number)) {
        return (string) $giftcard_row->giftcard_number;
    }

    return wallregi_normalize_giftcard_number($giftcard_number);
}

/**
 * Whether the same gift card (any casing/spacing) is already in the cart session.
 *
 * @param string $giftcard_number Code to check.
 * @return bool
 */
function wallregi_is_giftcard_applied_in_session($giftcard_number)
{
    if (!function_exists('WC') || !WC()->session) {
        return false;
    }

    $needle = wallregi_normalize_giftcard_number($giftcard_number);
    if ('' === $needle) {
        return false;
    }

    $applied = WC()->session->get('applied_giftcards', []);
    if (!is_array($applied)) {
        return false;
    }

    foreach ($applied as $code) {
        if (wallregi_normalize_giftcard_number($code) === $needle) {
            return true;
        }
    }

    return false;
}

/**
 * Find session index for an applied gift card (case-insensitive).
 *
 * @param string             $giftcard_number Code to find.
 * @param array<int, string> $applied         applied_giftcards session array.
 * @return int|false Array key or false.
 */
function wallregi_find_applied_giftcard_session_index($giftcard_number, array $applied)
{
    $needle = wallregi_normalize_giftcard_number($giftcard_number);
    if ('' === $needle) {
        return false;
    }

    foreach ($applied as $key => $code) {
        if (wallregi_normalize_giftcard_number($code) === $needle) {
            return $key;
        }
    }

    return false;
}

/**
 * Collapse case-variant duplicates in session and normalize keys to canonical codes.
 *
 * @return void
 */
function wallregi_normalize_session_applied_giftcards()
{
    if (!function_exists('WC') || !WC()->session) {
        return;
    }

    $applied = WC()->session->get('applied_giftcards', []);
    if (!is_array($applied) || empty($applied)) {
        return;
    }

    $amounts = WC()->session->get('applied_giftcard_amounts', []);
    $amounts = is_array($amounts) ? $amounts : [];
    $buyer = WC()->session->get('applied_giftcard_buyer_amounts', []);
    $buyer = is_array($buyer) ? $buyer : [];

    $canonical_applied = [];
    $canonical_amounts = [];
    $canonical_buyer = [];

    foreach ($applied as $code) {
        $canonical = wallregi_get_canonical_giftcard_number($code);
        if ('' === $canonical) {
            continue;
        }

        $norm = wallregi_normalize_giftcard_number($canonical);
        if (isset($canonical_amounts[$canonical]) || in_array($norm, array_map('wallregi_normalize_giftcard_number', $canonical_applied), true)) {
            continue;
        }

        $canonical_applied[] = $canonical;

        foreach ($amounts as $key => $value) {
            if (wallregi_normalize_giftcard_number($key) === $norm) {
                $canonical_amounts[$canonical] = $value;
                break;
            }
        }

        foreach ($buyer as $key => $value) {
            if (wallregi_normalize_giftcard_number($key) === $norm) {
                $canonical_buyer[$canonical] = $value;
                break;
            }
        }
    }

    WC()->session->set('applied_giftcards', array_values($canonical_applied));
    WC()->session->set('applied_giftcard_amounts', $canonical_amounts);
    WC()->session->set('applied_giftcard_buyer_amounts', $canonical_buyer);
}

/**
 * Load one gift card row by public gift card number (coupon code).
 *
 * Lookup is case- and spacing-insensitive.
 *
 * @param string $giftcard_number Gift card number.
 * @return object|null Row object or null.
 */
function wallregi_get_giftcard_by_number($giftcard_number)
{
    global $wpdb;

    $normalized = wallregi_normalize_giftcard_number($giftcard_number);
    if ('' === $normalized) {
        return null;
    }

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Single-row lookup by indexed code.
    return $wpdb->get_row(
        $wpdb->prepare(
            'SELECT * FROM %i WHERE BINARY giftcard_number = %s',
            wallregi_giftcard_db_table_name(),
            $normalized
        )
    );
}

/**
 * Validate a gift card row for applying to the WooCommerce session (cart/checkout).
 *
 * @param string $giftcard_number Gift card number.
 * @return true|\WP_Error True if valid; WP_Error with message code otherwise.
 */
function wallregi_validate_giftcard_for_session_apply($giftcard_number)
{
    $giftcard = wallregi_get_giftcard_by_number($giftcard_number);
    if (!$giftcard) {
        return new WP_Error(
            'wallregi_giftcard_not_found',
            __('Gift card not found. Please check the code and try again.', 'wallet-ready-gift-cards-for-woocommerce')
        );
    }

    $canonical = wallregi_get_canonical_giftcard_number($giftcard_number, $giftcard);
    if (wallregi_is_giftcard_applied_in_session($canonical)) {
        return new WP_Error(
            'wallregi_giftcard_already_applied',
            __('Gift card already applied.', 'wallet-ready-gift-cards-for-woocommerce')
        );
    }

    if (isset($giftcard->current_amount) && (int) $giftcard->current_amount <= 0) {
        return new WP_Error(
            'wallregi_giftcard_no_balance',
            __('This gift card has no remaining balance.', 'wallet-ready-gift-cards-for-woocommerce')
        );
    }

    if (!empty($giftcard->expiry_date) && strtotime((string) $giftcard->expiry_date) < current_time('timestamp')) {
        return new WP_Error(
            'wallregi_giftcard_expired',
            __('This gift card has expired.', 'wallet-ready-gift-cards-for-woocommerce')
        );
    }

    if (!empty($giftcard->status)) {
        switch ($giftcard->status) {
            case 'cancelled':
                return new WP_Error(
                    'wallregi_giftcard_cancelled',
                    __('This gift card has been cancelled.', 'wallet-ready-gift-cards-for-woocommerce')
                );
            case 'expired':
                return new WP_Error(
                    'wallregi_giftcard_expired_status',
                    __('This gift card has expired.', 'wallet-ready-gift-cards-for-woocommerce')
                );
            case 'used':
                return new WP_Error(
                    'wallregi_giftcard_used',
                    __('This gift card has already been used.', 'wallet-ready-gift-cards-for-woocommerce')
                );
        }
    }

    /**
     * Allow add-ons (e.g. Pro) to enforce per-order limits on how many distinct gift cards may be in session.
     *
     * @param true|\WP_Error $allow           Default true (no extra restriction).
     * @param string         $giftcard_number Code being applied (not yet in session).
     * @param object|null    $giftcard        Row from wallregi_get_giftcard_by_number(), if available.
     * @return true|\WP_Error
     */
    $session_limits = apply_filters('wallregi_validate_giftcard_session_limits_before_apply', true, $canonical, $giftcard);
    if (is_wp_error($session_limits)) {
        return $session_limits;
    }

    return true;
}

/**
 * Sum of wallet gift card discount amounts currently in the session (after cart totals).
 *
 * @return float
 */
function wallregi_get_session_applied_giftcard_total_amount()
{
    if (!function_exists('WC') || !WC()->session) {
        return 0.0;
    }

    $amounts = WC()->session->get('applied_giftcard_amounts', []);
    if (!is_array($amounts)) {
        return 0.0;
    }

    $total = 0.0;
    foreach ($amounts as $amount) {
        $total += (float) $amount;
    }

    return $total;
}

/**
 * Calculate the total order amount before gift card deductions.
 * A gift card acts as a payment method reducing the full payable total (items + taxes + shipping + other fees), not just subtotal.
 *
 * @param WC_Cart|null $cart Cart instance.
 * @return float Total payable amount before gift card application.
 */
function wallregi_get_cart_total_for_giftcard( $cart = null )
{
    if ( ! $cart ) {
        if ( function_exists( 'WC' ) && WC()->cart ) {
            $cart = WC()->cart;
        } else {
            return 0.0;
        }
    }

    $decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;

    $total = (float) $cart->get_cart_contents_total()
           + (float) $cart->get_cart_contents_tax()
           + (float) $cart->get_shipping_total()
           + (float) $cart->get_shipping_tax();

    // Include other non-gift-card fees already present on the cart.
    foreach ( $cart->get_fees() as $fee ) {
        $fee_id      = isset( $fee->id ) ? (string) $fee->id : '';
        $fee_name    = isset( $fee->name ) ? (string) $fee->name : '';
        $target_name = __( 'Gift card used', 'wallet-ready-gift-cards-for-woocommerce' );

        if (
            $fee_id === 'gift-card-used'
            || $fee_id === 'wallregi_gift_card_used'
            || strpos( $fee_id, 'gift-card' ) !== false
            || strpos( $fee_id, 'wallregi' ) !== false
            || $fee_name === $target_name
            || sanitize_title( $fee_name ) === sanitize_title( $target_name )
        ) {
            continue;
        }

        $total += (float) $fee->amount;
        if ( ! empty( $fee->tax ) ) {
            $total += (float) $fee->tax;
        }
    }

    if ( $total <= 0.0 && isset( $cart->subtotal ) ) {
        $total = (float) $cart->subtotal;
    }

    return max( 0.0, round( $total, $decimals ) );
}

/**
 * Remove one applied gift card code from the session and recalculate the cart.
 *
 * @param string $coupon_code Gift card number (same as session entry).
 */
function wallregi_revert_applied_giftcard_from_session($coupon_code)
{
    $coupon_code = sanitize_text_field((string) $coupon_code);
    if ('' === $coupon_code || !function_exists('WC') || !WC()->session || !WC()->cart) {
        return;
    }

    $applied = WC()->session->get('applied_giftcards', []);
    if (!is_array($applied)) {
        return;
    }

    $giftcard_key = wallregi_find_applied_giftcard_session_index($coupon_code, $applied);
    if (false === $giftcard_key) {
        return;
    }

    $stored_coupon_code = $applied[$giftcard_key];
    unset($applied[$giftcard_key]);

    $amounts = WC()->session->get('applied_giftcard_amounts', []);
    if (is_array($amounts)) {
        $norm = wallregi_normalize_giftcard_number($stored_coupon_code);
        foreach (array_keys($amounts) as $amount_key) {
            if (wallregi_normalize_giftcard_number($amount_key) === $norm) {
                unset($amounts[$amount_key]);
            }
        }
    }

    WC()->session->set('applied_giftcards', array_values($applied));
    WC()->session->set('applied_giftcard_amounts', is_array($amounts) ? $amounts : []);

    $buyer = WC()->session->get('applied_giftcard_buyer_amounts', []);
    if (is_array($buyer)) {
        $norm = wallregi_normalize_giftcard_number($stored_coupon_code);
        foreach (array_keys($buyer) as $buyer_key) {
            if (wallregi_normalize_giftcard_number($buyer_key) === $norm) {
                unset($buyer[$buyer_key]);
            }
        }
        WC()->session->set('applied_giftcard_buyer_amounts', $buyer);
    }

    WC()->cart->calculate_totals();
}

/**
 * Remove stale GTW checkout error notices from the WooCommerce session.
 *
 * GTW background hold sync used to call wc_add_notice() with raw API messages such as
 * "Input error(s)" even when apply/remove/hold succeeded. Blocks cart reads these via Store API.
 */
function wallregi_clear_gtw_checkout_error_notices()
{
    if (!function_exists('WC') || !WC()->session) {
        return;
    }

    $notices = WC()->session->get('wc_notices', []);
    if (!is_array($notices) || empty($notices['error']) || !is_array($notices['error'])) {
        return;
    }

    $keep = array_values(
        array_filter(
            $notices['error'],
            static function ($notice) {
                $text = isset($notice['notice']) ? wp_strip_all_tags((string) $notice['notice']) : '';
                if ('' === $text) {
                    return true;
                }
                if (false !== stripos($text, 'Input error')) {
                    return false;
                }
                if (false !== stripos($text, 'GiftToWallet')) {
                    return false;
                }

                return true;
            }
        )
    );

    if (count($keep) === count($notices['error'])) {
        return;
    }

    if (empty($keep)) {
        unset($notices['error']);
    } else {
        $notices['error'] = $keep;
    }

    WC()->session->set('wc_notices', $notices);

    if (function_exists('wc_clear_notices')) {
        wc_clear_notices('error');
        foreach ($keep as $notice) {
            if (isset($notice['notice'], $notice['type'])) {
                wc_add_notice($notice['notice'], $notice['type'], $notice['data'] ?? []);
            }
        }
    }
}

/**
 * Buyer-requested redeem amounts per code (when Pro UI is enabled).
 *
 * @return array<string, int>
 */
function wallregi_session_get_applied_giftcard_buyer_amounts()
{
    if (!function_exists('WC') || !WC()->session) {
        return [];
    }
    $b = WC()->session->get('applied_giftcard_buyer_amounts', []);
    return is_array($b) ? $b : [];
}

/**
 * @param string $coupon_code Gift card number.
 * @param int    $amount      Requested amount (store units); 0 removes the override.
 */
function wallregi_session_set_applied_giftcard_buyer_amount($coupon_code, $amount)
{
    if (!function_exists('WC') || !WC()->session) {
        return;
    }
    $code = wallregi_get_canonical_giftcard_number($coupon_code);
    $amount = max(0, (int) $amount);
    $buyer = wallregi_session_get_applied_giftcard_buyer_amounts();
    if ($amount <= 0) {
        unset($buyer[$code]);
    } else {
        $buyer[$code] = $amount;
    }
    WC()->session->set('applied_giftcard_buyer_amounts', $buyer);
}

/**
 * Single gift card column as SQL identifier (whitelist only).
 *
 * @param string $column Column name.
 * @return string Backtick-wrapped column, or empty string if not allowed.
 */
function wallregi_giftcard_quoted_column_sql($column)
{
    $key = sanitize_key((string) $column);
    if (!in_array($key, wallregi_get_giftcard_table_column_names(), true)) {
        return '';
    }

    return '`' . esc_sql($key) . '`';
}

/**
 * Column names from DESCRIBE for plugin tables only.
 *
 * @param string $table_full_name Full table name including prefix.
 * @return string[]
 */
function wallregi_db_describe_column_names($table_full_name)
{
    global $wpdb;

    $allowed = array(
        wallregi_giftcard_db_table_name(),
        wallregi_transaction_db_table_name(),
        wallregi_image_upload_db_table_name(),
    );
    if (!in_array($table_full_name, $allowed, true)) {
        return array();
    }

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- DESCRIBE on allowlisted plugin tables only.
    return $wpdb->get_col($wpdb->prepare('DESCRIBE %i', $table_full_name), 0);
}

/**
 * Whether all expected columns exist on a plugin table.
 *
 * @param string   $table_full_name   Full table name including prefix.
 * @param string[] $expected_columns Column names to require.
 * @return bool
 */
function wallregi_check_table_columns_exist($table_full_name, $expected_columns)
{
    if (empty($expected_columns) || !is_array($expected_columns)) {
        return false;
    }
    $existing_columns = wallregi_db_describe_column_names($table_full_name);
    if (empty($existing_columns)) {
        return false;
    }

    return empty(array_diff($expected_columns, $existing_columns));
}

/**
 * Comma-separated, backtick-quoted column list for SELECT. Whitelist-only; not passed through wpdb::prepare().
 *
 * @param string[]|null $columns Requested columns; each must be in the schema list, or null for all columns.
 * @return string
 */
function wallregi_giftcard_select_columns_sql($columns = null)
{
    $allowed = wallregi_get_giftcard_table_column_names();
    if (null === $columns) {
        $use = $allowed;
    } else {
        $use = array();
        foreach ($columns as $col) {
            $key = sanitize_key((string) $col);
            if (in_array($key, $allowed, true)) {
                $use[] = $key;
            }
        }
        if (empty($use)) {
            $use = $allowed;
        }
    }
    $parts = array();
    foreach ($use as $col) {
        $parts[] = '`' . esc_sql($col) . '`';
    }

    return implode(', ', $parts);
}

/**
 * Create the Gift Cards table on plugin activation
 */
function wallregi_create_database_tables()
{
    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset_collate = $wpdb->get_charset_collate();

    $wallregi_giftcard_table = $wpdb->prefix . 'wx_gift_cards';
    $wallregi_transaction_table = $wpdb->prefix . 'wx_giftcard_transaction';
    $giftcard_image_upload = $wpdb->prefix . 'wx_giftcard_image_upload';

    // Create Gift Card Table
    $giftcard_sql = "CREATE TABLE IF NOT EXISTS $wallregi_giftcard_table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        order_id BIGINT(20) DEFAULT 0,
        item_id BIGINT(20) DEFAULT 0,
        product_id BIGINT(20) DEFAULT 0,
        initial_amount BIGINT(20) NOT NULL, 
        current_amount BIGINT(20) NOT NULL, 
        giftcard_number VARCHAR(255) NOT NULL UNIQUE,  
        expiry_date DATE NOT NULL,
        expiry_period VARCHAR(100) NOT NULL,
        total_redeem BIGINT(20) DEFAULT 0, 
        receipent_name VARCHAR(100) NOT NULL,
        receipent_email VARCHAR(100) NOT NULL,
        sender_name VARCHAR(100) NOT NULL,
        message TEXT NULL,
        send_date_time DATETIME NOT NULL,
        preferred_date_time DATETIME NULL,
        giftcard_image VARCHAR(255) NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_by BIGINT(20) UNSIGNED NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        updated_by BIGINT(20) UNSIGNED NULL,
        send_mail_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        sent_at DATETIME DEFAULT '0000-00-00 00:00:00',
        email_status TINYINT(1) NOT NULL DEFAULT 0,  -- 0 = Pending, 1 = Sent, 2 = Failed
        delivery_channel VARCHAR(16) NOT NULL DEFAULT 'email',
        receipent_phone VARCHAR(32) NULL,
        sms_status TINYINT(1) NOT NULL DEFAULT 0,
        sms_sent_at DATETIME DEFAULT '0000-00-00 00:00:00',
        status ENUM('active', 'used', 'expired', 'cancelled') NOT NULL DEFAULT 'active',
        epass_data LONGTEXT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    dbDelta($giftcard_sql);

    // Create Transaction Table
    $transaction_sql = "CREATE TABLE IF NOT EXISTS $wallregi_transaction_table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        giftcard_id BIGINT(20) UNSIGNED NOT NULL,  -- Fixed foreign key column definition
        amount INT(11) NOT NULL, 
        order_id VARCHAR(50) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by BIGINT(20) UNSIGNED NULL,
        updated_by BIGINT(20) UNSIGNED NULL,
        reconciled TINYINT(1) DEFAULT 0,
        message TEXT NULL,
        PRIMARY KEY (id),
        FOREIGN KEY (giftcard_id) REFERENCES $wallregi_giftcard_table(id) ON DELETE CASCADE  -- Fixed the foreign key constraint
    ) $charset_collate;";
    dbDelta($transaction_sql);

    // Gift Card Image Upload Table (WITHOUT giftcard_id)
    $image_upload_sql = "CREATE TABLE IF NOT EXISTS $giftcard_image_upload (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        giftcard_image_url VARCHAR(255) NULL,
        uploaded_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($image_upload_sql);

    $wallregi_security_audit = wallregi_security_audit_db_table_name();
    $audit_sql = "CREATE TABLE IF NOT EXISTS $wallregi_security_audit (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        created_at DATETIME NOT NULL,
        action VARCHAR(64) NOT NULL,
        result VARCHAR(16) NOT NULL,
        ip VARCHAR(45) NOT NULL DEFAULT '',
        identifier VARCHAR(191) NOT NULL DEFAULT '',
        user_id BIGINT(20) UNSIGNED NULL,
        detail VARCHAR(500) NULL,
        PRIMARY KEY (id),
        KEY created_at (created_at),
        KEY action_created (action, created_at),
        KEY ip_created (ip, created_at)
    ) $charset_collate;";
    dbDelta($audit_sql);
}

function wallregi_delete_database_tables()
{
    global $wpdb;

    // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Uninstall removes plugin-only custom tables.
    $wpdb->query($wpdb->prepare('DROP TABLE IF EXISTS %i', wallregi_transaction_db_table_name()));
    $wpdb->query($wpdb->prepare('DROP TABLE IF EXISTS %i', wallregi_image_upload_db_table_name()));
    $wpdb->query($wpdb->prepare('DROP TABLE IF EXISTS %i', wallregi_giftcard_db_table_name()));
    $wpdb->query($wpdb->prepare('DROP TABLE IF EXISTS %i', wallregi_security_audit_db_table_name()));
    // phpcs:enable
}

if (!function_exists('wallregi_render_custom_pdf_body')) {
    /**
     * Render custom PDF body by replacing dynamic placeholder tags.
     *
     * @param string               $custom_html Custom HTML markup.
     * @param array<string, mixed> $context     Dynamic gift card data.
     * @return string
     */
    function wallregi_render_custom_pdf_body($custom_html, array $context)
    {
        $replacements = [
            '[giftcard_title]'     => $context['heading'] ?? '',
            '{{title}}'            => $context['heading'] ?? '',
            '{{giftcard_title}}'   => $context['heading'] ?? '',

            '[giftcard_price]'     => $context['formatted_price'] ?? '',
            '{{price}}'            => $context['formatted_price'] ?? '',
            '{{giftcard_price}}'   => $context['formatted_price'] ?? '',

            '[giftcard_code]'      => $context['gift_code'] ?? '',
            '{{code}}'             => $context['gift_code'] ?? '',
            '{{giftcard_code}}'    => $context['gift_code'] ?? '',
            '{{card_number}}'      => $context['gift_code'] ?? '',

            '[giftcard_image]'     => $context['image_html'] ?? '',
            '{{image}}'            => $context['image_html'] ?? '',
            '{{giftcard_image}}'   => $context['image_html'] ?? '',

            '[giftcard_image_url]' => $context['image_url'] ?? '',
            '{{image_url}}'        => $context['image_url'] ?? '',

            '[giftcard_logo]'      => $context['logo_html'] ?? '',
            '{{logo}}'             => $context['logo_html'] ?? '',
            '{{giftcard_logo}}'    => $context['logo_html'] ?? '',

            '[giftcard_scannable]' => $context['scannable_html'] ?? '',
            '{{scannable}}'        => $context['scannable_html'] ?? '',

            '[giftcard_qrcode]'    => $context['qrcode_html'] ?? '',
            '{{qrcode}}'           => $context['qrcode_html'] ?? '',

            '[giftcard_barcode]'   => $context['barcode_html'] ?? '',
            '{{barcode}}'          => $context['barcode_html'] ?? '',

            '[giftcard_expiry]'    => $context['expiry_date'] ?? '',
            '{{expiry}}'           => $context['expiry_date'] ?? '',
            '{{expiry_date}}'      => $context['expiry_date'] ?? '',

            '[giftcard_date]'      => $context['date_html'] ?? '',
            '{{date}}'             => $context['date_html'] ?? '',

            '[giftcard_message]'   => $context['message'] ?? '',
            '{{message}}'          => $context['message'] ?? '',

            '[giftcard_footer]'    => $context['short_description'] ?? '',
            '{{footer}}'           => $context['short_description'] ?? '',

            '[recipient_name]'     => $context['recipient_name'] ?? '',
            '{{recipient_name}}'   => $context['recipient_name'] ?? '',

            '[recipient_email]'    => $context['recipient_email'] ?? '',
            '{{recipient_email}}'  => $context['recipient_email'] ?? '',

            '[sender_name]'        => $context['sender_name'] ?? '',
            '{{sender_name}}'      => $context['sender_name'] ?? '',

            '[site_title]'         => $context['site_title'] ?? '',
            '{{site_title}}'       => $context['site_title'] ?? '',

            '[site_url]'           => $context['site_url'] ?? '',
            '{{site_url}}'         => $context['site_url'] ?? '',

            '[apply_url]'          => $context['apply_url'] ?? '',
            '{{apply_url}}'        => $context['apply_url'] ?? '',
        ];

        return strtr($custom_html, $replacements);
    }
}

