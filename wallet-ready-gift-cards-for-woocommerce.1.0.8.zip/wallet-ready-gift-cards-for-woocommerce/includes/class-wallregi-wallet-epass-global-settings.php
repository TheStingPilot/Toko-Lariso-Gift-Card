<?php
/**
 * Global ePasscard pass template (Settings → Google/Apple Wallet) + helpers.
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Parse global pass template + mapping from a request (POST/AJAX wallet tab).
 *
 * @param array<string, mixed> $request Raw request.
 * @return array{pass_config: array<string, mixed>, stripe_url: string}
 */
function wallregi_wallet_parse_global_pass_config_from_request( array $request ) {
	if ( ! function_exists( 'wallregi_wallet_epass_sanitize_template_uid' ) ) {
		$api = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-public-api.php';
		if ( file_exists( $api ) ) {
			require_once $api;
		}
	}

	$labels = class_exists( 'WALLREGI_Wallet_Epass_Product_Admin' )
		? WALLREGI_Wallet_Epass_Product_Admin::get_gift_element_labels()
		: [];

	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below.
	$raw_template = isset( $request['wallregi_global_epass_template_uid'] )
		? sanitize_text_field( wp_unslash( (string) $request['wallregi_global_epass_template_uid'] ) )
		: '';
	$template_uid = wallregi_wallet_epass_sanitize_template_uid( $raw_template );

	if ( false === $template_uid ) {
		$mapping = [];
		foreach ( array_keys( $labels ) as $slug ) {
			$mapping[ (string) $slug ] = '';
		}
		$stripe_raw = isset( $request['wallregi_global_epass_stripe_image_url'] )
			? wp_unslash( (string) $request['wallregi_global_epass_stripe_image_url'] )
			: '';
		$stripe_url = '' !== $stripe_raw ? esc_url_raw( $stripe_raw ) : '';

		return [
			'pass_config' => [
				'template_uid'   => '',
				'template_name'  => '',
				'template_id'    => 0,
				'pass_fields'    => [],
				'mapping'        => $mapping,
				'schema_version' => 1,
			],
			'stripe_url'  => $stripe_url,
		];
	}

	$template_name = isset( $request['wallregi_global_epass_template_name'] )
		? sanitize_text_field( wp_unslash( (string) $request['wallregi_global_epass_template_name'] ) )
		: '';
	$template_id   = isset( $request['wallregi_global_epass_template_id'] )
		? absint( wp_unslash( $request['wallregi_global_epass_template_id'] ) )
		: 0;

	$snapshot_raw = isset( $request['wallregi_global_epass_pass_fields_json'] )
		? wp_unslash( (string) $request['wallregi_global_epass_pass_fields_json'] )
		: '';
	$snapshot     = json_decode( $snapshot_raw, true );
	if ( ! is_array( $snapshot ) ) {
		$snapshot = [];
	}

	$allowed_uids = [];
	$clean_fields = [];
	foreach ( $snapshot as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$f_uid = isset( $row['uid'] ) ? wallregi_wallet_epass_sanitize_template_uid( (string) $row['uid'] ) : false;
		if ( false === $f_uid ) {
			continue;
		}
		$allowed_uids[] = $f_uid;
		$clean_fields[] = [
			'uid'        => $f_uid,
			'field_name' => isset( $row['field_name'] ) ? sanitize_text_field( (string) $row['field_name'] ) : '',
			'field_type' => isset( $row['field_type'] ) ? sanitize_key( (string) $row['field_type'] ) : '',
		];
	}
	$allowed_uids = array_values( array_unique( $allowed_uids ) );

	$mapping = [];
	$posted_map = isset( $request['wallregi_global_epass_mapping'] ) && is_array( $request['wallregi_global_epass_mapping'] )
		? wp_unslash( $request['wallregi_global_epass_mapping'] )
		: [];

	foreach ( array_keys( $labels ) as $slug ) {
		$slug = (string) $slug;
		if ( ! isset( $posted_map[ $slug ] ) ) {
			$mapping[ $slug ] = '';
			continue;
		}
		$val = sanitize_text_field( (string) $posted_map[ $slug ] );
		$val = wallregi_wallet_epass_sanitize_template_uid( $val );
		if ( false === $val ) {
			$mapping[ $slug ] = '';
			continue;
		}
		$mapping[ $slug ] = in_array( $val, $allowed_uids, true ) ? $val : '';
	}

	$stripe_raw = isset( $request['wallregi_global_epass_stripe_image_url'] )
		? wp_unslash( (string) $request['wallregi_global_epass_stripe_image_url'] )
		: '';
	$stripe_url = '' !== $stripe_raw ? esc_url_raw( $stripe_raw ) : '';

	return [
		'pass_config' => [
			'template_uid'   => $template_uid,
			'template_name'  => $template_name,
			'template_id'    => $template_id,
			'pass_fields'    => $clean_fields,
			'mapping'        => $mapping,
			'schema_version' => 1,
		],
		'stripe_url'  => $stripe_url,
	];
}

/**
 * Product-specific pass config if valid; otherwise global store config.
 *
 * Used for all pass issuance (checkout, manual admin, bulk import, dashboard “generate pass”):
 * when the gift card row has a `product_id`, a valid product-level Google/Apple template in
 * `_wallregi_epass_pass_config` wins; otherwise the global template from Wallet settings is used.
 *
 * @param int $product_id WooCommerce product ID (0 for manual / unlinked cards → global only).
 * @return array<string, mixed> Same shape as product meta `_wallregi_epass_pass_config` (may be empty).
 */
function wallregi_wallet_get_effective_epass_pass_config( $product_id ) {
	if ( ! function_exists( 'wallregi_wallet_epass_sanitize_template_uid' ) ) {
		$api = WALLREGI_PLUGIN_DIR . 'includes/class-wallregi-wallet-epass-public-api.php';
		if ( file_exists( $api ) ) {
			require_once $api;
		}
	}

	$product_id = absint( $product_id );
	if ( $product_id > 0 ) {
		$cfg = get_post_meta( $product_id, '_wallregi_epass_pass_config', true );
		if ( is_array( $cfg ) && ! empty( $cfg['template_uid'] ) ) {
			$u = wallregi_wallet_epass_sanitize_template_uid( (string) $cfg['template_uid'] );
			if ( false !== $u ) {
				return $cfg;
			}
		}
	}

	$opt = get_option( 'wallregi_wallet_settings', [] );
	if ( ! is_array( $opt ) ) {
		return [];
	}
	$g = isset( $opt['epass_global_pass_config'] ) && is_array( $opt['epass_global_pass_config'] )
		? $opt['epass_global_pass_config']
		: [];
	if ( ! empty( $g['template_uid'] ) ) {
		$u = wallregi_wallet_epass_sanitize_template_uid( (string) $g['template_uid'] );
		if ( false !== $u ) {
			return $g;
		}
	}

	return [];
}

/**
 * Main plugin bootstrap file path (for `plugins_url()`), relative to this file in `includes/`.
 *
 * @return string Absolute path or empty if not found.
 */
function wallregi_wallet_main_plugin_bootstrap_file() {
	static $path = null;
	if ( null !== $path ) {
		return $path;
	}
	$candidate = dirname( __DIR__ ) . '/wallet-ready-gift-cards-for-woocommerce.php';
	$path      = file_exists( $candidate ) ? $candidate : '';
	return $path;
}

/**
 * Default packaged stripe / thumbnail image URL for wallet passes when nothing else is set.
 *
 * @return string Public URL or empty when the asset file is missing.
 */
function wallregi_wallet_get_default_epass_stripe_image_url() {
	$main = wallregi_wallet_main_plugin_bootstrap_file();
	if ( '' === $main ) {
		return '';
	}
	$rel = 'backend/assets/giftcard-thumb.png';
	$abs = dirname( $main ) . '/' . $rel;
	if ( ! file_exists( $abs ) ) {
		return '';
	}
	return esc_url_raw( plugins_url( $rel, $main ) );
}

/**
 * Optional stripe image URL saved on the gift card product (`_wallregi_epass_pass_config['stripe_image_url']`).
 *
 * @param int $product_id WooCommerce product ID.
 * @return string Escaped URL or empty.
 */
function wallregi_wallet_get_product_epass_stripe_image_url( $product_id ) {
	$product_id = absint( $product_id );
	if ( $product_id <= 0 ) {
		return '';
	}
	$cfg = get_post_meta( $product_id, '_wallregi_epass_pass_config', true );
	if ( ! is_array( $cfg ) ) {
		return '';
	}
	$raw = isset( $cfg['stripe_image_url'] ) ? trim( (string) $cfg['stripe_image_url'] ) : '';
	return '' !== $raw ? esc_url_raw( $raw ) : '';
}

/**
 * Resolve the image URL sent for mapped “gift card image” / wallet stripe artwork.
 *
 * Order: PDF thumbnail on the gift card row (after filter for generated stripe assets) →
 * product-level stripe URL → global Wallet stripe fallback → packaged `giftcard-thumb.png`.
 *
 * @param array<string, mixed> $row wx_gift_cards row.
 * @return string Non-empty HTTPS/HTTP URL or empty if nothing could be resolved.
 */
function wallregi_wallet_resolve_epass_stripe_image_url( array $row ) {
	$thumb = isset( $row['giftcard_image'] ) ? trim( (string) $row['giftcard_image'] ) : '';
	if ( '' !== $thumb ) {
		/**
		 * Turn a stored PDF thumbnail URL into the wallet “stripe” image URL (e.g. generated 1125×432 asset).
		 *
		 * @param string               $thumb_url Thumbnail URL from the gift card row.
		 * @param array<string, mixed> $row        Full gift card row.
		 */
		$stripe_from_thumb = (string) apply_filters( 'wallregi_wallet_epass_stripe_image_from_pdf_thumbnail', $thumb, $row );
		$stripe_from_thumb = trim( $stripe_from_thumb );
		if ( '' !== $stripe_from_thumb ) {
			return esc_url_raw( $stripe_from_thumb );
		}
	}

	$product_id = isset( $row['product_id'] ) ? absint( $row['product_id'] ) : 0;
	$product_st = wallregi_wallet_get_product_epass_stripe_image_url( $product_id );
	if ( '' !== $product_st ) {
		return $product_st;
	}

	$global_st = function_exists( 'wallregi_wallet_get_global_stripe_image_url' ) ? trim( (string) wallregi_wallet_get_global_stripe_image_url() ) : '';
	if ( '' !== $global_st ) {
		return $global_st;
	}

	$default_st = wallregi_wallet_get_default_epass_stripe_image_url();
	return '' !== $default_st ? $default_st : '';
}

/**
 * Fallback stripe image URL for wallet passes (global setting).
 *
 * @return string
 */
function wallregi_wallet_get_global_stripe_image_url() {
	$opt = get_option( 'wallregi_wallet_settings', [] );
	if ( ! is_array( $opt ) ) {
		return '';
	}
	$url = isset( $opt['epass_global_stripe_image_url'] ) ? (string) $opt['epass_global_stripe_image_url'] : '';
	return '' !== $url ? esc_url_raw( $url ) : '';
}
