<?php
if (!defined('ABSPATH')) {
    exit;
}

class WALLREGI_Cron_Schedule {

    public function wallregi_corn_initialize() {

        // Register custom interval early
        add_filter('cron_schedules', [$this, 'wallregi_add_cron_interval']);

        // Register the cron hook
        add_action('init', [$this, 'wallregi_register_giftcard_cron_hook']);
    }

    public function wallregi_register_giftcard_cron_hook() {

        // Schedule the email handler
        if (!wp_next_scheduled('wallregi_cron_check_email_queue')) {
            wp_schedule_event(time(), 'every_five_minutes', 'wallregi_cron_check_email_queue');
        }

        // Schedule the expiry giftcards handler
        if (!wp_next_scheduled('wallregi_cron_check_expired_giftcards')) {
            wp_schedule_event(time(), 'wallregi_daily_expiry', 'wallregi_cron_check_expired_giftcards');
        }
    }

    /**
     * Add custom interval
     */
    public function wallregi_add_cron_interval($schedules) {
        $schedules['every_five_minutes'] = [
            'interval' => 300,
            'display'  => __('Every 5 Minutes', 'wallet-ready-gift-cards-for-woocommerce'),
        ];

        // Custom "daily" just for giftcard expiry — e.g. run every 86400 seconds (24 hours)
        $schedules['wallregi_daily_expiry'] = [
            'interval' => 86400, // 24 hours
            'display'  => __('Gift Card Expiry - Every 24 Hours', 'wallet-ready-gift-cards-for-woocommerce'),
        ];
        return $schedules;
    }

    /**
     * Cron job callback: send gift card emails where preferred time has passed
     */
    public function wallregi_cron_email_handler() {
        global $wpdb;
        $now = current_time('mysql');
        
        $query = "SELECT `giftcard_number` FROM %i
            WHERE `email_status` = 0
            AND `preferred_date_time` <= %s";

        if ( function_exists( 'wallregi_giftcard_table_has_column' ) && wallregi_giftcard_table_has_column( 'delivery_channel' ) ) {
            $query .= "
                AND COALESCE( NULLIF( `delivery_channel`, '' ), 'email' ) IN ( 'email', 'both' )";
        }

        // Select scheduled gift cards
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
        $giftcards = $wpdb->get_results(
            $wpdb->prepare(
                $query,
                wallregi_giftcard_db_table_name(),
                $now
            )
        );

        if (!empty($giftcards)) {
            // Get email settings
            $wallregi_settings = get_option('wallregi_email_settings', []);

            // Determine batch size (fallback to 5 if invalid)
            $batch_size = isset($wallregi_settings['email_batch_size']) && intval($wallregi_settings['email_batch_size']) > 0
                ? absint($wallregi_settings['email_batch_size'])
                : 5;

            $giftcard_codes = wp_list_pluck($giftcards, 'giftcard_number');
            $batches = array_chunk($giftcard_codes, $batch_size);

            foreach ($batches as $batch) {
                // Fire email function
                do_action('wallregi_send_bulk_giftcard_emails', $batch, ['batch_size' => $batch_size]);
            }
        }

        /**
         * Fires after the email queue cron pass so extensions (e.g. SMS) can process their queue.
         *
         * @param string $now MySQL datetime used for the queue cutoff.
         */
        do_action( 'wallregi_cron_after_email_queue', $now );
    }

    /**
     * Cron job callback: expire gift cards whose expiry date has passed
     */
    public function wallregi_expire_giftcards_handler() {
        global $wpdb;
        $today = current_time('Y-m-d');

        // Get all gift cards that are not already expired and are past expiry_date
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
        $expired_cards = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT `id` FROM %i WHERE `status` != %s AND `expiry_date` < %s',
                wallregi_giftcard_db_table_name(),
                'expired',
                $today
            )
        );

        if (!empty($expired_cards)) {
            foreach ($expired_cards as $card) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                $wpdb->update(
                    wallregi_giftcard_db_table_name(),
                    [
                        'status'     => 'expired',
                        'updated_at' => current_time('mysql'),
                    ],
                    ['id' => $card->id],
                    ['%s', '%s'],
                    ['%d']
                );
            }
        }

        do_action( 'wallregi_after_expire_giftcards_cron' );
    }

    /**
     * Cleanup: Unschedule on deactivation
     */
    public static function deactivate_cron() {
        $cleared = wp_clear_scheduled_hook('wallregi_cron_check_email_queue');
        wp_clear_scheduled_hook('wallregi_cron_check_expired_giftcards');
    }
}

// Run cron schedule
add_action('plugins_loaded', function () {
    if (class_exists('WALLREGI_Cron_Schedule')) {
        (new WALLREGI_Cron_Schedule())->wallregi_corn_initialize();
    }
});


// Handle email queue
add_action('wallregi_cron_check_email_queue', function() {

    $schedule = new WALLREGI_Cron_Schedule();
    $schedule->wallregi_cron_email_handler();

});

// Handle expiration
add_action('wallregi_cron_check_expired_giftcards', function () {
    $schedule = new WALLREGI_Cron_Schedule();
    $schedule->wallregi_expire_giftcards_handler();
});