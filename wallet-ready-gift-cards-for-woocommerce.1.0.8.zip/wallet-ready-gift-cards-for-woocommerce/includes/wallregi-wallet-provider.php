<?php
/**
 * Site-wide wallet provider: none, ePasscard, or GiftToWallet (mutually exclusive).
 *
 * @package Wallet_Ready_Gift_Cards_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Allowed wallet provider slugs.
 *
 * @return string[]
 */
function wallregi_wallet_provider_choices() {
	$choices = [
		'none'          => __( 'None (gift cards only, no wallet pass)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'epasscard'     => __( 'ePasscard (Apple / Google Wallet)', 'wallet-ready-gift-cards-for-woocommerce' ),
		'gifttowallet'  => __( 'GiftToWallet', 'wallet-ready-gift-cards-for-woocommerce' ),
	];

	/**
	 * Filter wallet provider choices shown in admin.
	 *
	 * @param array<string, string> $choices slug => label.
	 */
	return (array) apply_filters( 'wallregi_wallet_provider_choices', $choices );
}

/**
 * Active wallet provider for this site.
 *
 * @return string none|epasscard|gifttowallet
 */
function wallregi_get_wallet_provider() {
	$saved = get_option( 'wallregi_wallet_settings', [] );
	if ( is_array( $saved ) && ! empty( $saved['wallet_provider'] ) ) {
		$provider = sanitize_key( (string) $saved['wallet_provider'] );
		if ( array_key_exists( $provider, wallregi_wallet_provider_choices() ) ) {
			/**
			 * Filter resolved wallet provider.
			 *
			 * @param string $provider Active slug.
			 */
			return (string) apply_filters( 'wallregi_wallet_provider', $provider );
		}
	}

	// Back-compat: existing ePasscard connection implies epasscard until merchant chooses otherwise.
	if ( function_exists( 'wallregi_wallet_epass_is_api_configured' ) && wallregi_wallet_epass_is_api_configured() ) {
		return (string) apply_filters( 'wallregi_wallet_provider', 'epasscard' );
	}

	return (string) apply_filters( 'wallregi_wallet_provider', 'none' );
}

/**
 * @return bool
 */
function wallregi_wallet_provider_is_epasscard() {
	return 'epasscard' === wallregi_get_wallet_provider();
}

/**
 * @return bool
 */
function wallregi_wallet_provider_is_gifttowallet() {
	return 'gifttowallet' === wallregi_get_wallet_provider();
}

/**
 * Whether ePasscard outbound API / issuance should run.
 *
 * @return bool
 */
function wallregi_wallet_should_use_epasscard() {
	return wallregi_wallet_provider_is_epasscard()
		&& function_exists( 'wallregi_wallet_epass_is_api_configured' )
		&& wallregi_wallet_epass_is_api_configured();
}

/**
 * Sanitize wallet provider from request.
 *
 * @param string $raw Raw value.
 * @return string
 */
function wallregi_sanitize_wallet_provider( $raw ) {
	$provider = sanitize_key( (string) $raw );
	$choices  = wallregi_wallet_provider_choices();

	if ( ! array_key_exists( $provider, $choices ) ) {
		return 'none';
	}

	if ( 'gifttowallet' === $provider && ! wallregi_gtw_extension_is_active() ) {
		return wallregi_get_wallet_provider();
	}

	return $provider;
}

/**
 * Whether the GiftToWallet extension plugin is loaded.
 *
 * @return bool
 */
function wallregi_gtw_extension_is_active() {
	return defined( 'WALLREGI_GTW_VERSION' ) && class_exists( 'WALLREGI_GTW_Bootstrap' );
}
