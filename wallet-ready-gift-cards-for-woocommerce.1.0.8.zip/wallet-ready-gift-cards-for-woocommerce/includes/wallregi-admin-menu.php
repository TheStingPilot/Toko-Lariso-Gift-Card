<?php
/**
 * Admin menu slug and URLs for Gift Cards / GiftRocket screens.
 *
 * @package Wallet_Ready_Gift_Cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Top-level admin menu slug (GiftRocket → main gift card dashboard).
 *
 * @return string
 */
function wallregi_gift_cards_parent_menu_slug() {
	return 'wx-gift-cards';
}

/**
 * Build an admin.php URL for a GiftRocket–family screen.
 *
 * @param array<string, string> $query_args Merged into the query string. Include `page` for sub-screens (e.g. Pro bulk import).
 * @return string
 */
function wallregi_gift_cards_admin_url( array $query_args = [] ) {
	if ( ! isset( $query_args['page'] ) ) {
		$query_args['page'] = wallregi_gift_cards_parent_menu_slug();
	}

	return add_query_arg( $query_args, admin_url( 'admin.php' ) );
}

/**
 * Redirect legacy URLs (Products → Gift Cards) to the top-level menu URL.
 */
function wallregi_redirect_legacy_gift_cards_admin_url() {
	if ( ! is_admin() || ! isset( $_GET['post_type'], $_GET['page'] ) ) {
		return;
	}
	if ( 'product' !== $_GET['post_type'] || wallregi_gift_cards_parent_menu_slug() !== $_GET['page'] ) {
		return;
	}

	$tab    = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
	$nonce  = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
	$target = wallregi_gift_cards_admin_url();
	if ( '' !== $tab ) {
		$target = add_query_arg( 'tab', $tab, $target );
	}
	if ( '' !== $nonce ) {
		$target = add_query_arg( '_wpnonce', $nonce, $target );
	}

	wp_safe_redirect( $target );
	exit;
}
add_action( 'admin_init', 'wallregi_redirect_legacy_gift_cards_admin_url', 1 );

/**
 * Capability required for GiftRocket admin screens.
 *
 * Uses manage_woocommerce when WooCommerce is active; otherwise manage_options
 * so site administrators can access the menu without WooCommerce.
 *
 * @return string
 */
function wallregi_admin_capability() {
	if ( function_exists( 'wallregi_is_woocommerce_active' ) && wallregi_is_woocommerce_active() ) {
		return 'manage_woocommerce';
	}

	return 'manage_options';
}

/**
 * Register the GiftRocket admin menu when WooCommerce is not active.
 *
 * WooCommerce-dependent screens are not loaded; the dashboard shows a notice
 * that WooCommerce must be installed and activated for full functionality.
 */
function wallregi_register_admin_menu_without_woocommerce() {
	if ( ! function_exists( 'wallregi_is_woocommerce_active' ) || wallregi_is_woocommerce_active() ) {
		return;
	}

	$parent_slug = wallregi_gift_cards_parent_menu_slug();
	$menu_title  = apply_filters(
		'wallregi_gift_rocket_menu_title',
		__( 'GiftRocket', 'wallet-ready-gift-cards-for-woocommerce' )
	);
	$capability  = wallregi_admin_capability();

	add_menu_page(
		$menu_title,
		$menu_title,
		$capability,
		$parent_slug,
		'wallregi_render_woocommerce_required_admin_page',
		'dashicons-awards',
		56
	);

	add_submenu_page(
		$parent_slug,
		__( 'Gift Cards', 'wallet-ready-gift-cards-for-woocommerce' ),
		__( 'Gift Cards', 'wallet-ready-gift-cards-for-woocommerce' ),
		$capability,
		$parent_slug,
		'wallregi_render_woocommerce_required_admin_page'
	);
}
add_action( 'admin_menu', 'wallregi_register_admin_menu_without_woocommerce' );

/**
 * Admin page shown when WooCommerce is missing (menu shell only).
 */
function wallregi_render_woocommerce_required_admin_page() {
	if ( ! current_user_can( wallregi_admin_capability() ) ) {
		wp_die( esc_html__( 'You do not have permission to access this page.', 'wallet-ready-gift-cards-for-woocommerce' ) );
	}

	$install_url = admin_url( 'plugin-install.php?s=woocommerce&tab=search&type=term' );
	?>
	<div class="wrap">
		<h1><?php echo esc_html( apply_filters( 'wallregi_gift_rocket_menu_title', __( 'GiftRocket', 'wallet-ready-gift-cards-for-woocommerce' ) ) ); ?></h1>
		<div class="notice notice-warning">
			<p>
				<strong>
					<?php
					esc_html_e(
						'Wallet Ready Gift Cards requires WooCommerce for full functionality. Please install and activate WooCommerce to create, sell, and manage gift cards.',
						'wallet-ready-gift-cards-for-woocommerce'
					);
					?>
				</strong>
			</p>
			<?php if ( current_user_can( 'install_plugins' ) ) : ?>
				<p>
					<a class="button button-primary" href="<?php echo esc_url( $install_url ); ?>">
						<?php esc_html_e( 'Install WooCommerce', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
					</a>
				</p>
			<?php endif; ?>
		</div>
	</div>
	<?php
}
