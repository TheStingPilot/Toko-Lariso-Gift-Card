<?php
/**
 * Barcode / QR helpers for gift card PDF (Dompdf-safe data URIs).
 *
 * @package Wallet_Ready_Gift_Cards
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Map admin symbology key to Picqer type constant (string).
 *
 * @param string $key Stored setting key e.g. C128, C39.
 * @return string
 */
function wallregi_pdf_barcode_type_from_setting( $key ) {
	$key = strtoupper( sanitize_text_field( (string) $key ) );
	$map = array(
		'C128'   => \Picqer\Barcode\BarcodeGenerator::TYPE_CODE_128,
		'C128A'  => \Picqer\Barcode\BarcodeGenerator::TYPE_CODE_128_A,
		'C128B'  => \Picqer\Barcode\BarcodeGenerator::TYPE_CODE_128_B,
		'C128C'  => \Picqer\Barcode\BarcodeGenerator::TYPE_CODE_128_C,
		'C39'    => \Picqer\Barcode\BarcodeGenerator::TYPE_CODE_39,
		'C39+'   => \Picqer\Barcode\BarcodeGenerator::TYPE_CODE_39_CHECKSUM,
		'C93'    => \Picqer\Barcode\BarcodeGenerator::TYPE_CODE_93,
		'I25'    => \Picqer\Barcode\BarcodeGenerator::TYPE_INTERLEAVED_2_5,
		'I25+'   => \Picqer\Barcode\BarcodeGenerator::TYPE_INTERLEAVED_2_5_CHECKSUM,
		'ITF14'  => \Picqer\Barcode\BarcodeGenerator::TYPE_ITF_14,
		'CODABAR' => \Picqer\Barcode\BarcodeGenerator::TYPE_CODABAR,
		'CODE11' => \Picqer\Barcode\BarcodeGenerator::TYPE_CODE_11,
	);

	return $map[ $key ] ?? \Picqer\Barcode\BarcodeGenerator::TYPE_CODE_128;
}

/**
 * PNG data URI for a barcode, or empty string on failure.
 *
 * @param string $code Gift card number.
 * @param string $symbology Setting key (e.g. C128).
 * @return string
 */
function wallregi_giftcard_pdf_barcode_data_uri( $code, $symbology ) {
	if ( ! class_exists( \Picqer\Barcode\BarcodeGeneratorPNG::class ) ) {
		return '';
	}
	$code = (string) $code;
	if ( '' === $code ) {
		return '';
	}

	try {
		$generator = new \Picqer\Barcode\BarcodeGeneratorPNG();
		$type      = wallregi_pdf_barcode_type_from_setting( $symbology );
		$png       = $generator->getBarcode( $code, $type, 2, 50, array( 0, 0, 0 ) );
		if ( ! is_string( $png ) || '' === $png ) {
			return '';
		}
		return 'data:image/png;base64,' . base64_encode( $png );
	} catch ( \Throwable $e ) {
		return '';
	}
}

/**
 * PNG data URI for a QR code encoding a URL (or any string), or empty string on failure.
 *
 * @param string $data URL or text.
 * @return string
 */
function wallregi_giftcard_pdf_qrcode_data_uri( $data ) {
	$data = (string) $data;
	if ( '' === $data || ! class_exists( \chillerlan\QRCode\QRCode::class ) ) {
		return '';
	}

	try {
		$out = ( new \chillerlan\QRCode\QRCode() )->render( $data );
		return is_string( $out ) ? $out : '';
	} catch ( \Throwable $e ) {
		return '';
	}
}

/**
 * PNG data URI for a PDF417 symbol encoding the gift card number, or empty string on failure.
 *
 * Uses Tecnick tc-lib-barcode (requires GD or Imagick).
 *
 * @param string $code Gift card number.
 * @return string
 */
function wallregi_giftcard_pdf_pdf417_data_uri( $code ) {
	$code = (string) $code;
	if ( '' === $code || ! class_exists( \Com\Tecnick\Barcode\Barcode::class ) ) {
		return '';
	}

	try {
		$barcode = new \Com\Tecnick\Barcode\Barcode();
		// Negative width/height: column/row scale factors (see tc-lib-barcode examples).
		$bobj = $barcode->getBarcodeObj( 'PDF417', $code, -3, -3, 'black', array( 0, 0, 0, 0 ) );
		$png  = $bobj->getPngData( extension_loaded( 'imagick' ) );
		if ( ! is_string( $png ) || '' === $png ) {
			return '';
		}
		return 'data:image/png;base64,' . base64_encode( $png );
	} catch ( \Throwable $e ) {
		return '';
	}
}

/**
 * Resolve a WooCommerce store page URL safely (works before `init` / rewrite setup).
 *
 * @param string $page WooCommerce page key, e.g. checkout, cart.
 * @return string
 */
function wallregi_get_wc_store_page_url( $page ) {
	$page = sanitize_key( (string) $page );
	if ( '' === $page || ! function_exists( 'wc_get_page_id' ) ) {
		return '';
	}

	$page_id = absint( wc_get_page_id( $page ) );
	if ( $page_id <= 0 ) {
		return '';
	}

	global $wp_rewrite;
	if ( did_action( 'init' ) && $wp_rewrite instanceof WP_Rewrite ) {
		if ( 'checkout' === $page && function_exists( 'wc_get_checkout_url' ) ) {
			return (string) wc_get_checkout_url();
		}
		if ( 'cart' === $page && function_exists( 'wc_get_cart_url' ) ) {
			return (string) wc_get_cart_url();
		}

		$permalink = get_permalink( $page_id );
		return is_string( $permalink ) ? $permalink : '';
	}

	return home_url( '/?page_id=' . $page_id );
}

/**
 * Base storefront URL for deep links that apply a gift card (?wallregi_apply_giftcard=), from General settings.
 *
 * @return string
 */
function wallregi_get_apply_giftcard_redirect_base_url() {
	$settings = get_option( 'wallregi_settings', [] );
	if ( ! is_array( $settings ) ) {
		$settings = [];
	}
	$target = isset( $settings['apply_giftcard_redirect_to'] ) ? sanitize_key( (string) $settings['apply_giftcard_redirect_to'] ) : '';
	if ( 'cart' !== $target ) {
		$target = 'checkout';
	}

	$url = '';
	if ( 'cart' === $target ) {
		$url = wallregi_get_wc_store_page_url( 'cart' );
	}
	if ( '' === $url ) {
		$url = wallregi_get_wc_store_page_url( 'checkout' );
	}
	if ( '' === $url ) {
		$url = home_url( '/' );
	}

	/**
	 * Filter the base URL for apply-gift-card deep links (PDF QR, email links, etc.).
	 *
	 * @param string $url    Resolved URL (cart or checkout per setting).
	 * @param string $target Sanitized setting: `checkout` or `cart`.
	 */
	return (string) apply_filters( 'wallregi_apply_giftcard_redirect_base_url', $url, $target );
}

/**
 * Build the storefront URL that applies this gift card when opened (QR on PDF).
 *
 * @param string $giftcard_number Gift card number.
 * @return string
 */
function wallregi_giftcard_get_apply_checkout_url( $giftcard_number ) {
	$giftcard_number = sanitize_text_field( (string) $giftcard_number );
	$base            = wallregi_get_apply_giftcard_redirect_base_url();
	$url             = add_query_arg(
		'wallregi_apply_giftcard',
		rawurlencode( $giftcard_number ),
		$base
	);

	/**
	 * Filter the apply-gift-card URL encoded in PDF QR codes and similar links.
	 *
	 * @param string $url Full URL with query arg.
	 * @param string $giftcard_number Sanitized gift card number.
	 */
	return (string) apply_filters( 'wallregi_giftcard_apply_checkout_url', $url, $giftcard_number );
}

/**
 * HTML for a sample barcode or QR on the single gift card product preview (not a real code).
 *
 * @param array $settings Merged `wallregi_settings` (expects `pdf_scannable_code_type`, `pdf_barcode_symbology`, `pdf_show_placeholder_scannable_product`).
 * @return string Safe HTML fragment or empty string.
 */
function wallregi_get_product_placeholder_scannable_html( $settings ) {
	if ( ! is_array( $settings ) ) {
		return '';
	}

	$type = isset( $settings['pdf_scannable_code_type'] ) ? sanitize_text_field( (string) $settings['pdf_scannable_code_type'] ) : 'none';
	$show = isset( $settings['pdf_show_placeholder_scannable_product'] ) ? sanitize_text_field( (string) $settings['pdf_show_placeholder_scannable_product'] ) : 'no';

	if ( 'yes' !== $show || ! in_array( $type, array( 'barcode', 'qr', 'pdf417', 'barcode_qr' ), true ) ) {
		return '';
	}

	/**
	 * Filter the placeholder string encoded in the product-page sample barcode / QR (not a real gift card).
	 *
	 * @param string $code Alphanumeric-ish string safe for common symbologies.
	 * @param array  $settings Plugin settings.
	 */
	$placeholder_code = (string) apply_filters( 'wallregi_product_placeholder_scannable_code', 'xxxxx', $settings );
	$placeholder_code = sanitize_text_field( $placeholder_code );
	if ( '' === $placeholder_code ) {
		$placeholder_code = 'xxxxx';
	}

	$sym = isset( $settings['pdf_barcode_symbology'] ) ? sanitize_text_field( (string) $settings['pdf_barcode_symbology'] ) : 'C128';

	$html = '';

	if ( 'barcode' === $type ) {
		$uri = wallregi_giftcard_pdf_barcode_data_uri( $placeholder_code, $sym );
		if ( '' !== $uri ) {
			$html = '<div class="wallregi-preview-scannable wallregi-preview-scannable--barcode" aria-hidden="true"><img src="' . esc_attr( $uri ) . '" alt="" width="250" height="50" decoding="async" loading="lazy" /></div>';
		}
	} elseif ( 'qr' === $type ) {
		$apply_url = wallregi_giftcard_get_apply_checkout_url( $placeholder_code );
		$uri       = wallregi_giftcard_pdf_qrcode_data_uri( $apply_url );
		if ( '' !== $uri ) {
			$html = '<div class="wallregi-preview-scannable wallregi-preview-scannable--qr" aria-hidden="true"><img src="' . esc_attr( $uri ) . '" alt="" width="120" height="120" decoding="async" loading="lazy" /></div>';
		}
	} elseif ( 'pdf417' === $type ) {
		$uri = wallregi_giftcard_pdf_pdf417_data_uri( $placeholder_code );
		if ( '' !== $uri ) {
			$html = '<div class="wallregi-preview-scannable wallregi-preview-scannable--pdf417" aria-hidden="true"><img src="' . esc_attr( $uri ) . '" alt="" width="260" height="88" decoding="async" loading="lazy" /></div>';
		}
	} elseif ( 'barcode_qr' === $type ) {
		$bc_uri    = wallregi_giftcard_pdf_barcode_data_uri( $placeholder_code, $sym );
		$apply_url = wallregi_giftcard_get_apply_checkout_url( $placeholder_code );
		$qr_uri    = wallregi_giftcard_pdf_qrcode_data_uri( $apply_url );
		if ( '' !== $bc_uri || '' !== $qr_uri ) {
			$html  = '<div class="wallregi-preview-scannable wallregi-preview-scannable--both" aria-hidden="true" style="display:flex;align-items:center;justify-content:center;gap:15px;flex-wrap:wrap;">';
			if ( '' !== $qr_uri ) {
				$html .= '<img src="' . esc_attr( $qr_uri ) . '" alt="" width="90" height="90" decoding="async" loading="lazy" />';
			}
			if ( '' !== $bc_uri ) {
				$html .= '<img src="' . esc_attr( $bc_uri ) . '" alt="" width="200" height="45" decoding="async" loading="lazy" />';
			}
			$html .= '</div>';
		}
	}

	/**
	 * Filter the full placeholder markup for the product page preview.
	 *
	 * @param string $html     HTML fragment.
	 * @param array  $settings Plugin settings.
	 */
	return (string) apply_filters( 'wallregi_product_placeholder_scannable_html', $html, $settings );
}
