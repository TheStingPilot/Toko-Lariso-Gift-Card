<?php
/**
 * Build & return a dynamic CSS string for Gift Card for WooCommerce.
 * 
 * This file is responsible for:
 * - Merging default and saved settings.
 * - Including helper functions and spacing generators.
 * - Combining modular inline CSS parts.
 * - Returning a complete $wallregi_custom_css string.
 * 
 * Usage:
 * $wallregi_custom_css = include WALLREGI_PLUGIN_DIR . 'frontend/custom-inline-styles.php';
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * STEP 1: Load all default configuration files
 */
$wallregi_default_files = [
    'default-settings/default-form-settings.php',
    'default-settings/default-pdf-settings.php',
    'default-settings/default-genral-settings.php'
];

// Merge all defaults into a single array
$wallregi_defaults = [];

foreach ( $wallregi_default_files as $wallregi_file ) {
    // include files
    if ( file_exists( plugin_dir_path(__FILE__) . $wallregi_file ) ) {
        $wallregi_defaults_data = include_once plugin_dir_path(__FILE__) . $wallregi_file;
        // Only merge if the included file returns an array
        if ( is_array( $wallregi_defaults_data ) ) {
            $wallregi_defaults = array_merge( $wallregi_defaults, $wallregi_defaults_data );
        }
    }
}

/**
 * STEP 2: Load user-saved options and merge with defaults
 */

// Load saved options settings
$wallregi_settings_options = get_option( 'wallregi_settings', [] );

// Merge saved options with defaults
$wallregi_settings = wp_parse_args( $wallregi_settings_options, $wallregi_defaults );


/**
 * STEP 3: Include dynamic CSS helper functions
 */
$wallregi_generate_css_files = [
    'variables' => 'dynamic-css/generate-css-variables.php',
    'functions' => 'dynamic-css/generate-css-functions.php',
    'spacing'   => 'dynamic-css/generate-css-spacing.php',
];
foreach ($wallregi_generate_css_files as $wallregi_key => $wallregi_file) {
    // include files
    if (file_exists(plugin_dir_path(__FILE__) . $wallregi_file)) {
        //echo plugin_dir_path(__FILE__) . $wallregi_file;
        include_once plugin_dir_path(__FILE__) . $wallregi_file;
    }
}

//var_dump($wallregi_giftcard_header_title_styles_group);
/**
 * STEP 4: Load modular CSS parts
 * - Giftcard product base styles
 * - form styles (headings, inputs, placeholders, focus, spacing)
 * - PDF layout styles
 */

$wallregi_custom_css = "";

$wallregi_modular_css_files = [
    'base' => 'inline-styles/base-styles.php',
    'form' => 'inline-styles/form-styles.php',
    'pdf' => 'inline-styles/pdf-styles.php',
];
foreach ($wallregi_modular_css_files as $wallregi_key => $wallregi_file) {
    // include files - use include (not include_once) since each file is different
    $wallregi_file_path = plugin_dir_path(__FILE__) . $wallregi_file;
    if (file_exists($wallregi_file_path)) {
        // Include the file and capture its return value
        $wallregi_css_output = include $wallregi_file_path;
        // Only concatenate if we got a valid string
        if (is_string($wallregi_css_output) && !empty(trim($wallregi_css_output))) {
            $wallregi_custom_css .= $wallregi_css_output;
        }
    }
}

// Return the final concatenated CSS string
return $wallregi_custom_css;