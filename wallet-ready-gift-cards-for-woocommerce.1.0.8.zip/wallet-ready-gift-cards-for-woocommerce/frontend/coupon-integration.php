<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Prevent direct access
}

if ( ! function_exists( 'wallregi_is_wc_cart_checkout_block_template' ) ) {
	/**
	 * Whether the storefront cart or checkout page uses WooCommerce Blocks (Store API UI).
	 * Classic coupon + redeem modal must be skipped in that case — blocks-integration.js owns the flow.
	 *
	 * @return bool
	 */
	function wallregi_is_wc_cart_checkout_block_template() {
		if ( function_exists( 'is_cart' ) && is_cart() ) {
			if ( class_exists( '\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils' ) && method_exists( '\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils', 'is_cart_block_default' ) ) {
				return (bool) \Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils::is_cart_block_default();
			}
			$post_id = (int) get_queried_object_id();
			if ( $post_id > 0 && function_exists( 'has_block' ) && has_block( 'woocommerce/cart', $post_id ) ) {
				return true;
			}
		}
		if ( function_exists( 'is_checkout' ) && is_checkout() ) {
			if ( class_exists( '\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils' ) && method_exists( '\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils', 'is_checkout_block_default' ) ) {
				return (bool) \Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils::is_checkout_block_default();
			}
			$post_id = (int) get_queried_object_id();
			if ( $post_id > 0 && function_exists( 'has_block' ) && has_block( 'woocommerce/checkout', $post_id ) ) {
				return true;
			}
		}
		return false;
	}
}

if ( ! class_exists( 'WALLREGI_GiftCard_Coupon_Integration' ) ) {

    class WALLREGI_GiftCard_Coupon_Integration {

        /**
         * Constructor to hook actions and filters
         */
        public function __construct() {
            // Add the notice and form to WooCommerce cart and checkout pages
            add_action( 'woocommerce_before_cart', [$this, 'wallregi_display_coupon_section'] );
            add_action( 'woocommerce_before_checkout_form', [$this, 'wallregi_display_coupon_section'] );

            // Handle the frontend apply coupon AJAX
            add_action( 'wp_ajax_wallregi_apply_giftcard_coupon', [$this, 'wallregi_apply_giftcard_coupon_callback'] );
            add_action( 'wp_ajax_nopriv_wallregi_apply_giftcard_coupon', [$this, 'wallregi_apply_giftcard_coupon_callback'] );

            add_action('woocommerce_cart_calculate_fees', [$this, 'wallregi_apply_giftcards_discount'], 999);
            add_filter('woocommerce_cart_totals_get_fees_from_cart_taxes', [$this, 'wallregi_zero_giftcard_fee_taxes'], 10, 3);
            add_action('woocommerce_checkout_create_order_fee_item', [$this, 'wallregi_fix_checkout_fee_item_taxes'], 10, 4);
            add_action('woocommerce_order_item_fee_after_calculate_taxes', [$this, 'wallregi_order_item_fee_after_calculate_taxes'], 10, 2);

            add_action( 'woocommerce_cart_loaded_from_session', 'wallregi_normalize_session_applied_giftcards', 5 );

            //add_action('woocommerce_before_calculate_cart_totals', [$this, 'wallregi_apply_giftcards_discount']);

            // Show gift card amount usage on cart totals - checkout page
            add_action('woocommerce_review_order_before_order_total', [$this, 'wallregi_show_gift_card_amount_on_cart_totals']);

            // Show gift card amount usage on cart totals - cart page
            add_action('woocommerce_cart_totals_before_order_total', [$this, 'wallregi_show_gift_card_amount_on_cart_totals']);

            // Handle removing gift card from session
            add_action('wp', [$this, 'wallregi_remove_giftcard_from_session']);

            add_action( 'woocommerce_new_order', array( $this, 'wallregi_apply_giftcard_on_order' ) );

            add_action('woocommerce_order_status_changed', [$this, 'wallregi_process_giftcard_discount'], 10, 3);

            add_action( 'template_redirect', [ $this, 'wallregi_maybe_apply_giftcard_from_query' ], 5 );

            add_filter( 'wallregi_frontend_ajax_object', [ $this, 'wallregi_inject_pending_query_apply_into_ajax_object' ], 25, 2 );

            add_action( 'wp_ajax_wallregi_dismiss_pending_giftcard_query', [ $this, 'wallregi_dismiss_pending_giftcard_query_callback' ] );
            add_action( 'wp_ajax_nopriv_wallregi_dismiss_pending_giftcard_query', [ $this, 'wallregi_dismiss_pending_giftcard_query_callback' ] );

            // Show applied wallet gift card(s) from order meta — admin, emails, customer order view.
            add_action('woocommerce_admin_order_totals_after_total', [$this, 'wallregi_admin_order_wallet_redemptions']);
            add_action('woocommerce_email_after_order_table', [$this, 'wallregi_email_after_order_table_wallet_redemptions'], 10, 4);
            add_action('woocommerce_order_details_after_order_table', [$this, 'wallregi_order_details_wallet_redemptions']);

        }

        /**
         * Display the coupon section (input form and notice)
         */
        public function wallregi_display_coupon_section() {
            if ( function_exists( 'wallregi_is_wc_cart_checkout_block_template' ) && wallregi_is_wc_cart_checkout_block_template() ) {
                return;
            }
            ?>
            <div class="woocommerce-info" id="wallregi_giftcard_notice">
                <a href="javascript:void(0)" id="wallregi_toggle_form"><?php esc_html_e( 'Have a gift card code? Use it here', 'wallet-ready-gift-cards-for-woocommerce' ); ?></a>
            </div>

            <form method="POST" id="wallregi_giftcard_coupon_form" class="wallregi_coupon_form" style="display:none; margin-top:10px;">
                <?php wp_nonce_field( 'wallregi_apply_coupon_nonce', 'security' ); ?>
                <div class="wallregi_form_container" style="display:flex; align-items:center; gap:10px;">
                    <div class="wallregi_input_group" style="display: flex; gap: 5px;">
                        <input type="text" name="coupon_code" id="wallregi_coupon_code" class="input-text" placeholder="<?php esc_attr_e( 'Enter your gift card code', 'wallet-ready-gift-cards-for-woocommerce' ); ?>">
                        <button type="button" id="wallregi_apply_coupon" class="button apply_coupon_btn"><?php esc_html_e( 'Apply', 'wallet-ready-gift-cards-for-woocommerce' ); ?></button>
                    </div>
                </div>
                <div id="wallregi_error_message" style="margin-top: 10px;"></div>
            </form>
            <?php if ( apply_filters( 'wallregi_is_buyer_giftcard_redeem_amount_ui_enabled', false ) ) : ?>
            <div id="wallregi_redeem_amount_modal" class="wallregi-redeem-modal" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="wallregi_redeem_modal_title">
                <div class="wallregi-redeem-modal__backdrop"></div>
                <div class="wallregi-redeem-modal__panel">
                    <h3 id="wallregi_redeem_modal_title" class="wallregi-redeem-modal__title"></h3>
                    <dl class="wallregi-redeem-modal__meta"></dl>
                    <label class="wallregi-redeem-modal__label" for="wallregi_redeem_amount_input"></label>
                    <input type="text" inputmode="decimal" id="wallregi_redeem_amount_input" class="wallregi-redeem-modal__input input-text" autocomplete="off" />
                    <div class="wallregi-redeem-modal__actions">
                        <button type="button" class="button wallregi-redeem-modal__cancel"></button>
                        <button type="button" class="button button-primary wallregi-redeem-modal__confirm"></button>
                    </div>
                    <p class="wallregi-redeem-modal__error" style="display:none;color:#b42318;margin-top:8px;"></p>
                </div>
            </div>
            <?php endif; ?>
            <?php
            
        }

        /**
         * AJAX callback to apply the gift card coupon
         */
        public function wallregi_apply_giftcard_coupon_callback() {
            check_ajax_referer('wallregi_apply_coupon_nonce', 'security');

            $coupon_code = sanitize_text_field(wp_unslash($_POST['coupon_code'] ?? ''));
            if ( ! apply_filters( 'wallregi_security_allow_apply_giftcard_coupon_ajax', true, array( 'code' => $coupon_code ) ) ) {
                wp_send_json_error( array( 'message' => wallregi_security_rate_limit_message() ) );
            }
            $applied_giftcards = WC()->session->get('applied_giftcards', []);

            if ( wallregi_is_giftcard_applied_in_session( $coupon_code ) ) {
                wp_send_json_error(['message' => __('Gift card already applied.', 'wallet-ready-gift-cards-for-woocommerce')]);
            }

            $valid = wallregi_validate_giftcard_for_session_apply( $coupon_code );
            if ( is_wp_error( $valid ) ) {
                wp_send_json_error( [ 'message' => $valid->get_error_message() ] );
            }

            $giftcard = $this->wallregi_database_query_data( $coupon_code );
            $canonical_code = wallregi_get_canonical_giftcard_number( $coupon_code, $giftcard );

            $buyer_ui = (bool) apply_filters( 'wallregi_is_buyer_giftcard_redeem_amount_ui_enabled', false );
            $redeem_raw = isset( $_POST['redeem_amount'] ) ? wp_unslash( (string) $_POST['redeem_amount'] ) : '';
            $redeem_amount = null;
            if ( '' !== trim( $redeem_raw ) && function_exists( 'wc_format_decimal' ) && function_exists( 'wc_get_price_decimals' ) ) {
                $parsed = wc_format_decimal( $redeem_raw, wc_get_price_decimals() );
                if ( is_numeric( $parsed ) ) {
                    $redeem_amount = max( 0, (int) round( (float) $parsed ) );
                }
            }

            if ( $buyer_ui && ( null === $redeem_amount || '' === trim( $redeem_raw ) ) ) {
                $preview = apply_filters( 'wallregi_giftcard_apply_preview_payload', null, $coupon_code, $giftcard );
                if ( is_array( $preview ) && ! empty( $preview['needsRedeemAmount'] ) ) {
                    wp_send_json_success( $preview );
                }
            }

            if ( $buyer_ui ) {
                if ( null === $redeem_amount || $redeem_amount <= 0 ) {
                    wp_send_json_error( [ 'message' => __( 'Please enter a valid amount to redeem.', 'wallet-ready-gift-cards-for-woocommerce-pro' ) ] );
                }
                $amount_check = apply_filters( 'wallregi_validate_buyer_redeem_amount_for_apply', true, $canonical_code, $redeem_amount, $giftcard );
                if ( is_wp_error( $amount_check ) ) {
                    wp_send_json_error( [ 'message' => $amount_check->get_error_message() ] );
                }
            }

            $applied_giftcards[] = $canonical_code;
            WC()->session->set('applied_giftcards', $applied_giftcards);

            if ( $buyer_ui && $redeem_amount !== null && $redeem_amount > 0 && function_exists( 'wallregi_session_set_applied_giftcard_buyer_amount' ) ) {
                wallregi_session_set_applied_giftcard_buyer_amount( $canonical_code, $redeem_amount );
            }

            WC()->cart->calculate_totals();

            $amount_totals = apply_filters( 'wallregi_validate_applied_giftcard_amount_totals_after_apply', true, $canonical_code );
            if ( is_wp_error( $amount_totals ) ) {
                if ( function_exists( 'wallregi_revert_applied_giftcard_from_session' ) ) {
                    wallregi_revert_applied_giftcard_from_session( $canonical_code );
                }
                $this->wallregi_clear_pending_giftcard_apply_from_query_if_matches( $coupon_code );
                wp_send_json_error( [ 'message' => $amount_totals->get_error_message() ] );
            }

            if ( function_exists( 'wallregi_security_should_log_success' ) && wallregi_security_should_log_success() ) {
                wallregi_security_audit_log(
                    'apply_giftcard_coupon_ajax',
                    'success',
                    array(
                        'identifier' => function_exists( 'wallregi_security_redact_code' ) ? wallregi_security_redact_code( $canonical_code ) : '',
                    )
                );
            }

            $this->wallregi_clear_pending_giftcard_apply_from_query_if_matches( $coupon_code );

            if ( function_exists( 'wallregi_clear_gtw_checkout_error_notices' ) ) {
                wallregi_clear_gtw_checkout_error_notices();
            }

            wp_send_json_success([
                'message' => __('Gift card applied successfully!', 'wallet-ready-gift-cards-for-woocommerce'),
                'coupon_code' => esc_attr( $canonical_code ),
                'giftcard_data' => $giftcard,
            ]);
        }

        /**
         * Apply gift card when the storefront is opened with ?wallregi_apply_giftcard= (PDF QR link).
         */
        public function wallregi_maybe_apply_giftcard_from_query() {
            // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public deep link; same exposure as typing the code.
            if ( ! isset( $_GET['wallregi_apply_giftcard'] ) ) {
                return;
            }
            // phpcs:enable WordPress.Security.NonceVerification.Recommended

            if ( ! function_exists( 'WC' ) || ! WC()->session ) {
                return;
            }

            if ( function_exists( 'wc_load_cart' ) ) {
                wc_load_cart();
            }

            // phpcs:disable WordPress.Security.NonceVerification.Recommended
            $code = isset( $_GET['wallregi_apply_giftcard'] )
                ? sanitize_text_field( wp_unslash( (string) $_GET['wallregi_apply_giftcard'] ) )
                : '';
            // phpcs:enable WordPress.Security.NonceVerification.Recommended

            if ( '' === $code ) {
                wp_safe_redirect( remove_query_arg( 'wallregi_apply_giftcard' ) );
                exit;
            }

            $applied = WC()->session->get( 'applied_giftcards', [] );
            if ( ! is_array( $applied ) ) {
                $applied = [];
            }
            if ( wallregi_is_giftcard_applied_in_session( $code ) ) {
                $this->wallregi_clear_pending_giftcard_apply_from_query_if_matches( $code );
                wc_add_notice( __( 'Gift card is already applied.', 'wallet-ready-gift-cards-for-woocommerce' ), 'notice' );
                wp_safe_redirect( remove_query_arg( 'wallregi_apply_giftcard' ) );
                exit;
            }

            if ( ! apply_filters( 'wallregi_security_allow_apply_giftcard_from_query', true, array( 'code' => $code ) ) ) {
                wc_add_notice( wallregi_security_rate_limit_message(), 'error' );
                wp_safe_redirect( remove_query_arg( 'wallregi_apply_giftcard' ) );
                exit;
            }

            $check = wallregi_validate_giftcard_for_session_apply( $code );
            if ( is_wp_error( $check ) ) {
                wc_add_notice( $check->get_error_message(), 'error' );
                wp_safe_redirect( remove_query_arg( 'wallregi_apply_giftcard' ) );
                exit;
            }

            /**
             * When buyers must choose a redeem amount (Pro), do not add the code to the session here — that would
             * skip per-apply validation and apply the full balance. Defer to cart + AJAX + modal (same path as Apply).
             */
            $buyer_ui = (bool) apply_filters( 'wallregi_is_buyer_giftcard_redeem_amount_ui_enabled', false );
            if ( $buyer_ui ) {
                WC()->session->set( 'wallregi_pending_giftcard_apply_from_query', $code );
                /**
                 * Whether to queue a WooCommerce notice when a deep link defers apply until the buyer picks an amount.
                 * Default false: the cart script opens the redeem modal from session; a WC notice here often lingered in
                 * the session and later appeared alongside “already applied” after the card was actually applied.
                 *
                 * @param bool   $add_notice Default false.
                 * @param string $code       Gift card number from the URL.
                 */
                if ( apply_filters( 'wallregi_add_wc_notice_for_query_redeem_amount', false, $code ) ) {
                    $notice = apply_filters(
                        'wallregi_notice_giftcard_query_needs_redeem_amount',
                        __( 'Choose how much of your gift card to use on this order.', 'wallet-ready-gift-cards-for-woocommerce' )
                    );
                    if ( is_string( $notice ) && '' !== trim( $notice ) ) {
                        wc_add_notice( $notice, 'notice' );
                    }
                }
                $redirect_base = wallregi_get_apply_giftcard_redirect_base_url();
                $redirect      = remove_query_arg(
                    'wallregi_apply_giftcard',
                    add_query_arg( 'wallregi_giftcard_amount_prompt', '1', $redirect_base )
                );
                wp_safe_redirect( $redirect );
                exit;
            }

            $giftcard_row   = wallregi_get_giftcard_by_number( $code );
            $canonical_code = wallregi_get_canonical_giftcard_number( $code, $giftcard_row );

            $applied[] = $canonical_code;
            WC()->session->set( 'applied_giftcards', array_values( $applied ) );
            if ( WC()->cart ) {
                WC()->cart->calculate_totals();
            }

            $amount_totals = apply_filters( 'wallregi_validate_applied_giftcard_amount_totals_after_apply', true, $canonical_code );
            if ( is_wp_error( $amount_totals ) ) {
                if ( function_exists( 'wallregi_revert_applied_giftcard_from_session' ) ) {
                    wallregi_revert_applied_giftcard_from_session( $canonical_code );
                }
                $this->wallregi_clear_pending_giftcard_apply_from_query_if_matches( $code );
                wc_add_notice( $amount_totals->get_error_message(), 'error' );
            } else {
                wc_add_notice( __( 'Gift card applied successfully.', 'wallet-ready-gift-cards-for-woocommerce' ), 'success' );
                if ( function_exists( 'wallregi_clear_gtw_checkout_error_notices' ) ) {
                    wallregi_clear_gtw_checkout_error_notices();
                }
                if ( function_exists( 'wallregi_security_should_log_success' ) && wallregi_security_should_log_success() ) {
                    wallregi_security_audit_log(
                        'apply_giftcard_coupon_query',
                        'success',
                        array(
                            'identifier' => function_exists( 'wallregi_security_redact_code' ) ? wallregi_security_redact_code( $code ) : '',
                        )
                    );
                }
            }

            wp_safe_redirect( remove_query_arg( 'wallregi_apply_giftcard' ) );
            exit;
        }

        /**
         * Expose a pending QR/link apply code to JS on cart/checkout (buyer redeem amount flow).
         *
         * @param array<string, mixed> $obj      Localized object.
         * @param array<string, mixed> $settings Plugin settings (unused).
         * @return array<string, mixed>
         */
        public function wallregi_inject_pending_query_apply_into_ajax_object( $obj, $settings ) {
            unset( $settings );
            if ( ! is_array( $obj ) ) {
                $obj = [];
            }
            if ( ! function_exists( 'is_cart' ) || ! function_exists( 'is_checkout' ) ) {
                return $obj;
            }
            if ( ! is_cart() && ! is_checkout() ) {
                return $obj;
            }
            if ( function_exists( 'wallregi_is_wc_cart_checkout_block_template' ) && wallregi_is_wc_cart_checkout_block_template() ) {
                return $obj;
            }
            if ( ! function_exists( 'WC' ) || ! WC()->session ) {
                return $obj;
            }
            $pending = WC()->session->get( 'wallregi_pending_giftcard_apply_from_query', '' );
            if ( is_string( $pending ) && '' !== trim( $pending ) ) {
                $obj['pendingGiftcardApplyFromQuery'] = $pending;
            }
            return $obj;
        }

        /**
         * Clear deferred QR/link apply so the cart does not keep prompting.
         */
        public function wallregi_dismiss_pending_giftcard_query_callback() {
            check_ajax_referer( 'wallregi_apply_coupon_nonce', 'security' );
            if ( ! function_exists( 'WC' ) || ! WC()->session ) {
                wp_send_json_error( [ 'message' => __( 'Session unavailable.', 'wallet-ready-gift-cards-for-woocommerce' ) ] );
            }
            if ( method_exists( WC()->session, '__unset' ) ) {
                WC()->session->__unset( 'wallregi_pending_giftcard_apply_from_query' );
            } else {
                WC()->session->set( 'wallregi_pending_giftcard_apply_from_query', null );
            }
            wp_send_json_success();
        }

        /**
         * @param string $coupon_code Applied gift card number.
         */
        private function wallregi_clear_pending_giftcard_apply_from_query_if_matches( $coupon_code ) {
            if ( ! function_exists( 'WC' ) || ! WC()->session ) {
                return;
            }
            $pending = WC()->session->get( 'wallregi_pending_giftcard_apply_from_query', '' );
            if ( ! is_string( $pending ) || '' === $pending ) {
                return;
            }
            if ( (string) $pending !== (string) $coupon_code ) {
                return;
            }
            if ( method_exists( WC()->session, '__unset' ) ) {
                WC()->session->__unset( 'wallregi_pending_giftcard_apply_from_query' );
            } else {
                WC()->session->set( 'wallregi_pending_giftcard_apply_from_query', null );
            }
        }

        /**
         * Query the database for gift card data.
         * @param string $coupon_code
         * @return object|null
         */
        public function wallregi_database_query_data($coupon_code) {
            return wallregi_get_giftcard_by_number( $coupon_code );
        }

        /**
         * Apply gift card discount to the cart.
         * The gift card acts as a payment method, reducing from the total order price (items + taxes + shipping + other fees), not just subtotal.
         * Tax is NOT included with/discounted from the gift card fee.
         */
        public function wallregi_apply_giftcards_discount($cart) {

            // Check if any gift cards are applied in the session
            if (WC()->session->get('applied_giftcards')) {

                // Retrieve applied gift cards from session
                $applied_giftcards = WC()->session->get('applied_giftcards', []);
                $applied_amounts   = WC()->session->get('applied_giftcard_amounts', []);

                // Ensure $applied_amounts is always an array
                if (!is_array($applied_amounts)) {
                    $applied_amounts = [];
                }

                $total_discount = 0.0;
                $decimals       = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;

                // Gift cards act as a payment method reducing the full payable total (items + taxes + shipping + other fees), not just subtotal.
                $order_total = function_exists( 'wallregi_get_cart_total_for_giftcard' )
                    ? wallregi_get_cart_total_for_giftcard( $cart )
                    : ( (float) $cart->get_cart_contents_total() + (float) $cart->get_cart_contents_tax() + (float) $cart->get_shipping_total() + (float) $cart->get_shipping_tax() );

                if ( $order_total <= 0.0 && isset( $cart->subtotal ) ) {
                    $order_total = (float) $cart->subtotal;
                }

                $order_total = max( 0.0, round( (float) $order_total, $decimals ) );

                /**
                 * Cap total wallet gift card discount for this cart run (e.g. Pro per-order max combined redemption).
                 * Return a positive float/int, or null for no cap.
                 *
                 * @param float|null $max_combined Default null (no cap).
                 * @param WC_Cart    $cart         Cart instance.
                 */
                $max_combined = apply_filters( 'wallregi_max_combined_giftcard_discount_amount', null, $cart );
                $max_combined = ( is_numeric( $max_combined ) && (float) $max_combined > 0 )
                    ? (float) $max_combined
                    : null;

                $combined_applied = 0.0;

                $buyer_ui       = (bool) apply_filters( 'wallregi_is_buyer_giftcard_redeem_amount_ui_enabled', false );
                $buyer_amounts  = ( $buyer_ui && function_exists( 'wallregi_session_get_applied_giftcard_buyer_amounts' ) )
                    ? wallregi_session_get_applied_giftcard_buyer_amounts()
                    : [];

                $seen_cards = [];

                foreach ($applied_giftcards as $coupon_code) {
                    $canonical = wallregi_get_canonical_giftcard_number( $coupon_code );
                    $norm      = wallregi_normalize_giftcard_number( $canonical );
                    if ( '' === $norm || isset( $seen_cards[ $norm ] ) ) {
                        continue;
                    }
                    $seen_cards[ $norm ] = true;

                    // Fetch gift card details from DB
                    $giftcard = $this->wallregi_database_query_data( $canonical );
                    $card_balance = ( $giftcard && isset( $giftcard->current_amount ) ) ? (float) $giftcard->current_amount : 0.0;

                    if ($card_balance > 0 && $order_total > 0) {
                        $buyer_amount = 0.0;
                        foreach ( $buyer_amounts as $buyer_key => $buyer_value ) {
                            if ( wallregi_normalize_giftcard_number( $buyer_key ) === $norm ) {
                                $buyer_amount = (float) $buyer_value;
                                break;
                            }
                        }

                        if ( $buyer_ui && $buyer_amount > 0 ) {
                            $discount = min( $buyer_amount, $card_balance, $order_total );
                        } else {
                            $discount = min( $card_balance, $order_total );
                        }

                        if ( null !== $max_combined ) {
                            $remaining_cap = (float) $max_combined - $combined_applied;
                            if ( $remaining_cap <= 0 ) {
                                $discount = 0.0;
                            } else {
                                $discount = min( $discount, max( 0.0, (float) $remaining_cap ) );
                            }
                        }

                        $discount = max( 0.0, round( (float) $discount, $decimals ) );

                        $combined_applied += (float) $discount;
                        $total_discount   += (float) $discount;

                        // Store the final applied amount for this coupon code.
                        $applied_amounts[ $canonical ] = $discount;

                        // Reduce remaining order total after applying this gift card.
                        $order_total -= $discount;
                        $order_total  = max( 0.0, round( (float) $order_total, $decimals ) );
                    } else {
                        $applied_amounts[ $canonical ] = 0;
                    }
                }

                // Update the session with the new applied amounts
                WC()->session->set('applied_giftcard_amounts', $applied_amounts);

                if ($total_discount > 0) {
                    $cart->add_fee(__('Gift card used', 'wallet-ready-gift-cards-for-woocommerce'), -$total_discount, false);
                }

            }
        }

        /**
         * Ensure gift card fee does not carry taxes and restore uncapped total.
         * Gift cards act as a payment method, so taxes on cart items and shipping must remain intact.
         *
         * @param array    $taxes       Array of taxes.
         * @param object   $fee         Fee object from cart totals.
         * @param object   $cart_totals WC_Cart_Totals instance.
         * @return array
         */
        public function wallregi_zero_giftcard_fee_taxes( $taxes, $fee, $cart_totals ) {
            if ( ! empty( $fee->object ) ) {
                $fee_id      = isset( $fee->object->id ) ? (string) $fee->object->id : '';
                $fee_name    = isset( $fee->object->name ) ? (string) $fee->object->name : '';
                $target_name = __( 'Gift card used', 'wallet-ready-gift-cards-for-woocommerce' );

                if (
                    $fee_id === 'gift-card-used'
                    || $fee_id === 'wallregi_gift_card_used'
                    || strpos( $fee_id, 'gift-card' ) !== false
                    || strpos( $fee_id, 'wallregi' ) !== false
                    || $fee_name === $target_name
                    || sanitize_title( $fee_name ) === sanitize_title( $target_name )
                ) {
                    // Restore fee->total so WooCommerce core's ex-tax cap doesn't truncate the gift card payment
                    if ( isset( $fee->object->amount ) && (float) $fee->object->amount < 0 ) {
                        $fee->total = wc_add_number_precision_deep( (float) $fee->object->amount );
                    }
                    return [];
                }
            }
            return $taxes;
        }

        /**
         * Ensure order fee line item for gift card has no tax assigned during checkout order creation.
         *
         * @param WC_Order_Item_Fee $item
         * @param string            $fee_key
         * @param object            $fee
         * @param WC_Order          $order
         */
        public function wallregi_fix_checkout_fee_item_taxes( $item, $fee_key, $fee, $order ) {
            $fee_id      = isset( $fee->id ) ? (string) $fee->id : '';
            $fee_name    = isset( $fee->name ) ? (string) $fee->name : '';
            $target_name = __( 'Gift card used', 'wallet-ready-gift-cards-for-woocommerce' );

            if (
                $fee_id === 'gift-card-used'
                || $fee_id === 'wallregi_gift_card_used'
                || strpos( $fee_id, 'gift-card' ) !== false
                || strpos( $fee_id, 'wallregi' ) !== false
                || $fee_name === $target_name
                || sanitize_title( $fee_name ) === sanitize_title( $target_name )
            ) {
                $item->set_tax_status( 'none' );
                $item->set_tax_class( '' );
                $item->set_total_tax( 0 );
                $item->set_taxes( [ 'total' => [] ] );
            }
        }

        /**
         * Ensure order fee line item taxes remain zero if order taxes are recalculated.
         *
         * @param WC_Order_Item_Fee $item
         * @param array             $calculate_tax_for
         */
        public function wallregi_order_item_fee_after_calculate_taxes( $item, $calculate_tax_for ) {
            if ( is_a( $item, 'WC_Order_Item_Fee' ) ) {
                $name        = (string) $item->get_name();
                $target_name = __( 'Gift card used', 'wallet-ready-gift-cards-for-woocommerce' );
                if (
                    $name === $target_name
                    || sanitize_title( $name ) === sanitize_title( $target_name )
                    || strpos( $name, 'Gift card' ) !== false
                    || strpos( $name, 'gift_card' ) !== false
                ) {
                    $item->set_tax_status( 'none' );
                    $item->set_tax_class( '' );
                    $item->set_total_tax( 0 );
                    $item->set_taxes( [ 'total' => [] ] );
                }
            }
        }
        
        /**
        * Show gift card amount usage on cart totals
        */
        public function wallregi_show_gift_card_amount_on_cart_totals() {
            if(is_null(WC()->session)) return;
            $applied_giftcards = WC()->session->get('applied_giftcards', []);
            $applied_amounts = WC()->session->get('applied_giftcard_amounts', []);
            $base_url = is_checkout() ? wc_get_checkout_url() : wc_get_cart_url();
            $wallregi_nonce = wp_create_nonce('wallregi_remove_giftcard_nonce');

            // var_dump( $applied_amounts);

            if (empty($applied_giftcards)) {
                return;
            }
            ?>
            <tr>
                <td colspan="2">
                    <section class="wallregi_apply_coupon_sec">
                        <div class="wallregi_coupon_container">
                            <div class="wallregi_cart_accordion_heading" onclick="wallregi_toggle_coupon_accordion()">
                                <h3 class="heading"><?php esc_html_e( 'Applied gift cards', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h3>
                                <span class="wallregi_icon wallregi_icon_plus"></span>
                            </div>
                            <ul class="wallregi_usage_coupon_list" style="display: none;">
                                <?php
                                foreach ($applied_giftcards as $coupon_code) {

                                    $remove_url = esc_url(add_query_arg(['remove_giftcard' => $coupon_code, 'remove_nonce' => $wallregi_nonce], $base_url));

                                    $amount_used_val = 0.0;
                                    $canonical_code  = wallregi_get_canonical_giftcard_number( $coupon_code );
                                    if ( isset( $applied_amounts[ $coupon_code ] ) ) {
                                        $amount_used_val = (float) $applied_amounts[ $coupon_code ];
                                    } elseif ( isset( $applied_amounts[ $canonical_code ] ) ) {
                                        $amount_used_val = (float) $applied_amounts[ $canonical_code ];
                                    } else {
                                        foreach ( $applied_amounts as $amt_code => $amt_val ) {
                                            if ( wallregi_normalize_giftcard_number( $amt_code ) === wallregi_normalize_giftcard_number( $coupon_code ) ) {
                                                $amount_used_val = (float) $amt_val;
                                                break;
                                            }
                                        }
                                    }
                                    $amount_used = wc_price( $amount_used_val );
                                    ?>

                                        <li class="wallregi_coupon_item">
                                            <div class="coupon_item_left">
                                                <span class="coupon_code"><?php echo esc_html($coupon_code); ?></span>
                                                <span class="coupon_amount"><strong>-</strong><?php echo wp_kses_post(  $amount_used  ); ?></span>
                                            </div>
                                            <div class="coupon_item_right" style="display:flex; align-items:center; gap:10px;">
                                                <a href="<?php echo esc_attr($remove_url); ?>" class="remove_coupon_code" aria-label="<?php esc_attr_e( 'Remove gift card', 'wallet-ready-gift-cards-for-woocommerce' ); ?>">
                                                    <span class="wallregi_icon wallregi_icon_close "></span>
                                                </a>
                                            </div>
                                        </li>

                                    <?php
                                }
                                ?>
                            </ul>
                        </div>
                    </section>
                </td>
            </tr>
            <?php
        }


        /**
         * Remove gift card from session
         */
        public function wallregi_remove_giftcard_from_session() {
            if (isset($_GET['remove_giftcard']) && isset($_GET['remove_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['remove_nonce'])), 'wallregi_remove_giftcard_nonce')) {
                $removed_giftcard = sanitize_text_field(wp_unslash($_GET['remove_giftcard']));
                $applied_giftcards = WC()->session->get('applied_giftcards', []);
                $applied_amounts = WC()->session->get('applied_giftcard_amounts', []);

                if (($wallregi_key = wallregi_find_applied_giftcard_session_index( $removed_giftcard, $applied_giftcards )) !== false) {
                    do_action( 'wallregi_before_giftcard_remove_from_cart', $applied_giftcards[ $wallregi_key ] );
                    // Remove the gift card from the applied gift cards list
                    unset($applied_giftcards[$wallregi_key]);
                    $removed_canonical = wallregi_get_canonical_giftcard_number( $removed_giftcard );
                    foreach ( array_keys( $applied_amounts ) as $amount_key ) {
                        if ( wallregi_normalize_giftcard_number( $amount_key ) === wallregi_normalize_giftcard_number( $removed_canonical ) ) {
                            unset( $applied_amounts[ $amount_key ] );
                        }
                    }

                    $buyer = WC()->session->get( 'applied_giftcard_buyer_amounts', [] );
                    if ( is_array( $buyer ) ) {
                        foreach ( array_keys( $buyer ) as $buyer_key ) {
                            if ( wallregi_normalize_giftcard_number( $buyer_key ) === wallregi_normalize_giftcard_number( $removed_canonical ) ) {
                                unset( $buyer[ $buyer_key ] );
                            }
                        }
                        WC()->session->set( 'applied_giftcard_buyer_amounts', $buyer );
                    }

                    // Update the session with the new applied amounts
                    WC()->session->set('applied_giftcards', array_values($applied_giftcards));
                    WC()->session->set('applied_giftcard_amounts', $applied_amounts);

                    // Ensure the cart totals are updated (if needed)
                    WC()->cart->calculate_totals();

                    if ( function_exists( 'wallregi_clear_gtw_checkout_error_notices' ) ) {
                        wallregi_clear_gtw_checkout_error_notices();
                    }
                }

                // Redirect based on whether the user is on checkout or cart page
                if (is_checkout()) {
                    wp_safe_redirect(wc_get_checkout_url());
                    exit;
                } else {
                    wp_safe_redirect(wc_get_cart_url());
                    exit;
                }
                
            }
        }

        /**
         * Register gift card usage when a new order is created
         *
         * @param int $order_id The ID of the new order.
         */
        public function wallregi_apply_giftcard_on_order($order_id) {
            global $wpdb;
            $wallregi_giftcard_table = wallregi_giftcard_db_table_name();
            $wallregi_transaction_table = wallregi_transaction_db_table_name();
        
            $order = wc_get_order($order_id);
            if (!$order) return;

            // Admin / REST / cron: no customer session (gift cards applied via admin use order meta + wallregi_order_redeem_giftcard_balance).
            if ( ! function_exists( 'WC' ) || ! WC() || ! WC()->session ) {
                return;
            }

            // Already redeemed on this order (e.g. wp-admin apply) — do not read session.
            if ( 'yes' === $order->get_meta( '_wallregi_giftcard_applied', true ) ) {
                if ( function_exists( 'wallregi_order_get_wallet_redemptions' ) ) {
                    $existing = wallregi_order_get_wallet_redemptions( $order );
                    if ( ! empty( $existing ) ) {
                        return;
                    }
                }
            }
        
            $applied_giftcards = WC()->session->get('applied_giftcards', []);
            $applied_amounts = WC()->session->get('applied_giftcard_amounts', []);
            $total_redeem = 0;

            if (
                class_exists( 'WALLREGI_GTW_Checkout_Redeem' )
                && WALLREGI_GTW_Checkout_Redeem::is_active()
                && ! empty( $applied_giftcards )
            ) {
                $gtw_redeemed = WC()->session->get( WALLREGI_GTW_Checkout_Redeem::SESSION_REDEEMED, [] );
                if ( ! is_array( $gtw_redeemed ) ) {
                    $gtw_redeemed = [];
                }
                foreach ( $applied_giftcards as $coupon_code ) {
                    $discount_amount = isset( $applied_amounts[ $coupon_code ] ) ? (float) $applied_amounts[ $coupon_code ] : 0.0;
                    if ( $discount_amount <= 0 ) {
                        continue;
                    }
                    $card = WALLREGI_GTW_Checkout_Redeem::normalize_card_number( $coupon_code );
                    $session_redeemed = (
                        ! empty( $gtw_redeemed[ $card ] )
                        && is_array( $gtw_redeemed[ $card ] )
                        && ! empty( $gtw_redeemed[ $card ]['redeemed'] )
                    );
                    // GTW persist_redeemed_holds_on_order (priority 5) may clear session before this hook (priority 10).
                    $gtw_meta         = $order->get_meta( '_gtw_redeem_' . $card, true );
                    $order_meta_redeemed = is_array( $gtw_meta ) && ! empty( $gtw_meta['claim_id'] );
                    if ( ! $session_redeemed && ! $order_meta_redeemed ) {
                        if ( class_exists( 'WALLREGI_GTW_API_Client' ) ) {
                            WALLREGI_GTW_API_Client::log(
                                'error',
                                'Skipped local gift card deduction: GTW hold was not redeemed before order creation.',
                                [
                                    'order_id'    => (int) $order_id,
                                    'card_number' => $card,
                                ]
                            );
                        }
                        return;
                    }
                }
            }
        
            if (!empty($applied_giftcards) && !empty($applied_amounts)) {
                foreach ($applied_giftcards as $coupon_code) {
                    $discount_amount = 0.0;
                    $canonical_code  = wallregi_get_canonical_giftcard_number( $coupon_code );
                    if ( isset( $applied_amounts[ $coupon_code ] ) ) {
                        $discount_amount = (float) $applied_amounts[ $coupon_code ];
                    } elseif ( isset( $applied_amounts[ $canonical_code ] ) ) {
                        $discount_amount = (float) $applied_amounts[ $canonical_code ];
                    } else {
                        foreach ( $applied_amounts as $amt_code => $amt_val ) {
                            if ( wallregi_normalize_giftcard_number( $amt_code ) === wallregi_normalize_giftcard_number( $coupon_code ) ) {
                                $discount_amount = (float) $amt_val;
                                break;
                            }
                        }
                    }
        
                    if ($discount_amount > 0) {
                        // Deduct balance (ensure it never goes below 0)
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                        $wpdb->query(
                            $wpdb->prepare(
                                'UPDATE %i SET `current_amount` = GREATEST(0, `current_amount` - %f), `total_redeem` = `total_redeem` + %f WHERE `giftcard_number` = %s',
                                wallregi_giftcard_db_table_name(),
                                $discount_amount,
                                $discount_amount,
                                $coupon_code
                            )
                        );

                        // Check and update status to 'used' if balance is now zero
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                        $current_balance = $wpdb->get_var(
                            $wpdb->prepare(
                                'SELECT `current_amount` FROM %i WHERE `giftcard_number` = %s',
                                wallregi_giftcard_db_table_name(),
                                $coupon_code
                            )
                        );

                        if ((float) $current_balance <= 0) {
                            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                            $wpdb->query(
                                $wpdb->prepare(
                                    'UPDATE %i SET `status` = %s WHERE `giftcard_number` = %s',
                                    wallregi_giftcard_db_table_name(),
                                    'used',
                                    $coupon_code
                                )
                            );
                        }
        
                        // Get correct giftcard_id
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                        $giftcard_id = $wpdb->get_var(
                            $wpdb->prepare(
                                'SELECT `id` FROM %i WHERE `giftcard_number` = %s',
                                wallregi_giftcard_db_table_name(),
                                $coupon_code
                            )
                        );
                        $giftcard_id = $giftcard_id ? absint( $giftcard_id ) : 0;

                        if ($giftcard_id) {
                            // Insert transaction
                            $transaction_data = [
                                'giftcard_id'     => $giftcard_id,
                                'amount'          => $discount_amount,
                                'order_id'        => $order_id,
                                'created_at'      => current_time('mysql'),
                                'updated_at'      => current_time('mysql'),
                                'created_by'      => get_current_user_id(),
                                'updated_by'      => get_current_user_id(),
                                'message'         => sprintf(
                                    'Gift card %s applied for order #%s. Discount: %s',
                                    $coupon_code,
                                    $order_id,
                                    wc_price($discount_amount)
                                ),
                            ];
                            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom transaction table.
                            $wpdb->insert($wallregi_transaction_table, $transaction_data);
                        }

                        if ($giftcard_id) {
                            /**
                             * Gift card balance was reduced (e.g. checkout). Extensions sync wallet passes here.
                             *
                             * @param int   $giftcard_id wx_gift_cards.id.
                             * @param array $context     order_id, coupon_code (gift card number), discount_amount.
                             */
                            do_action(
                                'wallregi_giftcard_balance_changed',
                                $giftcard_id,
                                [
                                    'order_id'         => (int) $order_id,
                                    'coupon_code'      => (string) $coupon_code,
                                    'discount_amount'  => (float) $discount_amount,
                                    'context'          => 'checkout_redeem',
                                ]
                            );
                        } 
        
                        // Update order meta
                        $order->update_meta_data('_wallregi_giftcard_applied', 'yes');
                        $order->update_meta_data('_giftcard_discount_' . $coupon_code, $discount_amount);
                        $total_redeem += $discount_amount;
                        $order->save();
                    }
                }
        
                if ( WC()->session ) {
                    WC()->session->set('applied_giftcards', []);
                    WC()->session->set('applied_giftcard_amounts', []);
                }
            }
        }
        

        public function wallregi_process_giftcard_discount($order_id, $old_status, $new_status) {
            global $wpdb;
        
            $wallregi_giftcard_table = wallregi_giftcard_db_table_name();
            $wallregi_transaction_table = wallregi_transaction_db_table_name();
        
            // Get the order object
            $order = wc_get_order($order_id);
            if (!$order) {
                return;
            }
        
            // Check if a gift card was applied
            $giftcard_applied = $order->get_meta('_wallregi_giftcard_applied', true);
        
            if ($giftcard_applied !== 'yes') {
                return;
            }
        
        
            // Only process when order status changes to 'cancelled' or 'refunded'
            if (in_array($new_status, ['cancelled', 'refunded'])) {
        
                // Retrieve applied gift cards from order meta
                foreach ($order->get_meta_data() as $meta) {
                    $meta_key = $meta->key;
        
                    if (strpos($meta_key, '_giftcard_discount_') !== false) {
                        $giftcard_number = str_replace('_giftcard_discount_', '', $meta_key);
                        $refund_amount = (float) $meta->value;
        
                        if ($refund_amount > 0) {
        
                            // Fetch the gift card ID before updating
                            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                            $giftcard_id = $wpdb->get_var(
                                $wpdb->prepare(
                                    'SELECT `id` FROM %i WHERE `giftcard_number` = %s',
                                    wallregi_giftcard_db_table_name(),
                                    $giftcard_number
                                )
                            );
        
                            if (!$giftcard_id) {
                                continue; // Skip to the next iteration if ID is missing
                            }
        
                            // Restore gift card balance
                            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                            $wpdb->query(
                                $wpdb->prepare(
                                    'UPDATE %i SET `current_amount` = `current_amount` + %f, `total_redeem` = `total_redeem` - %f WHERE `giftcard_number` = %s',
                                    wallregi_giftcard_db_table_name(),
                                    $refund_amount,
                                    $refund_amount,
                                    $giftcard_number
                                )
                            );

                            // Check new balance and update status to 'active' if needed
                            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                            $new_balance = $wpdb->get_var(
                                $wpdb->prepare(
                                    'SELECT `current_amount` FROM %i WHERE `giftcard_number` = %s',
                                    wallregi_giftcard_db_table_name(),
                                    $giftcard_number
                                )
                            );

                            if ((float) $new_balance > 0) {
                                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                                $wpdb->query(
                                    $wpdb->prepare(
                                        'UPDATE %i SET `status` = %s WHERE `giftcard_number` = %s',
                                        wallregi_giftcard_db_table_name(),
                                        'active',
                                        $giftcard_number
                                    )
                                );
                            }
        
        
                            // Insert refund transaction record
                            $transaction_data = [
                                'giftcard_id'     => $giftcard_id,
                                'amount'          => -$refund_amount,
                                'order_id'        => $order_id,
                                'created_at'      => current_time('mysql'),
                                'updated_at'      => current_time('mysql'),
                                'created_by'      => get_current_user_id(),
                                'updated_by'      => get_current_user_id(),
                                'message'         => sprintf(
                                    'Gift card %s refunded for order #%s. Amount: %s',
                                    $giftcard_number,
                                    $order_id,
                                    wc_price($refund_amount)
                                ),
                            ];
                            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom transaction table.
                            $wpdb->insert($wallregi_transaction_table, $transaction_data);

                            /**
                             * Gift card balance was restored (e.g. order cancelled/refunded). Extensions sync wallet passes here.
                             *
                             * @param int   $giftcard_id wx_gift_cards.id.
                             * @param array $context     order_id, giftcard_number, refund_amount.
                             */
                            do_action(
                                'wallregi_giftcard_balance_changed',
                                (int) $giftcard_id,
                                [
                                    'order_id'         => (int) $order_id,
                                    'giftcard_number'  => (string) $giftcard_number,
                                    'refund_amount'    => (int) $refund_amount,
                                    'context'          => 'order_refund_restore',
                                ]
                            );
                        }
                    }
                }
            }
        }

        /**
         * Gift card numbers and amounts applied at checkout (stored as order meta).
         *
         * @param WC_Order|null $order Order object.
         * @return array<int, array{number: string, amount: float}>
         */
        private function wallregi_get_order_wallet_redemptions( $order ) {
            if ( ! $order instanceof WC_Order ) {
                return [];
            }
            if ( 'yes' !== $order->get_meta( '_wallregi_giftcard_applied', true ) ) {
                return [];
            }
            $prefix = '_giftcard_discount_';
            $rows   = [];

            foreach ( $order->get_meta_data() as $meta_data ) {
                $data     = $meta_data->get_data();
                $meta_key = isset( $data['key'] ) ? (string) $data['key'] : '';
                if ( strpos( $meta_key, $prefix ) !== 0 ) {
                    continue;
                }
                $number = substr( $meta_key, strlen( $prefix ) );
                $amount = isset( $data['value'] ) ? (float) $data['value'] : 0.0;
                if ( $amount > 0 && $number !== '' ) {
                    $rows[] = [
                        'number' => $number,
                        'amount' => $amount,
                    ];
                }
            }

            return $rows;
        }

        /**
         * Admin order screen — list applied gift cards after order totals table.
         *
         * @param int|WC_Order $order Order ID or order object.
         */
        public function wallregi_admin_order_wallet_redemptions( $order ) {
            $order_obj = $order instanceof WC_Order ? $order : wc_get_order( $order );
            $rows      = $this->wallregi_get_order_wallet_redemptions( $order_obj );
            if ( empty( $rows ) ) {
                return;
            }
            foreach ( $rows as $row ) {
                ?>
                <tr>
                    <td class="label">
                        <?php
                        echo esc_html(
                            sprintf(
                                /* translators: %s: gift card number */
                                __( 'Gift card %s', 'wallet-ready-gift-cards-for-woocommerce' ),
                                $row['number']
                            )
                        );
                        ?>
                        :
                    </td>
                    <td width="1%"></td>
                    <td class="total"><?php echo wp_kses_post( wc_price( $row['amount'] ) ); ?></td>
                </tr>
                <?php
            }
        }

        /**
         * Order emails — applied gift cards after main order table.
         *
         * @param WC_Order       $order Order.
         * @param bool           $sent_to_admin Whether email goes to admin.
         * @param bool           $plain_text Plain text mode.
         * @param WC_Email|false $email Email object.
         */
        public function wallregi_email_after_order_table_wallet_redemptions( $order, $sent_to_admin, $plain_text, $email ) {
            $rows = $this->wallregi_get_order_wallet_redemptions( $order );
            if ( empty( $rows ) ) {
                return;
            }

            $heading = __( 'Applied gift cards', 'wallet-ready-gift-cards-for-woocommerce' );

            if ( $plain_text ) {
                echo "\n" . esc_html( $heading ) . "\n";
                foreach ( $rows as $row ) {
                    echo esc_html(
                        sprintf(
                            /* translators: 1: gift card number, 2: formatted price */
                            __( '%1$s: %2$s', 'wallet-ready-gift-cards-for-woocommerce' ),
                            $row['number'],
                            wp_strip_all_tags( wc_price( $row['amount'] ) )
                        )
                    );
                    echo "\n";
                }
                return;
            }

            echo '<div style="margin-bottom:40px;"><h2>' . esc_html( $heading ) . '</h2>';
            echo '<table cellspacing="0" cellpadding="6" style="width:100%;border:1px solid #e5e5e5" border="1"><thead><tr>';
            echo '<th scope="col" style="text-align:left">' . esc_html__( 'Gift card', 'wallet-ready-gift-cards-for-woocommerce' ) . '</th>';
            echo '<th scope="col" style="text-align:left">' . esc_html__( 'Amount applied', 'wallet-ready-gift-cards-for-woocommerce' ) . '</th>';
            echo '</tr></thead><tbody>';
            foreach ( $rows as $row ) {
                echo '<tr>';
                echo '<td style="text-align:left">' . esc_html( $row['number'] ) . '</td>';
                echo '<td style="text-align:left">' . wp_kses_post( wc_price( $row['amount'] ) ) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table></div>';
        }

        /**
         * Frontend: My Account order view and Thank You page — after order table.
         *
         * @param WC_Order $order Order.
         */
        public function wallregi_order_details_wallet_redemptions( $order ) {
            $rows = $this->wallregi_get_order_wallet_redemptions( $order );
            if ( empty( $rows ) ) {
                return;
            }

            ?>
            <section class="wallregi-order-wallet-redemptions">
                <h2 class="woocommerce-column__title">
                    <?php echo esc_html__( 'Applied gift cards', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
                </h2>
                <table class="woocommerce-table woocommerce-table--wallet-gift-cards shop_table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Gift card', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                            <th><?php esc_html_e( 'Amount applied', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $rows as $row ) : ?>
                            <tr>
                                <td><?php echo esc_html( $row['number'] ); ?></td>
                                <td><?php echo wp_kses_post( wc_price( $row['amount'] ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </section>
            <?php
        }
        
    }

    new WALLREGI_GiftCard_Coupon_Integration();

}