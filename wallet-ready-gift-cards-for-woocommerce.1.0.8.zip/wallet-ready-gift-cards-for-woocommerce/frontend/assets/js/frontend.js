function wallregiHandleInputFocus(element) {

  const placeholderText = element.previousElementSibling;
  if (!placeholderText) return;

  if (element) {
    placeholderText.style.cssText = `
      bottom: 0px;
    `;
  }
}



function wallregiHandleInputBlur(element) {
  const inputValue = jQuery(element).val(); 
  
  const placeholderText = element.previousElementSibling;
  if (!placeholderText) return;

  // Delivery method select keeps the label above the control.
  if ( element.closest( '.wallregi_input_box--select' ) ) {
    return;
  }

  if (element && !inputValue) {
    placeholderText.style.cssText = `
     position: relative;
      bottom: -36px;
    `;
  } 
}


// Helper: Parse localized or raw price string into a standard float based on WooCommerce settings
function wallregiParseLocalizedPrice(rawVal) {
  if (typeof rawVal === 'number') {
    return isNaN(rawVal) ? 0 : rawVal;
  }
  if (!rawVal) {
    return 0;
  }

  let str = String(rawVal).trim();
  const decSep = (typeof wallregi_ajax_object !== 'undefined' && typeof wallregi_ajax_object.decimal_separator !== 'undefined')
    ? wallregi_ajax_object.decimal_separator
    : '.';
  const thousandSep = (typeof wallregi_ajax_object !== 'undefined' && typeof wallregi_ajax_object.thousand_separator !== 'undefined')
    ? wallregi_ajax_object.thousand_separator
    : ',';

  // 1. Remove WooCommerce thousand separator (e.g. '.', ',', ' ', "'")
  if (thousandSep && thousandSep !== '') {
    str = str.split(thousandSep).join('');
  }

  // 2. Convert WooCommerce decimal separator to standard dot '.'
  if (decSep && decSep !== '.') {
    str = str.split(decSep).join('.');
  }

  // 3. Remove any remaining non-numeric characters except digits, dot and minus
  str = str.replace(/[^0-9.-]/g, '');

  const val = parseFloat(str);
  return isNaN(val) ? 0 : val;
}

// Helper: Format number with WooCommerce decimal & thousand separators
function wallregiNumberFormat(number, decimals, decimalSeparator, thousandSeparator) {
  const n = !isFinite(+number) ? 0 : +number;
  const prec = !isFinite(+decimals) ? 0 : Math.abs(decimals);
  const dec = typeof decimalSeparator === 'undefined' ? '.' : decimalSeparator;
  const thousand = typeof thousandSeparator === 'undefined' ? ',' : thousandSeparator;

  const toFixedFix = function (val, precision) {
    const k = Math.pow(10, precision);
    return '' + (Math.round(val * k) / k).toFixed(precision);
  };

  const s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
  if (thousand !== '') {
    s[0] = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousand);
  }
  return s.join(dec);
}

// Helper: Update the gift card price display (dynamic formatting based on WooCommerce settings)
function wallregiUpdateGiftCardPriceDisplay(container, amount) {
  let amountThumb = container.find('.wallregi_price .woocommerce-Price-amount');
  let wrapNeeded = false;
  if (!amountThumb.length) {
    amountThumb = container.find('.wallregi_price');
    wrapNeeded = true;
  }

  const numAmount = parseFloat(amount);
  const isNum = !isNaN(numAmount);
  const numVal = isNum ? numAmount : 0;

  const currencySymbol = (typeof wallregi_ajax_object !== 'undefined' && typeof wallregi_ajax_object.currency_symbol !== 'undefined')
    ? wallregi_ajax_object.currency_symbol
    : '$';
  const decSep = (typeof wallregi_ajax_object !== 'undefined' && typeof wallregi_ajax_object.decimal_separator !== 'undefined')
    ? wallregi_ajax_object.decimal_separator
    : '.';
  const thousandSep = (typeof wallregi_ajax_object !== 'undefined' && typeof wallregi_ajax_object.thousand_separator !== 'undefined')
    ? wallregi_ajax_object.thousand_separator
    : ',';

  let decimals = (typeof wallregi_ajax_object !== 'undefined' && typeof wallregi_ajax_object.currency_decimals !== 'undefined' && wallregi_ajax_object.currency_decimals !== '')
    ? parseInt(wallregi_ajax_object.currency_decimals, 10)
    : 2;

  if (isNaN(decimals)) {
    decimals = 2;
  }

  // If store setting decimals is 0, but the price has fractional decimals (e.g. 25.5), display with decimals
  if (decimals === 0 && !Number.isInteger(numVal)) {
    decimals = 2;
  }

  const formattedNumber = wallregiNumberFormat(numVal, decimals, decSep, thousandSep);

  // Use WooCommerce price_format if available (e.g. "%1$s%2$s", "%2$s&nbsp;%1$s")
  const priceFormat = (typeof wallregi_ajax_object !== 'undefined' && wallregi_ajax_object.price_format)
    ? wallregi_ajax_object.price_format
    : '';

  let formattedPrice = '';
  if (priceFormat) {
    formattedPrice = priceFormat.replace('%1$s', currencySymbol).replace('%2$s', formattedNumber);
  } else {
    const currencyPosition = (typeof wallregi_ajax_object !== 'undefined' && wallregi_ajax_object.currency_position)
      ? wallregi_ajax_object.currency_position
      : 'left';

    switch (currencyPosition) {
      case 'left':
        formattedPrice = `${currencySymbol}${formattedNumber}`;
        break;
      case 'right':
        formattedPrice = `${formattedNumber}${currencySymbol}`;
        break;
      case 'left_space':
        formattedPrice = `${currencySymbol} ${formattedNumber}`;
        break;
      case 'right_space':
        formattedPrice = `${formattedNumber} ${currencySymbol}`;
        break;
      default:
        formattedPrice = `${currencySymbol}${formattedNumber}`;
        break;
    }
  }

  if (wrapNeeded) {
    amountThumb.html(`<span class="woocommerce-Price-amount amount">${formattedPrice}</span>`);
  } else {
    amountThumb.html(formattedPrice);
  }
}



// Handle price selection for preview
function wallregiSelectGiftCardPrice(priceItem) {
  const parent = jQuery(priceItem).closest('.wallregi_giftcard_contents');
  const giftcardPriceInput = jQuery(parent).find("input[name^='giftcard_price[']");
  const liItem = jQuery(priceItem).closest('.wallregi_item');
  const priceElement = liItem.length ? (liItem.find('.price_btn')[0] || liItem[0]) : (priceItem.querySelector ? (priceItem.querySelector('.price_btn') || priceItem) : priceItem);

  if (!priceElement || !giftcardPriceInput.length) return;

  // Remove 'wallregi_active' from siblings in current gift card block
  // Use wallregi_selected for price items only
  jQuery(parent).find('ul.wallregi_custom_price_options li.wallregi_selected').removeClass('wallregi_selected');
  if (liItem.length) {
    liItem.addClass('wallregi_selected');
  } else {
    jQuery(priceItem).addClass('wallregi_selected');
  }

  // Get raw price: try data-price first
  let rawPriceAttr = (liItem.length ? liItem.attr('data-price') : null)
    || jQuery(priceItem).attr('data-price')
    || (priceElement ? jQuery(priceElement).attr('data-price') : null);

  let rawPrice;
  if (typeof rawPriceAttr !== 'undefined' && rawPriceAttr !== false && rawPriceAttr !== null && rawPriceAttr !== '') {
    rawPrice = parseFloat(rawPriceAttr);
    if (isNaN(rawPrice)) {
      rawPrice = wallregiParseLocalizedPrice(rawPriceAttr);
    }
  } else if (priceElement) {
    rawPrice = wallregiParseLocalizedPrice(priceElement.textContent);
  } else {
    rawPrice = 0;
  }

  // Set price input value
  giftcardPriceInput.val(rawPrice);

  wallregiUpdateGiftCardPriceDisplay(parent, rawPrice);
}


// Handle click on preset price item
function wallregiGiftCardManualPriceEnable(priceItem) {
  const parent = jQuery(priceItem).closest('.wallregi_giftcard_contents');
  parent.find('.wallregi_custom_price_error').remove(); // Clear error
  parent.find('.wallregi_cprice_input_field').removeClass('wallregi_selected'); // Clear input & active
  parent.find('ul.wallregi_custom_price_options .wallregi_item').removeClass('wallregi_selected'); // Clear selected for price items

  // Set selected to clicked item (price)
  jQuery(priceItem).addClass('wallregi_selected');

  // Show error message
  const errorText = (typeof wallregi_ajax_object !== 'undefined' && wallregi_ajax_object.validation_messages && wallregi_ajax_object.validation_messages.validGiftCardAmount)
    ? wallregi_ajax_object.validation_messages.validGiftCardAmount
    : ((typeof wallregi_ajax_object !== 'undefined' && wallregi_ajax_object.enter_valid_amount)
      ? wallregi_ajax_object.enter_valid_amount
      : ((typeof wp !== 'undefined' && wp.i18n && typeof wp.i18n.__ === 'function')
        ? wp.i18n.__('Please enter a valid gift card amount to continue.', 'wallet-ready-gift-cards-for-woocommerce')
        : 'Please enter a valid gift card amount to continue.'));

  const errorDiv = jQuery('<div></div>', {
    class: 'wallregi_custom_price_error',
    text: errorText,
    css: {
      fontSize: '13px',
      marginTop: '5px'
    }
  });

  // Append error below the input field
  parent.find('.wallregi_cprice_input_field').parent().append(errorDiv);
}




// Handle focus out from custom price input
function wallregiGiftCardManualPriceFocusOut(inputItem) {
  const inputField = jQuery(inputItem);
  const parent = inputField.closest('.wallregi_giftcard_contents');
  const items = parent.find('ul.wallregi_custom_price_options .wallregi_item');
  const giftcardPriceInput = parent.find("input[name^='giftcard_price[']");
  const value = wallregiParseLocalizedPrice(inputField.val());

  parent.find('.wallregi_custom_price_error').remove();
  inputField.removeClass('wallregi_selected');
  items.removeClass('wallregi_selected');

  if (!isNaN(value) && value > 0) {
    inputField.addClass('wallregi_selected');
    giftcardPriceInput.val(value);

    let matched = false;
    items.each(function () {
      const itemPriceAttr = jQuery(this).attr('data-price') || jQuery(this).find('.price_btn').attr('data-price');
      const itemAmount = itemPriceAttr ? wallregiParseLocalizedPrice(itemPriceAttr) : wallregiParseLocalizedPrice(jQuery(this).text());
      if (value === itemAmount) {
        jQuery(this).addClass('wallregi_selected');
        matched = true;
        return false;
      }
    });

    if (!matched) {
      wallregiUpdateGiftCardPriceDisplay(parent, value);
    }
  } else {
    const defaultItem = items.first();
    const defaultPriceAttr = defaultItem.attr('data-price') || defaultItem.find('.price_btn').attr('data-price');
    const defaultAmount = defaultPriceAttr ? wallregiParseLocalizedPrice(defaultPriceAttr) : wallregiParseLocalizedPrice(defaultItem.text());
    if (!isNaN(defaultAmount) && defaultAmount > 0) {
      giftcardPriceInput.val(defaultAmount);
      defaultItem.addClass('wallregi_selected');
      wallregiUpdateGiftCardPriceDisplay(parent, defaultAmount);
    }
  }

  items.off('click').on('click', function () {
    const item = jQuery(this);
    const itemPriceAttr = item.attr('data-price') || item.find('.price_btn').attr('data-price');
    const selectedAmount = itemPriceAttr ? wallregiParseLocalizedPrice(itemPriceAttr) : wallregiParseLocalizedPrice(item.text());
    items.removeClass('wallregi_selected');
    inputField.removeClass('wallregi_active').val('');
    item.addClass('wallregi_selected');
    giftcardPriceInput.val(selectedAmount);
    wallregiUpdateGiftCardPriceDisplay(parent, selectedAmount);
  });
}

// Validate and adjust custom price on keyup
function wallregiGiftCardManualPriceKeyUp(inputItem) {
  const inputField = jQuery(inputItem);
  const rawVal = inputField.val();
  if (rawVal === '') {
    return;
  }
  const manualAmount = wallregiParseLocalizedPrice(rawVal);
  const minAmount = wallregiParseLocalizedPrice(inputField.data('min'));
  const maxAmount = wallregiParseLocalizedPrice(inputField.data('max'));

  const parent = inputField.closest('.wallregi_giftcard_contents');
  const giftcardPriceInput = parent.find("input[name^='giftcard_price[']");
  const errorMsgSelector = '.wallregi_custom_price_error';

  parent.find(errorMsgSelector).remove();

  let finalAmount = manualAmount;
  let showError = false;

  if (isNaN(manualAmount)) {
    showError = true;
  } else if (!isNaN(maxAmount) && maxAmount > 0 && manualAmount > maxAmount) {
    finalAmount = maxAmount;
    showError = true;
  } else if (!isNaN(minAmount) && minAmount > 0 && manualAmount < minAmount) {
    finalAmount = minAmount;
    showError = true;
  }

  if (finalAmount !== manualAmount && !isNaN(finalAmount)) {
    inputField.val(finalAmount);
  }
  if (!isNaN(finalAmount)) {
    giftcardPriceInput.val(finalAmount);
    wallregiUpdateGiftCardPriceDisplay(parent, finalAmount);
  }

  if (showError) {
    const errorDiv = jQuery('<div></div>', {
      class: 'wallregi_custom_price_error',
      css: {
        color: 'red',
        fontSize: '13px',
        marginTop: '5px'
      }
    });

    if (manualAmount > maxAmount) {
      errorDiv.text(`Maximum allowed amount is ${maxAmount}. Value adjusted.`);
    } else if (manualAmount < minAmount) {
      errorDiv.text(`Minimum allowed amount is ${minAmount}. Value adjusted.`);
    } else {
      errorDiv.text(`Please enter a valid number.`);
    }

    inputField.parent().append(errorDiv);
  }
}


// Handle image selection for preview
function wallregiGiftCardImagePreview(galleryItem) {
  const $item = jQuery(galleryItem);
  const $panel = $item.closest('.wallregi_giftcard_contents');
  const $modal = $item.closest('#wallregi_giftcard_edit_modal, .wallregi_edit_cart_modal_wrapper');

  let $imageThumb;
  let $giftcardImageInput;
  let $galleryUl;

  if ($panel.length) {
    $galleryUl = $panel.find('ul.wallregi_images__gallery');
    $imageThumb = $panel.find('img.wallregi_image_thumb').first();
    $giftcardImageInput = $panel.find("input[name^='giftcard_image[']");
  } else if ($modal.length) {
    $galleryUl = $modal.find('#edit_giftcard_gallery');
    $imageThumb = $modal.find('#edit_giftcard_image_preview');
    $giftcardImageInput = $modal.find("input[name^='giftcard_image[']");
  } else {
    return;
  }

  const imgElement = galleryItem.querySelector('img');
  if (!imgElement || !$galleryUl.length) {
    return;
  }

  $galleryUl.find('li.wallregi_active').removeClass('wallregi_active');
  $item.addClass('wallregi_active');

  if ($imageThumb.length) {
    $imageThumb.attr('src', imgElement.src);
  }
  if ($giftcardImageInput.length) {
    $giftcardImageInput.val(imgElement.src);
  }
}



// Handle gift card message preview
function wallregiGiftCardMessagePreview(textarea) {
  const parent = jQuery(textarea).closest('.wallregi_giftcard_contents, .wallregi_form_item, #wallregi_giftcard_edit_modal, .wallregi_edit_cart_modal');
  const messageArea = parent.find(".wallregi_preview__mgs");
  const charCount = parent.find(".charCount");
  const maxChars = parseInt(jQuery(textarea).attr("data-maxlength") || jQuery(textarea).attr("maxlength") || jQuery(textarea).data("maxlength")) || 250;


  let text = jQuery(textarea).val() || '';
  let currentLength = text.length;

  // Trim if over limit
  if (currentLength > maxChars) {
      text = text.substring(0, maxChars);
      jQuery(textarea).val(text);
      currentLength = maxChars;
  }

  // Update character count
  if (charCount.length) {
      charCount.text(currentLength);
      charCount.css("color", currentLength >= maxChars ? "red" : "inherit");
  }

  // Update message preview
  if (messageArea.length) {
      if (text.trim() !== "") {
          messageArea.text(text);
          messageArea.css({
              opacity: 1,
              visibility: "visible",
              transition: "opacity 0.3s"
          });
      } else {
          messageArea.text("");
          messageArea.css({
              opacity: 0,
              visibility: "hidden",
              transition: "opacity 0.3s"
          });
      }
  }
}


/*=========================================
 * ACCORDION SCRIPTS START HERE
 *================================== */

jQuery(document).ready(function ($) {
  // Initialize UI libraries
  initializeJqueryUILibraries();

  // Quantity plus/minus button click
  $(".wallregi_qty_btn_groups").on("click", ".button", function () {
    const $qtyInput = $(this).siblings('input[type="number"]');
    const min = parseInt($qtyInput.attr("min"), 10) || 1;
    const max = parseInt($qtyInput.attr("max"), 10) || 1;
    let currentVal = parseInt($qtyInput.val(), 10) || min;

    if ($(this).hasClass("plus_btn")) {
      if (currentVal < max) {
        $qtyInput.val(currentVal + 1).trigger("change");
      } else {
        alert("Maximum quantity allowed is " + max + ".");
      }
    } else if ($(this).hasClass("minus_btn")) {
      if (currentVal > min) {
        $qtyInput.val(currentVal - 1).trigger("change");
      }
    }
  });

  // Giftcard quantity change
  jQuery("#wallregi_giftcard_quantity").on("change", function () {
    const input = $(this);
    const min = parseInt(input.attr("min"), 10) || 1;
    const max = parseInt(input.attr("max"), 10) || min;
    let quantity = parseInt(input.val(), 10);

    // Enforce min/max
    if (isNaN(quantity) || quantity < min) {
      quantity = min;
      input.val(quantity);
    } else if (quantity > max) {
      alert("You cannot select more than " + max + " gift cards.");
      quantity = max;
      input.val(quantity);
    }

    const $accordion = jQuery("#wallregi_giftcard_accordion");

    if (isNaN(quantity) || quantity <= 0) {
      $accordion.empty();
      return;
    }

    // Capture existing sections before rebuilding
    const currentSections = [];
    const $existingHeaders = $accordion.children('h3');
    const $existingContents = $accordion.children('div');

    for (let i = 0; i < $existingHeaders.length; i++) {
      currentSections.push({
        header: $existingHeaders.eq(i).clone(),
        content: $existingContents.eq(i).clone()
      });
    }

    // Destroy and empty the accordion
    if ($accordion.hasClass("ui-accordion")) {
      $accordion.accordion("destroy");
    }
    $accordion.empty();

    const $templateHeader = currentSections.length 
      ? currentSections[0].header 
      : $accordion.children("h3").first().clone();
    const $templateContent = currentSections.length 
      ? currentSections[0].content 
      : $accordion.children("div").first().clone();

    for (let i = 0; i < quantity; i++) {
      let $clonedHeader, $clonedContent;

      if (i < currentSections.length) {
        // Use existing section data
        $clonedHeader = currentSections[i].header.clone();
        $clonedHeader.removeClass('ui-state-active').removeClass('ui-accordion-header-active'); 
        $clonedContent = currentSections[i].content.clone();
      } else {
        // Clone new sections from template
        $clonedHeader = $templateHeader.clone();
        $clonedHeader.removeClass('ui-state-active').removeClass('ui-accordion-header-active');

        $clonedContent = $templateContent.clone();

        if (i > 0) {
          // Retrieve values using updated selectors
          const originalProductId = $clonedContent.find("input[name^='product_id[']").val();
          const originalGiftcardPrice = $clonedContent.find("input[name^='giftcard_price[']").val();
          const originalGiftcardImage = $clonedContent.find("input[name^='giftcard_image[']").val();

          // Update input reset logic
          $clonedContent.find("[name]").each(function () {
            const name = jQuery(this).attr("name");
            const isPreservedField = 
              name.startsWith("product_id[") ||
              name.startsWith("giftcard_price[") ||
              name.startsWith("giftcard_image[");

            if (!isPreservedField) {
              jQuery(this).val(""); // Clear non-preserved fields
              const placeholderText = jQuery(this).siblings('span.wallregi_placeholder__text');

              // Clear styles on the placeholder reset original position
              if (placeholderText.length) {
                placeholderText.removeAttr('style');
              }

              
              $clonedContent.find(".wallregi_preview__mgs").text('');
            } else {
              // Restore preserved fields
              if (name.startsWith("product_id[")) jQuery(this).val(originalProductId);
              if (name.startsWith("giftcard_price[")) jQuery(this).val(originalGiftcardPrice);
              if (name.startsWith("giftcard_image[")) jQuery(this).val(originalGiftcardImage);
            }
            jQuery(this).removeClass("hasDatepicker").removeAttr("id");
          });

          // Reset UI states
          const $priceItems = $clonedContent.find(".wallregi_custom_price_options .wallregi_item");
          if ($priceItems.length) {
            $priceItems.removeClass("wallregi_selected");
            $priceItems.first().addClass("wallregi_selected");
          }

          const $galleryItems = $clonedContent.find(".wallregi_images__gallery .wallregi_item");
          if ($galleryItems.length) {
            $galleryItems.removeClass("wallregi_active");
            $galleryItems.first().addClass("wallregi_active");
          }

          const $uploadItems = $clonedContent.find(".wallregi_images__gallery .wallregi_upload_image_item");
          if ($uploadItems.length) {
            $uploadItems.each(function () {
              const $previewContainer = jQuery(this).find('.wallregi_preview_container');
              $previewContainer.html(`
                <div class="wallregi_icon">
                  <img src="${wallregi_ajax_object.upload_icon_url}" alt="cloud upload icon">
                </div>
              `);
            });
          }

          const $deliverySelect = $clonedContent.find('.wallregi_delivery_channel_select');
          if ($deliverySelect.length) {
            const defaultChannel = $deliverySelect.attr('data-default') || 'email';
            $deliverySelect.val(defaultChannel).removeAttr('data-wallregi-sms-bound');
            const needsPhoneDefault = defaultChannel === 'sms' || defaultChannel === 'both';
            $clonedContent.find('.wallregi_receiver_phone_field').val('').prop('required', needsPhoneDefault);
            $clonedContent.find('.wallregi_recipient_phone_item').css('display', needsPhoneDefault ? '' : 'none');
            $clonedContent.find('.wallregi_phone_required_mark').css('display', needsPhoneDefault ? '' : 'none');
            const $phoneLabel = $clonedContent.find('.wallregi_receiver_phone_label');
            if ($phoneLabel.length) {
              $phoneLabel.removeClass('wallregi_label_floated');
              $phoneLabel.attr('style', 'position: relative; bottom: -36px;');
            }
            const $emailInput = $clonedContent.find('input[name^="receiver_email"]');
            if ($emailInput.length) {
              const needsEmailDefault = defaultChannel === 'email' || defaultChannel === 'both';
              $emailInput.prop('required', needsEmailDefault);
              $clonedContent.find('.wallregi_email_required_mark').css('display', needsEmailDefault ? '' : 'none');
            }
          }

        }
      }

      // Update header and names
      $clonedHeader.text(`${$templateHeader.text().split(wallregi_ajax_object.validation_messages.separatorText)[0].trim()} ${wallregi_ajax_object.validation_messages.separatorText}${i + 1}`);
      $clonedHeader.attr("id", `giftcard_heading_${i}`);

      $clonedContent.find("[name]").each(function () {
        const name = jQuery(this).attr("name");
        const newName = name.replace(/\[\d*\]/, `[${i}]`);
        jQuery(this).attr("name", newName);
      });

      $accordion.append($clonedHeader, $clonedContent);
    }

    initializeJqueryUILibraries();

    if (typeof window.wallregi_sms_init_delivery_cards === 'function') {
      window.wallregi_sms_init_delivery_cards($accordion[0]);
    }
  });

  function initializeJqueryUILibraries() {
    jQuery("#wallregi_giftcard_accordion").accordion({
      heightStyle: "content",
      collapsible: false,
      active: 0
    });

    // Destroy and reinitialize flatpickr to prevent duplicates
    jQuery(".wallregi_datetime_picker").each(function () {
      if (this._flatpickr) {
        this._flatpickr.destroy();
      }
    });

    jQuery(".wallregi_datetime_picker").flatpickr({
      enableTime: true,
      time_24hr: false,
      dateFormat: "Y-m-d H:i",
      minDate: "today",
      defaultHour: new Date().getHours(),
      defaultMinute: new Date().getMinutes(),
      onClose: function(selectedDates, dateStr, instance){
        wallregiHandleInputBlur(instance.element);
      }

    });

  }
});

/*======================
 * ACCORDION SCRIPTS END HERE
 *=============================== */

/*============================
 * GIFTCARD FORM VALIDATION START HERE
 *====================================== */

// Handle giftcard form validation 
function wallregiGiftcardFormValidation(form) {
  const receiverNameFields = form.querySelectorAll('input[name^="receiver_name["]');
  const receiverEmailFields = form.querySelectorAll('input[name^="receiver_email["]');
  const receiverMessageFields = form.querySelectorAll('textarea[name^="receiver_message["]');
  const senderNameFields = form.querySelectorAll('input[name^="sender_name["]');
  const senderEmailScheduleFields  = form.querySelectorAll('input[name^="sender_email_shedule["]');

  const productIdFields = form.querySelectorAll('input[name^="product_id["]');
  const checkoutReceiverSourceFields = form.querySelectorAll('input[name^="wallregi_checkout_receiver_source["]');
  const giftcardPriceFields = form.querySelectorAll('input[name^="giftcard_price["]');
  const giftcardImageFields = form.querySelectorAll('input[name^="giftcard_image["]');
  

  // 1) Capture the default (template) heading prefix once:
  //    e.g. if your headings look like "Gift Card :1", we grab "Gift Card"
  const firstHeader = document.querySelector('#wallregi_giftcard_accordion h3');
  const defaultHeadingPrefix = firstHeader
    ? firstHeader.textContent.split(':')[0].trim()
    : 'Gift Card';

  // 2) Footer is global, no need to re-query inside the loop
  const footerEl = document.querySelector('.wallregi_giftcard_footer');

  let isValid = true;
  let giftcardFormData = [];
  let errorMessages = [];
  let firstInvalidIndex = null;

  // Remove existing error messages
  form.querySelectorAll('.wallregi_error_mgs').forEach(el => el.remove());


  for (let i = 0; i < productIdFields.length; i++) {
    // see if this panel already has its own <h3 id="giftcard_heading_i">
    const thisHeaderEl = document.querySelector(`#giftcard_heading_${i}`);

    // build a headingText for your data object
    const headingText = thisHeaderEl
      ? thisHeaderEl.textContent.trim()
      : `${defaultHeadingPrefix}`;

    const checkoutReceiverSource = checkoutReceiverSourceFields[i]
      ? String(checkoutReceiverSourceFields[i].value || '').trim()
      : '';
    const skipReceiverForm =
      checkoutReceiverSource === 'billing' || checkoutReceiverSource === 'shipping';

    let singleGiftcardData = {
      receiverName: receiverNameFields[i]?.value || '',
      receiverEmail: receiverEmailFields[i]?.value || '',
      receiverMessage: receiverMessageFields[i]?.value || '',
      senderName: senderNameFields[i]?.value || '',
      emailSchedule: senderEmailScheduleFields[i]?.value || '',
      productId: productIdFields[i]?.value || '',
      giftcardPrice: giftcardPriceFields[i]?.value || '',
      giftcardImage: giftcardImageFields[i]?.value || '',
      checkoutReceiverSource,
      // now these will actually have content:
      giftcardHeading:   headingText,
      giftcardShortDesc: footerEl  ? footerEl.textContent.trim()  : ''
    };

    // === VALIDATION ===
    if (!skipReceiverForm) {
      let requireEmail = true;
      let requirePhone = false;
      if (typeof window.wallregi_get_giftcard_delivery_client_rules === 'function') {
        const deliveryRules = window.wallregi_get_giftcard_delivery_client_rules(form, i);
        if (deliveryRules && typeof deliveryRules === 'object') {
          if (typeof deliveryRules.requireEmail === 'boolean') {
            requireEmail = deliveryRules.requireEmail;
          }
          if (typeof deliveryRules.requirePhone === 'boolean') {
            requirePhone = deliveryRules.requirePhone;
          }
        }
      }

      if (singleGiftcardData.receiverName.trim() === '') {
        wallregiShowValidationError(receiverNameFields[i], wallregi_ajax_object.validation_messages.receiverName);
        errorMessages.push(`${headingText}: ${wallregi_ajax_object.validation_messages.receiverName}`);
        isValid = false;
        if (firstInvalidIndex === null) firstInvalidIndex = i;
      }

      if (requireEmail && singleGiftcardData.receiverEmail.trim() === '') {
        wallregiShowValidationError(receiverEmailFields[i], wallregi_ajax_object.validation_messages.receiverEmail);
        errorMessages.push(`${headingText}: ${wallregi_ajax_object.validation_messages.receiverEmail}`);
        isValid = false;
        if (firstInvalidIndex === null) firstInvalidIndex = i;
      } else if (singleGiftcardData.receiverEmail.trim() !== '' && !wallregiIsValidEmail(singleGiftcardData.receiverEmail)) {
        wallregiShowValidationError(receiverEmailFields[i], wallregi_ajax_object.validation_messages.invalidEmail);
        errorMessages.push(`${headingText}: ${wallregi_ajax_object.validation_messages.invalidEmail}`);
        isValid = false;
        if (firstInvalidIndex === null) firstInvalidIndex = i;
      }

      if (requirePhone) {
        const cardRoot = receiverNameFields[i] ? receiverNameFields[i].closest('.wallregi_giftcard_form_card, .wallregi_form_wrap') : null;
        const phoneField = cardRoot ? cardRoot.querySelector('.wallregi_receiver_phone_field') : null;
        const phoneVal = phoneField ? phoneField.value.trim() : '';
        const phoneRules = (typeof window.wallregi_sms_storefront_obj !== 'undefined' && window.wallregi_sms_storefront_obj.phoneRules)
          ? window.wallregi_sms_storefront_obj.phoneRules
          : {};
        const requiredMsg = (phoneRules.messages && phoneRules.messages.required)
          ? phoneRules.messages.required
          : 'Please enter a recipient phone number.';

        if (phoneVal === '') {
          if (phoneField && typeof wallregiShowValidationError === 'function') {
            wallregiShowValidationError(phoneField, requiredMsg);
          }
          errorMessages.push(`${headingText}: ${requiredMsg}`);
          isValid = false;
          if (firstInvalidIndex === null) firstInvalidIndex = i;
        } else if (typeof window.wallregi_validate_giftcard_phone_client === 'function') {
          const phoneCheck = window.wallregi_validate_giftcard_phone_client(phoneVal);
          if (!phoneCheck.valid) {
            if (phoneField && typeof wallregiShowValidationError === 'function') {
              wallregiShowValidationError(phoneField, phoneCheck.message);
            }
            errorMessages.push(`${headingText}: ${phoneCheck.message}`);
            isValid = false;
            if (firstInvalidIndex === null) firstInvalidIndex = i;
          } else if (phoneField && phoneCheck.sanitized) {
            phoneField.value = phoneCheck.sanitized;
          }
        }
      }

      if (singleGiftcardData.senderName.trim() === '') {
        wallregiShowValidationError(senderNameFields[i], wallregi_ajax_object.validation_messages.senderName);
        errorMessages.push(`${headingText}: ${wallregi_ajax_object.validation_messages.senderName}`);
        isValid = false;
        if (firstInvalidIndex === null) firstInvalidIndex = i;
      }
    }

    if (typeof window.wallregi_get_giftcard_delivery_client_rules === 'function') {
      const deliveryRules = window.wallregi_get_giftcard_delivery_client_rules(form, i);
      if (deliveryRules && typeof deliveryRules === 'object') {
        if (deliveryRules.deliveryChannel) {
          singleGiftcardData.deliveryChannel = deliveryRules.deliveryChannel;
        }
        if (typeof deliveryRules.receiverPhone === 'string') {
          singleGiftcardData.receiverPhone = deliveryRules.receiverPhone;
        }
      }
    }

    giftcardFormData.push(singleGiftcardData);
  }
  

  // === ACTIVATE FIRST INVALID ACCORDION SECTION ===

  // If invalid, open the first accordion section with error 
  if (!isValid && firstInvalidIndex !== null) {
    jQuery("#wallregi_giftcard_accordion").accordion("option", "active", firstInvalidIndex);
    return;
  }

  // ======== SEND AJAX IF VALID ========
  if (isValid) {
    wallregiFormDataAjaxHandler(giftcardFormData, form);
  }
}



// Get the submit button element by its ID
const submitButton = document.getElementById('wallregiGiftcardSubmit');

if (submitButton) {
  submitButton.addEventListener('click', function (event) {
    event.preventDefault();

    const form = document.getElementById('wallregi_giftcardForm');
    wallregiGiftcardFormValidation(form);
  });
}

// Helper to show inline error messages
function wallregiShowValidationError(element, message) {
  if (!element.previousElementSibling || !element.previousElementSibling.classList.contains('wallregi_error_mgs')) {
    const errorMessage = document.createElement('span');
    errorMessage.className = 'wallregi_error_mgs';
    errorMessage.style.color = 'red';
    errorMessage.textContent = message;
    element.parentElement.insertAdjacentElement('afterend', errorMessage);

  }
}

// Email validation
function wallregiIsValidEmail(email) {
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
return emailRegex.test(email);
}


// AJAX handler function 
function wallregiFormDataAjaxHandler(giftcardData, form) {

  const submitButton = document.getElementById('wallregiGiftcardSubmit');
  let showErrorMgs = form ? form.querySelector('.showErrorMgs') : document.querySelector('.showErrorMgs');
  if (!showErrorMgs && form) {
    showErrorMgs = document.createElement('div');
    showErrorMgs.className = 'showErrorMgs';
    showErrorMgs.style.display = 'none';
    showErrorMgs.setAttribute('aria-live', 'polite');
    form.appendChild(showErrorMgs);
  }

  if (!submitButton) {
    console.error('wallregiFormDataAjaxHandler: #wallregiGiftcardSubmit not found');
    return;
  }

  const processingText = (typeof wallregi_ajax_object !== 'undefined' && wallregi_ajax_object.processing_text)
    ? wallregi_ajax_object.processing_text
    : 'Processing...';

  const defaultSubmitText = (typeof wallregi_ajax_object !== 'undefined' && (wallregi_ajax_object.submit_text || wallregi_ajax_object.submit_btn_text))
    ? (wallregi_ajax_object.submit_text || wallregi_ajax_object.submit_btn_text)
    : 'Submit';

  // Create spinner and loading text
  const loadingSpinner = document.createElement("span");
  loadingSpinner.className = "loading-spinner";

  const loadingText = document.createElement("span");
  loadingText.textContent = processingText;

  // Clear existing button content and append spinner + text
  submitButton.innerHTML = '';
  submitButton.appendChild(loadingSpinner);
  submitButton.appendChild(loadingText);
  submitButton.disabled = true;

  // Prepare form data
  const formData = new URLSearchParams();
  formData.append('action', 'wallregi_process_giftcard_form');
  formData.append('_wallreginonce', wallregi_ajax_object.nonce);
  formData.append('giftcards', JSON.stringify(giftcardData));

  fetch(wallregi_ajax_object.ajax_url, {
    method: 'POST',
    body: formData,
  })
  .then(response => response.json())
  .then(({ data, success }) => {
    submitButton.disabled = false;
    submitButton.innerHTML = `<span>${defaultSubmitText}</span>`;

    if (success) {
      const { message, giftcards, redirect } = data;

      if (message && showErrorMgs) {
        const content = document.createElement('span');
        content.className = 'wallregi_error_mgs';
        content.textContent = message;
        content.style.color = success ? 'green' : 'red';

        showErrorMgs.innerHTML = '';
        showErrorMgs.append(content);
        showErrorMgs.style.cssText = `display: block; margin-top: 15px;`;
      }

      if (giftcards) {
        window.location.href = redirect;
      }

      form.reset();
    } else {
      const errText = (data && data.message) ? data.message : 'Unknown error';
      if (showErrorMgs) {
        showErrorMgs.innerHTML = '';
        const errSpan = document.createElement('span');
        errSpan.className = 'wallregi_error_mgs';
        errSpan.style.color = 'red';
        errSpan.textContent = errText;
        showErrorMgs.appendChild(errSpan);
        showErrorMgs.style.cssText = 'display: block; margin-top: 15px;';
      } else {
        alert('Something went wrong: ' + errText);
      }
    }
  })
  .catch(error => {
    submitButton.disabled = false;
    submitButton.innerHTML = `<span>${defaultSubmitText}</span>`;
    console.error("AJAX error:", error);
    alert("An unexpected error occurred. Please try again.");
  });
}

/*============================
 * GIFTCARD FORM VALIDATION END HERE
 *====================================== */

