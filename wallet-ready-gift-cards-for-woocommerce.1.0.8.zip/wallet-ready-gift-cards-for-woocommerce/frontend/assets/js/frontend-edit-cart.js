
/*=========================================
* CART PAGE EDIT GIFTCARD FORM DATA START
*========================*/


let selectedGiftcardPrice = null; // Global variable for selected price
let currentCartItemKey = '';      // Global variable for current cart item key
let wallregiActiveEditModal = null;

/**
 * Resolve the cart edit modal root (handles duplicate markup on block cart/checkout).
 *
 * @param {jQuery} [$context] Optional element inside the modal.
 * @return {jQuery}
 */
function wallregiResolveEditModal($context) {
    if ($context && $context.length) {
        const $fromContext = $context.closest('#wallregi_giftcard_edit_modal');
        if ($fromContext.length) {
            wallregiActiveEditModal = $fromContext.first();
            return wallregiActiveEditModal;
        }
    }

    if (wallregiActiveEditModal && wallregiActiveEditModal.length) {
        return wallregiActiveEditModal;
    }

    const $modals = jQuery('#wallregi_giftcard_edit_modal');
    if ($modals.length === 0) {
        return jQuery();
    }
    if ($modals.length === 1) {
        wallregiActiveEditModal = $modals.first();
        return wallregiActiveEditModal;
    }

    const $visible = $modals.filter(':visible');
    wallregiActiveEditModal = $visible.length ? $visible.first() : $modals.last();
    return wallregiActiveEditModal;
}

function wallregiParseGiftcardEditData(raw) {
    if (!raw) {
        return {};
    }
    if (typeof raw === 'object') {
        return raw;
    }
    if (typeof raw === 'string') {
        try {
            const parsed = JSON.parse(raw);
            return parsed && typeof parsed === 'object' ? parsed : {};
        } catch (error) {
            return {};
        }
    }
    return {};
}

function wallregiGiftcardDeliveryChannelFromData(giftcardData) {
    if (!giftcardData) {
        return 'email';
    }
    if (giftcardData.delivery_channel) {
        return String(giftcardData.delivery_channel);
    }
    if (giftcardData.deliveryChannel) {
        return String(giftcardData.deliveryChannel);
    }
    return 'email';
}

function wallregiGiftcardPhoneFromData(giftcardData) {
    if (!giftcardData) {
        return '';
    }
    if (giftcardData.receiver_phone) {
        return String(giftcardData.receiver_phone);
    }
    if (giftcardData.receiverPhone) {
        return String(giftcardData.receiverPhone);
    }
    return '';
}

function wallregiDeliveryChannelsConfig() {
    const config = wallregiCartEditDeliveryConfig();
    if (config && config.channels) {
        return config.channels;
    }
    return {
        email: 'email',
        sms: 'sms',
        both: 'both',
        none: 'none',
    };
}

function wallregiChannelNeedsEmail(channel, channels) {
    channels = channels || wallregiDeliveryChannelsConfig();
    return channel === channels.email || channel === channels.both || channel === 'email' || channel === 'both';
}

function wallregiChannelNeedsPhone(channel, channels) {
    channels = channels || wallregiDeliveryChannelsConfig();
    return channel === channels.sms || channel === channels.both || channel === 'sms' || channel === 'both';
}

function wallregiGetEditModalInputValue($modal, selectors) {
    const value = $modal.find(selectors).first().val();
    return value == null ? '' : String(value).trim();
}

function wallregiBuildUploadTileHtml(uploadIconUrl) {
    const pro = window.wallregi_ajax_object && window.wallregi_ajax_object.pro_image_upload;
    const guestLocked = !!(pro && pro.guestUploadLocked);
    const previewLi = `
        <li class="wallregi_item wallregi_preview_item" onclick="wallregiGiftCardImagePreview(this);" style="display: none;">
            <figure class="wallregi_image_item wallregi_preview_container">
                <img class="wallregi_preview_img" src="" alt="Uploaded preview">
            </figure>
        </li>`;

    if (guestLocked) {
        const messages = (pro && pro.messages) ? pro.messages : {};
        const hint = messages.loginPlaceholder || messages.loginRequired || '';
        const linkText = messages.loginLink || 'Log in';
        const loginUrl = (pro && pro.loginUrl) ? String(pro.loginUrl).replace(/"/g, '&quot;') : '#';
        const safeHint = String(hint).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const safeLink = String(linkText).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const safeTitle = String(hint).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return previewLi + `
        <li class="wallregi_item wallregi_upload_image_item wallregi-pro-upload-placeholder" role="note" title="${safeTitle}"
            ondragover="event.preventDefault();" ondrop="event.preventDefault();"
            style="opacity:0.88;cursor:default;border-style:dashed;">
            <div class="wallregi_upload_label" style="display:block;text-align:center;padding:6px 4px 8px;">
                <figure class="wallregi_image_item wallregi_preview_container">
                    <div class="wallregi_icon">
                        <img src="${uploadIconUrl}" alt="" style="opacity:0.55;">
                    </div>
                </figure>
                <p class="wallregi-pro-upload-hint" style="font-size:11px;line-height:1.35;margin:6px 0 0;color:#555;">
                    ${safeHint} <a href="${loginUrl}" class="wallregi-pro-upload-login-link" style="font-weight:600;">${safeLink}</a>
                </p>
            </div>
        </li>`;
    }

    return previewLi + `
        <li class="wallregi_item wallregi_upload_image_item wallregi_drop_zone" title="Drop or Upload Your Image"
            ondragover="wallregiHandleDragOverEnter(this, event)"
            ondragenter="wallregiHandleDragOverEnter(this, event)"
            ondragleave="wallregiHandleDragLeaveOrDrop(this, event)"
            ondragend="wallregiHandleDragLeaveOrDrop(this, event)"
            ondrop="wallregiHandleFileDrop(this, event)">
            <label class="wallregi_upload_label">
                <figure class="wallregi_image_item wallregi_preview_container">
                    <div class="wallregi_icon">
                        <img src="${uploadIconUrl}" alt="cloud upload icon">
                    </div>
                </figure>
                <input onchange="wallregi_Handle_GiftCard_Image_Upload(this, event)" type="file" name="wallregi_upload_image" class="wallregi_upload_image" accept="image/*" aria-label="Upload custom gift card image">
            </label>
        </li>
    `;
}


/**
 * Hide recipient/sender fields in the cart edit modal when the line uses checkout address mode.
 *
 * @param {object} giftcardData Parsed data-giftcard object.
 */
function wallregiApplyEditModalCheckoutReceiverMode(giftcardData, $context) {
    const $modal = wallregiResolveEditModal($context);
    if (!$modal.length) {
        return;
    }

    const src = giftcardData && giftcardData.checkout_receiver_source
        ? String(giftcardData.checkout_receiver_source).trim()
        : '';
    const $wrap = $modal.find('.wallregi_edit_checkout_receiver_hidden_fields');
    const $note = $modal.find('.wallregi_edit_checkout_receiver_notice');
    const $deliveryFields = $modal.find('.wallregi_edit_delivery_fields');
    if (!$wrap.length) {
        return;
    }
    const isCheckout = src === 'billing' || src === 'shipping';
    const hints = (window.wallregi_ajax_object && wallregi_ajax_object.checkout_receiver_modal_notice) || {};
    if (isCheckout) {
        const msg = hints[src] || (src === 'billing'
            ? 'Recipient details are taken from your billing address at checkout and cannot be edited here.'
            : 'Recipient details are taken from your shipping address at checkout and cannot be edited here.');
        $note.text(msg).show();
        $wrap.hide();
        $deliveryFields.hide();
    } else {
        $note.hide().text('');
        $wrap.show();
        if (wallregiCartEditDeliveryIsAvailable($modal)) {
            $deliveryFields.show();
        } else {
            $deliveryFields.hide();
        }
        wallregiSyncEditModalDeliveryFields($modal);
    }
}

function wallregiCartEditDeliveryConfig() {
    return (window.wallregi_ajax_object && wallregi_ajax_object.cart_edit_delivery) || null;
}

function wallregiCartEditDeliveryIsAvailable($context) {
    const $modal = wallregiResolveEditModal($context);
    if ($modal.length && $modal.find('.wallregi_edit_delivery_channel_select').length) {
        return true;
    }

    const config = wallregiCartEditDeliveryConfig();
    return !!(config && config.available);
}

function wallregiSyncEditModalDeliveryFields($context) {
    const $modal = wallregiResolveEditModal($context);
    if (!$modal.length) {
        return;
    }

    const $wrap = $modal.find('.wallregi_edit_checkout_receiver_hidden_fields');
    if ($wrap.length && !$wrap.is(':visible')) {
        return;
    }

    const channels = wallregiDeliveryChannelsConfig();
    const $nameInput = $modal.find('[name="receiver_name"], #edit_receiver_name').first();
    const $emailInput = $modal.find('[name="receiver_email"], #edit_receiver_email').first();
    const $emailMark = $modal.find('.wallregi_email_required_mark');

    $nameInput.prop('required', true);

    let needsEmail = true;
    if (wallregiCartEditDeliveryIsAvailable($modal)) {
        const $select = $modal.find('.wallregi_edit_delivery_channel_select');
        const channel = $select.val() || channels.email || 'email';
        needsEmail = wallregiChannelNeedsEmail(channel, channels);
        const needsPhone = wallregiChannelNeedsPhone(channel, channels);

        const $phoneItem = $modal.find('.wallregi_edit_recipient_phone_item, .wallregi_recipient_phone_item');
        const $phoneMark = $modal.find('.wallregi_phone_required_mark');
        const $phoneInput = $modal.find('.wallregi_edit_receiver_phone_field, .wallregi_receiver_phone_field');

        if ($phoneItem.length) {
            if (needsPhone) {
                $phoneItem.show();
            } else {
                $phoneItem.hide();
            }
        }
        if ($phoneMark.length) {
            $phoneMark.css('display', needsPhone ? '' : 'none');
        }
        if ($phoneInput.length) {
            $phoneInput.prop('required', needsPhone);
            const phoneLabel = $modal.find('.wallregi_receiver_phone_label').get(0);
            const phoneValue = String($phoneInput.val() || '').trim();
            if (phoneLabel) {
                if (needsPhone || phoneValue) {
                    phoneLabel.classList.add('wallregi_label_floated');
                } else {
                    phoneLabel.classList.remove('wallregi_label_floated');
                }
            }
            wallregiSyncEditModalPhoneLabel($modal);
        }
    }

    $emailInput.prop('required', needsEmail);
    if ($emailMark.length) {
        $emailMark.css('display', needsEmail ? '' : 'none');
    }
}

function wallregiSyncEditModalPhoneLabel($context) {
    const $modal = wallregiResolveEditModal($context);
    const phoneInput = $modal.find('.wallregi_edit_receiver_phone_field, .wallregi_receiver_phone_field').get(0);
    if (!phoneInput) {
        return;
    }
    if (typeof window.wallregiHandleInputFocus === 'function' && phoneInput.value.trim()) {
        window.wallregiHandleInputFocus(phoneInput);
        const phoneLabel = $modal.find('.wallregi_receiver_phone_label').get(0);
        if (phoneLabel) {
            phoneLabel.classList.add('wallregi_label_floated');
        }
    } else if (typeof window.wallregiHandleInputBlur === 'function') {
        window.wallregiHandleInputBlur(phoneInput);
    }
}

function wallregiPopulateEditModalDeliveryFields(giftcardData, $context) {
    const $modal = wallregiResolveEditModal($context);
    if (!$modal.length || !wallregiCartEditDeliveryIsAvailable($modal)) {
        return;
    }

    const channel = wallregiGiftcardDeliveryChannelFromData(giftcardData);
    const phone = wallregiGiftcardPhoneFromData(giftcardData);
    const $select = $modal.find('.wallregi_edit_delivery_channel_select');

    const $matching = $select.find('option').filter(function () {
        return this.value === channel;
    });
    if ($matching.length) {
        $select.val(channel);
    } else {
        $select.prop('selectedIndex', 0);
    }

    $modal.find('.wallregi_edit_receiver_phone_field, #edit_receiver_phone').val(phone);
    wallregiSyncEditModalDeliveryFields($modal);
}

function wallregiValidateEditModalDeliveryFields($context) {
    const $modal = wallregiResolveEditModal($context);
    if (!$modal.length) {
        return true;
    }

    const $wrap = $modal.find('.wallregi_edit_checkout_receiver_hidden_fields');
    if ($wrap.length && !$wrap.is(':visible')) {
        return true;
    }

    const config = wallregiCartEditDeliveryConfig();
    const messages = (config && config.messages) || {};
    const generalMessages = (window.wallregi_ajax_object && wallregi_ajax_object.validation_messages) || {};
    const channels = wallregiDeliveryChannelsConfig();
    const name = wallregiGetEditModalInputValue($modal, '[name="receiver_name"], #edit_receiver_name');
    const email = wallregiGetEditModalInputValue($modal, '[name="receiver_email"], #edit_receiver_email');
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    let needsEmail = true;
    let needsPhone = false;

    if (wallregiCartEditDeliveryIsAvailable($modal)) {
        const channel = $modal.find('.wallregi_edit_delivery_channel_select').val() || channels.email || 'email';
        needsEmail = wallregiChannelNeedsEmail(channel, channels);
        needsPhone = wallregiChannelNeedsPhone(channel, channels);
    }

    if (name === '') {
        alert(messages.nameRequired || generalMessages.receiverName || 'Please enter the recipient name.');
        return false;
    }

    if (needsEmail && (email === '' || !emailPattern.test(email))) {
        alert(messages.emailRequired || 'Please enter a valid recipient email for the selected delivery method.');
        return false;
    }

    if (!needsEmail && email !== '' && !emailPattern.test(email)) {
        alert(messages.invalidEmail || 'Please enter a valid recipient email address.');
        return false;
    }

    if (needsPhone) {
        const phoneRaw = wallregiGetEditModalInputValue($modal, '.wallregi_edit_receiver_phone_field, #edit_receiver_phone');
        const phone = phoneRaw.replace(/[^\d+]/g, '');
        if (phone === '' || phone.charAt(0) !== '+' || phone.length < 9) {
            alert(messages.phoneRequired || 'Please enter a recipient phone number for SMS delivery.');
            return false;
        }
    }

    return true;
}

function wallregiCollectEditModalDeliveryPayload($context) {
    const $modal = wallregiResolveEditModal($context);
    if (!$modal.length || !wallregiCartEditDeliveryIsAvailable($modal)) {
        return {};
    }

    return {
        delivery_channel: $modal.find('.wallregi_edit_delivery_channel_select').val(),
        receiver_phone: wallregiGetEditModalInputValue($modal, '.wallregi_edit_receiver_phone_field, #edit_receiver_phone'),
    };
}


// Handle Edit Gift Card button click
function wallregiHandleGiftcardEditButtonClick(data, event) {

    event.preventDefault();

    currentCartItemKey = jQuery(data).data('cart_item_key');
    const giftcardData = wallregiParseGiftcardEditData(jQuery(data).data('giftcard'));
    wallregiActiveEditModal = jQuery('#wallregi_giftcard_edit_modal').last();
    const $modal = wallregiResolveEditModal();
    const displayPrice = jQuery(data).data('giftcard_price');
    const customPrices = jQuery(data).data('custom_prices');
    const manualPrice = jQuery(data).data('manual_price');

    // Inject gallery HTML (if present) so modal has product images to select
    const galleryImages = jQuery(data).data('gallery') || '[]';
    
    let $urls = '';
    try {
        const imageUrls = galleryImages;
        if (Array.isArray(imageUrls) && imageUrls.length > 0) {
            imageUrls.forEach((imgUrl, index) => {
                $urls += `
                    <li class="wallregi_item wallregi_item_${index + 1}" onclick="wallregiGiftCardImagePreview(this);">
                        <figure class="wallregi_image_item">
                            <img src="${imgUrl}" alt="Gallery Image">
                        </figure>
                    </li>
                `;
            });
            const proUploadEnabled = !!(window.wallregi_ajax_object && window.wallregi_ajax_object.pro_image_upload && window.wallregi_ajax_object.pro_image_upload.enabled === 'yes');
            if (proUploadEnabled) {
                const icon = (window.wallregi_ajax_object && window.wallregi_ajax_object.upload_icon_url) ? window.wallregi_ajax_object.upload_icon_url : '';
                $urls += wallregiBuildUploadTileHtml(icon);
            }
            jQuery('#edit_giftcard_gallery').html($urls);
        }
    } catch (e) {
        console.error('Failed to parse gallery images:', e);
    }

    
    const priceToCheck = giftcardData.giftcard_price;

    
    // does this price exist in your predefined list?
    const existsInCustom = Array.isArray(customPrices)
      && customPrices.includes(String(priceToCheck));


    // Reset price section
    const $priceList = jQuery('#wallregi_price_option_list');
    $priceList.empty();
    jQuery('.wallregi_custom_price_item').hide();
    jQuery('.wallregi_manual_price_item').hide();

    selectedGiftcardPrice = giftcardData.giftcard_price;

    // Render custom price options
    if (Array.isArray(customPrices)) {
        customPrices.forEach((price, index) => {
            const isActive = Number(price) === Number(giftcardData.giftcard_price) ? 'wallregi_selected' : '';
            const $btn = jQuery(`
                <li class="wallregi_item wallregi_item_${index} ${isActive}" onclick="wallregiSelectGiftcardPrice(this, '${price}')">
                   <button type="button" class="button price_btn wallregi_price_option_button">
                   ${price}
                </button>
                </li>
            `);
            $priceList.append($btn);
        });
        jQuery('.wallregi_custom_price_item').show();
        // Set active price value in edit_giftcard_price
            const $activeItem = jQuery('#wallregi_price_option_list').find('.wallregi_item.wallregi_selected');
            if ($activeItem.length > 0) {
                const activePrice = $activeItem.find('.price_btn').text().trim();
                jQuery('#edit_giftcard_price').text(activePrice);
            }
    }

    if (manualPrice === true) {
      jQuery('.wallregi_manual_price_item').show();
  
      // branch on that:
      if (!existsInCustom) {
        jQuery('.wallregi_edit_input').val(priceToCheck);
      } 

    }

    if (giftcardData.giftcard_heading) {
      jQuery('.edit_giftcard_heading_text').text(giftcardData.giftcard_heading);

    }


    // Fill form fields
    jQuery('#edit_receiver_name').val(giftcardData.receiver_name);
    jQuery('#edit_receiver_email').val(giftcardData.receiver_email);
    jQuery('#edit_giftcard_price').text(giftcardData.giftcard_price);
    jQuery('#edit_receiver_message').val(giftcardData.receiver_message);
    wallregiEnforceEditModalMessageLimit(jQuery('#edit_receiver_message'));
    jQuery('#edit_sender_name').val(giftcardData.sender_name);
    jQuery('#edit_email_schedule').val(giftcardData.email_schedule);
    jQuery('#edit_giftcard_image_preview').attr('src', giftcardData.giftcard_image);

    wallregiPopulateEditModalDeliveryFields(giftcardData, $modal);

    if (typeof window.wallregiProMountEditModalGreetingPresets === 'function') {
        window.wallregiProMountEditModalGreetingPresets(giftcardData.greeting_presets || null);
    }

    wallregiApplyEditModalCheckoutReceiverMode(giftcardData, $modal);

    // Show modal
    $modal.fadeIn();
}




// Handle modal close
function wallregiCloseGiftcardModal() {
    jQuery('#wallregi_giftcard_edit_modal').fadeOut();

}



// Initialize all event handlers after DOM is ready
jQuery(document).ready(function () {
    const uploadIconUrl = (window.wallregi_ajax_object && window.wallregi_ajax_object.upload_icon_url) ? window.wallregi_ajax_object.upload_icon_url : '';
    wallregiCloseGiftcardModal();
    jQuery('.wallregi_edit_modal_close').on('click', function () {
        jQuery('#wallregi_giftcard_edit_modal').fadeOut();
    });

    // Checkout review rows can be re-rendered and inline onclick may be stripped.
    // Use delegated binding so edit works reliably on classic cart + checkout.
    jQuery(document).on('click', '.wodg_cart_item_edit_button', function (event) {
        
        event.preventDefault();

        currentCartItemKey = jQuery(this).data('cart_item_key');
        wallregiActiveEditModal = jQuery('#wallregi_giftcard_edit_modal').last();
        const $modal = wallregiResolveEditModal();
        const giftcardData = wallregiParseGiftcardEditData(jQuery(this).data('giftcard'));
        const displayPrice = jQuery(this).data('giftcard_price');
        const customPrices = jQuery(this).data('custom_prices');
        const manualPrice = jQuery(this).data('manual_price');
        // Inject gallery HTML (if present) so modal has product images to select
        const galleryImages = jQuery(this).attr('data-gallery') || '[]';
        let $urls = '';
        
        try {
            const imageUrls = JSON.parse(galleryImages);
            
            if (Array.isArray(imageUrls) && imageUrls.length > 0) {
                imageUrls.forEach((imgUrl, index) => {
                    $urls += `
                        <li class="wallregi_item wallregi_item_${index + 1}" onclick="wallregiGiftCardImagePreview(this);">
                            <figure class="wallregi_image_item">
                                <img src="${imgUrl}" alt="Gallery Image">
                            </figure>
                        </li>
                    `;
                });

                const proUploadEnabled = !!(window.wallregi_ajax_object && window.wallregi_ajax_object.pro_image_upload && window.wallregi_ajax_object.pro_image_upload.enabled === 'yes');
                if (proUploadEnabled) {
                    $urls += wallregiBuildUploadTileHtml(uploadIconUrl);
                }

                jQuery('#edit_giftcard_gallery').html($urls);
            }
        } catch (e) {
            console.error('Failed to parse gallery images:', e);
        }
        const priceToCheck = giftcardData.giftcard_price;


        // does this price exist in your predefined list?
        const existsInCustom = Array.isArray(customPrices)
        && customPrices.includes(String(priceToCheck));
        
        // Reset price section
        const $priceList = jQuery('#wallregi_price_option_list');
        $priceList.empty();
        jQuery('.wallregi_custom_price_item').hide();
        jQuery('.wallregi_manual_price_item').hide();

        selectedGiftcardPrice = giftcardData.giftcard_price;

        // Render custom price options
        if (Array.isArray(customPrices) && customPrices.length > 0) {
            customPrices.forEach((price, index) => {
                const isActive = Number(price) === Number(giftcardData.giftcard_price) ? 'wallregi_selected' : '';
                const $btn = jQuery(`
                    <li class="wallregi_item wallregi_item_${index} ${isActive}" onclick="wallregiSelectGiftcardPrice(this, '${price}')">
                        <button type="button" class="button price_btn wallregi_price_option_button">
                            ${price}
                        </button>
                    </li>
                `);
                $priceList.append($btn);
            });
            jQuery('.wallregi_custom_price_item').show();
            // Set active price value in edit_giftcard_price
            const $activeItem = jQuery('#wallregi_price_option_list').find('.wallregi_item.wallregi_selected');
            if ($activeItem.length > 0) {
                const activePrice = $activeItem.find('.price_btn').text().trim();
                jQuery('#edit_giftcard_price').text(activePrice);
            }
        }

        if (manualPrice === true) {
            jQuery('.wallregi_manual_price_item').show();
        
            // branch on that:
            if (!existsInCustom) {
                jQuery('.wallregi_edit_input').val(priceToCheck);
            
            } 
        }

        if (giftcardData.giftcard_heading) {
            jQuery('.edit_giftcard_heading_text').text(giftcardData.giftcard_heading);
        }



        // Fill form fields
        jQuery('#edit_receiver_name').val(giftcardData.receiver_name);
        jQuery('#edit_receiver_email').val(giftcardData.receiver_email);
        jQuery('#edit_giftcard_price').text(giftcardData.giftcard_price);
        jQuery('#edit_receiver_message').val(giftcardData.receiver_message);
        wallregiEnforceEditModalMessageLimit(jQuery('#edit_receiver_message'));
        jQuery('#edit_sender_name').val(giftcardData.sender_name);
        jQuery('#edit_email_schedule').val(giftcardData.email_schedule);
        jQuery('#edit_giftcard_image_preview').attr('src', giftcardData.giftcard_image);

        wallregiPopulateEditModalDeliveryFields(giftcardData, $modal);

        if (typeof window.wallregiProMountEditModalGreetingPresets === 'function') {
            window.wallregiProMountEditModalGreetingPresets(giftcardData.greeting_presets || null);
        }

        wallregiApplyEditModalCheckoutReceiverMode(giftcardData, $modal);

        // Show modal
        $modal.fadeIn();
    });

    jQuery(document).on('change', '.wallregi_edit_delivery_channel_select', function () {
        wallregiSyncEditModalDeliveryFields(jQuery(this));
    });

    jQuery(document).on('input keyup paste change', '#edit_receiver_message, .wallregi_edit_textarea', function () {
        wallregiEnforceEditModalMessageLimit(jQuery(this));
    });

    // Handle form submission
    jQuery('#wallregi_edit_modal_form').on('submit', wallregiHandleUpdateGiftcardFormDataSubmit);


});


function wallregiEnforceEditModalMessageLimit($textarea) {
    if (!$textarea || !$textarea.length) {
        $textarea = jQuery('#edit_receiver_message');
    }
    if (!$textarea.length) {
        return;
    }
    if (typeof window.wallregiGiftCardMessagePreview === 'function' && $textarea[0]) {
        window.wallregiGiftCardMessagePreview($textarea[0]);
        return;
    }
    const maxChars = parseInt($textarea.attr('data-maxlength') || $textarea.attr('maxlength')) || 250;
    let text = $textarea.val() || '';
    if (text.length > maxChars) {
        text = text.substring(0, maxChars);
        $textarea.val(text);
    }
    const $container = $textarea.closest('.wallregi_form_item, .wallregi_edit_cart_modal');
    const $charCount = $container.find('.charCount');
    if ($charCount.length) {
        $charCount.text(text.length);
        $charCount.css('color', text.length >= maxChars ? 'red' : 'inherit');
    }
}

window.wallregiEnforceEditModalMessageLimit = wallregiEnforceEditModalMessageLimit;
window.wallregiValidateEditModalDeliveryFields = wallregiValidateEditModalDeliveryFields;
window.wallregiCollectEditModalDeliveryPayload = wallregiCollectEditModalDeliveryPayload;
window.wallregiSyncEditModalDeliveryFields = wallregiSyncEditModalDeliveryFields;
window.wallregiPopulateEditModalDeliveryFields = wallregiPopulateEditModalDeliveryFields;
window.wallregiResolveEditModal = wallregiResolveEditModal;



// Utility functions for price selection
function wallregiSelectGiftcardPrice(element, price) {
    selectedGiftcardPrice = price;
    jQuery('.wallregi_price_option_button').parent().removeClass('wallregi_selected');
    jQuery(element).addClass('wallregi_selected');

    // Update the edit_giftcard_price with the selected price
    jQuery('#edit_giftcard_price').text(price);

    // Clear manual price field if any
    jQuery('.wallregi_cprice_input_field').val('');
}

function wallregiEditGiftCardManualPriceEnable(input) {
    selectedGiftcardPrice = jQuery(input).val();
    jQuery('.wallregi_price_option_button').parent().removeClass('wallregi_selected');
}

function wallregiEditGiftCardManualPriceFocusOut(input) {
    const price = jQuery(input).val();
    if (price) {
        selectedGiftcardPrice = price;
    }
}

function wallregiEditGiftCardManualPriceKeyUp(input) {
    const price = jQuery(input).val();
    selectedGiftcardPrice = price;
}

/**
 * Resolve the price to save (manual field, selected chip, or displayed value).
 */
function wallregiResolveEditModalGiftcardPrice() {
    const manual = jQuery('.wallregi_cprice_input_field').val();
    if (manual !== null && manual !== undefined && String(manual).trim() !== '') {
        return String(manual).trim().replace(/[^0-9.,-]/g, '').replace(/,/g, '');
    }
    if (selectedGiftcardPrice !== null && selectedGiftcardPrice !== undefined && String(selectedGiftcardPrice).trim() !== '') {
        return String(selectedGiftcardPrice).trim();
    }
    return jQuery('#edit_giftcard_price').text().trim().replace(/[^0-9.,-]/g, '').replace(/,/g, '');
}


/*================================
* CART PAGE EDIT GIFTCARD FORM DATA END
*==========================================*/


// Reusable submit handler function
function wallregiHandleUpdateGiftcardFormDataSubmit(event) {
    // Block Cart uses Store API flow in blocks-integration.js.
    // Skip classic AJAX submit to avoid duplicate requests/reloads.
    if (window.wallregiCurrentBlockCartItemKey) {
        return;
    }

    event.preventDefault();

    if (!wallregiValidateEditModalDeliveryFields(wallregiResolveEditModal())) {
        return;
    }

    const $modal = wallregiResolveEditModal();
    const form = $modal.find('#wallregi_edit_modal_form');
    if (!form.length) {
        return;
    }
    const submitBtn = form.find('.submit_btn');
    const cartItemthumbUrl = $modal.find('#edit_giftcard_gallery .wallregi_item.wallregi_active img').attr('src')
        || $modal.find('#edit_giftcard_image_preview').attr('src');
    

    // Disable the button and show loading text/spinner
    submitBtn.prop('disabled', true).html('<span class="spinner is-active" style="float:none;margin:0 5px 0 0;"></span> Updating...');

    wallregiEnforceEditModalMessageLimit($modal.find('#edit_receiver_message, [name="receiver_message"]').first());

    const data = {
        action: 'wallregi_update_giftcard_data',
        _wallreginonce: wallregi_ajax_object.nonce,
        cart_item_key: currentCartItemKey,
        receiver_name: $modal.find('[name="receiver_name"], #edit_receiver_name').first().val(),
        receiver_email: $modal.find('[name="receiver_email"], #edit_receiver_email').first().val(),
        receiver_message: $modal.find('[name="receiver_message"], #edit_receiver_message').first().val(),
        sender_name: $modal.find('[name="sender_name"], #edit_sender_name').first().val(),
        email_schedule: $modal.find('[name="email_schedule"], #edit_email_schedule').first().val(),
        thumb_image_url:cartItemthumbUrl,
        giftcard_price: wallregiResolveEditModalGiftcardPrice(),
        ...wallregiCollectEditModalDeliveryPayload($modal),
    };

    jQuery.ajax({
        type: 'POST',
        url: wallregi_ajax_object.ajax_url,
        data: data,
        beforeSend: function () {
            // Optional: show loading spinner
        },
        success: function (response) {
                if (response.success) {
                    if (jQuery('form.checkout').length) {
                        $modal.fadeOut();
                        jQuery(document.body).trigger('update_checkout');
                    } else if (jQuery('.woocommerce-cart-form').length) {
                        $modal.fadeOut();
                    jQuery(document.body).trigger('wc_fragment_refresh');
                } else {
                    location.reload();
                }
            } else {
                alert(response.data?.message || 'Something went wrong!');
            }
        },
        error: function () {
            alert('AJAX request failed!');
        },
        complete: function () {
            // Re-enable the button and restore original text
            submitBtn.prop('disabled', false).text('Update');
        }
    });
}



