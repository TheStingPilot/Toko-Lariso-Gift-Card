document.addEventListener('DOMContentLoaded', function () {
  const toggleBtn = document.getElementById('wallregi_toggle_form');
  const form = document.getElementById('wallregi_giftcard_coupon_form');
  const applyButton = document.getElementById('wallregi_apply_coupon');
  const inputField = document.getElementById('wallregi_coupon_code');
  const errorMessage = document.getElementById('wallregi_error_message');
  const modal = document.getElementById('wallregi_redeem_amount_modal');
  // Classic cart/checkout output this inside a column; transform/filter ancestors break fixed → viewport.
  if (modal && modal.parentNode !== document.body) {
    document.body.appendChild(modal);
  }

  function getBuyerRedeemConfig() {
    if (typeof wallregi_ajax_object === 'undefined' || !wallregi_ajax_object || !wallregi_ajax_object.proBuyerRedeemAmount) {
      return null;
    }
    return wallregi_ajax_object.proBuyerRedeemAmount;
  }

  /** True when the Blocks cart/checkout gift card slot is in the DOM (Store API UI). */
  function wallregiGiftcardBlocksRedemptionOnPage() {
    try {
      return !!document.querySelector('.wallregi-block-giftcard-redemption');
    } catch (e) {
      return false;
    }
  }

  function wallregiDismissPendingQueryApply() {
    if (typeof wallregi_ajax_object === 'undefined' || !wallregi_ajax_object || !wallregi_ajax_object.apply_coupon_nonce || !wallregi_ajax_object.ajax_url) {
      return;
    }
    var params = new URLSearchParams({
      action: 'wallregi_dismiss_pending_giftcard_query',
      security: wallregi_ajax_object.apply_coupon_nonce,
    });
    fetch(wallregi_ajax_object.ajax_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params,
    }).catch(function () {});
  }

  function setErrorHtml(html) {
    if (errorMessage) {
      errorMessage.innerHTML = html;
    }
  }

  function openRedeemModal(preview, couponCode, modalOpts) {
    modalOpts = modalOpts || {};
    if (!modal) {
      return;
    }
    if (typeof modal._wallregiRedeemUnbind === 'function') {
      modal._wallregiRedeemUnbind();
      modal._wallregiRedeemUnbind = null;
    }
    const cfg = getBuyerRedeemConfig();
    const labels = (cfg && cfg.labels) ? cfg.labels : {};
    const titleEl = modal.querySelector('.wallregi-redeem-modal__title');
    const metaEl = modal.querySelector('.wallregi-redeem-modal__meta');
    const labelEl = modal.querySelector('.wallregi-redeem-modal__label');
    const inputEl = modal.querySelector('.wallregi-redeem-modal__input');
    const errEl = modal.querySelector('.wallregi-redeem-modal__error');
    const btnCancel = modal.querySelector('.wallregi-redeem-modal__cancel');
    const btnConfirm = modal.querySelector('.wallregi-redeem-modal__confirm');
    const backdrop = modal.querySelector('.wallregi-redeem-modal__backdrop');
    const panel = modal.querySelector('.wallregi-redeem-modal__panel');

    if (!titleEl || !metaEl || !labelEl || !inputEl || !errEl || !btnCancel || !btnConfirm || !backdrop || !panel) {
      return;
    }

    titleEl.textContent = labels.modalTitle || 'How much do you want to use?';
    labelEl.textContent = labels.inputLabel || 'Amount to use';
    btnCancel.textContent = labels.cancel || 'Cancel';
    btnConfirm.textContent = labels.confirm || 'Confirm';
    inputEl.value = String(preview.maxUsable || '');
    errEl.style.display = 'none';
    errEl.textContent = '';

    metaEl.innerHTML = '';
    function addRow(dt, dd) {
      const ddt = document.createElement('dt');
      ddt.textContent = dt;
      const ddd = document.createElement('dd');
      ddd.textContent = dd;
      metaEl.appendChild(ddt);
      metaEl.appendChild(ddd);
    }
    addRow(labels.availableLabel || 'Available balance', preview.balanceFormatted || String(preview.balance));
    addRow(labels.maxLabel || 'Maximum for this order', preview.maxUsableFormatted || String(preview.maxUsable));
    if (preview.minUsable && preview.minUsable > 1) {
      addRow(labels.minLabel || 'Minimum per redemption', preview.minUsableFormatted || String(preview.minUsable));
    }

    modal.style.display = 'flex';
    document.body.classList.add('wallregi-redeem-modal-open');

    var submittingFromModal = false;
    var confirmSubmitSpinner = null;

    function unbindListeners() {
      modal.removeEventListener('click', onModalClickCapture, true);
    }

    function close() {
      unbindListeners();
      modal._wallregiRedeemUnbind = null;
      modal.style.display = 'none';
      document.body.classList.remove('wallregi-redeem-modal-open');
    }

    function onCancel() {
      if (submittingFromModal) {
        return;
      }
      if (modalOpts.fromQueryFlow) {
        wallregiDismissPendingQueryApply();
      }
      close();
    }

    function onOkFromModal() {
      if (submittingFromModal) {
        return;
      }
      const raw = String(inputEl.value || '').trim();
      if (!raw) {
        errEl.textContent = labels.invalidAmount || 'Enter a valid amount.';
        errEl.style.display = 'block';
        return;
      }
      const amt = parseFloat(raw.replace(',', '.'));
      if (!isFinite(amt) || amt <= 0) {
        errEl.textContent = labels.invalidAmount || 'Enter a valid amount.';
        errEl.style.display = 'block';
        return;
      }
      errEl.style.display = 'none';
      errEl.textContent = '';
      submittingFromModal = true;
      btnConfirm.disabled = true;
      btnCancel.disabled = true;
      inputEl.readOnly = true;
      confirmSubmitSpinner = document.createElement('span');
      confirmSubmitSpinner.classList.add('loading-spinner');
      btnConfirm.prepend(confirmSubmitSpinner);

      const applyBtn = modalOpts.applyButtonEl;
      if (!applyBtn || typeof wallregi_ajax_object === 'undefined' || !wallregi_ajax_object) {
        submittingFromModal = false;
        btnConfirm.disabled = false;
        btnCancel.disabled = false;
        inputEl.readOnly = false;
        if (confirmSubmitSpinner && confirmSubmitSpinner.parentNode === btnConfirm) {
          btnConfirm.removeChild(confirmSubmitSpinner);
        }
        return;
      }

      applyGiftCardRequest(
        couponCode,
        Math.round(amt),
        applyBtn,
        null,
        !!modalOpts.fromQueryFlow,
        {
          onModalError: function (msg) {
            submittingFromModal = false;
            if (confirmSubmitSpinner && confirmSubmitSpinner.parentNode === btnConfirm) {
              btnConfirm.removeChild(confirmSubmitSpinner);
            }
            confirmSubmitSpinner = null;
            btnConfirm.disabled = false;
            btnCancel.disabled = false;
            inputEl.readOnly = false;
            if (applyBtn) {
              applyBtn.disabled = false;
            }
            errEl.textContent = msg || 'Something went wrong.';
            errEl.style.display = 'block';
          },
          onModalSuccessClose: function () {
            submittingFromModal = false;
            if (confirmSubmitSpinner && confirmSubmitSpinner.parentNode === btnConfirm) {
              btnConfirm.removeChild(confirmSubmitSpinner);
            }
            confirmSubmitSpinner = null;
            close();
          },
        }
      );
    }

    /** One capture-phase handler: avoids stacked listeners if openRedeemModal runs twice, and runs before theme handlers. */
    function onModalClickCapture(ev) {
      let t = ev.target;
      if (t && t.nodeType !== 1 && t.parentElement) {
        t = t.parentElement;
      }
      if (!t || typeof t.closest !== 'function') {
        return;
      }
      if (panel && panel.contains(t)) {
        if (t.closest('.wallregi-redeem-modal__cancel')) {
          ev.preventDefault();
          ev.stopPropagation();
          onCancel();
          return;
        }
        if (t.closest('.wallregi-redeem-modal__confirm')) {
          ev.preventDefault();
          ev.stopPropagation();
          onOkFromModal();
          return;
        }
        return;
      }
      if (submittingFromModal) {
        ev.preventDefault();
        ev.stopPropagation();
        return;
      }
      ev.preventDefault();
      ev.stopPropagation();
      onCancel();
    }

    modal.addEventListener('click', onModalClickCapture, true);

    modal._wallregiRedeemUnbind = unbindListeners;
  }

  function applyGiftCardRequest(couponCode, redeemAmount, applyButtonEl, loadingSpinner, fromQueryFlowContext, modalFeedback) {
    fromQueryFlowContext = !!fromQueryFlowContext;
    modalFeedback = modalFeedback || null;
    const params = new URLSearchParams({
      action: 'wallregi_apply_giftcard_coupon',
      security: wallregi_ajax_object.apply_coupon_nonce,
      coupon_code: couponCode,
    });
    if (redeemAmount !== null && redeemAmount !== undefined) {
      params.set('redeem_amount', String(redeemAmount));
    }

    return fetch(wallregi_ajax_object.ajax_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params,
    })
      .then(function (response) {
        return response.json();
      })
      .then(function (json) {
        if (loadingSpinner && loadingSpinner.parentNode === applyButtonEl) {
          applyButtonEl.removeChild(loadingSpinner);
        }
        if (!modalFeedback) {
          applyButtonEl.disabled = false;
        }

        if (!json.success) {
          const msg = (json.data && json.data.message) ? json.data.message : 'Something went wrong.';
          if (modalFeedback && typeof modalFeedback.onModalError === 'function') {
            modalFeedback.onModalError(msg);
          } else {
            setErrorHtml('<span style="color: red;">' + msg + '</span>');
          }
          if (fromQueryFlowContext && !modalFeedback) {
            wallregiDismissPendingQueryApply();
          }
          return;
        }

        const data = json.data || {};
        if (data.needsRedeemAmount) {
          if (wallregiGiftcardBlocksRedemptionOnPage()) {
            if (fromQueryFlowContext) {
              wallregiDismissPendingQueryApply();
            }
            var hintB =
              wallregi_ajax_object && wallregi_ajax_object.giftcardBlocksRedeemHint
                ? String(wallregi_ajax_object.giftcardBlocksRedeemHint)
                : 'Use the gift card field in the order summary to choose an amount and apply your code.';
            setErrorHtml('<span style="color:#2271b1;">' + hintB.replace(/</g, '&lt;') + '</span>');
            return;
          }
          openRedeemModal(data, couponCode, {
            fromQueryFlow: fromQueryFlowContext,
            applyButtonEl: applyButtonEl,
          });
          return;
        }

        if (modalFeedback && typeof modalFeedback.onModalSuccessClose === 'function') {
          modalFeedback.onModalSuccessClose();
        }
        setErrorHtml('<span style="color: green;">' + (data.message || '') + '</span>');
        window.location.reload();
      })
      .catch(function () {
        if (loadingSpinner && loadingSpinner.parentNode === applyButtonEl) {
          applyButtonEl.removeChild(loadingSpinner);
        }
        if (!modalFeedback) {
          applyButtonEl.disabled = false;
        }
        const fallback = 'Something went wrong. Please try again.';
        if (modalFeedback && typeof modalFeedback.onModalError === 'function') {
          modalFeedback.onModalError(fallback);
        } else {
          setErrorHtml('<span style="color: red;">' + fallback + '</span>');
        }
        if (fromQueryFlowContext && !modalFeedback) {
          wallregiDismissPendingQueryApply();
        }
      });
  }

  if (toggleBtn && form && applyButton) {
    toggleBtn.addEventListener('click', function () {
      form.style.display = form.style.display === 'none' ? 'block' : 'none';
    });

    applyButton.addEventListener('click', function () {
      const couponCode = inputField.value.trim();
      if (!couponCode) {
        setErrorHtml('<span style="color: red;">Please enter a gift card code.</span>');
        return;
      }

      var maxCards = 0;
      var appliedCount = 0;
      if (typeof wallregi_ajax_object !== 'undefined' && wallregi_ajax_object) {
        maxCards = parseInt(String(wallregi_ajax_object.maxGiftcardsPerOrder || '0'), 10) || 0;
        appliedCount = parseInt(String(wallregi_ajax_object.appliedGiftcardsCount || '0'), 10) || 0;
      }
      if (maxCards > 0 && appliedCount >= maxCards) {
        var limitMsg = (wallregi_ajax_object && wallregi_ajax_object.sessionLimitReachedMessage)
          ? wallregi_ajax_object.sessionLimitReachedMessage
          : 'You cannot apply more gift cards for this order.';
        setErrorHtml('<span style="color: red;">' + limitMsg + '</span>');
        return;
      }

      const loadingSpinner = document.createElement('span');
      loadingSpinner.classList.add('loading-spinner');
      applyButton.prepend(loadingSpinner);
      applyButton.disabled = true;

      applyGiftCardRequest(couponCode, null, applyButton, loadingSpinner, false);
    });
  }

  // PDF / QR ?wallregi_apply_giftcard= — when Pro requires a redeem amount, PHP stores code in session and redirects here.
  if (
    typeof wallregi_ajax_object !== 'undefined' &&
    wallregi_ajax_object &&
    wallregi_ajax_object.pendingGiftcardApplyFromQuery &&
    wallregi_ajax_object.apply_coupon_nonce &&
    applyButton &&
    inputField &&
    !wallregiGiftcardBlocksRedemptionOnPage()
  ) {
    var pcode = String(wallregi_ajax_object.pendingGiftcardApplyFromQuery || '').trim();
    if (pcode !== '') {
      if (form) {
        form.style.display = 'block';
      }
      inputField.value = pcode;
      var maxCardsQ = 0;
      var appliedCountQ = 0;
      if (wallregi_ajax_object) {
        maxCardsQ = parseInt(String(wallregi_ajax_object.maxGiftcardsPerOrder || '0'), 10) || 0;
        appliedCountQ = parseInt(String(wallregi_ajax_object.appliedGiftcardsCount || '0'), 10) || 0;
      }
      if (maxCardsQ > 0 && appliedCountQ >= maxCardsQ) {
        var limitMsgQ = wallregi_ajax_object.sessionLimitReachedMessage
          ? wallregi_ajax_object.sessionLimitReachedMessage
          : 'You cannot apply more gift cards for this order.';
        setErrorHtml('<span style="color: red;">' + limitMsgQ + '</span>');
        wallregiDismissPendingQueryApply();
      } else {
        try {
          var uq = new URL(window.location.href);
          if (uq.searchParams.has('wallregi_giftcard_amount_prompt')) {
            uq.searchParams.delete('wallregi_giftcard_amount_prompt');
            window.history.replaceState({}, document.title, uq.pathname + (uq.search || '') + (uq.hash || ''));
          }
        } catch (eQ) {}
        var spinQ = document.createElement('span');
        spinQ.classList.add('loading-spinner');
        applyButton.prepend(spinQ);
        applyButton.disabled = true;
        applyGiftCardRequest(pcode, null, applyButton, spinQ, true);
      }
    }
  }
});

function wallregi_toggle_coupon_accordion() {
  const container = jQuery('.wallregi_coupon_container');
  const couponList = container.find('.wallregi_usage_coupon_list');
  couponList.slideToggle('slow');
  const icon = jQuery(this).find('.wallregi_icon');
  icon.toggleClass('wallregi_icon_minus wallregi_icon_plus rotate');
}
