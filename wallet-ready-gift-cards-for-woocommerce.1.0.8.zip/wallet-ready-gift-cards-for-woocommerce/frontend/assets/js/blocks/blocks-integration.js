(function () {
    const settings = window.wallregiBlocksSettings || {};
    const namespace = settings.namespace || 'wallet-ready-gift-cards-for-woocommerce';
    const labels = settings.labels || {};
    const wcBlocksCheckout = window.wc && window.wc.blocksCheckout ? window.wc.blocksCheckout : {};
    const extensionCartUpdate = wcBlocksCheckout.extensionCartUpdate;

    if (!extensionCartUpdate) {
        return;
    }

    function getExtensionData(extensions) {
        return (extensions && extensions[namespace]) || {};
    }

    function getErrorMessage(error) {
        if (error && error.message) {
            return error.message;
        }

        if (error && error.data && error.data.message) {
            return error.data.message;
        }

        return labels.genericError || 'Something went wrong. Please try again.';
    }

    function normalizePriceValue(value) {
        const rawValue = String(value || '').trim();
        if (!rawValue) {
            return '';
        }

        const normalizedValue = rawValue.replace(/[^0-9.,-]/g, '').replace(/,/g, '');
        return normalizedValue;
    }

    function registerGiftcardDiscountSlot() {
        if (!window.wp || !wp.element || !wp.plugins || !wcBlocksCheckout.ExperimentalDiscountsMeta) {
            return;
        }

        const el = wp.element.createElement;
        const useState = wp.element.useState;
        const useSelect = wp.data && wp.data.useSelect ? wp.data.useSelect : null;
        const __ = wp.i18n && wp.i18n.__ ? wp.i18n.__ : function (text) { return text; };

        function useCartNamespaceData() {
            if (!useSelect) {
                return {};
            }
            return useSelect(function (select) {
                try {
                    var cart = select('wc/store/cart').getCartData();
                    return getExtensionData(cart && cart.extensions);
                } catch (e) {
                    return {};
                }
            }, []);
        }

        function AppliedGiftcardRow(props) {
            var giftcard = props.giftcard;
            var isBusy = props.isBusy;
            var removeGiftcard = props.removeGiftcard;

            return el(
                'li',
                { key: giftcard.code, className: 'wallregi-block-applied-giftcards-row' },
                el('div', { className: 'wallregi-block-applied-giftcards-row-main' },
                    el('span', { className: 'wallregi-block-applied-giftcards-code' }, giftcard.code),
                    el('span', { className: 'wallregi-block-applied-giftcards-amount' }, '-' + (giftcard.formattedAmount || ''))
                ),
                el(
                    'button',
                    {
                        type: 'button',
                        className: 'button wallregi-block-remove-giftcard',
                        disabled: isBusy,
                        onClick: function (event) { removeGiftcard(giftcard.code, event); },
                        'aria-label': __('Remove gift card', 'wallet-ready-gift-cards-for-woocommerce')
                    },
                    '×'
                )
            );
        }

        function fetchRedeemPreview(couponCode) {
            var br = settings.proBuyerRedeemAmount || {};
            var fd = new URLSearchParams();
            fd.set('action', 'wallregi_preview_giftcard_redeem');
            fd.set('security', br.previewNonce || '');
            fd.set('coupon_code', couponCode);
            return fetch(br.ajaxUrl || '', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: fd,
            }).then(function (response) {
                return response.json();
            }).then(function (json) {
                if (!json.success) {
                    throw new Error((json.data && json.data.message) ? json.data.message : 'Preview failed');
                }
                return json.data;
            });
        }

        var wallregiActiveBlockRedeemRoot = null;

        function openBlockRedeemModalApplyFlow(preview, couponCode, callbacks) {
            callbacks = callbacks || {};
            if (wallregiActiveBlockRedeemRoot && wallregiActiveBlockRedeemRoot.parentNode) {
                try {
                    wallregiActiveBlockRedeemRoot.parentNode.removeChild(wallregiActiveBlockRedeemRoot);
                } catch (eRemove) {}
                wallregiActiveBlockRedeemRoot = null;
            }
            var br = settings.proBuyerRedeemAmount || {};
            var L = br.labels || {};
            var root = document.createElement('div');
            root.className = 'wallregi-redeem-modal wallregi-redeem-modal--blocks';
            root.style.display = 'flex';
            root.style.zIndex = '2147483646';
            root.setAttribute('role', 'dialog');
            root.setAttribute('aria-modal', 'true');
            root.innerHTML =
                '<div class="wallregi-redeem-modal__backdrop"></div>' +
                '<div class="wallregi-redeem-modal__panel">' +
                '<h3 class="wallregi-redeem-modal__title"></h3>' +
                '<dl class="wallregi-redeem-modal__meta"></dl>' +
                '<label class="wallregi-redeem-modal__label" for="wallregi_block_redeem_amt"></label>' +
                '<input type="text" inputmode="decimal" id="wallregi_block_redeem_amt" class="wallregi-redeem-modal__input input-text" autocomplete="off" />' +
                '<div class="wallregi-redeem-modal__actions">' +
                '<button type="button" class="button wallregi-redeem-modal__cancel"></button>' +
                '<button type="button" class="button button-primary wallregi-redeem-modal__confirm"></button>' +
                '</div>' +
                '<p class="wallregi-redeem-modal__error" style="display:none;color:#b42318;margin-top:8px;"></p>' +
                '</div>';
            document.body.appendChild(root);
            wallregiActiveBlockRedeemRoot = root;
            document.body.classList.add('wallregi-redeem-modal-open');

            var title = root.querySelector('.wallregi-redeem-modal__title');
            var meta = root.querySelector('.wallregi-redeem-modal__meta');
            var label = root.querySelector('.wallregi-redeem-modal__label');
            var input = root.querySelector('#wallregi_block_redeem_amt');
            var err = root.querySelector('.wallregi-redeem-modal__error');
            var btnC = root.querySelector('.wallregi-redeem-modal__cancel');
            var btnO = root.querySelector('.wallregi-redeem-modal__confirm');
            var panel = root.querySelector('.wallregi-redeem-modal__panel');

            title.textContent = L.modalTitle || 'How much do you want to use?';
            label.textContent = L.inputLabel || 'Amount to use';
            btnC.textContent = L.cancel || 'Cancel';
            btnO.textContent = L.confirm || 'Confirm';
            input.value = String(preview.maxUsable || '');

            function row(dt, dd) {
                var ddt = document.createElement('dt');
                ddt.textContent = dt;
                var ddd = document.createElement('dd');
                ddd.textContent = dd;
                meta.appendChild(ddt);
                meta.appendChild(ddd);
            }
            row(L.availableLabel || 'Available balance', preview.balanceFormatted || String(preview.balance));
            row(L.maxLabel || 'Maximum for this order', preview.maxUsableFormatted || String(preview.maxUsable));
            if (preview.minUsable && preview.minUsable > 1) {
                row(L.minLabel || 'Minimum per redemption', preview.minUsableFormatted || String(preview.minUsable));
            }

            var submitting = false;
            var confirmSpin = null;

            function destroy() {
                document.body.classList.remove('wallregi-redeem-modal-open');
                if (root.parentNode) {
                    root.parentNode.removeChild(root);
                }
                if (wallregiActiveBlockRedeemRoot === root) {
                    wallregiActiveBlockRedeemRoot = null;
                }
            }

            function cleanupUiListeners() {
                root.removeEventListener('click', onRootClickCapture, true);
            }

            function finishCancel() {
                if (submitting) {
                    return;
                }
                cleanupUiListeners();
                destroy();
                if (typeof callbacks.onCancel === 'function') {
                    callbacks.onCancel();
                }
            }

            function onRootClickCapture(ev) {
                var t = ev.target;
                if (t && t.nodeType !== 1 && t.parentElement) {
                    t = t.parentElement;
                }
                if (!t || typeof t.closest !== 'function') {
                    return;
                }
                if (panel && panel.contains(t)) {
                    if (t.closest('.wallregi-redeem-modal__cancel')) {
                        ev.preventDefault();
                        ev.stopPropagation();
                        finishCancel();
                        return;
                    }
                    if (t.closest('.wallregi-redeem-modal__confirm')) {
                        ev.preventDefault();
                        ev.stopPropagation();
                        onConfirmApply();
                        return;
                    }
                    return;
                }
                if (submitting) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    return;
                }
                ev.preventDefault();
                ev.stopPropagation();
                finishCancel();
            }

            function onConfirmApply() {
                if (submitting) {
                    return;
                }
                var raw = String(input.value || '').trim();
                if (!raw) {
                    err.textContent = L.invalidAmount || 'Enter a valid amount.';
                    err.style.display = 'block';
                    return;
                }
                var amt = parseFloat(raw.replace(',', '.'));
                if (!isFinite(amt) || amt <= 0) {
                    err.textContent = L.invalidAmount || 'Enter a valid amount.';
                    err.style.display = 'block';
                    return;
                }
                err.style.display = 'none';
                err.textContent = '';
                submitting = true;
                btnO.disabled = true;
                btnC.disabled = true;
                input.readOnly = true;
                confirmSpin = document.createElement('span');
                confirmSpin.classList.add('loading-spinner');
                btnO.prepend(confirmSpin);

                extensionCartUpdate({
                    namespace: namespace,
                    data: {
                        action: 'apply_giftcard',
                        couponCode: couponCode,
                        redeemAmount: String(Math.round(amt)),
                    },
                })
                    .then(function () {
                        submitting = false;
                        cleanupUiListeners();
                        destroy();
                        if (typeof callbacks.onSuccess === 'function') {
                            callbacks.onSuccess();
                        }
                    })
                    .catch(function (eApply) {
                        submitting = false;
                        if (confirmSpin && confirmSpin.parentNode === btnO) {
                            btnO.removeChild(confirmSpin);
                        }
                        confirmSpin = null;
                        btnO.disabled = false;
                        btnC.disabled = false;
                        input.readOnly = false;
                        err.textContent = getErrorMessage(eApply);
                        err.style.display = 'block';
                    });
            }

            root.addEventListener('click', onRootClickCapture, true);
        }

        function GiftcardRedemption() {
            var extensionData = useCartNamespaceData ? useCartNamespaceData() : {};
            var appliedGiftcards = extensionData.appliedGiftcards || [];

            var stateCode = useState('');
            var code = stateCode[0];
            var setCode = stateCode[1];
            var stateOpen = useState(false);
            var isOpen = stateOpen[0];
            var setIsOpen = stateOpen[1];
            var stateBusy = useState(false);
            var isBusy = stateBusy[0];
            var setIsBusy = stateBusy[1];
            var stateMessage = useState('');
            var message = stateMessage[0];
            var setMessage = stateMessage[1];
            var stateError = useState(false);
            var isError = stateError[0];
            var setIsError = stateError[1];

            var maxGiftcards = Number(settings.maxGiftcardsPerOrder) || 0;
            var atSessionLimit = maxGiftcards > 0 && appliedGiftcards.length >= maxGiftcards;

            function applyGiftcard(event) {
                event.preventDefault();

                var couponCode = code.trim();
                if (!couponCode) {
                    setMessage(labels.emptyCode || __('Please enter a gift card code.', 'wallet-ready-gift-cards-for-woocommerce'));
                    setIsError(true);
                    return;
                }

                if (maxGiftcards > 0 && appliedGiftcards.length >= maxGiftcards) {
                    setMessage(labels.sessionLimitReached || __('You cannot apply more gift cards for this order.', 'wallet-ready-gift-cards-for-woocommerce'));
                    setIsError(true);
                    return;
                }

                var br = settings.proBuyerRedeemAmount || {};
                if (br.enabled) {
                    setIsBusy(true);
                    setMessage('');
                    setIsError(false);
                    fetchRedeemPreview(couponCode)
                        .then(function (preview) {
                            openBlockRedeemModalApplyFlow(preview, couponCode, {
                                onSuccess: function () {
                                    setCode('');
                                    setIsOpen(false);
                                    setIsError(false);
                                },
                                onCancel: function () {},
                            });
                        })
                        .catch(function (error) {
                            setMessage(getErrorMessage(error));
                            setIsError(true);
                        })
                        .finally(function () {
                            setIsBusy(false);
                        });
                    return;
                }

                setIsBusy(true);
                setMessage('');
                extensionCartUpdate({
                    namespace: namespace,
                    data: {
                        action: 'apply_giftcard',
                        couponCode: couponCode,
                    },
                }).then(function () {
                    setCode('');
                    setIsOpen(false);
                    setIsError(false);
                }).catch(function (error) {
                    setMessage(getErrorMessage(error));
                    setIsError(true);
                }).finally(function () {
                    setIsBusy(false);
                });
            }

            function removeGiftcard(couponCode, event) {
                if (event) {
                    event.preventDefault();
                    event.stopPropagation();
                }

                couponCode = String(couponCode || '').trim();
                if (!couponCode) {
                    return;
                }

                setIsBusy(true);
                setMessage('');
                extensionCartUpdate({
                    namespace: namespace,
                    data: {
                        action: 'remove_giftcard',
                        couponCode: couponCode
                    }
                }).catch(function (error) {
                    setMessage(getErrorMessage(error));
                    setIsError(true);
                }).finally(function () {
                    setIsBusy(false);
                });
            }

            return el(
                'div',
                { className: 'wallregi-block-giftcard-redemption wc-block-components-totals-wrapper' },
                el(
                    'button',
                    {
                        type: 'button',
                        className: 'button wallregi-block-giftcard-toggle',
                        onClick: function () { setIsOpen(!isOpen); }
                    },
                    labels.toggle || __('Have a gift card code? Use it here', 'wallet-ready-gift-cards-for-woocommerce')
                ),
                isOpen && el(
                    'form',
                    { className: 'wallregi-block-giftcard-form', onSubmit: applyGiftcard },
                    el('input', {
                        type: 'text',
                        value: code,
                        placeholder: labels.placeholder || __('Enter your gift card code', 'wallet-ready-gift-cards-for-woocommerce'),
                        onChange: function (event) { setCode(event.target.value); },
                        disabled: isBusy || atSessionLimit
                    }),
                    el(
                        'button',
                        { type: 'submit', className: 'button', disabled: isBusy || atSessionLimit },
                        isBusy ? (labels.applying || __('Applying...', 'wallet-ready-gift-cards-for-woocommerce')) : (labels.apply || __('Apply', 'wallet-ready-gift-cards-for-woocommerce'))
                    )
                ),
                atSessionLimit && el(
                    'p',
                    { className: 'wallregi-block-giftcard-message error wallregi-block-giftcard-session-limit' },
                    labels.sessionLimitReached || ''
                ),
                message && el(
                    'p',
                    { className: isError ? 'wallregi-block-giftcard-message error' : 'wallregi-block-giftcard-message success' },
                    message
                ),
                appliedGiftcards.length > 0 && el(
                    'div',
                    { className: 'wallregi-block-applied-giftcards' },
                    el('h4', null, labels.applied || __('Applied gift cards', 'wallet-ready-gift-cards-for-woocommerce')),
                    el(
                        'ul',
                        { className: 'wallregi-block-applied-giftcards-list' },
                        appliedGiftcards.map(function (giftcard) {
                            return el(AppliedGiftcardRow, {
                                key: giftcard.code,
                                giftcard: giftcard,
                                isBusy: isBusy,
                                removeGiftcard: removeGiftcard
                            });
                        })
                    )
                )
            );
        }

        function registerOne(pluginId, scope) {
            wp.plugins.registerPlugin(pluginId, {
                render: function () {
                    return el(
                        wcBlocksCheckout.ExperimentalDiscountsMeta,
                        null,
                        el(GiftcardRedemption)
                    );
                },
                scope: scope
            });
        }

        registerOne('wallregi-giftcard-redemption-checkout', 'woocommerce-checkout');
        registerOne('wallregi-giftcard-redemption-cart', 'woocommerce-cart');

        function stripWallregiAmountPromptQueryParam() {
            try {
                var u = new URL(window.location.href);
                if (!u.searchParams.has('wallregi_giftcard_amount_prompt')) {
                    return;
                }
                u.searchParams.delete('wallregi_giftcard_amount_prompt');
                var next = u.pathname + (u.search || '') + (u.hash || '');
                window.history.replaceState({}, document.title, next);
            } catch (e) {}
        }

        function dismissPendingGiftcardQueryForBlocks() {
            var nonce = settings.applyCouponAjaxNonce;
            var ajaxUrl = settings.wcAdminAjaxUrl || (settings.proBuyerRedeemAmount && settings.proBuyerRedeemAmount.ajaxUrl);
            if (!nonce || !ajaxUrl) {
                return;
            }
            var fd = new URLSearchParams();
            fd.set('action', 'wallregi_dismiss_pending_giftcard_query');
            fd.set('security', nonce);
            fetch(ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: fd,
            }).catch(function () {});
        }

        var wallregiPendingQueryBlocksDone = false;
        function tryApplyPendingGiftcardFromQueryForBlocks() {
            if (wallregiPendingQueryBlocksDone) {
                return;
            }
            var pending = settings.pendingGiftcardApplyFromQuery;
            if (!pending || !String(pending).trim()) {
                return;
            }
            var br = settings.proBuyerRedeemAmount || {};
            if (!br || !br.enabled) {
                dismissPendingGiftcardQueryForBlocks();
                stripWallregiAmountPromptQueryParam();
                wallregiPendingQueryBlocksDone = true;
                return;
            }

            wallregiPendingQueryBlocksDone = true;
            stripWallregiAmountPromptQueryParam();

            var code = String(pending).trim();
            fetchRedeemPreview(code)
                .then(function (preview) {
                    openBlockRedeemModalApplyFlow(preview, code, {
                        onSuccess: function () {
                            dismissPendingGiftcardQueryForBlocks();
                        },
                        onCancel: function () {
                            dismissPendingGiftcardQueryForBlocks();
                        },
                    });
                })
                .catch(function () {
                    dismissPendingGiftcardQueryForBlocks();
                });
        }

        var wallregiPendingQueryBlocksAttempts = 0;
        function schedulePendingQueryApplyForBlocks() {
            if (wallregiPendingQueryBlocksDone) {
                return;
            }
            if (!settings.pendingGiftcardApplyFromQuery || !String(settings.pendingGiftcardApplyFromQuery).trim()) {
                return;
            }
            wallregiPendingQueryBlocksAttempts += 1;
            if (wallregiPendingQueryBlocksAttempts > 50) {
                dismissPendingGiftcardQueryForBlocks();
                stripWallregiAmountPromptQueryParam();
                wallregiPendingQueryBlocksDone = true;
                return;
            }
            if (window.wp && wp.data && wp.data.select) {
                try {
                    var cart = wp.data.select('wc/store/cart').getCartData();
                    if (cart) {
                        tryApplyPendingGiftcardFromQueryForBlocks();
                        return;
                    }
                } catch (e) {}
            }
            window.setTimeout(schedulePendingQueryApplyForBlocks, 120);
        }
        window.setTimeout(schedulePendingQueryApplyForBlocks, 80);
    }

    function escapeAttribute(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    function registerCartItemEditFilter() {
        if ((!settings.isCartEditEnabled && !settings.isCheckoutEditEnabled) || !wcBlocksCheckout.registerCheckoutFilters) {
            return;
        }

        wcBlocksCheckout.registerCheckoutFilters(namespace, {
            itemName: function (defaultValue, extensions, args) {
                const cartItem = args && args.cartItem ? args.cartItem : {};
                const extensionData = getExtensionData(cartItem.extensions);

                const context = args && args.context ? args.context : '';
                const isCartContext = context === 'cart';
                const isCheckoutContext = context === 'summary';
                const allowCart = !!settings.isCartEditEnabled;
                const allowCheckout = !!settings.isCheckoutEditEnabled;

                if (!args || !extensionData.isGiftCard) {
                    return defaultValue;
                }

                if ((isCartContext && !allowCart) || (isCheckoutContext && !allowCheckout) || (!isCartContext && !isCheckoutContext)) {
                    return defaultValue;
                }

                return defaultValue + '<div class="wodg_edit_cart_item_button_box wallregi-block-cart-edit-box"><button type="button" class="button wodg_cart_item_edit_button wallregi-block-cart-item-edit-button" data-cart_item_key="' + escapeAttribute(cartItem.key) + '" data-giftcard="' + escapeAttribute(JSON.stringify(extensionData.giftcardData || {})) + '" data-giftcard_price="' + escapeAttribute(extensionData.displayPrice || '') + '" data-custom_prices="' + escapeAttribute(JSON.stringify(extensionData.customPrices || [])) + '" data-manual_price="' + escapeAttribute(extensionData.manualPrice ? 'true' : 'false') + '" data-gallery="' + escapeAttribute(JSON.stringify(extensionData.gallery || [])) + '">' + escapeAttribute(labels.edit || 'Edit') + '</button></div>';
            }
        });
    }

    function bindBlockEditButtons() {
        document.addEventListener('click', function (event) {
            const button = event.target.closest('.wallregi-block-cart-item-edit-button');
            if (!button) {
                return;
            }

            window.wallregiCurrentBlockCartItemKey = button.getAttribute('data-cart_item_key') || '';

            if (window.jQuery) {
                const $button = window.jQuery(button);
                try {
                    $button.data('giftcard', JSON.parse(button.getAttribute('data-giftcard') || '{}'));
                    $button.data('custom_prices', JSON.parse(button.getAttribute('data-custom_prices') || '[]'));
                    $button.data('gallery', JSON.parse(button.getAttribute('data-gallery') || '[]'));
                    $button.data('manual_price', button.getAttribute('data-manual_price') === 'true');
                } catch (error) {
                    return;
                }
            }

            if (typeof window.wallregiHandleGiftcardEditButtonClick === 'function') {
                window.wallregiHandleGiftcardEditButtonClick(button, event);
            }
        });
    }

    function bindBlockModalSubmit() {
        if (!window.jQuery) {
            return;
        }

        const $ = window.jQuery;

        $(document).on('submit.wallregiBlocks', '#wallregi_edit_modal_form', function (event) {
            if (!window.wallregiCurrentBlockCartItemKey) {
                return;
            }

            event.preventDefault();
            event.stopImmediatePropagation();

            const form = $(this);
            const submitBtn = form.find('.submit_btn');
            const manualPrice = $('.wallregi_cprice_input_field').val();
            const displayPrice = $('#edit_giftcard_price').text().trim();
            const priceValue = normalizePriceValue(manualPrice || displayPrice);
            const cartItemthumbUrl = $('#edit_giftcard_gallery .wallregi_item.wallregi_active img').attr('src')
                || $('#edit_giftcard_image_preview').attr('src')
                || '';

            submitBtn.prop('disabled', true).text(labels.updating || 'Updating...');

            if (typeof window.wallregiValidateEditModalDeliveryFields === 'function' && !window.wallregiValidateEditModalDeliveryFields()) {
                submitBtn.prop('disabled', false).text('Update');
                return;
            }

            const $modal = typeof window.wallregiResolveEditModal === 'function'
                ? window.wallregiResolveEditModal()
                : $('#wallregi_giftcard_edit_modal').last();

            if (typeof window.wallregiEnforceEditModalMessageLimit === 'function') {
                window.wallregiEnforceEditModalMessageLimit($modal.find('#edit_receiver_message, [name="receiver_message"]').first());
            }

            const deliveryPayload = typeof window.wallregiCollectEditModalDeliveryPayload === 'function'
                ? window.wallregiCollectEditModalDeliveryPayload($modal)
                : {};

            extensionCartUpdate({
                namespace: namespace,
                data: {
                    action: 'update_cart_giftcard',
                    cartItemKey: window.wallregiCurrentBlockCartItemKey,
                    receiver_name: $modal.find('[name="receiver_name"], #edit_receiver_name').first().val(),
                    receiver_email: $modal.find('[name="receiver_email"], #edit_receiver_email').first().val(),
                    receiver_message: $modal.find('[name="receiver_message"], #edit_receiver_message').first().val(),
                    sender_name: $modal.find('[name="sender_name"], #edit_sender_name').first().val(),
                    email_schedule: $modal.find('[name="email_schedule"], #edit_email_schedule').first().val(),
                    thumb_image_url: cartItemthumbUrl,
                    giftcard_price: priceValue,
                    delivery_channel: deliveryPayload.delivery_channel || '',
                    receiver_phone: deliveryPayload.receiver_phone || '',
                }
            }).then(function () {
                window.wallregiCurrentBlockCartItemKey = '';
                $modal.fadeOut();
            }).catch(function (error) {
                alert(getErrorMessage(error));
            }).finally(function () {
                submitBtn.prop('disabled', false).text('Update');
            });
        });
    }

    registerGiftcardDiscountSlot();
    registerCartItemEditFilter();
    bindBlockEditButtons();
    bindBlockModalSubmit();
})();
