<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Automattic\WooCommerce\StoreApi\Schemas\V1\CartItemSchema;
use Automattic\WooCommerce\StoreApi\Schemas\V1\CartSchema;

if ( ! class_exists( 'WALLREGI_Blocks_Integration' ) ) {

    class WALLREGI_Blocks_Integration {
        private const NAMESPACE = 'wallet-ready-gift-cards-for-woocommerce';

        public function __construct() {
            add_action( 'woocommerce_blocks_loaded', [ $this, 'wallregi_register_store_api_data' ] );
            add_action( 'wp_enqueue_scripts', [ $this, 'wallregi_enqueue_blocks_assets' ] );
            add_filter( 'wallregi_blocks_settings', [ $this, 'wallregi_add_pending_query_apply_to_blocks_settings' ], 8, 1 );
        }

        public function wallregi_register_store_api_data() {
            if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) || ! function_exists( 'woocommerce_store_api_register_update_callback' ) ) {
                return;
            }

            woocommerce_store_api_register_endpoint_data(
                [
                    'endpoint'        => CartSchema::IDENTIFIER,
                    'namespace'       => self::NAMESPACE,
                    'data_callback'   => [ $this, 'wallregi_cart_data_callback' ],
                    'schema_callback' => [ $this, 'wallregi_cart_schema_callback' ],
                    'schema_type'     => ARRAY_A,
                ]
            );

            woocommerce_store_api_register_endpoint_data(
                [
                    'endpoint'        => CartItemSchema::IDENTIFIER,
                    'namespace'       => self::NAMESPACE,
                    'data_callback'   => [ $this, 'wallregi_cart_item_data_callback' ],
                    'schema_callback' => [ $this, 'wallregi_cart_item_schema_callback' ],
                    'schema_type'     => ARRAY_A,
                ]
            );

            woocommerce_store_api_register_update_callback(
                [
                    'namespace' => self::NAMESPACE,
                    'callback'  => [ $this, 'wallregi_cart_update_callback' ],
                ]
            );
        }

        public function wallregi_enqueue_blocks_assets() {
            if ( ! is_cart() && ! is_checkout() ) {
                return;
            }
            if ( function_exists( 'wallregi_is_wc_cart_checkout_block_template' ) && ! wallregi_is_wc_cart_checkout_block_template() ) {
                return;
            }

            wp_enqueue_style(
                'wallregi_blocks_integration',
                WALLREGI_PLUGIN_URL . 'frontend/assets/css/blocks-integration.css',
                [],
                WALLREGI_VERSION,
                'all'
            );

            wp_enqueue_script(
                'wallregi_blocks_integration',
                WALLREGI_PLUGIN_URL . 'frontend/assets/js/blocks/blocks-integration.js',
                [ 'jquery', 'wp-element', 'wp-i18n', 'wp-plugins', 'wp-data', 'wc-blocks-checkout' ],
                WALLREGI_VERSION,
                true
            );

            wp_add_inline_script(
                'wallregi_blocks_integration',
                'window.wallregiBlocksSettings = ' . wp_json_encode(
                    apply_filters(
                        'wallregi_blocks_settings',
                        [
                        'namespace'      => self::NAMESPACE,
                        'currencySymbol' => get_woocommerce_currency_symbol(),
                        'isCartEditEnabled' => $this->wallregi_is_cart_edit_enabled(),
                        'isCheckoutEditEnabled' => $this->wallregi_is_checkout_edit_enabled(),
                        'labels'         => [
                            'toggle'        => __( 'Have a gift card code? Use it here', 'wallet-ready-gift-cards-for-woocommerce' ),
                            'placeholder'   => __( 'Enter your gift card code', 'wallet-ready-gift-cards-for-woocommerce' ),
                            'apply'         => __( 'Apply', 'wallet-ready-gift-cards-for-woocommerce' ),
                            'applied'       => __( 'Applied gift cards', 'wallet-ready-gift-cards-for-woocommerce' ),
                            'emptyCode'     => __( 'Please enter a gift card code.', 'wallet-ready-gift-cards-for-woocommerce' ),
                            'genericError'  => __( 'Something went wrong. Please try again.', 'wallet-ready-gift-cards-for-woocommerce' ),
                            'applying'      => __( 'Applying...', 'wallet-ready-gift-cards-for-woocommerce' ),
                            'updating'      => __( 'Updating...', 'wallet-ready-gift-cards-for-woocommerce' ),
                            'edit'          => __( 'Edit', 'wallet-ready-gift-cards-for-woocommerce' ),
                        ],
                        ]
                    )
                ) . ';',
                'before'
            );
        }

        /**
         * Block cart/checkout: expose deferred ?wallregi_apply_giftcard= code + nonce for dismiss (classic cart uses wallregi_ajax_object).
         *
         * @param array<string, mixed> $settings Block settings.
         * @return array<string, mixed>
         */
        public function wallregi_add_pending_query_apply_to_blocks_settings( $settings ) {
            if ( ! is_array( $settings ) ) {
                $settings = [];
            }
            if ( ! function_exists( 'is_cart' ) || ! function_exists( 'is_checkout' ) ) {
                return $settings;
            }
            if ( ! is_cart() && ! is_checkout() ) {
                return $settings;
            }
            if ( ! function_exists( 'WC' ) || ! WC()->session ) {
                return $settings;
            }
            $settings['applyCouponAjaxNonce'] = wp_create_nonce( 'wallregi_apply_coupon_nonce' );
            $settings['wcAdminAjaxUrl']       = admin_url( 'admin-ajax.php' );
            $pending                          = WC()->session->get( 'wallregi_pending_giftcard_apply_from_query', '' );
            if ( is_string( $pending ) && '' !== trim( $pending ) ) {
                $settings['pendingGiftcardApplyFromQuery'] = $pending;
            }
            return $settings;
        }

        public function wallregi_cart_data_callback() {
            $data = [
                'appliedGiftcards' => $this->wallregi_get_applied_giftcards_for_blocks(),
            ];

            return apply_filters( 'wallregi_blocks_cart_namespace_data', $data );
        }

        public function wallregi_cart_schema_callback() {
            return [
                'appliedGiftcards' => [
                    'description' => __( 'Applied wallet gift cards.', 'wallet-ready-gift-cards-for-woocommerce' ),
                    'type'        => 'array',
                    'readonly'    => true,
                    'items'       => [
                        'type'       => 'object',
                        'properties' => [
                            'code'              => [ 'type' => 'string' ],
                            'amount'            => [ 'type' => 'number' ],
                            'formattedAmount'   => [ 'type' => 'string' ],
                        ],
                    ],
                ],
            ];
        }

        public function wallregi_cart_item_data_callback( $cart_item ) {
            if ( empty( $cart_item['giftcard_data'] ) || ! is_array( $cart_item['giftcard_data'] ) ) {
                return [
                    'isGiftCard' => false,
                ];
            }

            $product_id = absint( $cart_item['product_id'] ?? 0 );
            $giftcard   = $cart_item['giftcard_data'];

            /**
             * Augment gift card data for block cart edit (same shape as classic `data-giftcard`).
             *
             * @param array $giftcard   Cart line gift card field values.
             * @param array $cart_item  Full WooCommerce cart line.
             */
            $giftcard = apply_filters( 'wallregi_giftcard_cart_edit_payload', $giftcard, $cart_item );

            $price_data = function_exists( 'wallregi_get_giftcard_display_price' )
                ? wallregi_get_giftcard_display_price( $product_id, $giftcard )
                : [ 'price_formatted' => '', 'price_options' => [], 'manual_price' => false ];

            $gallery_urls = $this->wallregi_get_product_gallery_urls( $product_id );
            $gallery_urls = apply_filters( 'wallregi_giftcard_gallery_urls', $gallery_urls, $cart_item, $giftcard );

            return [
                'isGiftCard'      => true,
                'giftcardData'    => $giftcard,
                'displayPrice'    => $price_data['price_formatted'] ?? '',
                'customPrices'    => $price_data['price_options'] ?? [],
                'manualPrice'     => ! empty( $price_data['manual_price'] ),
                'gallery'         => $gallery_urls,
            ];
        }

        public function wallregi_cart_item_schema_callback() {
            return [
                'isGiftCard'   => [
                    'description' => __( 'Whether this cart item is a wallet gift card.', 'wallet-ready-gift-cards-for-woocommerce' ),
                    'type'        => 'boolean',
                    'context'     => [ 'view', 'edit' ],
                    'readonly'    => true,
                ],
                'giftcardData' => [
                    'description'          => __( 'Wallet gift card cart item data (receiver, message, schedule, etc.). Shaped for classic cart edit and Blocks; optional keys may be added via filters.', 'wallet-ready-gift-cards-for-woocommerce' ),
                    'type'                 => [ 'object', 'null' ],
                    'context'              => [ 'view', 'edit' ],
                    'readonly'             => true,
                    'additionalProperties' => true,
                    'properties'           => [
                        'greeting_presets' => $this->wallregi_store_api_greeting_presets_schema(),
                    ],
                ],
                'displayPrice' => [
                    'type'     => 'string',
                    'context'  => [ 'view', 'edit' ],
                    'readonly' => true,
                ],
                'customPrices' => [
                    'type'     => 'array',
                    'context'  => [ 'view', 'edit' ],
                    'readonly' => true,
                ],
                'manualPrice'  => [
                    'type'     => 'boolean',
                    'context'  => [ 'view', 'edit' ],
                    'readonly' => true,
                ],
                'gallery'      => [
                    'type'     => 'array',
                    'context'  => [ 'view', 'edit' ],
                    'readonly' => true,
                ],
            ];
        }

        /**
         * JSON Schema fragment for Pro preset greetings on `extensions[namespace].giftcardData.greeting_presets`.
         *
         * @return array<string, mixed>
         */
        private function wallregi_store_api_greeting_presets_schema() {
            return [
                'description' => __( 'Optional preset greeting payload for the cart edit UI. Present when global or per-product presets apply to this line (Pro add-on); omitted when disabled.', 'wallet-ready-gift-cards-for-woocommerce' ),
                'type'        => [ 'object', 'null' ],
                'context'     => [ 'view', 'edit' ],
                'readonly'    => true,
                'properties'  => [
                    'enabled' => [
                        'description' => __( 'Whether quick-pick chips are available for this line.', 'wallet-ready-gift-cards-for-woocommerce' ),
                        'type'        => 'boolean',
                        'context'     => [ 'view', 'edit' ],
                        'readonly'    => true,
                    ],
                    'items'   => [
                        'description' => __( 'Preset rows: `title` is the chip label; `message` is inserted into the greeting field.', 'wallet-ready-gift-cards-for-woocommerce' ),
                        'type'        => 'array',
                        'context'     => [ 'view', 'edit' ],
                        'readonly'    => true,
                        'items'       => [
                            'type'       => 'object',
                            'context'    => [ 'view', 'edit' ],
                            'readonly'   => true,
                            'properties' => [
                                'title'   => [
                                    'description' => __( 'Short chip label.', 'wallet-ready-gift-cards-for-woocommerce' ),
                                    'type'        => 'string',
                                    'context'     => [ 'view', 'edit' ],
                                    'readonly'    => true,
                                ],
                                'message' => [
                                    'description' => __( 'Full greeting text applied when the chip is chosen.', 'wallet-ready-gift-cards-for-woocommerce' ),
                                    'type'        => 'string',
                                    'context'     => [ 'view', 'edit' ],
                                    'readonly'    => true,
                                ],
                            ],
                        ],
                    ],
                    'label'            => [
                        'description' => __( 'Heading shown above the chips.', 'wallet-ready-gift-cards-for-woocommerce' ),
                        'type'        => 'string',
                        'context'     => [ 'view', 'edit' ],
                        'readonly'    => true,
                    ],
                    'writeYourOwnChip' => [
                        'description' => __( 'Label for the “write your own” chip.', 'wallet-ready-gift-cards-for-woocommerce' ),
                        'type'        => 'string',
                        'context'     => [ 'view', 'edit' ],
                        'readonly'    => true,
                    ],
                    'writeYourOwn'     => [
                        'description' => __( 'Helper text for custom messages.', 'wallet-ready-gift-cards-for-woocommerce' ),
                        'type'        => 'string',
                        'context'     => [ 'view', 'edit' ],
                        'readonly'    => true,
                    ],
                    'maxMessageChars'  => [
                        'description' => __( 'Maximum greeting length used when applying a preset (mirrors checkout textarea limit).', 'wallet-ready-gift-cards-for-woocommerce' ),
                        'type'        => 'integer',
                        'context'     => [ 'view', 'edit' ],
                        'readonly'    => true,
                    ],
                ],
            ];
        }

        public function wallregi_cart_update_callback( $data ) {
            $action = isset( $data['action'] ) ? sanitize_key( $data['action'] ) : '';

            try {
                switch ( $action ) {
                    case 'apply_giftcard':
                        $this->wallregi_apply_giftcard_for_blocks( $data );
                        break;
                    case 'remove_giftcard':
                        $this->wallregi_remove_giftcard_for_blocks( $data );
                        break;
                    case 'update_cart_giftcard':
                        $this->wallregi_update_cart_giftcard_for_blocks( $data );
                        break;
                    default:
                        $this->wallregi_throw_store_api_error( 'invalid_action', __( 'Invalid cart update action.', 'wallet-ready-gift-cards-for-woocommerce' ) );
                }
            } catch ( \Automattic\WooCommerce\StoreApi\Exceptions\RouteException $exception ) {
                throw $exception;
            } catch ( \Throwable $throwable ) {
                $this->wallregi_throw_store_api_error(
                    'update_failed',
                    ! empty( $throwable->getMessage() ) ? $throwable->getMessage() : __( 'Could not update gift card.', 'wallet-ready-gift-cards-for-woocommerce' )
                );
            }

            return [
                'success' => true,
            ];
        }

        private function wallregi_apply_giftcard_for_blocks( $data ) {
            $coupon_code = isset( $data['couponCode'] ) ? sanitize_text_field( wp_unslash( $data['couponCode'] ) ) : '';
            if ( '' === $coupon_code ) {
                $this->wallregi_throw_store_api_error( 'empty_giftcard_code', __( 'Please enter a gift card code.', 'wallet-ready-gift-cards-for-woocommerce' ) );
            }

            $applied_giftcards = WC()->session ? WC()->session->get( 'applied_giftcards', [] ) : [];
            if ( wallregi_is_giftcard_applied_in_session( $coupon_code ) ) {
                $this->wallregi_throw_store_api_error( 'giftcard_already_applied', __( 'Gift card already applied.', 'wallet-ready-gift-cards-for-woocommerce' ) );
            }

            $session_limits = apply_filters( 'wallregi_validate_giftcard_session_limits_before_apply', true, $coupon_code, null );
            if ( is_wp_error( $session_limits ) ) {
                $code = $session_limits->get_error_code();
                $this->wallregi_throw_store_api_error(
                    $code ? sanitize_key( (string) $code ) : 'giftcard_session_limit',
                    $session_limits->get_error_message()
                );
            }

            $giftcard = $this->wallregi_database_query_data( $coupon_code );
            $this->wallregi_validate_giftcard_for_redemption( $giftcard );
            $canonical_code = wallregi_get_canonical_giftcard_number( $coupon_code, $giftcard );

            $buyer_ui = (bool) apply_filters( 'wallregi_is_buyer_giftcard_redeem_amount_ui_enabled', false );
            $redeem_raw = isset( $data['redeemAmount'] ) ? wp_unslash( (string) $data['redeemAmount'] ) : '';
            $redeem_amount = null;
            if ( '' !== trim( $redeem_raw ) && function_exists( 'wc_format_decimal' ) && function_exists( 'wc_get_price_decimals' ) ) {
                $parsed = wc_format_decimal( $redeem_raw, wc_get_price_decimals() );
                if ( is_numeric( $parsed ) ) {
                    $redeem_amount = max( 0, (int) round( (float) $parsed ) );
                }
            }

            if ( $buyer_ui && ( null === $redeem_amount || '' === trim( $redeem_raw ) ) ) {
                $this->wallregi_throw_store_api_error(
                    'redeem_amount_required',
                    __( 'Please choose how much to redeem from this gift card.', 'wallet-ready-gift-cards-for-woocommerce-pro' )
                );
            }

            if ( $buyer_ui ) {
                if ( null === $redeem_amount || $redeem_amount <= 0 ) {
                    $this->wallregi_throw_store_api_error(
                        'invalid_redeem_amount',
                        __( 'Please enter a valid amount to redeem.', 'wallet-ready-gift-cards-for-woocommerce-pro' )
                    );
                }
                $amount_check = apply_filters( 'wallregi_validate_buyer_redeem_amount_for_apply', true, $canonical_code, $redeem_amount, $giftcard );
                if ( is_wp_error( $amount_check ) ) {
                    $ec = $amount_check->get_error_code();
                    $this->wallregi_throw_store_api_error(
                        $ec ? sanitize_key( (string) $ec ) : 'invalid_redeem_amount',
                        $amount_check->get_error_message()
                    );
                }
            }

            $applied_giftcards[] = $canonical_code;
            WC()->session->set( 'applied_giftcards', $applied_giftcards );

            if ( $buyer_ui && $redeem_amount !== null && $redeem_amount > 0 && function_exists( 'wallregi_session_set_applied_giftcard_buyer_amount' ) ) {
                wallregi_session_set_applied_giftcard_buyer_amount( $canonical_code, $redeem_amount );
            }

            if ( WC()->cart ) {
                WC()->cart->set_session();
            }

            WC()->cart->calculate_totals();

            $amount_totals = apply_filters( 'wallregi_validate_applied_giftcard_amount_totals_after_apply', true, $canonical_code );
            if ( is_wp_error( $amount_totals ) ) {
                if ( function_exists( 'wallregi_revert_applied_giftcard_from_session' ) ) {
                    wallregi_revert_applied_giftcard_from_session( $canonical_code );
                }
                $err_code = $amount_totals->get_error_code();
                $this->wallregi_throw_store_api_error(
                    $err_code ? sanitize_key( (string) $err_code ) : 'giftcard_redemption_amount',
                    $amount_totals->get_error_message()
                );
            }

            if ( function_exists( 'wallregi_clear_gtw_checkout_error_notices' ) ) {
                wallregi_clear_gtw_checkout_error_notices();
            }
        }

        private function wallregi_remove_giftcard_for_blocks( $data ) {
            $coupon_code = isset( $data['couponCode'] ) ? trim( sanitize_text_field( wp_unslash( $data['couponCode'] ) ) ) : '';
            $applied_giftcards = WC()->session ? WC()->session->get( 'applied_giftcards', [] ) : [];
            $applied_amounts   = WC()->session ? WC()->session->get( 'applied_giftcard_amounts', [] ) : [];

            if ( ! is_array( $applied_giftcards ) ) {
                $applied_giftcards = [];
            }
            if ( ! is_array( $applied_amounts ) ) {
                $applied_amounts = [];
            }

            $giftcard_key = wallregi_find_applied_giftcard_session_index( $coupon_code, $applied_giftcards );
            if ( false !== $giftcard_key ) {
                $stored_coupon_code = $applied_giftcards[ $giftcard_key ];
                do_action( 'wallregi_before_giftcard_remove_from_cart', $stored_coupon_code );
                unset( $applied_giftcards[ $giftcard_key ] );
                $removed_norm = wallregi_normalize_giftcard_number( $stored_coupon_code );
                foreach ( array_keys( $applied_amounts ) as $amount_key ) {
                    if ( wallregi_normalize_giftcard_number( $amount_key ) === $removed_norm ) {
                        unset( $applied_amounts[ $amount_key ] );
                    }
                }

                $buyer = WC()->session ? WC()->session->get( 'applied_giftcard_buyer_amounts', [] ) : [];
                if ( is_array( $buyer ) ) {
                    foreach ( array_keys( $buyer ) as $buyer_key ) {
                        if ( wallregi_normalize_giftcard_number( $buyer_key ) === $removed_norm ) {
                            unset( $buyer[ $buyer_key ] );
                        }
                    }
                    WC()->session->set( 'applied_giftcard_buyer_amounts', $buyer );
                }

                WC()->session->set( 'applied_giftcards', array_values( $applied_giftcards ) );
                WC()->session->set( 'applied_giftcard_amounts', $applied_amounts );
                WC()->cart->calculate_totals();
            }

            if ( function_exists( 'wallregi_clear_gtw_checkout_error_notices' ) ) {
                wallregi_clear_gtw_checkout_error_notices();
            }
        }

        private function wallregi_update_cart_giftcard_for_blocks( $data ) {
            if ( function_exists( 'is_checkout' ) && is_checkout() && function_exists( 'wallregi_checkout_giftcard_edit_is_enabled' ) && ! wallregi_checkout_giftcard_edit_is_enabled() ) {
                $this->wallregi_throw_store_api_error(
                    'checkout_edit_disabled',
                    __( 'Editing gift cards at checkout is not available.', 'wallet-ready-gift-cards-for-woocommerce' )
                );
            }

            $cart_item_key = isset( $data['cartItemKey'] ) ? sanitize_text_field( wp_unslash( $data['cartItemKey'] ) ) : '';
            if ( '' === $cart_item_key ) {
                $this->wallregi_throw_store_api_error( 'missing_cart_item_key', __( 'Cart item key missing.', 'wallet-ready-gift-cards-for-woocommerce' ) );
            }

            $cart = WC()->cart->get_cart();
            if ( empty( $cart[ $cart_item_key ]['giftcard_data'] ) || ! is_array( $cart[ $cart_item_key ]['giftcard_data'] ) ) {
                $this->wallregi_throw_store_api_error( 'giftcard_item_not_found', __( 'Item not found.', 'wallet-ready-gift-cards-for-woocommerce' ) );
            }

            $giftcard_data = $cart[ $cart_item_key ]['giftcard_data'];
            $fields        = [
                'giftcard_price',
                'receiver_name',
                'receiver_email',
                'receiver_message',
                'sender_name',
                'email_schedule',
            ];
            $fields = apply_filters( 'wallregi_editable_giftcard_fields', $fields, $cart_item_key, $giftcard_data, 'store_api' );

            foreach ( $fields as $field ) {
                if ( ! isset( $data[ $field ] ) || is_array( $data[ $field ] ) ) {
                    continue;
                }

                $raw_value = wp_unslash( $data[ $field ] );
                switch ( $field ) {
                    case 'receiver_email':
                        $giftcard_data[ $field ] = sanitize_email( $raw_value );
                        break;
                    case 'delivery_channel':
                        $giftcard_data[ $field ] = function_exists( 'wallregi_sanitize_delivery_channel' )
                            ? wallregi_sanitize_delivery_channel( $raw_value )
                            : sanitize_key( $raw_value );
                        break;
                    case 'receiver_phone':
                        $giftcard_data[ $field ] = function_exists( 'wallregi_sanitize_giftcard_phone' )
                            ? wallregi_sanitize_giftcard_phone( $raw_value )
                            : sanitize_text_field( $raw_value );
                        break;
                    case 'receiver_message':
                        $wallregi_global_settings = get_option( 'wallregi_settings', [] );
                        $max_mgs_length           = isset( $wallregi_global_settings['max_mgs_length'] ) ? intval( $wallregi_global_settings['max_mgs_length'] ) : 250;
                        $sanitized_msg            = sanitize_textarea_field( $raw_value );
                        if ( $max_mgs_length > 0 && mb_strlen( $sanitized_msg ) > $max_mgs_length ) {
                            $sanitized_msg = mb_substr( $sanitized_msg, 0, $max_mgs_length );
                        }
                        $giftcard_data[ $field ] = $sanitized_msg;
                        break;
                    case 'giftcard_price':
                        $giftcard_data[ $field ] = max( 0, intval( sanitize_text_field( $raw_value ) ) );
                        break;
                    default:
                        $giftcard_data[ $field ] = sanitize_text_field( $raw_value );
                        break;
                }
            }

            if ( ! empty( $data['thumb_image_url'] ) && ! is_array( $data['thumb_image_url'] ) ) {
                $giftcard_data['giftcard_image'] = esc_url_raw( wp_unslash( $data['thumb_image_url'] ) );
            }

            if ( function_exists( 'wallregi_validate_giftcard_cart_edit_delivery' ) ) {
                $delivery_validated = wallregi_validate_giftcard_cart_edit_delivery( $giftcard_data );
                if ( is_wp_error( $delivery_validated ) ) {
                    $this->wallregi_throw_store_api_error( 'invalid_delivery_fields', $delivery_validated->get_error_message() );
                }
                $giftcard_data = $delivery_validated;
            }

            $cart[ $cart_item_key ]['giftcard_data'] = $giftcard_data;
            WC()->cart->cart_contents[ $cart_item_key ] = $cart[ $cart_item_key ];
            if ( function_exists( 'wallregi_apply_giftcard_prices_to_cart' ) ) {
                wallregi_apply_giftcard_prices_to_cart( WC()->cart );
            }
            WC()->cart->set_session();
            WC()->cart->calculate_totals();
            do_action( 'wallregi_after_giftcard_cart_item_updated', $cart_item_key, $giftcard_data, 'store_api' );
        }

        private function wallregi_get_applied_giftcards_for_blocks() {
            if ( ! WC()->session ) {
                return [];
            }

            $applied_giftcards = WC()->session->get( 'applied_giftcards', [] );
            $applied_amounts   = WC()->session->get( 'applied_giftcard_amounts', [] );
            $giftcards         = [];

            foreach ( $applied_giftcards as $coupon_code ) {
                $amount           = isset( $applied_amounts[ $coupon_code ] ) ? (float) $applied_amounts[ $coupon_code ] : 0.0;
                $formatted_amount = html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, get_bloginfo( 'charset' ) );
                $row              = [
                    'code'            => (string) $coupon_code,
                    'amount'          => $amount,
                    'formattedAmount' => $formatted_amount,
                ];

                $giftcards[] = $row;
            }

            return $giftcards;
        }

        /**
         * True when the checkout page uses the WooCommerce Checkout block (not the classic shortcode checkout).
         *
         * @return bool
         */
        private function wallregi_is_checkout_page_using_blocks() {
            if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
                return false;
            }

            if ( class_exists( '\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils' ) && method_exists( '\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils', 'is_checkout_block_default' ) ) {
                if ( \Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils::is_checkout_block_default() ) {
                    return true;
                }
            }

            $post_id  = (int) get_queried_object_id();
            $content  = $post_id > 0 ? (string) get_post_field( 'post_content', $post_id ) : '';
            if ( '' !== $content ) {
                if ( function_exists( 'has_block' ) && has_block( 'woocommerce/checkout', $content ) ) {
                    return true;
                }
                if ( false !== strpos( $content, 'wp:woocommerce/checkout' ) ) {
                    return true;
                }
            }

            // FSE / template-only checkout: page post may be empty while CartCheckoutUtils still reports block checkout.
            if ( function_exists( 'wallregi_is_wc_cart_checkout_block_template' ) && wallregi_is_wc_cart_checkout_block_template() ) {
                return true;
            }

            return false;
        }

        private function wallregi_database_query_data( $coupon_code ) {
            return wallregi_get_giftcard_by_number( $coupon_code );
        }

        private function wallregi_validate_giftcard_for_redemption( $giftcard ) {
            if ( ! $giftcard ) {
                $this->wallregi_throw_store_api_error( 'giftcard_not_found', __( 'Gift card not found. Please check the code and try again.', 'wallet-ready-gift-cards-for-woocommerce' ) );
            }

            if ( $giftcard->current_amount <= 0 ) {
                $this->wallregi_throw_store_api_error( 'giftcard_empty_balance', __( 'This gift card has no remaining balance.', 'wallet-ready-gift-cards-for-woocommerce' ) );
            }

            if ( ! empty( $giftcard->expiry_date ) && strtotime( $giftcard->expiry_date ) < current_time( 'timestamp' ) ) {
                $this->wallregi_throw_store_api_error( 'giftcard_expired', __( 'This gift card has expired.', 'wallet-ready-gift-cards-for-woocommerce' ) );
            }

            switch ( $giftcard->status ) {
                case 'cancelled':
                    $this->wallregi_throw_store_api_error( 'giftcard_cancelled', __( 'This gift card has been cancelled.', 'wallet-ready-gift-cards-for-woocommerce' ) );
                    break;
                case 'expired':
                    $this->wallregi_throw_store_api_error( 'giftcard_expired', __( 'This gift card has expired.', 'wallet-ready-gift-cards-for-woocommerce' ) );
                    break;
                case 'used':
                    $this->wallregi_throw_store_api_error( 'giftcard_used', __( 'This gift card has already been used.', 'wallet-ready-gift-cards-for-woocommerce' ) );
                    break;
            }
        }

        private function wallregi_get_product_gallery_urls( $product_id ) {
            $product = wc_get_product( $product_id );
            if ( ! $product ) {
                return [];
            }

            $ids = $product->get_gallery_image_ids();
            if ( $thumb = get_post_thumbnail_id( $product_id ) ) {
                array_unshift( $ids, $thumb );
            }

            $urls = [];
            foreach ( $ids as $id ) {
                $url = wp_get_attachment_url( $id );
                if ( $url ) {
                    $urls[] = $url;
                }
            }

            return $urls;
        }

        private function wallregi_is_cart_edit_enabled() {
            $settings = wp_parse_args(
                get_option( 'wallregi_settings', [] ),
                [
                    'giftcard_edit_in_cart' => 'no',
                ]
            );

            $enabled = is_cart() && 'yes' === $settings['giftcard_edit_in_cart'];

            return (bool) apply_filters( 'wallregi_is_cart_edit_enabled', $enabled, $settings );
        }

        private function wallregi_is_checkout_edit_enabled() {
            $settings = wp_parse_args(
                get_option( 'wallregi_settings', [] ),
                [
                    'giftcard_edit_in_checkout' => 'no',
                ]
            );

            return wallregi_checkout_giftcard_edit_is_enabled( $settings );
        }

        private function wallregi_throw_store_api_error( $code, $message ) {
            if ( class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) {
                throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'wallregi_' . $code, $message, 400 );
            }

            throw new Exception( $message );
        }
    }

    new WALLREGI_Blocks_Integration();
}
