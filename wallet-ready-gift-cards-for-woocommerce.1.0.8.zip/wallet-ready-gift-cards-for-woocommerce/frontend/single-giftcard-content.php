<?php
// Ensure this file is not accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}



global $post, $product;

// Load saved settings
$wallregi_settings = get_option('wallregi_settings', []);

// Set default values to avoid undefined index warnings
$wallregi_defaults = [
    'pdf_footer_text'               => 'yes',
    'giftcard_summary_text'         => 'yes',
    'character_counts'              => 'yes',
    'heading_color'                 => '#565757',
    'para_color'                    => '#9d9d9d',
    'border_color'                  => '#7f54b3',
    'pseudo_color'                  => '#bb98e7',
    'coupon_pattren'                => '****-****-****-****',
    'giftcard_code_length'          => 16,
    'giftcrd_layout'                => 'row',
    'background_style'              => 'solid',
    'solid_color'                   => '#f8fafb',
    'gradient_start'                => '#e7eff2',
    'gradient_middle'               => '#d7ebe7',
    'gradient_end'                  => '#e7eff2',
    'bg_image_url'                  => WALLREGI_PLUGIN_URL . 'frontend/assets/bg-image.png',
    'price_label'                   => 'Choose an amount',
    'manual_price_placeholder'      => 'Enter an amount',
    'gallery_label'                 => 'Choose a picture',
    'form_title'                    => 'Recipient information',
    'name_label'                    => 'Receiver name',
    'email_label'                   => 'Receiver email',
    'greeting_label'                => 'Greeting/Message',
    'sender_label'                  => 'Sender name',
    'datepicker_label'              => 'Send at',
    'submit_btn_text'               => 'Add to cart',
    'max_mgs_length'                => 250,
    'max_giftcard_qty'              => 5,
    'min_cprice'                    => 1,
    'max_cprice'                    => 9990,
    // Gift card preview: logo
    'show_card_logo'                => 'no',
    'card_logo_position'            => 'center',
    'card_custom_logo'              => '',
    // Gift card preview: date
    'show_card_date'                => 'no',
    'card_date_position'            => 'left',
    'card_date_label'               => 'Date:',
];

// Merge saved settings with defaults
$wallregi_settings = wp_parse_args($wallregi_settings, $wallregi_defaults);

$wallregi_pdf_defaults_path = plugin_dir_path(__DIR__) . 'default-settings/default-pdf-settings.php';
if (file_exists($wallregi_pdf_defaults_path)) {
    $wallregi_pdf_file_defaults = include $wallregi_pdf_defaults_path;
    if (is_array($wallregi_pdf_file_defaults)) {
        $wallregi_settings = wp_parse_args($wallregi_settings, $wallregi_pdf_file_defaults);
    }
}

$wallregi_product = wc_get_product( $post->ID );

// Keep WooCommerce/global product in sync for theme hooks (e.g. Storefront sticky add-to-cart).
if ( $wallregi_product instanceof WC_Product ) {
    $product = $wallregi_product;
    $GLOBALS['product'] = $wallregi_product;
}

$wallregi_custom_prices = get_post_meta($post->ID, '_wallregi_custom_prices', true);
$wallregi_enable_variation_price = get_post_meta($post->ID, '_wallregi_enable_variation_price', true);
$wallregi_enable_manual_price = get_post_meta($post->ID, '_wallregi_enable_manual_price', true);
$wallregi_enable_email_schedule = get_post_meta($post->ID, '_wallregi_enable_email_schedule', true);

$wallregi_checkout_receiver_address = function_exists( 'wallregi_get_product_checkout_receiver_source' )
	? wallregi_get_product_checkout_receiver_source( (int) $post->ID )
	: '';

// Initialize product variables
$wallregi_product_id = $wallregi_product->get_id();
$wallregi_product_image = null;
$wallregi_product_gallery = [];
$wallregi_product_price = null;

// Check product type 
if ($wallregi_product->get_type() === 'wxgiftcard') {
    // Get the main product image ID
    $wallregi_product_image = wp_get_attachment_image_url($wallregi_product->get_image_id(), 'large');

    // Fetch gallery image IDs
    $wallregi_galleryImageIds = $wallregi_product->get_gallery_image_ids();
    if (!empty($wallregi_galleryImageIds)) {
        // Add the main image to the gallery images array
        if($wallregi_product->get_image_id()) array_unshift($wallregi_galleryImageIds, $wallregi_product->get_image_id());

        // Fetch URLs for large gallery images
        $wallregi_product_gallery = array_map(function($imageId) {
            $image = wp_get_attachment_image_url($imageId, 'large'); 
            return $image ?: ''; 
        }, $wallregi_galleryImageIds);
    } else {
        // If no gallery images, just set the main product image
        $wallregi_product_gallery[] = $wallregi_product_image;
    }

    // Determine the product price
    if ($wallregi_enable_variation_price === 'yes' && !empty($wallregi_custom_prices) && is_array($wallregi_custom_prices)) {
        // Use custom prices 
        $wallregi_product_price = $wallregi_custom_prices[0]; 
    } else {
        $wallregi_product_price = $wallregi_product->get_price();
    }

} else {
    wc_get_template('single-product.php'); // Fallback if not an wallregi_giftcard type

    return;
}

// Check if valid product and correct ID
if ( ! $wallregi_product || $wallregi_product->get_type() !== 'wxgiftcard' ) {
    wc_get_template( 'single-product.php' ); // Fallback to default template

    return;
} else {

    if (wp_is_block_theme()) {
        wp_head();
        get_header();
    }else{
        get_header( 'shop' );
    }
    // Before your content:
    // phpcs:ignore
    do_action('wallregi_woocommerce_before_main_content');
    ?>

<div id="product-<?php the_ID(); ?>" <?php wc_product_class( '', $wallregi_product ); ?>>
        <section class="wallregi_giftcard_section" id="wallregi_giftcard_products">
            <div class="wallregi_section_container">
                <form action="#" method="post" id="wallregi_giftcardForm" class="wallregi_single__giftcard_form">
                    <div id="wallregi_giftcard_accordion">
                        <h3 class="wallregi_accordion_title" id="giftcard_heading_"><?php the_title(); ?></h3>
                        <div class="wallregi_giftcard_contents" >
                            <div class="wallregi_single__giftcard_wrapper" id="giftcard_productId-<?php echo esc_attr($wallregi_product_id); ?>">
                                <div class="wallregi_giftcard__body">
                                    <article class="wallregi_giftcard__row" style="flex-direction: <?php echo esc_html( $wallregi_settings['giftcrd_layout'] ); ?>">
                                        <div class="wallregi_giftcard__column wallregi_left__contents">
                                             <article class="wallregi_giftcard__card">
                                                 <?php
                                                 // --- Gift Card Logo ---
                                                 $wallregi_show_logo  = ( $wallregi_settings['show_card_logo'] ?? 'no' ) === 'yes';
                                                 $wallregi_logo_url   = '';
                                                 if ( $wallregi_show_logo ) :
                                                     if ( ! empty( $wallregi_settings['card_custom_logo'] ) ) {
                                                         // Custom logo is set: visible to everyone
                                                         $wallregi_logo_url = esc_url( $wallregi_settings['card_custom_logo'] );
                                                     } elseif ( current_user_can( 'manage_options' ) || current_user_can( 'edit_pages' ) || current_user_can( 'administrator' ) || current_user_can( 'editor' ) ) {
                                                         // Default logo asset: visible ONLY to Administrator and Editor
                                                         $wallregi_logo_url = esc_url( WALLREGI_PLUGIN_URL . 'frontend/assets/default-logo.png' );
                                                     }
                                                     $wallregi_logo_align = esc_attr( $wallregi_settings['card_logo_position'] ?? 'center' );
                                                 endif;

                                                 // --- Gift Card Date ---
                                                 $wallregi_show_date  = ( $wallregi_settings['show_card_date'] ?? 'no' ) === 'yes';
                                                 $wallregi_date_align = esc_attr( $wallregi_settings['card_date_position'] ?? 'left' );
                                                 $wallregi_date_label = esc_html( $wallregi_settings['card_date_label'] ?? 'Date:' );
                                                 ?>
                                                 <?php if ( $wallregi_show_logo && $wallregi_logo_url ) : ?>
                                                 <div class="wallregi_card__logo" style="text-align:<?php echo $wallregi_logo_align; ?>;">
                                                     <?php // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                                     <img src="<?php echo $wallregi_logo_url; ?>" alt="<?php esc_attr_e( 'Logo', 'wallet-ready-gift-cards-for-woocommerce' ); ?>">
                                                 </div>
                                                 <?php endif; ?>
                                                 <figure class="wallregi_card__header image_box">
                                                     <!-- Display the first image as the default active image -->
                                                     <?php 
                                                     if ($wallregi_product_image) {
                                                             $wallregi_alt_text = esc_html__('Product Image', 'wallet-ready-gift-cards-for-woocommerce');
                                                             // phpcs:ignore
                                                             echo '<img src="' . esc_url($wallregi_product_image) . '" alt="' . esc_attr($wallregi_alt_text) . '" class="wallregi_image_thumb">';
                                                         }
                                                     ?>
                                                 </figure>
                                                 <div class="wallregi_card__body content_box">
                                                     <?php if ( $wallregi_show_date ) : ?>
                                                     <div class="wallregi_card__date" style="text-align:<?php echo $wallregi_date_align; ?>;">
                                                         <span class="wallregi_date_label"><?php echo $wallregi_date_label; ?></span>
                                                         <span class="wallregi_date_value"><?php echo esc_html( date_i18n( 'd-m-Y' ) ); ?></span>
                                                     </div>
                                                     <?php endif; ?>
                                                     <span class="wallregi_title"><?php the_title(); ?></span>
                                                     <div class="wallregi_card__price">
                                                         <span class="wallregi_price">
                                                             <?php echo wp_kses_post(wc_price($wallregi_product_price)); ?>
                                                         </span>
                                                     </div>
                                                     <?php
                                                     if (function_exists('wallregi_get_product_placeholder_scannable_html')) {
                                                         // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- data URI images built with esc_attr inside helper.
                                                         echo wallregi_get_product_placeholder_scannable_html($wallregi_settings);
                                                     }
                                                     ?>
                                                     <div class="wallregi_preview__mgs"></div>
                                                 </div>
                                                 <?php if ( ! empty( $wallregi_product->get_short_description() ) ) : ?>
                                             
                                                 <div class="wallregi_giftcard_footer" <?php echo ($wallregi_settings['pdf_footer_text'] === 'yes') ? 'style="display:block;"' : 'style="display:none;"'; ?>>
                                                     <?php 
                                                         echo wp_kses_post($wallregi_product->get_short_description()); 
                                                     ?>
                                                 </div>

                                                 <?php endif; ?>
                                             </article>
                                        </div>
                                        <div class="wallregi_giftcard__column wallregi_right__contents">
                                            <article class="wallregi_box_contents">
                                                <?php do_action( 'wallregi_before_giftcard_summary', (int) $wallregi_product_id ); ?>
                                                <div class="wallregi_giftcard_summary" <?php echo ($wallregi_settings['giftcard_summary_text'] === 'yes') ? 'style="display:block;"' : 'style="display:none;"'; ?>>
                                                    <div class="wallregi_desc">
                                                        <?php echo wp_kses_post($wallregi_product->get_description()); ?>
                                                    </div>
                                                </div>
                                                <?php do_action( 'wallregi_after_giftcard_summary', (int) $wallregi_product_id ); ?>
                                                <?php do_action( 'wallregi_before_custom_price_box', (int) $wallregi_product_id ); ?>
                                                <?php if ($wallregi_enable_variation_price === 'yes' && !empty($wallregi_custom_prices) && is_array($wallregi_custom_prices)) : ?>
                                                    <div class="wallregi_custom_price_box">
                                                        <h4 class="wallregi_heading"><?php echo esc_html( $wallregi_settings['price_label'] ); ?></h4>
                                                        <?php if (!empty($wallregi_custom_prices)) : ?>
                                                            <ul class="wallregi_custom_price_options">
                                                                <?php foreach ($wallregi_custom_prices as $wallregi_index => $wallregi_price) : ?>
                                                                    <li class="wallregi_item wallregi_item_<?php echo esc_attr($wallregi_index); ?> <?php echo $wallregi_index === 0 ? 'wallregi_selected' : ''; ?>" data-price="<?php echo esc_attr($wallregi_price); ?>" onclick="wallregiSelectGiftCardPrice(this)">
                                                                        <button type="button" class="button price_btn" data-price="<?php echo esc_attr($wallregi_price); ?>">
                                                                            <?php echo wp_kses_post(wc_price($wallregi_price)); ?>
                                                                        </button>    
                                                                    </li>
                                                                <?php endforeach; ?>
                                                            </ul>
                                                        <?php endif; ?>
                                                         
                                                        <?php if ($wallregi_enable_manual_price === 'yes') : ?>
                                                            <div class="wallregi_custom_price_wraper" style="display: <?php echo $wallregi_enable_manual_price ? 'block' : 'none'; ?>;">
                                                                
                                                                <input placeholder="<?php echo esc_attr('(' . get_woocommerce_currency_symbol() . ') ' . $wallregi_settings['manual_price_placeholder']); ?>" type="number" step="any" name="wallregi_manual_price[]" data-min="<?php echo esc_attr($wallregi_settings['min_cprice']); ?>" data-max="<?php echo esc_attr($wallregi_settings['max_cprice']); ?>" onclick="wallregiGiftCardManualPriceEnable(this)" onfocusout="wallregiGiftCardManualPriceFocusOut(this)" onkeyup="wallregiGiftCardManualPriceKeyUp(this)" class="wallregi_cprice_input_field">
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>


                                                <?php endif; ?>
                                                <?php do_action( 'wallregi_after_custom_price_box', (int) $wallregi_product_id ); ?>
                                                <?php do_action( 'wallregi_before_gallery_images_content_box', (int) $wallregi_product_id ); ?>
                                                <div class="wallregi_gallery_images_content_box">
                                                    <h4 class="wallregi_heading"><?php echo esc_html( $wallregi_settings['gallery_label'] ); ?></h4>

                                                    <?php if (!empty($wallregi_product_gallery)) : ?>
                                                        <ul class="wallregi_images__gallery">
                                                            <?php foreach ($wallregi_product_gallery as $wallregi_index => $wallregi_imageURL) : ?>
                                                                <li class="wallregi_item wallregi_item_<?php echo esc_attr($wallregi_index); ?> <?php echo $wallregi_index === 0 ? 'wallregi_active' : ''; ?>" onclick="wallregiGiftCardImagePreview(this);">
                                                                    <figure class="wallregi_image_item">
                                                                        <?php // phpcs:ignore ?>
                                                                        <img src="<?php echo esc_url($wallregi_imageURL); ?>" alt="Gallery Image">
                                                                    </figure>    
                                                                </li>
                                                            <?php endforeach; ?>
                                                        </ul>
                                                    <?php endif; ?>

                                                </div>
                                                <?php do_action( 'wallregi_after_gallery_images_content_box', (int) $wallregi_product_id ); ?>
                                                
                                            </article>
                                            <?php if ( '' === $wallregi_checkout_receiver_address ) : ?>
                                            <div class="wallregi_form_wrap">
                                                <h4 class="wallregi_heading">
                                                    <?php echo esc_html($wallregi_settings['form_title']) ?>
                                                </h4>
                                                <div class="wallregi_form_items">
                                                    <?php
                                                    //phpcs:ignore
                                                    do_action( 'wallregi_gift_card_allowed_form_item', (int) $wallregi_product_id ); ?>
                                                    <div class="wallregi_form__item">
                                                        <div class="wallregi_input_box">
                                                            <span class="wallregi_placeholder__text"><?php echo esc_html($wallregi_settings['name_label']); ?> <span>*</span></span>
                                                            <input 
                                                            type="text" 
                                                            name="receiver_name[]" 
                                                            class="wallregi_input__field"
                                                            required
                                                            onfocus="wallregiHandleInputFocus(this)"
                                                            onblur="wallregiHandleInputBlur(this)"
                                                            />
                                                    
                                                        </div>
                                                    </div>
                                                

                                                    <div class="wallregi_form__item">
                                                        <div class="wallregi_input_box">
                                                            <span class="wallregi_placeholder__text wallregi_receiver_email_label"><?php echo esc_html($wallregi_settings['email_label']); ?><span class="wallregi_email_required_mark">*</span></span>
                                                            <input 
                                                            type="email" 
                                                            name="receiver_email[]" 
                                                            class="wallregi_input__field wallregi_receiver_email_field"
                                                            required
                                                            onfocus="wallregiHandleInputFocus(this)"
                                                            onblur="wallregiHandleInputBlur(this)"
                                                            />
                                                        </div>
                                                    </div>
                                                    <?php
                                                    /**
                                                     * After recipient email field — SMS extension adds delivery method + phone.
                                                     *
                                                     * @param int $wallregi_product_id Gift card product ID.
                                                     */
                                                    do_action( 'wallregi_after_giftcard_receiver_email_field', (int) $wallregi_product_id );
                                                    ?>
                                                    <?php 
                                                    //phpcs:ignore
                                                        do_action( 'wallregi_gift_card_allowed_form_item_info', (int) $wallregi_product_id ); 
                                                        
                                                        $wallregi_max_length = isset($wallregi_settings['max_mgs_length']) ? intval($wallregi_settings['max_mgs_length']) : 250;
                                                    ?>
                                                    <?php
                                                    /**
                                                     * Output preset greeting UI (e.g. Pro) immediately above the message textarea.
                                                     *
                                                     * @param int $wallregi_product_id Gift card product ID.
                                                     */
                                                    do_action( 'wallregi_before_greeting_textarea', (int) $wallregi_product_id );
                                                    ?>
                                                    <div class="wallregi_form__item wallregi_textarea__item">
                                                        <div class="wallregi_text_box">
                                                            <span class="wallregi_placeholder__text"><?php echo esc_html($wallregi_settings['greeting_label']); ?></span>
                                                            <?php do_action( 'wallregi_textarea_shorttext_field', (int) $wallregi_product_id );  ?>
                                                            <textarea rows="3" class="wallregi_textarea__field" name="receiver_message[]" 
                                                            data-maxlength="<?php echo esc_attr($wallregi_max_length); ?>" 
                                                            onfocus="wallregiHandleInputFocus(this)"
                                                            onblur="wallregiHandleInputBlur(this)"
                                                            onkeyup="wallregiGiftCardMessagePreview(this)"></textarea>
                                                    
                                                            <div id="max_lenght" <?php echo ($wallregi_settings['character_counts'] === 'yes') ? 'style="display:block;"' : 'style="display:none;"'; ?>>
                                                                <div class="wallregi_charcter_count">
                                                                    <span><?php esc_html_e('Character count:', 'wallet-ready-gift-cards-for-woocommerce'); ?></span> 
                                                                    (<span class="charCount"><?php esc_html_e('0', 'wallet-ready-gift-cards-for-woocommerce'); ?></span>/<?php echo esc_html($wallregi_max_length); ?>)

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php do_action('wallregi_after_greeting_textarea', (int) $wallregi_product_id); ?>
                                                    <?php do_action( 'wallregi_before_sender_name_field', (int) $wallregi_product_id ); ?>
                                                    <div class="wallregi_item_wrap">
                                                    <div class="wallregi_form__item wallregi_sender_item">
                                                        <div class="wallregi_input_box">
                                                            <span class="wallregi_placeholder__text"><?php echo esc_html($wallregi_settings['sender_label']); ?><span>*</span></span>
                                                            <input 
                                                            type="text" 
                                                            name="sender_name[]" 
                                                            class="wallregi_input__field"
                                                            required
                                                            onfocus="wallregiHandleInputFocus(this)"
                                                            onblur="wallregiHandleInputBlur(this)"
                                                            />
                                                    
                                                        </div>
                                                    </div>
                                                    <?php if ($wallregi_enable_email_schedule === 'yes') : ?>
                                                    <div class="wallregi_form__item wallregi_email_shedule">
                                                        <div class="wallregi_input_box">
                                                            <span class="wallregi_placeholder__text"><?php echo esc_html($wallregi_settings['datepicker_label']);?></span>
                                                            <input type="text" name="sender_email_shedule[]" class="wallregi_datetime_picker wallregi_datetime__field" onfocus="wallregiHandleInputFocus(this)"/>
                                                        
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php do_action('wallregi_after_sender_name_field', (int) $wallregi_product_id); ?>
                                                    </div>
                                                    <div class="showErrorMgs" style="display:none"></div>

                                                    <input type="hidden" name="product_id[]" value="<?php echo esc_attr($wallregi_product_id); ?>" />
                                                    <input type="hidden" name="giftcard_price[]" value="<?php echo esc_attr($wallregi_product_price); ?>" />
                                                    <input type="hidden" name="giftcard_image[]" value="<?php echo esc_url($wallregi_product_image); ?>" />
                                                </div>
                                            </div>
                                            <?php else : ?>
                                            <div class="wallregi_form_wrap wallregi_checkout_receiver_notice_wrap">
                                                <p class="woocommerce-info wallregi_checkout_receiver_notice">
                                                    <?php
                                                    if ( 'billing' === $wallregi_checkout_receiver_address ) {
                                                        esc_html_e( 'Recipient details will be taken from the billing address entered at checkout.', 'wallet-ready-gift-cards-for-woocommerce' );
                                                    } else {
                                                        esc_html_e( 'Recipient details will be taken from the shipping address entered at checkout (billing email is used if the shipping address has no email).', 'wallet-ready-gift-cards-for-woocommerce' );
                                                    }
                                                    ?>
                                                </p>
                                                <input type="hidden" name="wallregi_checkout_receiver_source[]" value="<?php echo esc_attr( $wallregi_checkout_receiver_address ); ?>" />
                                                <input type="hidden" name="receiver_name[]" value="" />
                                                <input type="hidden" name="receiver_email[]" value="" />
                                                <input type="hidden" name="receiver_message[]" value="" />
                                                <input type="hidden" name="sender_name[]" value="" />
                                                <?php if ( $wallregi_enable_email_schedule === 'yes' ) : ?>
                                                    <input type="hidden" name="sender_email_shedule[]" value="" />
                                                <?php endif; ?>
                                                <input type="hidden" name="product_id[]" value="<?php echo esc_attr( $wallregi_product_id ); ?>" />
                                                <input type="hidden" name="giftcard_price[]" value="<?php echo esc_attr( $wallregi_product_price ); ?>" />
                                                <input type="hidden" name="giftcard_image[]" value="<?php echo esc_url( $wallregi_product_image ); ?>" />
                                                <div class="showErrorMgs" style="display:none" aria-live="polite"></div>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </article>
                                </div>

                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="wallregi_button__items">
        
                <div class="wallregi_qty_btn_groups">
                    <button type="button" class="button btn_primary minus_btn">
                        <span class="wallregi_icon wallregi_icon_minus"></span>
                    </button>                                    
                    <input type="number" name="wallregi_giftcard_quantity[]" value="1" min="1" max="<?php echo esc_attr( $wallregi_settings['max_giftcard_qty'] ); ?>" id="wallregi_giftcard_quantity" class="button btn_primary">
                    <button type="button" class="button btn_primary plus_btn">
                        <span class="wallregi_icon wallregi_icon_plus"></span>
                    </button>                                      
                </div>

                <button type="submit" name="wallregi_giftcard_submit" id="wallregiGiftcardSubmit" class="button btn-primary wallregi_gift_card_submit_btn">
                    <span><?php echo esc_html(!empty($wallregi_settings['submit_btn_text']) ? __($wallregi_settings['submit_btn_text'], 'wallet-ready-gift-cards-for-woocommerce') : __('Add to cart', 'wallet-ready-gift-cards-for-woocommerce')); ?></span>
                </button>

            </div>

        </section>
    </div>
<?php
    // After your content:
    // phpcs:ignore
    do_action('wallregi_woocommerce_after_main_content');
    if (wp_is_block_theme()) {
        get_footer();
        wp_footer();
    }else{
        get_footer( 'shop' );
    }

}





