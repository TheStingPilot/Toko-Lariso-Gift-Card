<?php

if (!defined('ABSPATH')) {
    exit;  // Prevent direct access
}

if (!class_exists('WALLREGI_Gift_Card_Frontend')) {
    class WALLREGI_Gift_Card_Frontend
    {
        /**
         * Sanitize inline CSS before printing it with wp_add_inline_style().
         *
         * @param mixed $css Raw CSS string.
         * @return string
         */
        private function wallregi_sanitize_inline_css($css)
        {
            if (!is_string($css)) {
                return '';
            }

            // Remove HTML tags first
            $css = wp_strip_all_tags($css);

            // Remove potentially dangerous CSS properties
            $dangerous_patterns = [
                '/expression\s*\(/i',
                '/behavior\s*:/i',
                '/javascript\s*:/i',
                '/vbscript\s*:/i',
                '/binding\s*:/i',
                '/@import/i',
                '/@namespace/i',
            ];

            foreach ($dangerous_patterns as $pattern) {
                $css = preg_replace($pattern, '', $css);
            }

            return $css;
        }

        /**
         * Constructor to initialize hooks
         */
        public function __construct()
        {
            // Cart Page Quantity Input Field Disable
            add_filter('woocommerce_cart_item_quantity', [$this, 'wallregi_disable_cart_quantity_fields'], 10, 3);

            add_action('wp_enqueue_scripts', [$this, 'wallregi_enqueue_assets_for_frontend']);

            // Override WooCommerce single product template for gift card product type.
            add_filter('template_include', [$this, 'wallregi_load_gift_card_template'], 99);
            add_filter('wc_get_template_part', [$this, 'wallregi_override_single_product_template'], 99, 3);

            // Handle the forntend ajax
            add_action('wp_ajax_wallregi_process_giftcard_form', [$this, 'wallregi_process_giftcard_form_callback']);
            add_action('wp_ajax_nopriv_wallregi_process_giftcard_form', [$this, 'wallregi_process_giftcard_form_callback']);

            // Display gift card data in the cart.
            add_filter('woocommerce_get_item_data', [$this, 'wallregi_display_giftcard_data'], 10, 2);

            // Hook modal output to both Cart and Checkout pages
            add_action('woocommerce_after_cart', [$this, 'wallregi_render_giftcard_edit_modal']);
            add_action('woocommerce_after_checkout_form', [$this, 'wallregi_render_giftcard_edit_modal']);

            // Handle cart page edit gift card
            add_action('wp_ajax_wallregi_update_giftcard_data', [$this, 'wallregi_update_giftcard_data_callback']);
            add_action('wp_ajax_nopriv_wallregi_update_giftcard_data', [$this, 'wallregi_update_giftcard_data_callback']);

            // Replace cart item thumbnail with gift card image.
            add_filter('woocommerce_cart_item_thumbnail', [$this, 'wallregi_replace_cart_item_thumbnail'], 10, 3);

            // Add gift card data to order item meta.
            add_action('woocommerce_checkout_create_order_line_item', [$this, 'wallregi_giftcard_add_order_item_meta'], 20, 4);

            // Add filter for hiding gift card meta data
            add_filter('woocommerce_display_item_meta', [$this, 'wallregi_hide_giftcard_meta_on_thank_you_page'], 10, 3);

            // Hide gift card meta data from WooCommerce emails
            add_filter('woocommerce_order_item_get_formatted_meta_data', [$this, 'wallregi_hide_giftcard_meta_from_emails'], 10, 2);

            // add giftcard data to giftcard table
            add_action('woocommerce_order_status_changed', [$this, 'wallregi_order_complete_insert_data'], 99, 3);

            // show pdf download link in order success page
            add_action('woocommerce_order_item_meta_end', [$this, 'wallregi_item_pdf_download_link'], 10, 3);

            // show pdf download link in admin order page
            add_action('woocommerce_after_order_itemmeta', [$this, 'wallregi_admin_item_pdf_download_link'], 10, 3);

            // Wooocommerce cart page price changed
            add_filter('woocommerce_cart_contents_changed', [$this, 'wallregi_woocommerce_cart_contents_changed_callback'], 99, 1);
            add_action('woocommerce_before_calculate_totals', [$this, 'wallregi_sync_giftcard_line_prices_before_totals'], 99, 1);
        }

        /**
         * Cart Page Quantity Input Field Disable
         */
        public function wallregi_disable_cart_quantity_fields($product_quantity, $cart_item_key, $cart_item)
        {
            $product = wc_get_product($cart_item['product_id']);  // Get product object

            // Check if the product is of type 'wxgiftcard'
            if ($product && $product->get_type() === 'wxgiftcard') {
                return '<span class="qty">' . esc_html($cart_item['quantity']) . '</span>';  // Show static quantity
            }

            return $product_quantity;  // Return default quantity field for other products
        }

        /**
         * Enqueue frontend CSS and JS assets
         */
        public function wallregi_enqueue_assets_for_frontend()
        {
            // Enqueue CSS
            wp_enqueue_style(
                'wallregi_frontend_style',
                WALLREGI_PLUGIN_URL . 'frontend/assets/css/frontend.css',
                [],
                WALLREGI_VERSION,
                'all'
            );

            // Enqueue a *PHP‐generated* stylesheet that will output dynamic CSS.
            $dynamic_css_file = WALLREGI_PLUGIN_DIR . 'frontend/custom-inline-styles.php';
            if (file_exists($dynamic_css_file)) {
                // Use include to get the CSS string from custom-inline-styles.php
                $wallregi_custom_css = include $dynamic_css_file;

                // Only add inline style if CSS string is valid and not empty
                if (is_string($wallregi_custom_css) && !empty(trim($wallregi_custom_css))) {
                    $wallregi_safe_custom_css = $this->wallregi_sanitize_inline_css($wallregi_custom_css);
                    wp_add_inline_style('wallregi_frontend_style', $wallregi_safe_custom_css);
                }
            }

            wp_enqueue_style(
                'wallregi_jquery_ui_css',
                WALLREGI_PLUGIN_URL . 'frontend/assets/css/jquery-ui.min.css',
                [],
                WALLREGI_VERSION,
                'all'
            );
            wp_enqueue_style(
                'wallregi_flatpickr_css',
                WALLREGI_PLUGIN_URL . 'frontend/assets/css/flatpickr.min.css',
                [],
                WALLREGI_VERSION,
                'all'
            );

            // Enqueue Responsive CSS
            wp_enqueue_style(
                'wallregi_responsive_css',
                WALLREGI_PLUGIN_URL . 'frontend/assets/css/responsive.css',
                [],
                WALLREGI_VERSION,
                'all'
            );

            // Enqueue jQuery UI Accordion
            wp_enqueue_script('jquery-ui-accordion');

            wp_enqueue_script(
                'wallregi_flatpickr_script',
                WALLREGI_PLUGIN_URL . 'frontend/assets/js/flatpickr.min.js',
                ['jquery'],
                WALLREGI_VERSION,
                true
            );

            // Enqueue JS
            $wallregi_frontend_js_path = WALLREGI_PLUGIN_DIR . 'frontend/assets/js/frontend.js';
            $wallregi_frontend_js_ver = defined('WALLREGI_VERSION') ? WALLREGI_VERSION : '1.0.0';
            if (file_exists($wallregi_frontend_js_path)) {
                $wallregi_frontend_js_ver .= '.' . filemtime($wallregi_frontend_js_path);
            }
            wp_enqueue_script(
                'wallregi_frontend_script',
                WALLREGI_PLUGIN_URL . 'frontend/assets/js/frontend.js',
                ['jquery', 'wp-i18n'],
                $wallregi_frontend_js_ver,
                true
            );
            if (function_exists('wp_set_script_translations')) {
                wp_set_script_translations('wallregi_frontend_script', 'wallet-ready-gift-cards-for-woocommerce');
            }

            // Edit Giftcard in cart/checkout page JS
            wp_enqueue_script(
                'wallregi_frontend_edit_cart_script',
                WALLREGI_PLUGIN_URL . 'frontend/assets/js/frontend-edit-cart.js',
                ['jquery'],
                WALLREGI_VERSION,
                true
            );

            wp_enqueue_script(
                'wallregi_coupon_integration_script',
                WALLREGI_PLUGIN_URL . 'frontend/assets/js/coupon-integration.js',
                ['jquery'],
                WALLREGI_VERSION,
                true
            );

            // Get settings with defaults
            $wallregi_settings = get_option('wallregi_settings', []);
            $wallregi_defaults = [
                'valid_mgs_receiver' => 'Receiver Name is required.',
                'valid_mgs_receiver_email' => 'Receiver Email is required.',
                'valid_mgs_sender' => 'Sender Name is required.',
                'invalid_email' => 'Enter a valid email address.',
                'giftcard_hseparator' => '-',
            ];
            $wallregi_settings = wp_parse_args($wallregi_settings, $wallregi_defaults);

            // Localize script for AJAX URL (same global for frontend.js + coupon-integration.js)
            $wallregi_ajax_object = [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wallregi_nonce'),
                'cart_url' => wc_get_cart_url(),
                'upload_icon_url' => esc_url(WALLREGI_PLUGIN_URL . 'frontend/assets/cloud-upload.svg'),
                'currency_position' => get_option('woocommerce_currency_pos'),
                'currency_symbol' => get_woocommerce_currency_symbol(),
                'currency_decimals' => function_exists('wc_get_price_decimals') ? wc_get_price_decimals() : 2,
                'decimal_separator' => function_exists('wc_get_price_decimal_separator') ? wc_get_price_decimal_separator() : '.',
                'thousand_separator' => function_exists('wc_get_price_thousand_separator') ? wc_get_price_thousand_separator() : ',',
                'price_format' => function_exists('get_woocommerce_price_format') ? get_woocommerce_price_format() : '',
                'is_cart_edit_enabled' => $this->wallregi_is_cart_edit_enabled(),
                'is_checkout_edit_enabled' => $this->wallregi_is_checkout_edit_enabled(),
                'is_user_logged_in' => is_user_logged_in(),
                'processing_text' => __('Processing...', 'wallet-ready-gift-cards-for-woocommerce'),
                'submit_text' => __('Submit', 'wallet-ready-gift-cards-for-woocommerce'),
                'submit_btn_text' => !empty($wallregi_settings['submit_btn_text']) ? __($wallregi_settings['submit_btn_text'], 'wallet-ready-gift-cards-for-woocommerce') : __('Add to cart', 'wallet-ready-gift-cards-for-woocommerce'),
                'enter_valid_amount' => __('Please enter a valid gift card amount to continue.', 'wallet-ready-gift-cards-for-woocommerce'),
                'validation_messages' => [
                    'receiverName' => $wallregi_settings['valid_mgs_receiver'],
                    'receiverEmail' => $wallregi_settings['valid_mgs_receiver_email'],
                    'senderName' => $wallregi_settings['valid_mgs_sender'],
                    'invalidEmail' => $wallregi_settings['invalid_email'],
                    'separatorText' => $wallregi_settings['giftcard_hseparator'],
                    'validGiftCardAmount' => __('Please enter a valid gift card amount to continue.', 'wallet-ready-gift-cards-for-woocommerce'),
                ],
                'checkout_receiver_modal_notice' => [
                    'billing' => __('Recipient details are taken from your billing address at checkout and cannot be edited here.', 'wallet-ready-gift-cards-for-woocommerce'),
                    'shipping' => __('Recipient details are taken from your shipping address at checkout and cannot be edited here.', 'wallet-ready-gift-cards-for-woocommerce'),
                ],
            ];
            // Must match check_ajax_referer() in coupon callback (different action than wallregi_nonce).
            if (is_cart() || is_checkout()) {
                $wallregi_ajax_object['apply_coupon_nonce'] = wp_create_nonce('wallregi_apply_coupon_nonce');
                $wallregi_ajax_object['giftcardBlocksRedeemHint'] = __('Use the gift card field in the order summary to choose an amount and apply your code.', 'wallet-ready-gift-cards-for-woocommerce');
            }

            $wallregi_ajax_object = apply_filters('wallregi_frontend_ajax_object', $wallregi_ajax_object, $wallregi_settings);

            wp_localize_script('wallregi_frontend_script', 'wallregi_ajax_object', $wallregi_ajax_object);
            wp_localize_script('wallregi_frontend_edit_cart_script', 'wallregi_ajax_object', $wallregi_ajax_object);
        }

        /**
         * Load custom template for a specific product
         */
        public function wallregi_load_gift_card_template($template)
        {
            global $post;

            if (!$post || !isset($post->ID)) {
                return $template;
            }

            $product = wc_get_product($post->ID);

            if (is_singular('product') && $product instanceof WC_Product && $product->get_type() === 'wxgiftcard') {
                $new_template = WALLREGI_PLUGIN_DIR . 'frontend/single-giftcard-content.php';
                if (file_exists($new_template)) {
                    return $new_template;
                }
            }

            return $template;
        }

        /**
         * Override WooCommerce single product template for gift card product type.
         */
        public function wallregi_override_single_product_template($template, $slug, $wallregi_name)
        {
            if ($slug === 'content' && $wallregi_name === 'single-product') {
                global $product;
                if ($product instanceof WC_Product && $product->get_type() === 'wxgiftcard') {
                    $new_template = WALLREGI_PLUGIN_DIR . 'frontend/single-giftcard-content.php';
                    if (file_exists($new_template)) {
                        return $new_template;
                    }
                }
            }
            return $template;
        }

        /**
         * Display gift card data in cart item
         */
        public function wallregi_display_giftcard_data($item_data, $cart_item)
        {
            if (isset($cart_item['giftcard_data']) && is_array($cart_item['giftcard_data'])) {
                $product_id = $cart_item['product_id'] ?? 0;
                $giftcard = $cart_item['giftcard_data'] ?? [];
                $cart_item_key = $cart_item['key'] ?? '';

                // Build product gallery HTML for edit modal
                if ($product = wc_get_product($product_id)) {
                    $ids = $product->get_gallery_image_ids();
                    if ($thumb = get_post_thumbnail_id($product_id))
                        array_unshift($ids, $thumb);
                    $urls = [];
                    if (!empty($ids)) {
                        foreach ($ids as $i => $id) {
                            $urls[] = wp_get_attachment_url($id);
                        }
                    }
                    $urls = apply_filters('wallregi_giftcard_gallery_urls', $urls, $cart_item, $giftcard);
                    $urls = json_encode($urls);
                }

                // Load saved settings
                $wallregi_settings = get_option('wallregi_settings', []);

                // Set default values
                $wallregi_defaults = [
                    'giftcard_edit_in_cart' => 'no',
                    'giftcard_edit_in_checkout' => 'no',
                    'name_label' => 'Receiver name',
                    'email_label' => 'Receiver email',
                    'greeting_label' => 'Greeting/Message',
                    'sender_label' => 'Sender name',
                    'datepicker_label' => 'Send at',
                ];

                $wallregi_settings = wp_parse_args($wallregi_settings, $wallregi_defaults);

                // Get date format from WordPress settings
                $date_format = get_option('date_format');  // Default: 'F j, Y' (August 15, 2023)

                // Get time format from WordPress settings
                $time_format = get_option('time_format');  // Default: 'g:i a' (2:30 pm)

                // Get combined format (if needed)
                $datetime_format = $date_format . ' ' . $time_format;
                $current_datetime = current_time($datetime_format);
                // Gift card fields
                $checkout_rcv = isset($giftcard['checkout_receiver_source']) ? $giftcard['checkout_receiver_source'] : '';
                if (in_array($checkout_rcv, array('billing', 'shipping'), true)) {
                    $addr_label = ('billing' === $checkout_rcv)
                        ? __('billing address', 'wallet-ready-gift-cards-for-woocommerce')
                        : __('shipping address', 'wallet-ready-gift-cards-for-woocommerce');
                    $item_data[] = array(
                        'name' => __('Recipient details', 'wallet-ready-gift-cards-for-woocommerce'),
                        'value' => sprintf(
                            /* translators: %s: billing address or shipping address */
                            __('Taken from your %s when you place the order.', 'wallet-ready-gift-cards-for-woocommerce'),
                            $addr_label
                        ),
                    );
                } else {
                    $item_data[] = array('name' => __('Recipient Name', 'wallet-ready-gift-cards-for-woocommerce'), 'value' => $giftcard['receiver_name'] ?? '');
                    $item_data[] = array('name' => __('Recipient Email', 'wallet-ready-gift-cards-for-woocommerce'), 'value' => $giftcard['receiver_email'] ?? '');
                    if (function_exists('wallregi_cart_edit_delivery_is_available') && wallregi_cart_edit_delivery_is_available()) {
                        $wallregi_channel = function_exists('wallregi_normalize_delivery_channel')
                            ? wallregi_normalize_delivery_channel($giftcard['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL)
                            : WALLREGI_DELIVERY_CHANNEL_EMAIL;
                        $item_data[] = array(
                            'name' => __('Delivery method', 'wallet-ready-gift-cards-for-woocommerce'),
                            'value' => wallregi_giftcard_delivery_channel_label($wallregi_channel),
                        );
                        if (
                            in_array($wallregi_channel, array(WALLREGI_DELIVERY_CHANNEL_SMS, WALLREGI_DELIVERY_CHANNEL_BOTH), true) &&
                            !empty($giftcard['receiver_phone'])
                        ) {
                            $item_data[] = array(
                                'name' => __('Recipient phone', 'wallet-ready-gift-cards-for-woocommerce'),
                                'value' => $giftcard['receiver_phone'],
                            );
                        }
                    }
                    $item_data[] = array('name' => __('Greeting/Message', 'wallet-ready-gift-cards-for-woocommerce'), 'value' => $giftcard['receiver_message'] ?? '');
                    $item_data[] = array('name' => __('Sender Name', 'wallet-ready-gift-cards-for-woocommerce'), 'value' => $giftcard['sender_name'] ?? '');
                    $item_data[] = array('name' => esc_html($wallregi_settings['datepicker_label']), 'value' => $giftcard['email_schedule'] ?? $current_datetime);
                }

                // Show classic PHP edit row only on shortcode cart/checkout (hide on block cart, block checkout, and Store API: Blocks JS injects .wallregi-block-cart-item-edit-button).
                $is_edit_enabled = (
                    !$this->wallregi_is_store_api_request() &&
                    !$this->wallregi_is_block_cart_page() &&
                    !$this->wallregi_is_checkout_page_using_blocks() &&
                    (
                        (is_cart() && $wallregi_settings['giftcard_edit_in_cart'] === 'yes') ||
                        (is_checkout() && wallregi_checkout_giftcard_edit_is_enabled($wallregi_settings))
                    )
                );
                $is_edit_enabled = (bool) apply_filters('wallregi_is_cart_item_edit_enabled', $is_edit_enabled, $cart_item, $wallregi_settings);

                if ($is_edit_enabled) {
                    $price_data = wallregi_get_giftcard_display_price($product_id, $giftcard);
                    $display_price = $price_data['price_formatted'];
                    $custom_price_options = $price_data['price_options'];
                    $manual_price = $price_data['manual_price'];

                    /**
                     * Augment gift card data passed to the cart edit modal (e.g. per-product preset messages).
                     *
                     * @param array $giftcard   Cart line gift card field values.
                     * @param array $cart_item  Full WooCommerce cart line.
                     */
                    $giftcard_for_edit = apply_filters('wallregi_giftcard_cart_edit_payload', $giftcard, $cart_item);

                    $item_data[] = [
                        'name' => __('Edit Gift Card', 'wallet-ready-gift-cards-for-woocommerce'),
                        'value' => sprintf(
                            '<div class="wodg_edit_cart_item_button_box">
                                <button type="button"
                                    class="button wodg_cart_item_edit_button"
                                    data-cart_item_key="%s"
                                    data-giftcard=\'%s\'
                                    data-giftcard_price="%s"
                                    data-custom_prices=\'%s\'
                                    data-manual_price="%s"
                                    data-gallery="%s"
                                    onclick="wallregiHandleGiftcardEditButtonClick(this, event)"
                                >%s</button>
                            </div>',
                            esc_attr($cart_item_key),
                            esc_attr(wp_json_encode($giftcard_for_edit)),
                            esc_attr($display_price),
                            esc_attr(wp_json_encode($custom_price_options)),
                            esc_attr($manual_price ? 'true' : 'false'),
                            esc_attr($urls),
                            __('Edit', 'wallet-ready-gift-cards-for-woocommerce')
                        ),
                    ];
                }
            }

            return $item_data;
        }

        /**
         * Whether cart item data is being prepared for WooCommerce Blocks Store API.
         */
        private function wallregi_is_store_api_request()
        {
            // WooCommerce Blocks defines this during Store API requests.
            if (defined('WC_BLOCKS_IS_STORE_API_REQUEST') && WC_BLOCKS_IS_STORE_API_REQUEST) {
                return true;
            }

            if (!defined('REST_REQUEST') || !REST_REQUEST) {
                return false;
            }

            // Store API requests can come in 2 shapes:
            // - Pretty permalinks: /wp-json/wc/store/...
            // - Plain: /wp-json/?rest_route=/wc/store/...
            $request_uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '';
            $request_uri = sanitize_text_field($request_uri);

            if (false !== strpos($request_uri, '/wc/store/')) {
                return true;
            }

            $rest_route = isset($_GET['rest_route']) ? (string) wp_unslash($_GET['rest_route']) : '';
            $rest_route = sanitize_text_field($rest_route);

            return '' !== $rest_route && false !== strpos($rest_route, '/wc/store/');
        }

        /** Whether current request is rendering the Cart block page. */

        /**
         * True when the checkout page uses the WooCommerce Checkout block.
         *
         * @return bool
         */
        private function wallregi_is_checkout_page_using_blocks()
        {
            if (!function_exists('is_checkout') || !is_checkout()) {
                return false;
            }

            if (class_exists('\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils') && method_exists('\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils', 'is_checkout_block_default')) {
                if (\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils::is_checkout_block_default()) {
                    return true;
                }
            }

            $post_id = (int) get_queried_object_id();
            $content = $post_id > 0 ? (string) get_post_field('post_content', $post_id) : '';
            if ('' !== $content) {
                if (function_exists('has_block') && has_block('woocommerce/checkout', $content)) {
                    return true;
                }
                if (false !== strpos($content, 'wp:woocommerce/checkout')) {
                    return true;
                }
            }

            if (function_exists('wallregi_is_wc_cart_checkout_block_template') && wallregi_is_wc_cart_checkout_block_template()) {
                return true;
            }

            return false;
        }

        private function wallregi_is_block_cart_page()
        {
            if (!is_cart()) {
                return false;
            }

            // Prefer WooCommerce Blocks native detection when available.
            if (class_exists('\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils')) {
                if (method_exists('\Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils', 'is_cart_block_default')) {
                    return \Automattic\WooCommerce\Blocks\Utils\CartCheckoutUtils::is_cart_block_default();
                }
            }

            // Fallback: inspect the currently queried cart page content only.
            $post_id = get_queried_object_id();
            if ($post_id <= 0) {
                return false;
            }

            $cart_content = get_post_field('post_content', $post_id);
            if (!is_string($cart_content) || '' === $cart_content) {
                return false;
            }

            // Classic cart page usually uses shortcode markup.
            if (function_exists('has_shortcode') && has_shortcode($cart_content, 'woocommerce_cart')) {
                return false;
            }

            // Detect native WooCommerce Cart block markup.
            return false !== strpos($cart_content, 'wp:woocommerce/cart');
        }

        /**
         * Whether gift card edit is enabled for current cart context.
         */
        private function wallregi_is_cart_edit_enabled()
        {
            $settings = wp_parse_args(
                get_option('wallregi_settings', []),
                [
                    'giftcard_edit_in_cart' => 'no',
                ]
            );

            $enabled = is_cart() && 'yes' === $settings['giftcard_edit_in_cart'];

            return (bool) apply_filters('wallregi_is_cart_edit_enabled', $enabled, $settings);
        }

        /**
         * Whether gift card edit is enabled for current checkout context.
         */
        private function wallregi_is_checkout_edit_enabled()
        {
            $settings = wp_parse_args(
                get_option('wallregi_settings', []),
                [
                    'giftcard_edit_in_checkout' => 'no',
                ]
            );

            return wallregi_checkout_giftcard_edit_is_enabled($settings);
        }

        /**
         * Output gift card edit modal in cart or checkout
         */
        public function wallregi_render_giftcard_edit_modal()
        {
            $wallregi_settings = get_option('wallregi_settings', []);

            $wallregi_settings = wp_parse_args($wallregi_settings, [
                'giftcard_edit_in_cart' => 'no',
                'giftcard_edit_in_checkout' => 'no',
                'min_cprice' => 1,
                'max_cprice' => 9990,
                'manual_price_placeholder' => 'Enter an amount',
                'name_label' => 'Receiver name',
                'email_label' => 'Receiver email',
                'greeting_label' => 'Greeting/Message',
                'sender_label' => 'Sender name',
                'datepicker_label' => 'Send at',
                'gallery_label' => __('Choose a picture', 'wallet-ready-gift-cards-for-woocommerce'),
                'max_mgs_length' => 250,
                'character_counts' => 'yes',
            ]);

            $is_cart_edit_enabled = (bool) apply_filters(
                'wallregi_is_cart_edit_enabled',
                (is_cart() && $wallregi_settings['giftcard_edit_in_cart'] === 'yes'),
                $wallregi_settings
            );
            $is_checkout_edit_enabled = wallregi_checkout_giftcard_edit_is_enabled($wallregi_settings);

            if ($is_cart_edit_enabled || $is_checkout_edit_enabled):
                if (function_exists('wallregi_is_wc_cart_checkout_block_template') && wallregi_is_wc_cart_checkout_block_template()) {
                    return;
                }
                ?>
                <div class="wallregi_edit_cart_modal_wrapper">
                    <div class="wallregi_edit_cart_modal" id="wallregi_giftcard_edit_modal">
                        <div class="wallregi_edit_modal_header">
                            <h3 class="wallregi_title edit_giftcard_heading">
                                <span class="edit_giftcard_heading_text"><?php esc_html_e('Edit Gift Card', 'wallet-ready-gift-cards-for-woocommerce'); ?></span>
                            </h3>

                            <span class="wallregi_edit_modal_close">&times;</span>
                        </div>
  
                        <form id="wallregi_edit_modal_form">
                            <div class="wallregi_form_price_edit_item">
                                <label class="wallregi_price_edit_heading">
                                    <?php
                                    esc_html_e('Gift card amount', 'wallet-ready-gift-cards-for-woocommerce');
                                    echo ' ( ' . esc_html(get_woocommerce_currency_symbol()) . ') :';
                                    ?>
                                </label>
                                <span id="edit_giftcard_price"></span>
                            </div>
                            <div class="wallregi_form_item wallregi_custom_price_item" style="display: none;">
                                <div class="wallregi_price_item_wrap">
                                    <ul class="wallregi_custom_price_options" id="wallregi_price_option_list">
                                        <!-- Dynamic buttons will be injected here -->
                                    </ul>
                                    <div class="wallregi_manual_price_item" style="display: none;">
                                        <div class="wallregi_custom_price_wraper">
                                            <input placeholder="<?php echo esc_attr('(' . get_woocommerce_currency_symbol() . ') ' . $wallregi_settings['manual_price_placeholder']); ?>" type="number" name="wallregi_custom_price[]" data-min="<?php echo esc_attr($wallregi_settings['min_cprice']); ?>" data-max="<?php echo esc_attr($wallregi_settings['max_cprice']); ?>" onclick="wallregiEditGiftCardManualPriceEnable(this)" onfocusout="wallregiEditGiftCardManualPriceFocusOut(this)" onkeyup="wallregiEditGiftCardManualPriceKeyUp(this)" class="wallregi_edit_input wallregi_cprice_input_field">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="wallregi_gallery_images_content_box">
                                   <h4 class="wallregi_heading"><?php echo esc_html($wallregi_settings['gallery_label']); ?></h4>
                                   <div class="wallregi_gallery_preview">
                                        <figure class="wallregi_image_preview">
                                            <img id="edit_giftcard_image_preview" class="wallregi_image_thumb" src="" alt="Preview Image">
                                        </figure>
                                        <!-- Gallery will be injected here by JS -->
                                        <ul id="edit_giftcard_gallery" class="wallregi_images__gallery"></ul>
                                    </div>
                            </div> 

                            <div class="wallregi_modal_form_contents">
                                <p class="woocommerce-info wallregi_edit_checkout_receiver_notice" style="display:none;" aria-live="polite"></p>
                                <div class="wallregi_edit_checkout_receiver_hidden_fields">
                                <div class="wallregi_modal_form_group">
                                    <div class="wallregi_form_item">
                                        <label for="edit_receiver_name"><?php echo esc_html($wallregi_settings['name_label']); ?><span class="wallregi_field_required_mark">*</span></label>
                                        <input type="text" id="edit_receiver_name" name="receiver_name" class="wallregi_edit_input" required>
                                    </div>
                                    <div class="wallregi_form_item">
                                        <label for="edit_receiver_email"><?php echo esc_html($wallregi_settings['email_label']); ?><span class="wallregi_email_required_mark">*</span></label>
                                        <input type="email" id="edit_receiver_email" name="receiver_email" class="wallregi_edit_input" required>
                                    </div>
                                </div>
                                <?php
                                if (function_exists('wallregi_render_cart_edit_delivery_fields')) {
                                    wallregi_render_cart_edit_delivery_fields();
                                }
                                ?>
                       
                                <?php
                                /** @see WALLREGI_Pro_Greeting_Presets */
                                do_action('wallregi_before_edit_greeting_textarea');
                                ?>
                                <div class="wallregi_form_item">
                                    <label for="edit_receiver_message"><?php echo esc_html($wallregi_settings['greeting_label']); ?></label>
                                    <textarea id="edit_receiver_message" name="receiver_message" class="wallregi_edit_textarea" maxlength="<?php echo esc_attr((int) $wallregi_settings['max_mgs_length']); ?>" data-maxlength="<?php echo esc_attr((int) $wallregi_settings['max_mgs_length']); ?>" onkeyup="wallregiGiftCardMessagePreview(this)" oninput="wallregiGiftCardMessagePreview(this)"></textarea>
                                    <?php $wallregi_show_char_counts = (!isset($wallregi_settings['character_counts']) || $wallregi_settings['character_counts'] === 'yes'); ?>
                                    <div id="edit_max_lenght" class="wallregi_edit_max_lenght" <?php echo $wallregi_show_char_counts ? 'style="display:block;"' : 'style="display:none;"'; ?>>
                                        <div class="wallregi_charcter_count">
                                            <span><?php esc_html_e('Character count:', 'wallet-ready-gift-cards-for-woocommerce'); ?></span> 
                                            (<span class="charCount"><?php esc_html_e('0', 'wallet-ready-gift-cards-for-woocommerce'); ?></span>/<?php echo esc_html((int) $wallregi_settings['max_mgs_length']); ?>)
                                        </div>
                                    </div>
                                </div>
                                <div class="wallregi_modal_form_group">
                                    <div class="wallregi_form_item">
                                        <label for="edit_sender_name"><?php echo esc_html($wallregi_settings['sender_label']); ?></label>
                                        <input type="text" id="edit_sender_name" name="sender_name" class="wallregi_edit_input">
                                    </div>
                                    <div class="wallregi_form_item">
                                        <label for="edit_email_schedule"><?php echo esc_html($wallregi_settings['datepicker_label']); ?></label>
                                        <input type="text" id="edit_email_schedule" name="email_schedule" class="wallregi_edit_input wallregi_datetime_picker wallregi_datetime__field">
                                    </div>
                                </div>
                                </div>

                            </div>
                            <div class="wallregi_form_button_items">
                            <button type="submit" class="button submit_btn"><?php esc_html_e('Update', 'wallet-ready-gift-cards-for-woocommerce'); ?></button>
                            <button type="button" class="button cancel_btn wallregi_edit_modal_close"><?php esc_html_e('Cancel', 'wallet-ready-gift-cards-for-woocommerce'); ?></button>
                        </div>
                        </form>
                        
                    </div>
                </div>
                <?php
            endif;
        }

        // AJAX Handler for Woocommerce cart page data updated
        public function wallregi_update_giftcard_data_callback()
        {
            // Check nonce for security
            check_ajax_referer('wallregi_nonce', '_wallreginonce');

            if (function_exists('is_checkout') && is_checkout() && !wallregi_checkout_giftcard_edit_is_enabled()) {
                wp_send_json_error(
                    [
                        'message' => __('Editing gift cards at checkout is not available.', 'wallet-ready-gift-cards-for-woocommerce'),
                    ]
                );
            }

            $wallregi_receiver_for_rate = '';
            if (isset($_POST['receiver_email']) && !is_array($_POST['receiver_email'])) {
                $wallregi_receiver_for_rate = sanitize_email(wp_unslash($_POST['receiver_email']));
            }
            if (!apply_filters('wallregi_security_allow_cart_giftcard_update', true, array('receiver_email' => $wallregi_receiver_for_rate))) {
                wp_send_json_error(array('message' => wallregi_security_rate_limit_message()));
            }

            // Check and sanitize cart_item_key
            if (isset($_POST['cart_item_key'])) {
                $cart_item_key = sanitize_text_field(wp_unslash($_POST['cart_item_key']));
            }

            if (empty($cart_item_key)) {
                wp_send_json_error(['message' => 'Cart item key missing']);
            }

            $cart = WC()->cart->get_cart();

            if (isset($cart[$cart_item_key]['giftcard_data'])) {
                $giftcard_data = $cart[$cart_item_key]['giftcard_data'];

                // Define allowed editable fields.
                $wallregi_fields = [
                    'giftcard_heading',
                    'giftcard_price',
                    'receiver_name',
                    'receiver_email',
                    'receiver_message',
                    'sender_name',
                    'email_schedule',
                ];
                $wallregi_fields = apply_filters('wallregi_editable_giftcard_fields', $wallregi_fields, $cart_item_key, $giftcard_data, 'ajax');

                foreach ($wallregi_fields as $wallregi_key) {
                    if (isset($_POST[$wallregi_key]) && !is_array($_POST[$wallregi_key])) {
                        // First unslash, then sanitize/validate by field type.
                        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                        $raw_value = wp_unslash($_POST[$wallregi_key]);
                        switch ($wallregi_key) {
                            case 'receiver_email':
                                $giftcard_data[$wallregi_key] = sanitize_email($raw_value);
                                break;
                            case 'delivery_channel':
                                $giftcard_data[$wallregi_key] = function_exists('wallregi_sanitize_delivery_channel')
                                    ? wallregi_sanitize_delivery_channel($raw_value)
                                    : sanitize_key($raw_value);
                                break;
                            case 'receiver_phone':
                                $giftcard_data[$wallregi_key] = function_exists('wallregi_sanitize_giftcard_phone')
                                    ? wallregi_sanitize_giftcard_phone($raw_value)
                                    : sanitize_text_field($raw_value);
                                break;
                            case 'receiver_message':
                                $wallregi_global_settings = get_option('wallregi_settings', []);
                                $max_mgs_length = isset($wallregi_global_settings['max_mgs_length']) ? intval($wallregi_global_settings['max_mgs_length']) : 250;
                                $sanitized_msg = sanitize_textarea_field($raw_value);
                                if ($max_mgs_length > 0 && mb_strlen($sanitized_msg) > $max_mgs_length) {
                                    $sanitized_msg = mb_substr($sanitized_msg, 0, $max_mgs_length);
                                }
                                $giftcard_data[$wallregi_key] = $sanitized_msg;
                                break;
                            case 'giftcard_price':
                                $giftcard_data[$wallregi_key] = max(0, intval(sanitize_text_field($raw_value)));
                                break;
                            default:
                                $giftcard_data[$wallregi_key] = sanitize_text_field($raw_value);
                                break;
                        }
                    }
                }

                if (isset($_POST['thumb_image_url']) && !empty($_POST['thumb_image_url'])) {
                    $giftcard_data['giftcard_image'] = esc_url_raw(wp_unslash($_POST['thumb_image_url']));
                }

                if (function_exists('wallregi_validate_giftcard_cart_edit_delivery')) {
                    $delivery_validated = wallregi_validate_giftcard_cart_edit_delivery($giftcard_data);
                    if (is_wp_error($delivery_validated)) {
                        wp_send_json_error(array('message' => $delivery_validated->get_error_message()));
                    }
                    $giftcard_data = $delivery_validated;
                }

                // Update cart contents directly
                $cart[$cart_item_key]['giftcard_data'] = $giftcard_data;
                WC()->cart->cart_contents[$cart_item_key] = $cart[$cart_item_key];
                wallregi_apply_giftcard_prices_to_cart(WC()->cart);
                WC()->cart->set_session();  // Save to session
                WC()->cart->calculate_totals();
                do_action('wallregi_after_giftcard_cart_item_updated', $cart_item_key, $giftcard_data, 'ajax');

                wp_send_json_success(['message' => __('Gift card updated', 'wallet-ready-gift-cards-for-woocommerce')]);
            }

            wp_send_json_error(['message' => __('Item not found', 'wallet-ready-gift-cards-for-woocommerce')]);
        }

        /**
         * Replace cart item thumbnail with the gift card image if provided.
         */
        public function wallregi_replace_cart_item_thumbnail($thumbnail, $cart_item, $cart_item_key)
        {
            if (isset($cart_item['giftcard_data']['giftcard_image']) && !empty($cart_item['giftcard_data']['giftcard_image'])) {
                $giftcard_image = $cart_item['giftcard_data']['giftcard_image'];

                $wallregi_alt_text = isset($cart_item['giftcard_data']['giftcard_alt']) ? esc_attr($cart_item['giftcard_data']['giftcard_alt']) : __('Gift Card Image', 'wallet-ready-gift-cards-for-woocommerce');

                if (!empty($giftcard_image)) {
                    // phpcs:ignore
                    $thumbnail = '<img src="' . esc_url($giftcard_image) . '" alt="' . esc_attr($wallregi_alt_text) . '" class="cart_thumb" />';
                }
            }
            return $thumbnail;
        }

        /**
         * AJAX callback to process and add gift cards to the WooCommerce cart.
         */
        public function wallregi_process_giftcard_form_callback()
        {
            // Check nonce for security
            check_ajax_referer('wallregi_nonce', '_wallreginonce');

            // Get settings, fallback to defaults
            $wallregi_settings = get_option('wallregi_settings', []);
            $wallregi_defaults = [
                'response_success_mgs' => __('All gift cards have been successfully added to the cart.', 'wallet-ready-gift-cards-for-woocommerce'),
                // other default messages
            ];

            // Use either saved or default message
            $success_message = $wallregi_settings['response_success_mgs'] ?? $wallregi_defaults['response_success_mgs'];

            // Check if giftcards data is sent
            if (!isset($_POST['giftcards'])) {
                wp_send_json_error(['message' => __('No gift card data received.', 'wallet-ready-gift-cards-for-woocommerce')]);
            }

            // Raw JSON: do not run through sanitize_textarea_field() — it can alter valid JSON payloads.
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Decoded then field-level sanitization below.
            $giftcards_json = isset($_POST['giftcards']) ? wp_unslash((string) $_POST['giftcards']) : '';
            if (strlen($giftcards_json) > 500000) {
                wp_send_json_error(array('message' => __('Gift card data is too large.', 'wallet-ready-gift-cards-for-woocommerce')));
            }
            $giftcards = json_decode($giftcards_json, true);

            if (!is_array($giftcards)) {
                wp_send_json_error(['message' => __('Invalid gift card format.', 'wallet-ready-gift-cards-for-woocommerce')]);
            }

            if (!apply_filters('wallregi_security_allow_giftcard_form_submit', true, array('giftcards' => $giftcards))) {
                wp_send_json_error(array('message' => wallregi_security_rate_limit_message()));
            }

            // Ensure session + cart exist (some AJAX contexts run before the cart is initialized).
            if (function_exists('wc_load_cart') && did_action('woocommerce_init')) {
                if (!WC()->session || !(WC()->cart instanceof WC_Cart)) {
                    wc_load_cart();
                }
            }

            $processed_giftcards = [];
            // Get date format from WordPress settings
            $date_format = get_option('date_format');  // Default: 'F j, Y' (August 15, 2023)

            // Get time format from WordPress settings
            $time_format = get_option('time_format');  // Default: 'g:i a' (2:30 pm)

            // Get combined format (if needed)
            $datetime_format = $date_format . ' ' . $time_format;

            $current_datetime = current_time($datetime_format);
            // Example: process each gift card entry
            foreach ($giftcards as $giftcard) {
                $schedule_datetime = !empty($giftcard['emailSchedule']) ? sanitize_text_field($giftcard['emailSchedule']) : $current_datetime;
                $receiver_name = sanitize_text_field($giftcard['receiverName'] ?? '');
                $receiver_email = sanitize_email($giftcard['receiverEmail'] ?? '');
                $receiver_message = sanitize_textarea_field($giftcard['receiverMessage'] ?? '');
                $sender_name = sanitize_text_field($giftcard['senderName'] ?? '');
                $email_schedule = sanitize_text_field($schedule_datetime);
                $product_id = intval($giftcard['productId'] ?? 0);
                $giftcard_price = floatval($giftcard['giftcardPrice'] ?? 0);
                $giftcard_image = esc_url_raw($giftcard['giftcardImage'] ?? '');
                $giftcard_heading = sanitize_text_field($giftcard['giftcardHeading'] ?? '');
                $giftcard_short_desc = sanitize_text_field($giftcard['giftcardShortDesc'] ?? '');
                $checkout_receiver_req = isset($giftcard['checkoutReceiverSource']) ? sanitize_text_field($giftcard['checkoutReceiverSource']) : '';
                $checkout_receiver_req = strtolower(trim($checkout_receiver_req));
                $delivery_channel = function_exists('wallregi_sanitize_delivery_channel')
                    ? wallregi_sanitize_delivery_channel($giftcard['deliveryChannel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL)
                    : WALLREGI_DELIVERY_CHANNEL_EMAIL;
                $receiver_phone = '';

                $needs_sms_phone = in_array($delivery_channel, array(WALLREGI_DELIVERY_CHANNEL_SMS, WALLREGI_DELIVERY_CHANNEL_BOTH), true);
                if ($needs_sms_phone && function_exists('wallregi_validate_giftcard_phone')) {
                    $validated_phone = wallregi_validate_giftcard_phone($giftcard['receiverPhone'] ?? '', true);
                    if (is_wp_error($validated_phone)) {
                        wp_send_json_error(array('message' => $validated_phone->get_error_message()));
                    }
                    $receiver_phone = $validated_phone;
                } elseif (function_exists('wallregi_sanitize_giftcard_phone')) {
                    $receiver_phone = wallregi_sanitize_giftcard_phone($giftcard['receiverPhone'] ?? '');
                }

                $checkout_receiver_product = function_exists('wallregi_get_product_checkout_receiver_source')
                    ? wallregi_get_product_checkout_receiver_source($product_id)
                    : '';

                $use_checkout_receiver = (
                    $checkout_receiver_product !== '' &&
                    $checkout_receiver_req === $checkout_receiver_product &&
                    in_array($checkout_receiver_product, ['billing', 'shipping'], true)
                );

                $form_entry = array(
                    'receiver_name' => $receiver_name,
                    'receiver_email' => $receiver_email,
                    'receiver_message' => $receiver_message,
                    'sender_name' => $sender_name,
                    'email_schedule' => $email_schedule,
                    'product_id' => $product_id,
                    'giftcard_price' => $giftcard_price,
                    'delivery_channel' => $delivery_channel,
                    'receiver_phone' => $receiver_phone,
                    'use_checkout_receiver' => $use_checkout_receiver,
                );

                $entry_validation = apply_filters('wallregi_validate_giftcard_form_entry', null, $form_entry);
                if (is_wp_error($entry_validation)) {
                    wp_send_json_error(array('message' => $entry_validation->get_error_message()));
                }

                // Validate required fields (default rules when extension does not override).
                if (null === $entry_validation) {
                    if ($use_checkout_receiver) {
                        if ($product_id <= 0 || $giftcard_price <= 0) {
                            wp_send_json_error(['message' => __('Missing or invalid gift card fields.', 'wallet-ready-gift-cards-for-woocommerce')]);
                        }
                    } elseif (
                        empty($receiver_name) ||
                        empty($receiver_email) ||
                        empty($sender_name) ||
                        $product_id <= 0 ||
                        $giftcard_price <= 0
                    ) {
                        wp_send_json_error(['message' => __('Missing or invalid gift card fields.', 'wallet-ready-gift-cards-for-woocommerce')]);
                    }
                }

                // Add custom gift card data to cart item
                $giftcard_data = compact('receiver_name', 'receiver_email', 'receiver_message', 'sender_name', 'email_schedule', 'product_id', 'giftcard_price', 'giftcard_image', 'giftcard_heading', 'giftcard_short_desc');
                $giftcard_data['delivery_channel'] = $delivery_channel;
                $giftcard_data['receiver_phone'] = $receiver_phone;
                $giftcard_data = apply_filters('wallregi_giftcard_cart_item_data', $giftcard_data, $giftcard);
                if ($use_checkout_receiver) {
                    $giftcard_data['checkout_receiver_source'] = $checkout_receiver_product;
                }

                $cart_item_data = ['giftcard_data' => $giftcard_data];
                $cart_item_key = WC()->cart->add_to_cart($product_id, 1, 0, [], $cart_item_data);

                if ($cart_item_key) {
                    do_action('wallregi_after_giftcard_added_to_cart', $cart_item_key, $giftcard_data, 'ajax_form');
                    $processed_giftcards[] = $giftcard_data;
                } else {
                    $detail = __('Failed to add one of the Gift Cards to the cart.', 'wallet-ready-gift-cards-for-woocommerce');
                    $wc_errors = function_exists('wc_get_notices') ? wc_get_notices('error') : array();
                    if (!empty($wc_errors) && is_array($wc_errors)) {
                        $parts = array();
                        foreach ($wc_errors as $notice_row) {
                            if (is_array($notice_row) && !empty($notice_row['notice'])) {
                                $parts[] = wp_strip_all_tags(wc_kses_notice((string) $notice_row['notice']));
                            }
                        }
                        if ($parts) {
                            $detail .= ' ' . implode(' ', array_filter($parts));
                        }
                        wc_clear_notices();
                    }
                    wp_send_json_error(array('message' => $detail));
                }
            }

            // Final response after all gift cards are added
            if (function_exists('wallregi_security_should_log_success') && wallregi_security_should_log_success()) {
                wallregi_security_audit_log(
                    'giftcard_form_add_to_cart',
                    'success',
                    array(
                        'detail' => sprintf('items:%d', count($processed_giftcards)),
                    )
                );
            }

            wp_send_json_success([
                'message' => $success_message,
                'giftcards' => $processed_giftcards,
                'redirect' => wc_get_cart_url(),
            ]);
        }

        /**
         * Sync WooCommerce line prices from giftcard_data (runs on every totals calculation).
         *
         * @param WC_Cart $cart Cart being calculated.
         */
        public function wallregi_sync_giftcard_line_prices_before_totals($cart)
        {
            wallregi_apply_giftcard_prices_to_cart($cart);
        }

        // Change or update woocommerce cart page price
        public function wallregi_woocommerce_cart_contents_changed_callback($cart_contents)
        {
            if (!is_array($cart_contents)) {
                return $cart_contents;
            }

            foreach ($cart_contents as $wallregi_key => $cart_item) {
                if (empty($cart_item['giftcard_data']) || !is_array($cart_item['giftcard_data'])) {
                    continue;
                }
                if (empty($cart_item['data']) || !$cart_item['data'] instanceof WC_Product) {
                    continue;
                }
                if (!isset($cart_item['giftcard_data']['giftcard_price']) || !is_numeric($cart_item['giftcard_data']['giftcard_price'])) {
                    continue;
                }
                $cart_item['data']->set_price((float) $cart_item['giftcard_data']['giftcard_price']);
                $cart_contents[$wallregi_key] = $cart_item;
            }

            return $cart_contents;
        }

        /**
         * Save gift card form data to order item meta
         */
        public function wallregi_giftcard_add_order_item_meta($item, $cart_item_key, $values, $order)
        {
            if (isset($values['giftcard_data']) && !empty($values['giftcard_data'])) {
                $giftcard_data = $values['giftcard_data'];
                $product_id = $giftcard_data['product_id'] ?? 0;

                if (!empty($product_id)) {
                    $product = wc_get_product($product_id);
                    if (!$product instanceof WC_Product || $product->get_type() !== 'wxgiftcard') {
                        return;
                    }

                    $cfg_checkout_src = function_exists('wallregi_get_product_checkout_receiver_source')
                        ? wallregi_get_product_checkout_receiver_source($product_id)
                        : '';
                    $cart_checkout_src = isset($giftcard_data['checkout_receiver_source']) ? $giftcard_data['checkout_receiver_source'] : '';
                    if (
                        $cfg_checkout_src &&
                        $cart_checkout_src &&
                        $cfg_checkout_src === $cart_checkout_src &&
                        in_array($cfg_checkout_src, array('billing', 'shipping'), true) &&
                        $order instanceof WC_Order
                    ) {
                        $giftcard_data = wallregi_merge_order_address_into_giftcard_data($giftcard_data, $order, $cfg_checkout_src);
                    }

                    // Get optional prefix/suffix from form (default to empty string)
                    $prefix = !empty($giftcard_data['prefix']) ? sanitize_text_field($giftcard_data['prefix']) : '';
                    $suffix = !empty($giftcard_data['suffix']) ? sanitize_text_field($giftcard_data['suffix']) : '';

                    // Generate the coupon code with prefix/suffix
                    $generated_code = '';  // wallregi_generate_giftcard_coupon_code($prefix, $suffix);
                    $giftcard_coupon = '';  // preg_replace('/\s+/', '-', $generated_code);

                    // Determine expiry date
                    $enable_custom_expiry_date = get_post_meta($product_id, '_wallregi_enable_custom_expiry_date', true);
                    $wallregi_expiry_period = get_post_meta($product_id, '_wallregi_expiry_date', true);  // e.g. "3 months"
                    $expiry_value = get_post_meta($product_id, '_wallregi_expiry_value', true);
                    $expiry_duration = get_post_meta($product_id, '_wallregi_expiry_duration', true);
                    $manual_expiry_date = get_post_meta($product_id, '_wallregi_manual_expiry_date', true);

                    if (empty($wallregi_expiry_period)) {
                        $wallregi_expiry_period = '3 months';
                    }

                    $wallregi_expiry_date = '';

                    if ($enable_custom_expiry_date === 'yes') {
                        // Priority: manual expiry
                        if (!empty($manual_expiry_date)) {
                            $wallregi_expiry_date = $manual_expiry_date;
                        }
                        // Else use value + duration
                        elseif (!empty($expiry_value) && !empty($expiry_duration)) {
                            $date = new DateTime();
                            switch ($expiry_duration) {
                                case 'days':
                                    $date->modify("+{$expiry_value} days");
                                    $wallregi_expiry_period = "{$expiry_value} days";
                                    break;
                                case 'weeks':
                                    $date->modify("+{$expiry_value} weeks");
                                    $wallregi_expiry_period = "{$expiry_value} weeks";
                                    break;
                                case 'months':
                                    $date->modify("+{$expiry_value} months");
                                    $wallregi_expiry_period = "{$expiry_value} months";
                                    break;
                                case 'years':
                                    $date->modify("+{$expiry_value} years");
                                    $wallregi_expiry_period = "{$expiry_value} years";
                                    break;
                                default:
                                    $date->modify('+3 months');
                                    break;
                            }
                            $wallregi_expiry_date = $date->format('Y-m-d');
                        }
                        // Fallback to selected expiry
                        else {
                            $wallregi_expiry_date = gmdate('Y-m-d', strtotime('+' . $wallregi_expiry_period));
                        }
                    } else {
                        // Use selected expiry or fallback
                        $wallregi_expiry_date = gmdate('Y-m-d', strtotime('+' . $wallregi_expiry_period));
                    }

                    // Allow filters to override expiry date
                    $wallregi_expiry_date = apply_filters('wallregi_giftcard_expiry_date', $wallregi_expiry_date, $wallregi_expiry_period, $product_id);

                    $giftcard_data['email_schedule'] = wallregi_normalize_giftcard_preferred_datetime($giftcard_data['email_schedule'] ?? '');

                    $delivery_channel = function_exists('wallregi_sanitize_delivery_channel')
                        ? wallregi_sanitize_delivery_channel($giftcard_data['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL)
                        : WALLREGI_DELIVERY_CHANNEL_EMAIL;
                    $receiver_phone = function_exists('wallregi_sanitize_giftcard_phone')
                        ? wallregi_sanitize_giftcard_phone($giftcard_data['receiver_phone'] ?? '')
                        : '';

                    $item->add_meta_data('_wallregi_giftcard_data', $giftcard_data, true);
                    $item->add_meta_data('giftcard_product_id', $giftcard_data['product_id'] ?? '');
                    $item->add_meta_data('giftcard_product_price', $giftcard_data['giftcard_price'] ?? '');
                    $item->add_meta_data('giftcard_product_image', $giftcard_data['giftcard_image'] ?? '');
                    $item->add_meta_data('giftcard_receiver_name', $giftcard_data['receiver_name'] ?? '');
                    $item->add_meta_data('giftcard_receiver_email', $giftcard_data['receiver_email'] ?? '');
                    if ('' !== $receiver_phone) {
                        $item->add_meta_data('giftcard_receiver_phone', $receiver_phone, true);
                    }
                    $item->add_meta_data('giftcard_sender_name', $giftcard_data['sender_name'] ?? '');
                    $item->add_meta_data('giftcard_message', $giftcard_data['receiver_message'] ?? '');
                    $item->add_meta_data('giftcard_heading', $giftcard_data['giftcard_heading'] ?? '');
                    $item->add_meta_data('short_description', $giftcard_data['short_description'] ?? '');
                    $item->add_meta_data('giftcard_date_expiry', $wallregi_expiry_date);
                    $item->add_meta_data('giftcard_expiry_period', $wallregi_expiry_period);
                    $item->add_meta_data('giftcard_coupon_number', $giftcard_coupon, true);
                    do_action('wallregi_after_giftcard_order_item_meta_added', $item, $values, $order, $giftcard_data);
                }
            }
        }

        public function wallregi_hide_giftcard_meta_on_thank_you_page($html, $item, $args)
        {
            if (is_order_received_page()) {
                // Define meta keys to exclude
                $exclude_keys = [
                    'giftcard_product_id',
                    'giftcard_product_price',
                    'giftcard_product_image',
                    'giftcard_heading',
                    'short_description',
                    'giftcard_expiry_period',
                ];

                // Map for custom label replacements
                $custom_labels = [
                    'giftcard_receiver_name'  => __('Receiver Name', 'wallet-ready-gift-cards-for-woocommerce'),
                    'giftcard_receiver_email' => __('Receiver Email', 'wallet-ready-gift-cards-for-woocommerce'),
                    'giftcard_receiver_phone' => __('Receiver Phone', 'wallet-ready-gift-cards-for-woocommerce'),
                    'giftcard_sender_name'    => __('Sender Name', 'wallet-ready-gift-cards-for-woocommerce'),
                    'giftcard_message'        => __('Greeting/Message', 'wallet-ready-gift-cards-for-woocommerce'),
                    'giftcard_date_expiry'    => __('Giftcard Expiry Date', 'wallet-ready-gift-cards-for-woocommerce'),
                    'giftcard_coupon_number'  => __('Giftcard Number', 'wallet-ready-gift-cards-for-woocommerce'),
                ];

                // Start building custom HTML
                $html = '<ul class="wc-item-meta">';
                $meta_data = $item->get_all_formatted_meta_data();

                foreach ($meta_data as $meta) {
                    if (!in_array($meta->key, $exclude_keys)) {
                        $wallregi_value = wp_kses_post(trim($meta->display_value));

                        if (filter_var($wallregi_value, FILTER_VALIDATE_URL)) {
                            $wallregi_value = '<a href="' . esc_url($wallregi_value) . '">' . esc_url($wallregi_value) . '</a>';
                        }

                        // Use custom label if available
                        $label = isset($custom_labels[$meta->key]) ? $custom_labels[$meta->key] : $meta->display_key;
                        $label = apply_filters('woocommerce_order_item_display_meta_key', $label, $meta, $item);

                        $html .= '<li>';
                        $html .= '<strong class="wc-item-meta-label">' . wp_kses_post($label) . ' :</strong>';
                        $html .= ' <p>' . $wallregi_value . '</p>';
                        $html .= '</li>';
                    }
                }

                $html .= '</ul>';
            }

            return $html;
        }

        /**
         * Hide specific gift card meta keys from WooCommerce emails
         */
        public function wallregi_hide_giftcard_meta_from_emails($formatted_meta, $item)
        {
            // Meta keys to hide
            $exclude_keys = [
                'giftcard_product_id',
                'giftcard_product_price',
                'giftcard_product_image',
                'giftcard_heading',
                'short_description',
                'giftcard_expiry_period'
            ];

            // Custom label replacements
            $custom_labels = [
                'giftcard_receiver_name'  => __('Receiver Name', 'wallet-ready-gift-cards-for-woocommerce'),
                'giftcard_receiver_email' => __('Receiver Email', 'wallet-ready-gift-cards-for-woocommerce'),
                'giftcard_receiver_phone' => __('Receiver Phone', 'wallet-ready-gift-cards-for-woocommerce'),
                'giftcard_sender_name'    => __('Sender Name', 'wallet-ready-gift-cards-for-woocommerce'),
                'giftcard_message'        => __('Greeting/Message', 'wallet-ready-gift-cards-for-woocommerce'),
                'giftcard_date_expiry'    => __('Giftcard Expiry Date', 'wallet-ready-gift-cards-for-woocommerce'),
                'giftcard_coupon_number'  => __('Giftcard Number', 'wallet-ready-gift-cards-for-woocommerce'),
            ];

            $new_formatted_meta = [];

            foreach ($formatted_meta as $meta) {
                if (!in_array($meta->key, $exclude_keys, true)) {
                    $label = isset($custom_labels[$meta->key]) ? $custom_labels[$meta->key] : $meta->display_key;
                    $label = apply_filters('woocommerce_order_item_display_meta_key', $label, $meta, $item);
                    $wallregi_value = wp_kses_post(trim($meta->display_value));

                    if (filter_var($wallregi_value, FILTER_VALIDATE_URL)) {
                        $wallregi_value = '<a href="' . esc_url($wallregi_value) . '">' . esc_url($wallregi_value) . '</a>';
                    }

                    $meta->display_key = $label;
                    $meta->display_value = $wallregi_value;

                    $new_formatted_meta[] = $meta;
                }
            }

            return $new_formatted_meta;
        }

        /*
         * Handles gift card generation and data insertion.
         */
        public function wallregi_order_complete_insert_data($order_id, $old_status, $new_status)
        {
            global $wpdb;

            $wallregi_giftcard_table = wallregi_giftcard_db_table_name();
            $wallregi_transaction_table = wallregi_transaction_db_table_name();

            $order = wc_get_order($order_id);

            // 3. Generate gift cards if processing/completed
            if (in_array($new_status, ['processing', 'completed'])) {
                if (sanitize_text_field($order->get_meta('_wallregi_giftcard_processed')) === 'yes') {
                    return;  // Skip if already processed
                }

                $giftCardProcessed = false;
                foreach ($order->get_items() as $item_id => $item) {
                    $product_id = $item->get_product_id();
                    if (empty($product_id)) {
                        continue;  // Skip if no product ID
                    }
                    $product = wc_get_product($product_id);
                    $product_type = $product->get_type();
                    if ($product_type !== 'wxgiftcard') {
                        continue;  // Only process if product type is 'wxgiftcard'
                    }

                    $giftcard_coupon_number = $item->get_meta('giftcard_coupon_number', true);
                    if (!empty($giftcard_coupon_number)) {
                        continue;  // Skip if gift card already exists
                    }

                    $giftcard_data = $item->get_meta('_wallregi_giftcard_data', true);

                    if (empty($giftcard_data)) {
                        continue;  // Skip if no gift card data
                    }

                    $prefix = !empty($giftcard_data['prefix']) ? sanitize_text_field($giftcard_data['prefix']) : '';
                    $suffix = !empty($giftcard_data['suffix']) ? sanitize_text_field($giftcard_data['suffix']) : '';

                    // Generate the coupon code with prefix/suffix
                    $generated_code = wallregi_generate_giftcard_coupon_code($prefix, $suffix);
                    $giftcard_coupon = preg_replace('/\s+/', '-', $generated_code);

                    $initial_amount = floatval($giftcard_data['giftcard_price'] ?? 0);
                    $current_amount = $initial_amount;

                    // Email schedule (preferred_date_time): never persist epoch or invalid values.
                    $email_schedule = wallregi_normalize_giftcard_preferred_datetime($giftcard_data['email_schedule'] ?? '');

                    $wallregi_expiry_date = $item->get_meta('giftcard_date_expiry', true);
                    $wallregi_expiry_period = $item->get_meta('giftcard_expiry_period', true);
                    $receipent_name = $item->get_meta('giftcard_receiver_name', true);
                    $receipent_email = $item->get_meta('giftcard_receiver_email', true);
                    $sender_name = $item->get_meta('giftcard_sender_name', true);
                    $message = $item->get_meta('giftcard_message', true);
                    $giftcard_image = $item->get_meta('giftcard_product_image', true);

                    $order_channel = function_exists('wallregi_sanitize_delivery_channel')
                        ? wallregi_sanitize_delivery_channel($giftcard_data['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL)
                        : WALLREGI_DELIVERY_CHANNEL_EMAIL;
                    if ('' === trim((string) $receipent_email)) {
                        $fallback_email = $order->get_billing_email();
                        if (is_email($fallback_email)) {
                            $receipent_email = $fallback_email;
                        } elseif (in_array($order_channel, array(WALLREGI_DELIVERY_CHANNEL_SMS, WALLREGI_DELIVERY_CHANNEL_NONE), true)) {
                            $receipent_email = 'sms-only@invalid.local';
                        }
                    }

                    $giftcard_data_array = [
                        'order_id' => $order_id,
                        'item_id' => $item_id,
                        'product_id' => $product_id,
                        'initial_amount' => $initial_amount,
                        'current_amount' => $current_amount,
                        'giftcard_number' => $giftcard_coupon,
                        'expiry_date' => $wallregi_expiry_date,
                        'expiry_period' => $wallregi_expiry_period,
                        'total_redeem' => 0,
                        'receipent_name' => $receipent_name,
                        'receipent_email' => $receipent_email,
                        'sender_name' => $sender_name,
                        'message' => $message,
                        'send_date_time' => '0000-00-00 00:00:00',
                        'preferred_date_time' => $email_schedule,
                        'giftcard_image' => $giftcard_image,
                        'created_at' => current_time('mysql'),
                        'created_by' => get_current_user_id(),
                        'send_mail_time' => '0000-00-00 00:00:00',
                        'email_status' => 0,  // Pending email
                        'delivery_channel' => function_exists('wallregi_sanitize_delivery_channel')
                            ? wallregi_sanitize_delivery_channel($giftcard_data['delivery_channel'] ?? WALLREGI_DELIVERY_CHANNEL_EMAIL)
                            : WALLREGI_DELIVERY_CHANNEL_EMAIL,
                        'receipent_phone' => function_exists('wallregi_sanitize_giftcard_phone')
                            ? wallregi_sanitize_giftcard_phone($giftcard_data['receiver_phone'] ?? '')
                            : '',
                        'sms_status' => 0,
                        'status' => 'active'
                    ];

                    $giftcard_data_array = apply_filters('wallregi_giftcard_db_insert_data', $giftcard_data_array, $giftcard_data, $item, $order);

                    // Insert into gift card table
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                    $inserted = $wpdb->insert($wallregi_giftcard_table, $giftcard_data_array);
                    $giftcard_id = $wpdb->insert_id;

                    // Insert into transaction table
                    // phpcs:ignore
                    $transaction_table_array = [
                        'giftcard_id' => $giftcard_id,
                        'amount' => $current_amount,
                        'order_id' => $order_id,
                        'created_by' => get_current_user_id(),
                        'reconciled' => 0,
                        'message' => 'Gift card purchased amount',
                    ];
                    if ($inserted === false) {
                        continue;
                    }

                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom transaction table.
                    $inserted_transaction = $wpdb->insert($wallregi_transaction_table, $transaction_table_array);
                    if ($inserted_transaction === false) {
                        continue;
                    }

                    // Save coupon meta for the item
                    $item->add_meta_data('giftcard_coupon_number', $giftcard_coupon, true);
                    $item->save();
                    // Hook for create pass in epasscard plugin
                    do_action('wallregi_giftcard_created', $giftcard_id, 'create_giftcard');
                    $giftCardProcessed = true;
                }

                // Mark order as processed to prevent multiple executions
                if ($giftCardProcessed) {
                    $order->update_meta_data('_wallregi_giftcard_processed', 'yes');
                    $order->save();
                }
            } else {
                if (sanitize_text_field($order->get_meta('_wallregi_giftcard_processed')) === 'yes') {
                    $deleteGiftCardProcessed = false;
                    foreach ($order->get_items() as $item_id => $item) {
                        $product_id = $item->get_product_id();
                        if (empty($product_id)) {
                            continue;  // Skip if no product ID
                        }
                        $product = wc_get_product($product_id);
                        $product_type = $product->get_type();
                        if ($product_type !== 'wxgiftcard') {
                            continue;  // Only process if product type is 'wxgiftcard'
                        }
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
                        $wpdb->update(
                            $wallregi_giftcard_table,
                            ['status' => 'cancelled'],
                            [
                                'order_id' => $order_id,
                                'item_id' => $item_id,
                            ]
                        );

                        // Optional: also update transaction status or note if needed
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom transaction table.
                        $wpdb->update($wallregi_transaction_table, ['reconciled' => 1], ['order_id' => $order_id]);

                        $deleteGiftCardProcessed = true;
                    }

                    // Optional: clear the processed flag
                    if ($deleteGiftCardProcessed) {
                        $order->delete_meta_data('_wallregi_giftcard_processed');
                        $order->save();
                    }
                    return;
                }
            }
        }

        // show pdf download link in order success page
        public function wallregi_item_pdf_download_link($item_id, $item, $order)
        {
            $productId = $item->get_product_id();
            $product = wc_get_product($productId);
            if (!$product) {
                return;
            }

            global $wpdb;

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
            $gift_row = $wpdb->get_row(
                $wpdb->prepare(
                    'SELECT `giftcard_number`, `epass_data` FROM %i WHERE `item_id` = %d LIMIT 1',
                    wallregi_giftcard_db_table_name(),
                    $item_id
                ),
                ARRAY_A
            );

            $giftcard_number = is_array($gift_row) && isset($gift_row['giftcard_number']) ? $gift_row['giftcard_number'] : '';
            $epass_json = is_array($gift_row) && isset($gift_row['epass_data']) ? $gift_row['epass_data'] : '';

            $pass_link = '';
            if (is_string($epass_json) && '' !== $epass_json) {
                $decoded = json_decode($epass_json, true);
                if (is_array($decoded) && !empty($decoded['passLink']) && is_string($decoded['passLink'])) {
                    $pass_link = trim($decoded['passLink']);
                }
            }
            if ('' === $pass_link && $item instanceof WC_Order_Item_Product) {
                $meta_link = $item->get_meta('_wallregi_epass_pass_link', true);
                if ('' === trim((string) $meta_link)) {
                    $meta_link = $item->get_meta('_wallregi_gtw_pass_link', true);
                }
                $pass_link = is_string($meta_link) ? trim($meta_link) : '';
            }

            if (!empty($giftcard_number)) {
                $wallregi_nonce = wp_create_nonce('gcpdf_nonce');
                $download_url = site_url() . '?giftcard-pdf=true&noncekey=' . $wallregi_nonce . '&giftcode=' . base64_encode($giftcard_number);
                // phpcs:ignore
                echo '<a href="' . esc_url($download_url) . '" class="giftcard_pdf_download">' . esc_html__('Download PDF', 'wallet-ready-gift-cards-for-woocommerce') . '</a>';
            }

            if ('' !== $pass_link && function_exists('wallregi_epass_print_wallet_anchor')) {
                echo '<span class="wallregi-epass-wallet-wrap" style="display:inline-block;margin-left:8px;">';
                wallregi_epass_print_wallet_anchor(
                    $pass_link,
                    ['class' => 'wallregi-epass-wallet-link wallregi-epass-wallet-link--order']
                );
                echo '</span>';
            }
        }

        // show pdf download in admin order page
        public function wallregi_admin_item_pdf_download_link($item_id, $item, $product)
        {
            global $wpdb;

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom gift card table.
            $gift_row = $wpdb->get_row(
                $wpdb->prepare(
                    'SELECT `giftcard_number`, `epass_data` FROM %i WHERE `item_id` = %d LIMIT 1',
                    wallregi_giftcard_db_table_name(),
                    $item_id
                ),
                ARRAY_A
            );

            $giftcard_number = is_array($gift_row) && isset($gift_row['giftcard_number']) ? $gift_row['giftcard_number'] : '';
            $epass_json = is_array($gift_row) && isset($gift_row['epass_data']) ? $gift_row['epass_data'] : '';

            $pass_link = '';
            if (is_string($epass_json) && '' !== $epass_json) {
                $decoded = json_decode($epass_json, true);
                if (is_array($decoded) && !empty($decoded['passLink']) && is_string($decoded['passLink'])) {
                    $pass_link = trim($decoded['passLink']);
                }
            }
            if ('' === $pass_link && $item instanceof WC_Order_Item_Product) {
                $meta_link = $item->get_meta('_wallregi_epass_pass_link', true);
                if ('' === trim((string) $meta_link)) {
                    $meta_link = $item->get_meta('_wallregi_gtw_pass_link', true);
                }
                $pass_link = is_string($meta_link) ? trim($meta_link) : '';
            }

            if (!is_null($product)) {
                if (!empty($giftcard_number)) {
                    $wallregi_nonce = wp_create_nonce('gcpdf_nonce');
                    $download_url = site_url() . '?giftcard-pdf=true&noncekey=' . $wallregi_nonce . '&giftcode=' . base64_encode($giftcard_number);
                    echo '<a target="_blank" href="' . esc_url($download_url) . '" class="giftcard_pdf_download">' . esc_html__('Download PDF', 'wallet-ready-gift-cards-for-woocommerce') . '</a>';
                }
                if ('' !== $pass_link && function_exists('wallregi_epass_print_wallet_anchor')) {
                    echo '<span class="wallregi-epass-wallet-wrap" style="display:inline-block;margin-left:8px;">';
                    wallregi_epass_print_wallet_anchor(
                        $pass_link,
                        ['class' => 'wallregi-epass-wallet-link wallregi-epass-wallet-link--admin']
                    );
                    echo '</span>';
                }
            }
        }
    }
}

// Instantiate the frontend class
function wallregi_initialize_gift_card_frontend_class()
{
    return new WALLREGI_Gift_Card_Frontend();
}

add_action('plugins_loaded', 'wallregi_initialize_gift_card_frontend_class');

/**
 * Apply giftcard_data.giftcard_price to each gift card line's WC_Product price.
 *
 * Cart/checkout edit updates giftcard_data directly; this keeps order review and totals in sync.
 *
 * @param WC_Cart|null $cart Optional cart instance.
 */
function wallregi_apply_giftcard_prices_to_cart($cart = null)
{
    if (!function_exists('WC') || !WC()->cart) {
        return;
    }

    if (!$cart instanceof WC_Cart) {
        $cart = WC()->cart;
    }

    if (!$cart) {
        return;
    }

    foreach ($cart->get_cart() as $cart_item) {
        if (empty($cart_item['giftcard_data']) || !is_array($cart_item['giftcard_data'])) {
            continue;
        }
        if (empty($cart_item['data']) || !$cart_item['data'] instanceof WC_Product) {
            continue;
        }
        if (!isset($cart_item['giftcard_data']['giftcard_price']) || !is_numeric($cart_item['giftcard_data']['giftcard_price'])) {
            continue;
        }

        $cart_item['data']->set_price((float) $cart_item['giftcard_data']['giftcard_price']);
    }
}

/**
 * Get dynamic gift card display price.
 */
function wallregi_get_giftcard_display_price($product_id, $giftcard_data = [])
{
    $product = wc_get_product($product_id);

    if (!$product) {
        return [
            'price_formatted' => '',
            'price_options' => [],
            'manual_price' => false,
        ];
    }

    // Correct way to access meta for the current product
    $wallregi_enable_variation_price = get_post_meta($product_id, '_wallregi_enable_variation_price', true);
    $wallregi_enable_manual_price = get_post_meta($product_id, '_wallregi_enable_manual_price', true);

    // Get custom gift card prices
    $wallregi_custom_prices = get_post_meta($product_id, '_wallregi_custom_prices', true);
    $wallregi_custom_prices = is_array($wallregi_custom_prices) ? $wallregi_custom_prices : [];

    // Determine display price
    if (isset($giftcard_data['giftcard_price']) && is_numeric($giftcard_data['giftcard_price'])) {
        $display_price = floatval($giftcard_data['giftcard_price']);
    } elseif ($product->is_on_sale()) {
        $display_price = $product->get_sale_price();
    } else {
        $display_price = $product->get_price();
    }

    // If either variation or manual pricing is enabled, return options instead of fixed price
    if ($wallregi_enable_variation_price === 'yes' && $wallregi_enable_manual_price === 'yes') {
        return [
            'price_formatted' => '',
            'price_options' => $wallregi_custom_prices,
            'manual_price' => true,
        ];
    }
    if ($wallregi_enable_variation_price === 'yes' && $wallregi_enable_manual_price === 'no') {
        return [
            'price_formatted' => '',
            'price_options' => $wallregi_custom_prices,
            'manual_price' => false,
        ];
    }

    return [
        'price_formatted' => $display_price,
        'price_options' => [],
        'manual_price' => false,
    ];
}

/**
 * Uploads an external image URL into the WordPress Media Library.
 *
 * This function downloads an image from a remote URL, stores it temporarily,
 * and then uses WordPress core functions to sideload it into the Media Library.
 */
function wallregi_image_in_wp_media_library($wallregi_file, $description = '')
{
    // Load required WordPress core media/image functions
    if (!function_exists('download_url')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }
    if (!function_exists('media_handle_sideload')) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
    }
    if (!function_exists('wp_read_image_metadata')) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }

    // Download image to a temporary file
    $tmp = download_url($wallregi_file);

    // If download failed, return the error
    if (is_wp_error($tmp)) {
        return $tmp;
    }

    // Prepare the file array for sideload
    $wallregi_file_array = [
        'name' => wp_basename($wallregi_file),
        'tmp_name' => $tmp,
    ];

    // Handle sideload into media library
    $wallregi_attachment_id = media_handle_sideload($wallregi_file_array, 0, $description);

    // Cleanup temp file if error occurs
    if (is_wp_error($wallregi_attachment_id)) {
        // phpcs:ignore
        @unlink($wallregi_file_array['tmp_name']);
        return $wallregi_attachment_id;
    }

    return $wallregi_attachment_id;  // return the attachment ID
}

/**
 * Expose a custom image for cart items to the WooCommerce Store API (Cart block).
 * unchanged so other products are unaffected.
 */
add_filter('woocommerce_store_api_cart_item_images', function ($images, $cart_item, $cart_item_key) {
    unset($cart_item_key);

    if (empty($cart_item['giftcard_data']) || !is_array($cart_item['giftcard_data'])) {
        return $images;
    }

    if (empty($cart_item['data']) || !is_a($cart_item['data'], 'WC_Product')) {
        return $images;
    }

    $product = $cart_item['data'];
    $gift_img = $cart_item['giftcard_data']['giftcard_image'] ?? '';

    $image_path = !empty($gift_img)
        ? $gift_img
        : wp_get_attachment_url($product->get_image_id());

    if (!$image_path) {
        return $images;
    }

    return [
        (object) [
            'id' => (int) 0,
            'src' => (string) $image_path,
            'thumbnail' => (string) $image_path,
            'srcset' => (string) '',
            'sizes' => (string) '',
            'name' => (string) __('Gift Card Image', 'wallet-ready-gift-cards-for-woocommerce'),
            'alt' => (string) esc_attr__('Gift Card Image', 'wallet-ready-gift-cards-for-woocommerce'),
        ],
    ];
},
    10,
    3);

// Replace order item thumbnails (admin, email, frontend) with selected gift card image.
add_filter('woocommerce_admin_order_item_thumbnail', 'wallregi_order_item_giftcard_image', 10, 3);
add_filter('woocommerce_order_item_thumbnail', 'wallregi_order_item_giftcard_image', 10, 2);

function wallregi_order_item_giftcard_image($thumb, $item, $maybe_item = null)
{
    $item_obj = is_object($item) ? $item : (is_object($maybe_item) ? $maybe_item : null);
    $gift_img = $item_obj && method_exists($item_obj, 'get_meta')
        ? $item_obj->get_meta('giftcard_product_image', true)
        : ($item['giftcard_product_image'] ?? '');

    return !empty($gift_img)
        ? '<img src="' . esc_url($gift_img) . '" alt="' . esc_attr__('Gift Card Image', 'wallet-ready-gift-cards-for-woocommerce') . '" width="150" />'
        : $thumb;
}
