<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}


return [
    'heading_color'                  => '#565757',
    'para_color'                     => '#9d9d9d',
    'background_style'               => 'solid',
    'solid_color'                    => '#f8fafb',
    'gradient_start'                 => '#e7eff2',
    'gradient_middle'                => '#d7ebe7',
    'gradient_end'                   => '#e7eff2',
    'bg_image_url'                   => WALLREGI_PLUGIN_URL . 'frontend/assets/bg-image.png',

    // Single Giftcard Default Header Title Default Values
    'giftcard_header_title_styles_group' => [
        'giftcard_header_title_text_color'      => '#333333',
        'giftcard_header_title_font_size'       => 16,
        'giftcard_header_title_font_weight'     => 'normal',
        'giftcard_header_title_text_align'      => 'left',
        'giftcard_header_title_text_transform'  => 'capitalize',
    ],

    // Single Giftcard Default Header Border Default Values
    'giftcard_header_border_group' => [
        'giftcard_header_border_width'      => 1,
        'giftcard_header_border_styles'     => 'solid',
        'giftcard_header_border_color'      => '#c5c5c5',
        'giftcard_header_bg_color'          => '#f3f3f3',
        'giftcard_header_border_position'   => 'bottom',
    ],

    // Single Giftcard Default Header Box Model Default Values
    'giftcard_header_box_model_group' => [
        'giftcard_header_padding_width'      => 8,
        'giftcard_header_padding_position'     => 'all',
        'giftcard_header_radius_width'      => 0,
        'giftcard_header_radius_position'   => 'none',
    ],

    // Single Giftcard Default Header Pseudo (Hover) Default Values
    'giftcard_header_pseudo_styles_group' => [
        'giftcard_header_pseudo_text_color'          => '#7e7c7c',
        'giftcard_header_pseudo_bg_color'          => '#f4f8fb',
        'giftcard_header_pseudo_border_color'      => '#be88eb',
    ],

    // Single Giftcard Active Header Title Default Values
    'giftcard_active_header_title_styles_group' => [
        'giftcard_active_header_title_text_color'    => '#ffffff',
        'giftcard_active_header_title_font_size'     => 18,
        'giftcard_active_header_title_font_weight'   => 'bold',
        'giftcard_active_header_title_text_align'    => 'left',
        'giftcard_active_header_title_text_transform'     => 'capitalize',
    ],

    // Single Giftcard Active Header Border Default Values
    'giftcard_active_header_border_group' => [
        'giftcard_active_header_border_width'      => 1,
        'giftcard_active_header_border_styles'     => 'solid',
        'giftcard_active_header_border_color'      => '#7f54b3',
        'giftcard_active_header_bg_color'          => '#7f54b3',
        'giftcard_active_header_border_position'   => 'top',
    ],

    // Single Giftcard Active Header Box Model Default Values
    'giftcard_active_header_box_model_group' => [
        'giftcard_active_header_padding_width'      => 8,
        'giftcard_active_header_padding_position'     => 'all',
        'giftcard_active_header_radius_width'      => 0,
        'giftcard_active_header_radius_position'   => 'none',
    ],

    // Single Giftcard Active Header Pseudo (Hover) Default Values
    'giftcard_active_header_pseudo_styles_group' => [
        'giftcard_active_header_pseudo_text_color'          => '#f4f8fb',
        'giftcard_active_header_pseudo_bg_color'          => '#be88eb',
        'giftcard_active_header_pseudo_border_color'      => '#f4f8fb',
    ],

    // Single Giftcard Contents Body Box Model Default Values
    'giftcard_body_fields_group' => [
        'giftcard_body_border_width'      => 1,
        'giftcard_body_border_styles'     => 'solid',
        'giftcard_body_border_color'      => '#7f54b3',
        'giftcard_body_border_position'   => 'all',
        'giftcard_body_radius_width'      => 5,
        'giftcard_body_radius_position'   => 'bottom',

        'giftcard_body_padding_width'      => 15,
        'giftcard_body_padding_position'     => 'all',
    ],



/*====================================
* GIFTCARD RIGHT SIDE CONTENTS SET DEFAULT VALUES START
*====================================================== */

    // Giftcard Contents Body Right Side Contents Summary Text Set Default Values
    'giftcard_right_side_contents_group' => [
        'giftcard_right_side_contents_text_color'         => '#333333',
        'giftcard_right_side_contents_font_size'          => 14,
        'giftcard_right_side_contents_font_weight'        => 'normal',
        'giftcard_right_side_contents_text_align'         => 'justify',
        'giftcard_right_side_contents_text_transform'     => 'none',

        'giftcard_right_side_contents_border_width'       => 0,
        'giftcard_right_side_contents_border_styles'      => 'solid',
        'giftcard_right_side_contents_border_color'       => '#7f54b3',
        'giftcard_right_side_contents_border_position'    => 'none',
        'giftcard_right_side_contents_radius_width'       => 0,
        'giftcard_right_side_contents_radius_position'    => 'none',

        'giftcard_right_side_contents_padding_width'      => 0,
        'giftcard_right_side_contents_padding_position'   => 'none',
        'giftcard_right_side_contents_margin_width'       => 10,
        'giftcard_right_side_contents_margin_position'    => 'bottom',
    ],

    // Giftcard Right Side Custom Price Box Set Default Values
    'giftcard_custom_price_box_group' => [

        'giftcard_custom_price_box_border_width'        => 0,
        'giftcard_custom_price_box_border_styles'       => 'solid',
        'giftcard_custom_price_box_border_color'        => '#7f54b3',
        'giftcard_custom_price_box_border_position'     => 'none',
        'giftcard_custom_price_box_radius_width'        => 0,
        'giftcard_custom_price_box_radius_position'     => 'none',

        'giftcard_custom_price_box_padding_width'       => 0,
        'giftcard_custom_price_box_padding_position'    => 'none',
        'giftcard_custom_price_box_margin_width'        => 10,
        'giftcard_custom_price_box_margin_position'     => 'top_bottom',
    ],

    // Giftcard Right Side Custom Price Heading Set Default Values
    'giftcard_custom_price_heading_group' => [
        'giftcard_custom_price_heading_text_color'        => '#333333',
        'giftcard_custom_price_heading_font_size'         => 16,
        'giftcard_custom_price_heading_font_weight'       => 'normal',
        'giftcard_custom_price_heading_text_align'        => 'left',
        'giftcard_custom_price_heading_text_transform'    => 'none',

        'giftcard_custom_price_heading_margin_width'      => 10,
        'giftcard_custom_price_heading_margin_position'   => 'bottom',
    ],

    // Giftcard Right Side Custom Price Button Group Set Default Values
    'giftcard_price_button_group' => [
        'giftcard_price_button_text_color'         => '#333333',
        'giftcard_price_button_font_size'          => 14,
        'giftcard_price_button_font_weight'        => 'bold',
        'giftcard_price_button_text_align'         => 'center',
        'giftcard_price_button_bg_color'           => '#f3f3f3',

        'giftcard_price_button_border_width'       => 1,
        'giftcard_price_button_border_styles'      => 'solid',
        'giftcard_price_button_border_color'       => '#7f54b3',
        'giftcard_price_button_border_position'    => 'all',
        'giftcard_price_button_radius_width'       => 5,
        'giftcard_price_button_radius_position'    => 'all',

        'giftcard_price_button_padding_width'      => 25,
        'giftcard_price_button_padding_position'   => 'left_right',
        'giftcard_price_button_margin_width'       => 10,
        'giftcard_price_button_margin_position'    => 'bottom',
    ],

    // Giftcard Right Side Gallery Images Box Set Default Values
    'giftcard_img_gallery_box_group' => [

        'giftcard_img_gallery_box_border_width'        => 0,
        'giftcard_img_gallery_box_border_styles'       => 'solid',
        'giftcard_img_gallery_box_border_color'        => '#7f54b3',
        'giftcard_img_gallery_box_border_position'     => 'none',
        'giftcard_img_gallery_box_radius_width'        => 0,
        'giftcard_img_gallery_box_radius_position'     => 'none',

        'giftcard_img_gallery_box_padding_width'       => 0,
        'giftcard_img_gallery_box_padding_position'    => 'none',
        'giftcard_img_gallery_box_margin_width'        => 10,
        'giftcard_img_gallery_box_margin_position'     => 'top_bottom',
    ],

    // Giftcard Right Side Gallery Images Heading Set Default Values
    'giftcard_img_gallery_heading_group' => [
        'giftcard_img_gallery_heading_text_color'        => '#333333',
        'giftcard_img_gallery_heading_font_size'         => 16,
        'giftcard_img_gallery_heading_font_weight'       => 'normal',
        'giftcard_img_gallery_heading_text_align'        => 'left',
        'giftcard_img_gallery_heading_text_transform'    => 'none',

        'giftcard_img_gallery_heading_margin_width'      => 10,
        'giftcard_img_gallery_heading_margin_position'   => 'bottom',
    ],

    // Giftcard Right Side Gallery Item Images Set Default Values
    'giftcard_img_gallery_item_group' => [
        'giftcard_img_gallery_item_border_width'       => 1,
        'giftcard_img_gallery_item_border_styles'      => 'solid',
        'giftcard_img_gallery_item_border_color'       => '#7f54b3',
        'giftcard_img_gallery_item_border_position'    => 'all',
        'giftcard_img_gallery_item_radius_width'       => 2,
        'giftcard_img_gallery_item_radius_position'    => 'all',

    ],

    // Giftcard Right Side Gallery Item Images Pseudo Set Default Values
    'giftcard_img_gallery_item_pseudo_group' => [
        'giftcard_img_gallery_item_pseudo_shadow_type'        => 'outer',
        'giftcard_img_gallery_item_pseudo_shadow_horizontal'  => 0,
        'giftcard_img_gallery_item_pseudo_shadow_vertical'    => 4,
        'giftcard_img_gallery_item_pseudo_shadow_blur'        => 12,
        'giftcard_img_gallery_item_pseudo_shadow_spread'      => 0,
        'giftcard_img_gallery_item_pseudo_shadow_color'       => '#c0c0c0',
        'giftcard_img_gallery_item_pseudo_border_styles'      => 'solid',
        'giftcard_img_gallery_item_pseudo_border_color'       => '#be88eb',

    ],




/*====================================
* GIFTCARD RIGHT SIDE CONTENTS SET DEFAULT VALUES END
*====================================================== */

/*============================
* APPLY GIFTCARD SET DEFAULT VALUES END
*======================================== */

    // Apply Giftcard Container Set Default Values
    'apply_giftcard_container_group' => [
        'apply_giftcard_container_border_width'     => 2,
        'apply_giftcard_container_border_styles'    => 'solid',
        'apply_giftcard_container_border_color'     => '#7f54b3',
        'apply_giftcard_container_border_position'  => 'all',
        'apply_giftcard_container_radius_width'     => 5,
        'apply_giftcard_container_radius_position'  => 'all',

    ],

    // Apply Giftcard Accordion Header Padding Set Default Values
    'apply_giftcard_container_header_group' => [
        'apply_giftcard_container_header_text_color'        => '#ffffff',
        'apply_giftcard_container_header_bg_color'          => '#7f54b3',
        'apply_giftcard_container_header_font_size'         => 16,
        'apply_giftcard_container_header_font_weight'       => 'normal',
        'apply_giftcard_container_header_text_align'        => 'left',
        'apply_giftcard_container_header_text_transform'    => 'none',

        'apply_giftcard_container_header_padding_width'     => 15,
        'apply_giftcard_container_header_padding_position'  => 'all',
    ],

    // Apply Giftcard Accordion Header Padding Set Default Values
    'apply_giftcard_coupon_code_box_group' => [
        'apply_giftcard_coupon_code_box_padding_width'     => 10,
        'apply_giftcard_coupon_code_box_padding_position'  => 'all',
    ],

    // Apply Giftcard Coupon Code List Item Set Default Values
    'apply_giftcard_coupon_code_group' => [
        'apply_giftcard_coupon_code_text_color'         => '#333333',
        'apply_giftcard_coupon_code_font_size'          => 14,
        'apply_giftcard_coupon_code_font_weight'        => 'normal',
        'apply_giftcard_coupon_code_text_align'         => 'left',

        'apply_giftcard_coupon_code_padding_width'      => 10,
        'apply_giftcard_coupon_code_padding_position'   => 'all',
        'apply_giftcard_coupon_code_margin_width'       => 5,
        'apply_giftcard_coupon_code_margin_position'    => 'top_bottom',

        'apply_giftcard_coupon_code_border_width'       => 1,
        'apply_giftcard_coupon_code_border_styles'      => 'solid',
        'apply_giftcard_coupon_code_border_color'       => '#7f54b3',
        'apply_giftcard_coupon_code_border_position'    => 'all',
        'apply_giftcard_coupon_code_radius_width'       => 5,
        'apply_giftcard_coupon_code_radius_position'    => 'all',
    ],

/*==============================
* APPLY GIFTCARD SET DEFAULT VALUES END
*======================================= */


];



