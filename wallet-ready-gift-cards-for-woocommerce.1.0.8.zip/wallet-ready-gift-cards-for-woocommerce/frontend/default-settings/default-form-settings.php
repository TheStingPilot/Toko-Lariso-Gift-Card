<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}


return [

    // Giftcard form heading styling default
    'giftcard_form_items_heading_group' => [
        'giftcard_form_items_heading_text_color'      => '#333333',
        'giftcard_form_items_heading_font_size'       => 16,
        'giftcard_form_items_heading_font_weight'     => 'normal',
        'giftcard_form_items_heading_text_align'      => 'left',
        'giftcard_form_items_heading_text_transform'  => 'none',
    ],

    // Giftcard form label styling default
    'giftcard_form_items_label_group' => [
        'giftcard_form_items_label_text_color'        => '#7e7c7c',
        'giftcard_form_items_label_font_size'         => 14,
        'giftcard_form_items_label_font_weight'       => 'normal',
        'giftcard_form_items_label_text_align'        => 'left',
        'giftcard_form_items_label_text_transform'    => 'capitalize',
    ],

    // Giftcard form items spacing (Border, Radius & Padding) default
    'giftcard_form_items_box_model_group' => [
        'giftcard_form_items_border_width'         => 1,
        'giftcard_form_items_border_styles'        => 'solid',
        'giftcard_form_items_border_color'         => '#7f54b3',
        'giftcard_form_items_border_position'      => 'all',
        'giftcard_form_items_radius_width'         => 7,
        'giftcard_form_items_radius_position'      => 'all',
        'giftcard_form_items_padding_width'        => 12,
        'giftcard_form_items_padding_position'     => 'all',
    ],

    // Giftcard form items styling default
    'giftcard_form_items_styles_group' => [
        'giftcard_form_items_text_color'       => '#333333',
        'giftcard_form_items_font_size'        => 14,
        'giftcard_form_items_bg_color'         => '#f3f3f3',
    ],

    // Giftcard form items placeholder styling default
    'giftcard_form_items_placeholder_group' => [
        'giftcard_form_items_placeholder_text_color'        => '#7e7c7c',
        'giftcard_form_items_placeholder_font_size'         => 13,
        'giftcard_form_items_placeholder_font_weight'       => 'normal',
        'giftcard_form_items_placeholder_text_align'        => 'left',
        'giftcard_form_items_placeholder_text_transform'    => 'capitalize',
    ],

    // Giftcard form items pseudo styling default
    'giftcard_form_items_pseudo_group' => [
        'giftcard_form_items_pseudo_text_color'       => '#7e7c7c',
        'giftcard_form_items_pseudo_bg_color'         => '#f4f8fb',
        'giftcard_form_items_pseudo_border_color'     => '#be88eb',
        'giftcard_form_items_pseudo_border_styles'    => 'solid',
    ],

    // Giftcard form submit ajax message styling default
    'giftcard_form_submit_mgs_group' => [
        'giftcard_form_submit_mgs_font_size'         => 14,
        'giftcard_form_submit_mgs_font_weight'       => 'normal',
        'giftcard_form_submit_mgs_text_align'        => 'left',
        'giftcard_form_submit_mgs_text_transform'    => 'none',
    ],

    // Edit Giftcard form label text set default values 
    'edit_giftcard_label_style_group' => [
        'edit_giftcard_label_style_text_color'        => '#333333',
        'edit_giftcard_label_style_font_size'         => 14,
        'edit_giftcard_label_style_font_weight'       => 'normal',
        'edit_giftcard_label_style_text_align'        => 'left',
        'edit_giftcard_label_style_text_transform'    => 'none',

        'edit_giftcard_label_style_margin_width'      => 10,
        'edit_giftcard_label_style_margin_position'   => 'bottom',
    ],

/*====================================
* GIFTCARD ALL BUTTONS GROUP SET DEFAULT VALUES START
*====================================================== */
    // Giftcard All Buttons Group Text Default Values
    'giftcard_all_buttons_styles_group' => [
        'giftcard_all_buttons_text_color'    => '#333333',
        'giftcard_all_buttons_font_size'     => 16,
        'giftcard_all_buttons_font_weight'   => 'normal',
        'giftcard_all_buttons_text_align'    => 'left',
        'giftcard_all_buttons_text_transform'     => 'capitalize',
    ],

    // Giftcard All Buttons Group Border Default Values
    'giftcard_all_buttons_border_group' => [
        'giftcard_all_buttons_border_width'      => 1,
        'giftcard_all_buttons_border_styles'     => 'solid',
        'giftcard_all_buttons_border_color'      => '#7f54b3',
        'giftcard_all_buttons_border_position'   => 'all',
        'giftcard_all_buttons_bg_color'          => '#f3f3f3',
    ],

    // Giftcard All Buttons Group Box Model Default Values
    'giftcard_all_buttons_box_model_group' => [
        'giftcard_all_buttons_padding_width'      => 25,
        'giftcard_all_buttons_padding_position'     => 'left_right',
        'giftcard_all_buttons_radius_width'      => 8,
        'giftcard_all_buttons_radius_position'   => 'all',
    ],

    // Giftcard All Buttons Group Pseudo (Hover) Default Values
    'giftcard_all_buttons_pseudo_styles_group' => [
        'giftcard_all_buttons_pseudo_text_color'          => '#f8f8f8',
        'giftcard_all_buttons_pseudo_bg_color'          => '#7f54b3',
        'giftcard_all_buttons_pseudo_border_color'      => '#be88eb',
        'giftcard_all_buttons_pseudo_border_styles'      => 'solid',
    ],

/*====================================
* GIFTCARD ALL BUTTONS GROUP SET DEFAULT VALUES END
*====================================================== */

];
