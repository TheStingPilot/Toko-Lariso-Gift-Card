<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

return [
    // PDF full template layout default values
    'pdf_template_container_group' => [
        'pdf_template_container_border_width' => 4,
        'pdf_template_container_border_styles' => 'double',
        'pdf_template_container_border_color' => '#7f54b3',
        'pdf_template_container_border_position' => 'all',
        'pdf_template_container_radius_width' => 7,
        'pdf_template_container_radius_position' => 'all',
        'pdf_template_container_margin_width' => 0,
        'pdf_template_container_margin_position' => 'none',
    ],
    // PDF Header style default values
    'pdf_header_style_group' => [
        'pdf_header_style_border_width' => 0,
        'pdf_header_style_border_styles' => 'none',
        'pdf_header_style_border_color' => '#cccccc',
        'pdf_header_style_border_position' => 'none',
        'pdf_header_style_padding_width' => 0,
        'pdf_header_style_padding_position' => 'none',
        'pdf_header_style_margin_width' => 0,
        'pdf_header_style_margin_position' => 'none',
    ],
    // PDF Header box shadow
    'pdf_header_box_shadow_group' => [
        'pdf_header_shadow_type' => 'none',
        'pdf_header_shadow_horizontal' => 0,
        'pdf_header_shadow_vertical' => 4,
        'pdf_header_shadow_blur' => 10,
        'pdf_header_shadow_spread' => 0,
        'pdf_header_shadow_color' => '#c0c0c0',
    ],
    // PDF Content body layout style default values
    'pdf_content_style_group' => [
        'pdf_content_style_border_width' => 1,
        'pdf_content_style_border_styles' => 'solid',
        'pdf_content_style_border_color' => '#cccccc',
        'pdf_content_style_border_position' => 'top',
        'pdf_content_style_padding_width' => 10,
        'pdf_content_style_padding_position' => 'all',
        'pdf_content_style_margin_width' => 10,
        'pdf_content_style_margin_position' => 'bottom',
    ],
    // PDF Content title text style default values
    'pdf_title_text_style_group' => [
        'pdf_title_text_style_text_color' => '#333333',
        'pdf_title_text_style_font_size' => 18,
        'pdf_title_text_style_font_weight' => 'bold',
        'pdf_title_text_style_text_align' => 'center',
        'pdf_title_text_style_text_transform' => 'none',
        // 'pdf_title_text_style_padding_width'     => 5,
        // 'pdf_title_text_style_padding_position'  => 'all',
        'pdf_title_text_style_margin_width' => 10,
        'pdf_title_text_style_margin_position' => 'top_bottom',
    ],
    // PDF Content Gift Card Price Content Styling Default Values
    'pdf_giftcard_price_style_group' => [
        'pdf_giftcard_price_style_text_color' => '#333333',
        'pdf_giftcard_price_style_font_size' => 32,
        'pdf_giftcard_price_style_font_weight' => 'bold',
        'pdf_giftcard_price_style_text_align' => 'center',
        'pdf_giftcard_price_style_border_width' => 3,
        'pdf_giftcard_price_style_border_styles' => 'solid',
        'pdf_giftcard_price_style_border_color' => '#7f54b3',
        'pdf_giftcard_price_style_border_position' => 'top_bottom',
        'pdf_giftcard_price_style_padding_width' => 10,
        'pdf_giftcard_price_style_padding_position' => 'top_bottom',
        'pdf_giftcard_price_style_margin_width' => 20,
        'pdf_giftcard_price_style_margin_position' => 'bottom',
    ],
    // PDF Content Preview Message Section Styling Default Values
    'pdf_preview_mgs_style_group' => [
        'pdf_preview_mgs_style_text_color' => '#333333',
        'pdf_preview_mgs_style_font_size' => 14,
        'pdf_preview_mgs_style_font_weight' => 'normal',
        'pdf_preview_mgs_style_text_align' => 'center',
        'pdf_preview_mgs_style_text_transform' => 'none',
        'pdf_preview_mgs_style_border_width' => 0,
        'pdf_preview_mgs_style_border_styles' => 'solid',
        'pdf_preview_mgs_style_border_color' => '#cccccc',
        'pdf_preview_mgs_style_border_position' => 'none',
        'pdf_preview_mgs_style_padding_width' => 0,
        'pdf_preview_mgs_style_padding_position' => 'none',
        'pdf_preview_mgs_style_margin_width' => 0,
        'pdf_preview_mgs_style_margin_position' => 'none',
    ],
    // PDF Footer styles
    'pdf_footer_styles_group' => [
        'pdf_footer_text_color' => '#333333',
        'pdf_footer_font_size' => 13,
        'pdf_footer_font_weight' => 'normal',
        'pdf_footer_text_align' => 'center',
        'pdf_footer_text_transform' => 'none',
    ],
    // PDF Footer border
    'pdf_footer_border_group' => [
        'pdf_footer_border_width' => 1,
        'pdf_footer_border_styles' => 'solid',
        'pdf_footer_border_color' => '#cccccc',
        'pdf_footer_border_position' => 'top',
    ],
    // PDF Footer padding & margin
    'pdf_footer_box_model_group' => [
        'pdf_footer_padding_width' => 10,
        'pdf_footer_padding_position' => 'all',
        'pdf_footer_margin_width' => 10,
        'pdf_footer_margin_position' => 'bottom',
    ],
    'pdf_scannable_code_type' => 'none',
    'pdf_barcode_symbology' => 'C128',
    /** When PDF barcode or QR is enabled: show a sample on the single gift card product preview. */
    'pdf_show_placeholder_scannable_product' => 'no',
    // Custom PDF Layout Defaults
    'enable_custom_pdf_layout' => 'no',
    'custom_pdf_css' => '',
    'custom_pdf_html' => '',
];
