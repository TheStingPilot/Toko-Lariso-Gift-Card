<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'WALLREGI_My_Account_Gift_Cards' ) ) {

    /**
     * My Account → Gift cards (purchaser only).
     */
    class WALLREGI_My_Account_Gift_Cards {

        public function __construct() {
            add_action( 'init', [ $this, 'register_endpoints' ], 5 );
            add_action( 'init', [ $this, 'maybe_flush_rewrite_rules' ], 99 );

            add_filter( 'woocommerce_account_menu_items', [ $this, 'account_menu_items' ], 40 );
            add_filter( 'woocommerce_account_menu_item_classes', [ $this, 'account_menu_item_classes' ], 10, 2 );
            add_filter( 'woocommerce_get_query_vars', [ $this, 'register_wc_query_vars' ] );

            add_action( 'woocommerce_account_gift-cards_endpoint', [ $this, 'endpoint_gift_cards_list' ], 10, 1 );
            add_action( 'woocommerce_account_gift-card-transactions_endpoint', [ $this, 'endpoint_gift_card_transactions' ], 10, 1 );

            add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_gift_cards_endpoint_assets' ], 20 );

            add_filter( 'woocommerce_endpoint_gift-cards_title', [ $this, 'endpoint_title_gift_cards' ], 10, 3 );
            add_filter( 'woocommerce_endpoint_gift-card-transactions_title', [ $this, 'endpoint_title_transactions' ], 10, 3 );

            add_action( 'admin_init', [ $this, 'maybe_one_time_rewrite_flush_upgrade' ], 20 );
        }

        /**
         * @return void
         */
        public function register_endpoints() {
            add_rewrite_endpoint( 'gift-cards', EP_PAGES );
            add_rewrite_endpoint( 'gift-card-transactions', EP_PAGES );
        }

        /**
         * Map My Account rewrite tags to WooCommerce query vars.
         *
         * @param string[] $vars Endpoint => query var.
         * @return string[]
         */
        public function register_wc_query_vars( $vars ) {
            if ( ! is_array( $vars ) ) {
                $vars = [];
            }
            $vars['gift-cards']               = 'gift-cards';
            $vars['gift-card-transactions']   = 'gift-card-transactions';
            return $vars;
        }

        /**
         * @return void
         */
        public function maybe_flush_rewrite_rules() {
            if ( ! get_option( 'wallregi_flush_rewrite_rules' ) ) {
                return;
            }
            flush_rewrite_rules( false );
            delete_option( 'wallregi_flush_rewrite_rules' );
        }

        /**
         * Existing installs may not hit activation hook again; flush once on admin load.
         *
         * @return void
         */
        public function maybe_one_time_rewrite_flush_upgrade() {
            if ( get_option( 'wallregi_my_account_gift_cards_rewrite_ok' ) ) {
                return;
            }
            flush_rewrite_rules( false );
            update_option( 'wallregi_my_account_gift_cards_rewrite_ok', '1', false );
        }

        /**
         * Whether WooCommerce stores orders in the custom orders table (HPOS).
         *
         * @return bool
         */
        private function wallregi_wc_orders_use_hpos() {
            return class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
                && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
        }

        /**
         * Gift cards whose purchase order belongs to current user (purchaser).
         *
         * Uses a single JOIN on orders by customer_id. Rows in `wx_gift_cards` are only created when
         * a `wxgiftcard` product is issued for an order, so there is no need to load all order IDs or
         * scan line items for product type.
         *
         * @return array<int, stdClass>
         */
        private function get_purchased_gift_cards_for_current_user() {
            global $wpdb;

            $user_id = absint( get_current_user_id() );
            if ( ! $user_id ) {
                return [];
            }

            $gc_table_sql = wallregi_giftcard_db_table_sql();

            if ( $this->wallregi_wc_orders_use_hpos() ) {
                $orders_table = $wpdb->prefix . 'wc_orders';
                $orders_sql   = '`' . esc_sql( $orders_table ) . '`';

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Gift cards for logged-in purchaser (HPOS).
                $results = $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT gc.*
						FROM {$gc_table_sql} AS gc
						INNER JOIN {$orders_sql} AS o ON o.`id` = gc.`order_id` AND o.`customer_id` = %d
						WHERE gc.`order_id` > 0
						ORDER BY gc.`created_at` DESC",
                        $user_id
                    )
                );
            } else {
                // Legacy order posts: purchaser stored in `_customer_user` post meta.
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Gift cards for logged-in purchaser (CPT orders).
                $results = $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT gc.*
						FROM {$gc_table_sql} AS gc
						INNER JOIN {$wpdb->posts} AS p ON p.`ID` = gc.`order_id`
							AND p.`post_type` IN ( 'shop_order', 'shop_order_placehold' )
						INNER JOIN {$wpdb->postmeta} AS pm ON pm.`post_id` = p.`ID`
							AND pm.`meta_key` = '_customer_user'
							AND pm.`meta_value` = %s
						WHERE gc.`order_id` > 0
						ORDER BY gc.`created_at` DESC",
                        (string) $user_id
                    )
                );
            }

            return is_array( $results ) ? $results : [];
        }

        /**
         * Ownership: gift card row must belong to an order purchased by user.
         *
         * @param int      $giftcard_db_id PK in wx_gift_cards.
         * @param int|null $user_id        Defaults to current user.
         * @return stdClass|null
         */
        private function get_owned_gift_card_row( $giftcard_db_id, $user_id = null ) {
            global $wpdb;

            $giftcard_db_id = absint( $giftcard_db_id );
            if ( ! $giftcard_db_id ) {
                return null;
            }

            if ( null === $user_id ) {
                $user_id = get_current_user_id();
            }
            $user_id = absint( $user_id );
            if ( ! $user_id ) {
                return null;
            }

            $gc_sql = wallregi_giftcard_db_table_sql();

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Single row by PK.
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * FROM {$gc_sql} WHERE `id` = %d",
                    $giftcard_db_id
                )
            );

            if ( ! $row || empty( $row->order_id ) ) {
                return null;
            }

            $order = wc_get_order( absint( $row->order_id ) );
            if ( ! $order || (int) $order->get_customer_id() !== $user_id ) {
                return null;
            }

            return $row;
        }

        /**
         * View URL for customer's order only.
         *
         * @param int|string $order_id Order ID.
         * @return string
         */
        private function get_customer_order_view_url( $order_id ) {
            $order_id = absint( $order_id );
            if ( ! $order_id ) {
                return '';
            }
            $order = wc_get_order( $order_id );
            if ( ! $order || (int) $order->get_customer_id() !== get_current_user_id() ) {
                return '';
            }
            return $order->get_view_order_url();
        }

        /**
         * Styles for PDF / wallet icons on My Account → Gift cards (dashicons).
         *
         * @return void
         */
        public function enqueue_gift_cards_endpoint_assets() {
            if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
                return;
            }
            if ( ! function_exists( 'is_wc_endpoint_url' ) || ! is_wc_endpoint_url( 'gift-cards' ) ) {
                return;
            }
            wp_enqueue_style( 'dashicons' );
        }

        /**
         * Signed URL to download the gift card PDF (same flow as order confirmation).
         *
         * @param string $giftcard_number Gift card code.
         * @return string
         */
        private function get_gift_card_pdf_download_url( $giftcard_number ) {
            $num = is_string( $giftcard_number ) ? trim( $giftcard_number ) : '';
            if ( '' === $num ) {
                return '';
            }

            return add_query_arg(
                [
                    'giftcard-pdf' => 'true',
                    'noncekey'     => wp_create_nonce( 'gcpdf_nonce' ),
                    'giftcode'     => base64_encode( $num ),
                ],
                site_url( '/' )
            );
        }

        /**
         * Wallet pass URL from DB row (epass_data JSON or order item meta fallback).
         *
         * @param stdClass $row Gift card row.
         * @return string
         */
        private function get_pass_link_for_gift_card_row( $row ) {
            $pass_link = '';
            $epass_json = isset( $row->epass_data ) ? (string) $row->epass_data : '';
            if ( '' !== $epass_json ) {
                $decoded = json_decode( $epass_json, true );
                if ( is_array( $decoded ) && ! empty( $decoded['passLink'] ) && is_string( $decoded['passLink'] ) ) {
                    $pass_link = trim( $decoded['passLink'] );
                }
            }
            if ( '' === $pass_link && ! empty( $row->item_id ) && function_exists( 'wc_get_order_item_meta' ) ) {
                $meta = wc_get_order_item_meta( absint( $row->item_id ), '_wallregi_epass_pass_link', true );
                if ( '' === trim( (string) $meta ) ) {
                    $meta = wc_get_order_item_meta( absint( $row->item_id ), '_wallregi_gtw_pass_link', true );
                }
                $pass_link = is_string( $meta ) ? trim( $meta ) : '';
            }

            return $pass_link;
        }

        /**
         * Classify ledger row for display.
         *
         * @param stdClass $row Transaction row.
         * @return string purchase|redeem|refund|other
         */
        private function classify_transaction_row( $row ) {
            $amount_signed = isset( $row->amount ) ? (float) $row->amount : 0.0;
            if ( $amount_signed < 0 ) {
                return 'refund';
            }

            $m = strtolower( (string) ( $row->message ?? '' ) );
            if ( str_contains( $m, 'refund' ) || str_contains( $m, 'refunded' ) ) {
                return 'refund';
            }
            if (
                str_contains( $m, 'purchased' )
                || str_contains( $m, 'ready for use' )
                || str_contains( $m, 'initial gift card' )
            ) {
                return 'purchase';
            }
            if ( str_contains( $m, 'applied for order' ) ) {
                return 'redeem';
            }

            return 'other';
        }

        /**
         * @param string $title    Default title.
         * @param string $endpoint Endpoint key.
         * @param string $action   Optional sub-action (WC 4.6+).
         * @return string
         */
        public function endpoint_title_gift_cards( $title, $endpoint, $action ) {
            unset( $title, $endpoint, $action );
            return __( 'Gift cards', 'wallet-ready-gift-cards-for-woocommerce' );
        }

        /**
         * @param string $title    Default title.
         * @param string $endpoint Endpoint key.
         * @param string $action   Optional sub-action (WC 4.6+).
         * @return string
         */
        public function endpoint_title_transactions( $title, $endpoint, $action ) {
            unset( $title, $endpoint, $action );
            return __( 'Gift card transactions', 'wallet-ready-gift-cards-for-woocommerce' );
        }

        /**
         * @param string[] $menu_items Endpoint => label.
         * @return string[]
         */
        public function account_menu_items( $menu_items ) {
            if ( ! is_array( $menu_items ) ) {
                return $menu_items;
            }

            $new = [];
            foreach ( $menu_items as $endpoint => $label ) {
                $new[ $endpoint ] = $label;
                if ( 'orders' === $endpoint ) {
                    $new['gift-cards'] = __( 'Gift cards', 'wallet-ready-gift-cards-for-woocommerce' );
                }
            }

            return $new;
        }

        /**
         * Highlight "Gift cards" when viewing ledger for one card.
         *
         * @param array  $classes Nav item classes.
         * @param string $endpoint Endpoint key.
         * @return array
         */
        public function account_menu_item_classes( $classes, $endpoint ) {
            if ( ! is_array( $classes ) ) {
                $classes = [];
            }

            global $wp;
            if ( ! empty( $wp->query_vars['gift-card-transactions'] ) && 'gift-cards' === $endpoint && ! in_array( 'is-active', $classes, true ) ) {
                $classes[] = 'is-active';
            }

            return $classes;
        }

        /**
         * @param int|string|false $dashboard_page Unused page value for dashboard-style endpoints.
         * @return void
         */
        public function endpoint_gift_cards_list( $dashboard_page ) {
            unset( $dashboard_page );

            $rows = $this->get_purchased_gift_cards_for_current_user();
            $myaccount = wc_get_page_permalink( 'myaccount' );

            ?>
            <div class="wallregi-my-account-gift-cards woocommerce-order-gift-cards">
                <?php if ( empty( $rows ) ) : ?>
                    <p><?php esc_html_e( 'You have no purchased gift cards yet.', 'wallet-ready-gift-cards-for-woocommerce' ); ?></p>
                <?php else : ?>
                    <table class="woocommerce-table woocommerce-table--gift-cards shop_table shop_table_responsive my-account-gift-cards">
                        <thead>
                            <tr>
                                <th scope="col"><?php esc_html_e( 'Gift card number', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th scope="col"><?php esc_html_e( 'Initial amount', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th scope="col"><?php esc_html_e( 'Balance', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th scope="col"><?php esc_html_e( 'Used amount', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th scope="col">&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $rows as $row ) : ?>
                                <?php
                                $tx_url = wc_get_endpoint_url(
                                    'gift-card-transactions',
                                    (string) absint( $row->id ),
                                    $myaccount
                                );
                                ?>
                                <tr>
                                    <td
                                        class="wallregi-my-account-gc-number-cell"
                                        data-title="<?php echo esc_attr__( 'Gift card number', 'wallet-ready-gift-cards-for-woocommerce' ); ?>"
                                    >
                                        <span class="wallregi-my-account-gc-code"><?php echo esc_html( (string) $row->giftcard_number ); ?></span>
                                        <div class="wallregi-my-account-gc-actions" role="group" aria-label="<?php echo esc_attr__( 'Gift card downloads', 'wallet-ready-gift-cards-for-woocommerce' ); ?>">
                                            <?php
                                            $wallregi_pdf_url = $this->get_gift_card_pdf_download_url( (string) $row->giftcard_number );
                                            if ( '' !== $wallregi_pdf_url ) :
                                                ?>
                                                <a
                                                    class="wallregi-my-account-gc-pdf-link"
                                                    href="<?php echo esc_url( $wallregi_pdf_url ); ?>"
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                >
                                                    <span class="dashicons dashicons-pdf" aria-hidden="true"></span>
                                                    <span class="screen-reader-text"><?php esc_html_e( 'Download gift card PDF', 'wallet-ready-gift-cards-for-woocommerce' ); ?></span>
                                                </a>
                                                <?php
                                            endif;
                                            $wallregi_pass_url = $this->get_pass_link_for_gift_card_row( $row );
                                            if ( '' !== $wallregi_pass_url && function_exists( 'wallregi_epass_print_wallet_anchor' ) ) :
                                                echo '<span class="wallregi-epass-wallet-wrap wallregi-epass-wallet-wrap--my-account">';
                                                wallregi_epass_print_wallet_anchor(
                                                    $wallregi_pass_url,
                                                    [ 'class' => 'wallregi-epass-wallet-link wallregi-epass-wallet-link--my-account' ]
                                                );
                                                echo '</span>';
                                            endif;
                                            ?>
                                        </div>
                                    </td>
                                    <td><?php echo wp_kses_post( wc_price( (float) $row->initial_amount ) ); ?></td>
                                    <td><?php echo wp_kses_post( wc_price( (float) $row->current_amount ) ); ?></td>
                                    <td><?php echo wp_kses_post( wc_price( (float) $row->total_redeem ) ); ?></td>
                                    <td data-title="<?php esc_attr_e( 'Actions', 'wallet-ready-gift-cards-for-woocommerce' ); ?>">
                                        <a class="button wallregi-gift-cards-view-transactions" href="<?php echo esc_url( $tx_url ); ?>">
                                            <?php esc_html_e( 'View transactions', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            <?php
        }

        /**
         * @param int|string|false $giftcard_id Raw endpoint value from URL.
         * @return void
         */
        public function endpoint_gift_card_transactions( $giftcard_id ) {
            global $wpdb;

            $giftcard_id = absint( $giftcard_id );
            if ( ! $giftcard_id ) {
                wc_print_notice(
                    esc_html__( 'Invalid gift card.', 'wallet-ready-gift-cards-for-woocommerce' ),
                    'error'
                );
                return;
            }

            $card = $this->get_owned_gift_card_row( $giftcard_id );
            if ( ! $card ) {
                wc_print_notice(
                    esc_html__( 'Gift card not found or you do not have permission to view it.', 'wallet-ready-gift-cards-for-woocommerce' ),
                    'error'
                );
                return;
            }

            $tx_sql = wallregi_transaction_db_table_sql();

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Ledger rows for owned gift card.
            $ledger = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM {$tx_sql} WHERE `giftcard_id` = %d ORDER BY `created_at` ASC, `id` ASC",
                    $giftcard_id
                )
            );
            $ledger = is_array( $ledger ) ? $ledger : [];

            $purchase_rows  = [];
            $activity_rows  = [];
            $purchase_order = absint( $card->order_id );

            foreach ( $ledger as $tr ) {
                $kind           = $this->classify_transaction_row( $tr );
                $txn_order_id   = absint( $tr->order_id );
                $amount_signed  = isset( $tr->amount ) ? (float) $tr->amount : 0.0;

                if ( 'refund' === $kind || 'redeem' === $kind ) {
                    $activity_rows[] = $tr;
                    continue;
                }

                if ( 'purchase' === $kind || ( $amount_signed >= 0 && $txn_order_id === $purchase_order ) ) {
                    $purchase_rows[] = $tr;
                    continue;
                }

                $activity_rows[] = $tr;
            }

            // If legacy data has no recognizable purchase ledger row, show summary from gift card row.
            $purchase_fallback = [];
            if ( empty( $purchase_rows ) ) {
                $purchase_fallback[] = [
                    'label'       => __( 'Initial purchase', 'wallet-ready-gift-cards-for-woocommerce' ),
                    'amount'      => (float) $card->initial_amount,
                    'order_id'    => absint( $card->order_id ),
                    'message'     => __( 'Recorded from gift card issuance.', 'wallet-ready-gift-cards-for-woocommerce' ),
                    'created_at'  => isset( $card->created_at ) ? (string) $card->created_at : '',
                ];
            }

            $list_url = esc_url( wc_get_endpoint_url( 'gift-cards', '', wc_get_page_permalink( 'myaccount' ) ) );

            ?>
            <div class="wallregi-my-account-gift-card-transactions">
                <p>
                    <a class="woocommerce-Button wallregi-back-to-gift-cards" href="<?php echo esc_url( $list_url ); ?>">
                        <?php esc_html_e( '← Gift cards', 'wallet-ready-gift-cards-for-woocommerce' ); ?>
                    </a>
                </p>
                <p>
                    <?php
                    echo esc_html(
                        sprintf(
                            /* translators: %s: gift card number */
                            __( 'Gift card: %s', 'wallet-ready-gift-cards-for-woocommerce' ),
                            (string) $card->giftcard_number
                        )
                    );
                    ?>
                </p>

                <h3><?php esc_html_e( 'Initial purchase', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h3>
                <?php if ( ! empty( $purchase_fallback ) ) : ?>
                    <table class="woocommerce-table shop_table shop_table_responsive">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Date', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th><?php esc_html_e( 'Amount', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th><?php esc_html_e( 'Order', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th><?php esc_html_e( 'Details', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $purchase_fallback as $pf ) : ?>
                                <?php
                                $href = $this->get_customer_order_view_url( $pf['order_id'] );
                                ?>
                                <tr>
                                    <td><?php echo esc_html( $pf['created_at'] ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $pf['created_at'] ) ) : '—' ); ?></td>
                                    <td><?php echo wp_kses_post( wc_price( $pf['amount'] ) ); ?></td>
                                    <td>
                                        <?php if ( $href && $pf['order_id'] ) : ?>
                                            <a href="<?php echo esc_url( $href ); ?>">#<?php echo esc_html( (string) $pf['order_id'] ); ?></a>
                                        <?php elseif ( $pf['order_id'] ) : ?>
                                            #<?php echo esc_html( (string) $pf['order_id'] ); ?>
                                        <?php else : ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html( $pf['message'] ); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <table class="woocommerce-table shop_table shop_table_responsive">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Date', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th><?php esc_html_e( 'Amount', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th><?php esc_html_e( 'Order', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th><?php esc_html_e( 'Details', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $purchase_rows as $tr ) : ?>
                                <?php
                                $oid  = absint( $tr->order_id );
                                $href = $this->get_customer_order_view_url( $oid );
                                $ts   = isset( $tr->created_at ) ? strtotime( (string) $tr->created_at ) : false;
                                ?>
                                <tr>
                                    <td><?php echo $ts ? esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $ts ) ) : '—'; ?></td>
                                    <td><?php echo wp_kses_post( wc_price( (float) $tr->amount ) ); ?></td>
                                    <td>
                                        <?php if ( $href && $oid ) : ?>
                                            <a href="<?php echo esc_url( $href ); ?>">#<?php echo esc_html( (string) $oid ); ?></a>
                                        <?php elseif ( $oid ) : ?>
                                            #<?php echo esc_html( (string) $oid ); ?>
                                        <?php else : ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html( wp_strip_all_tags( (string) ( $tr->message ?? '' ) ) ); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <h3><?php esc_html_e( 'Usage & adjustments', 'wallet-ready-gift-cards-for-woocommerce' ); ?></h3>
                <?php if ( empty( $activity_rows ) ) : ?>
                    <p><?php esc_html_e( 'No redemptions or adjustments recorded yet.', 'wallet-ready-gift-cards-for-woocommerce' ); ?></p>
                <?php else : ?>
                    <table class="woocommerce-table shop_table shop_table_responsive">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Date', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th><?php esc_html_e( 'Type', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th><?php esc_html_e( 'Amount', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th><?php esc_html_e( 'Order ref', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                                <th><?php esc_html_e( 'Details', 'wallet-ready-gift-cards-for-woocommerce' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $activity_rows as $tr ) : ?>
                                <?php
                                $kind    = $this->classify_transaction_row( $tr );
                                $type_l  = __( 'Other', 'wallet-ready-gift-cards-for-woocommerce' );
                                if ( 'redeem' === $kind ) {
                                    $type_l = __( 'Redemption', 'wallet-ready-gift-cards-for-woocommerce' );
                                } elseif ( 'refund' === $kind ) {
                                    $type_l = __( 'Refund', 'wallet-ready-gift-cards-for-woocommerce' );
                                }

                                $oid  = absint( $tr->order_id );
                                $href = $this->get_customer_order_view_url( $oid );
                                $ts   = isset( $tr->created_at ) ? strtotime( (string) $tr->created_at ) : false;
                                ?>
                                <tr>
                                    <td><?php echo $ts ? esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $ts ) ) : '—'; ?></td>
                                    <td><?php echo esc_html( $type_l ); ?></td>
                                    <td><?php echo wp_kses_post( wc_price( (float) $tr->amount ) ); ?></td>
                                    <td>
                                        <?php if ( $href && $oid ) : ?>
                                            <a href="<?php echo esc_url( $href ); ?>">#<?php echo esc_html( (string) $oid ); ?></a>
                                        <?php elseif ( $oid ) : ?>
                                            #<?php echo esc_html( (string) $oid ); ?>
                                        <?php else : ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html( wp_strip_all_tags( (string) ( $tr->message ?? '' ) ) ); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            <?php
        }
    }

    new WALLREGI_My_Account_Gift_Cards();
}
