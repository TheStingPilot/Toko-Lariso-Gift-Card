<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Ensure all CSS variables are defined (fallback to empty strings if not set)
$wallregi_giftcard_header_border_css = $wallregi_giftcard_header_border_css ?? '';
$wallregi_giftcard_header_radius_css = $wallregi_giftcard_header_radius_css ?? '';
$wallregi_giftcard_header_padding_css = $wallregi_giftcard_header_padding_css ?? '';
$wallregi_giftcard_active_header_border_css = $wallregi_giftcard_active_header_border_css ?? '';
$wallregi_giftcard_active_header_radius_css = $wallregi_giftcard_active_header_radius_css ?? '';
$wallregi_giftcard_active_header_padding_css = $wallregi_giftcard_active_header_padding_css ?? '';
$wallregi_background_css = $wallregi_background_css ?? '';
$wallregi_giftcard_body_border_css = $wallregi_giftcard_body_border_css ?? '';
$wallregi_giftcard_body_radius_css = $wallregi_giftcard_body_radius_css ?? '';
$wallregi_giftcard_body_padding_css = $wallregi_giftcard_body_padding_css ?? '';
$wallregi_giftcard_all_buttons_styles_group = $wallregi_giftcard_all_buttons_styles_group ?? [];
$wallregi_giftcard_right_side_contents_group = $wallregi_giftcard_right_side_contents_group ?? [];
$wallregi_giftcard_right_side_contents_border_css = $wallregi_giftcard_right_side_contents_border_css ?? '';
$wallregi_giftcard_right_side_contents_radius_css = $wallregi_giftcard_right_side_contents_radius_css ?? '';
$wallregi_giftcard_right_side_contents_padding_css = $wallregi_giftcard_right_side_contents_padding_css ?? '';
$wallregi_giftcard_right_side_contents_margin_css = $wallregi_giftcard_right_side_contents_margin_css ?? '';
$wallregi_giftcard_custom_price_box_border_css = $wallregi_giftcard_custom_price_box_border_css ?? '';
$wallregi_giftcard_custom_price_box_radius_css = $wallregi_giftcard_custom_price_box_radius_css ?? '';
$wallregi_giftcard_custom_price_box_padding_css = $wallregi_giftcard_custom_price_box_padding_css ?? '';
$wallregi_giftcard_custom_price_box_margin_css = $wallregi_giftcard_custom_price_box_margin_css ?? '';
$wallregi_giftcard_custom_price_heading_group = $wallregi_giftcard_custom_price_heading_group ?? [];
$wallregi_giftcard_custom_price_heading_margin_css = $wallregi_giftcard_custom_price_heading_margin_css ?? '';
$wallregi_giftcard_img_gallery_box_border_css = $wallregi_giftcard_img_gallery_box_border_css ?? '';
$wallregi_giftcard_img_gallery_box_radius_css = $wallregi_giftcard_img_gallery_box_radius_css ?? '';
$wallregi_giftcard_img_gallery_box_padding_css = $wallregi_giftcard_img_gallery_box_padding_css ?? '';
$wallregi_giftcard_img_gallery_box_margin_css = $wallregi_giftcard_img_gallery_box_margin_css ?? '';
$wallregi_giftcard_img_gallery_heading_group = $wallregi_giftcard_img_gallery_heading_group ?? [];
$wallregi_giftcard_img_gallery_heading_margin_css = $wallregi_giftcard_img_gallery_heading_margin_css ?? '';
$wallregi_giftcard_img_gallery_item_border_css = $wallregi_giftcard_img_gallery_item_border_css ?? '';
$wallregi_giftcard_img_gallery_item_radius_css = $wallregi_giftcard_img_gallery_item_radius_css ?? '';
$wallregi_giftcard_img_gallery_item_pseudo_group = $wallregi_giftcard_img_gallery_item_pseudo_group ?? [];
$wallregi_giftcard_img_gallery_item_pseudo_shadow_css = $wallregi_giftcard_img_gallery_item_pseudo_shadow_css ?? '';
$wallregi_apply_giftcard_container_border_css = $wallregi_apply_giftcard_container_border_css ?? '';
$wallregi_apply_giftcard_container_radius_css = $wallregi_apply_giftcard_container_radius_css ?? '';
$wallregi_apply_giftcard_container_header_group = $wallregi_apply_giftcard_container_header_group ?? [];
$wallregi_apply_giftcard_container_header_padding_css = $wallregi_apply_giftcard_container_header_padding_css ?? '';
$wallregi_apply_giftcard_coupon_code_box_padding_css = $wallregi_apply_giftcard_coupon_code_box_padding_css ?? '';
$wallregi_apply_giftcard_coupon_code_group = $wallregi_apply_giftcard_coupon_code_group ?? [];
$wallregi_apply_giftcard_coupon_code_padding_css = $wallregi_apply_giftcard_coupon_code_padding_css ?? '';
$wallregi_apply_giftcard_coupon_code_margin_css = $wallregi_apply_giftcard_coupon_code_margin_css ?? '';
$wallregi_apply_giftcard_coupon_code_border_css = $wallregi_apply_giftcard_coupon_code_border_css ?? '';
$wallregi_apply_giftcard_coupon_code_radius_css = $wallregi_apply_giftcard_coupon_code_radius_css ?? '';

return "

/* Gift Card for WooCommerce — Dynamic Styles */

    /* Giftcard Product Layout Default Header Styling */
    .wallregi_section_container .ui-accordion .wallregi_accordion_title {
        color: " . esc_attr($wallregi_giftcard_header_title_styles_group['giftcard_header_title_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_giftcard_header_title_styles_group['giftcard_header_title_font_size'] ?? 16) . "px;
        font-weight: " . esc_attr($wallregi_giftcard_header_title_styles_group['giftcard_header_title_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_giftcard_header_title_styles_group['giftcard_header_title_text_align'] ?? 'left') . ";
        text-transform: " . esc_attr($wallregi_giftcard_header_title_styles_group['giftcard_header_title_text_transform'] ?? 'capitalize') . ";
        background-color: " . esc_attr($wallregi_giftcard_header_border_group['giftcard_header_bg_color'] ?? '#f3f3f3') . ";

        {$wallregi_giftcard_header_border_css}
        {$wallregi_giftcard_header_radius_css}
        {$wallregi_giftcard_header_padding_css}
        transition: all .3s linear;
    }

    /* Giftcard Product Layout Default Header Pseudo Styling */
    .wallregi_section_container .ui-accordion .ui-accordion-header.ui-state-default:hover {
        color: " . esc_attr($wallregi_giftcard_header_pseudo_styles_group['giftcard_header_pseudo_text_color'] ?? '#7e7c7c') . ";
        background-color: " . esc_attr($wallregi_giftcard_header_pseudo_styles_group['giftcard_header_pseudo_bg_color'] ?? '#f4f8fb') . ";
        border-color: " . esc_attr($wallregi_giftcard_header_pseudo_styles_group['giftcard_header_pseudo_border_color'] ?? '#be88eb') . ";
    }

    /* Giftcard Product Layout Active Header Styling */
    .wallregi_section_container .ui-accordion .wallregi_accordion_title.ui-accordion-header-active {
        color: " . esc_attr($wallregi_giftcard_active_header_title_styles_group['giftcard_active_header_title_text_color'] ?? '#ffffff') . ";
        font-size: " . intval($wallregi_giftcard_active_header_title_styles_group['giftcard_active_header_title_font_size'] ?? 18) . "px;
        font-weight: " . esc_attr($wallregi_giftcard_active_header_title_styles_group['giftcard_active_header_title_font_weight'] ?? 'bold') . ";
        text-align: " . esc_attr($wallregi_giftcard_active_header_title_styles_group['giftcard_active_header_title_text_align'] ?? 'left') . ";
        text-transform: " . esc_attr($wallregi_giftcard_active_header_title_styles_group['giftcard_active_header_title_text_transform'] ?? 'capitalize') . ";
        background-color: " . esc_attr($wallregi_giftcard_active_header_border_group['giftcard_active_header_bg_color'] ?? '#7f54b3') . ";

        {$wallregi_giftcard_active_header_border_css}
        {$wallregi_giftcard_active_header_radius_css}
        {$wallregi_giftcard_active_header_padding_css}

    }

    /* Giftcard Product Layout Active Header Pseudo Styling */
    .wallregi_section_container .ui-accordion .ui-accordion-header.ui-state-default.ui-accordion-header-active:hover {
        color: " . esc_attr($wallregi_giftcard_active_header_pseudo_styles_group['giftcard_active_header_pseudo_text_color'] ?? '#f4f8fb') . ";
        background-color: " . esc_attr($wallregi_giftcard_active_header_pseudo_styles_group['giftcard_active_header_pseudo_bg_color'] ?? '#be88eb') . ";
        border-color: " . esc_attr($wallregi_giftcard_active_header_pseudo_styles_group['giftcard_active_header_pseudo_border_color'] ?? '#f4f8fb') . ";
    }


    /* Giftcard Product Layout Contents Body Styling */
    .wallregi_giftcard_contents .wallregi_giftcard__body {
        {$wallregi_background_css}
        {$wallregi_giftcard_body_border_css}
        {$wallregi_giftcard_body_radius_css}
        {$wallregi_giftcard_body_padding_css}
        padding-bottom: var(--wallregi-spacing-3xl);

    }

    /* Icon Lines */
    .wallregi_qty_btn_groups .wallregi_icon::before,
    .wallregi_qty_btn_groups .wallregi_icon::after {
        background-color: " . esc_attr($wallregi_giftcard_all_buttons_styles_group['giftcard_all_buttons_text_color'] ?? '#333333') . ";
    } 

    /* Giftcard Right Side Column Contents Styling */
    .wallregi_right__contents .wallregi_giftcard_summary{
        color: " . esc_attr($wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_font_size'] ?? 14) . "px;
        font-weight: " . esc_attr($wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_text_align'] ?? 'left') . ";
        text-transform: " . esc_attr($wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_text_transform'] ?? 'none') . ";

        {$wallregi_giftcard_right_side_contents_border_css}
        {$wallregi_giftcard_right_side_contents_radius_css}
        {$wallregi_giftcard_right_side_contents_padding_css}
        {$wallregi_giftcard_right_side_contents_margin_css}
    }

    /* Giftcard Custom Price Box Styling */
    .wallregi_form_item wallregi_custom_price_item,
    .wallregi_right__contents .wallregi_custom_price_box {
        {$wallregi_giftcard_custom_price_box_border_css}
        {$wallregi_giftcard_custom_price_box_radius_css}
        {$wallregi_giftcard_custom_price_box_padding_css}
        {$wallregi_giftcard_custom_price_box_margin_css}
    }

    .wallregi_form_item wallregi_custom_price_item .wallregi_price_heading,
    .wallregi_custom_price_box .wallregi_heading{
        color: " . esc_attr($wallregi_giftcard_custom_price_heading_group['giftcard_custom_price_heading_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_giftcard_custom_price_heading_group['giftcard_custom_price_heading_font_size'] ?? 16) . "px;
        font-weight: " . esc_attr($wallregi_giftcard_custom_price_heading_group['giftcard_custom_price_heading_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_giftcard_custom_price_heading_group['giftcard_custom_price_heading_text_align'] ?? 'left') . ";
        text-transform: " . esc_attr($wallregi_giftcard_custom_price_heading_group['giftcard_custom_price_heading_text_transform'] ?? 'none') . ";

        {$wallregi_giftcard_custom_price_heading_margin_css}
    }


    /* Giftcard Custom Price Box Styling */
    .wallregi_right__contents .wallregi_gallery_images_content_box {
        {$wallregi_giftcard_img_gallery_box_border_css}
        {$wallregi_giftcard_img_gallery_box_radius_css}
        {$wallregi_giftcard_img_gallery_box_padding_css}
        {$wallregi_giftcard_img_gallery_box_margin_css}
    }
    .wallregi_gallery_images_content_box .wallregi_heading{
        color: " . esc_attr($wallregi_giftcard_img_gallery_heading_group['giftcard_img_gallery_heading_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_giftcard_img_gallery_heading_group['giftcard_img_gallery_heading_font_size'] ?? 16) . "px;
        font-weight: " . esc_attr($wallregi_giftcard_img_gallery_heading_group['giftcard_img_gallery_heading_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_giftcard_img_gallery_heading_group['giftcard_img_gallery_heading_text_align'] ?? 'left') . ";
        text-transform: " . esc_attr($wallregi_giftcard_img_gallery_heading_group['giftcard_img_gallery_heading_text_transform'] ?? 'none') . ";

        {$wallregi_giftcard_img_gallery_heading_margin_css}
    }
    .wallregi_images__gallery .wallregi_item{
        {$wallregi_giftcard_img_gallery_item_border_css}
        {$wallregi_giftcard_img_gallery_item_radius_css}
    }
    .wallregi_images__gallery .wallregi_item.wallregi_active{
        border-style: " . esc_attr($wallregi_giftcard_img_gallery_item_pseudo_group['giftcard_img_gallery_item_pseudo_border_styles'] ?? 'solid') . ";
        border-color: " . esc_attr($wallregi_giftcard_img_gallery_item_pseudo_group['giftcard_img_gallery_item_pseudo_border_color'] ?? '#333333') . ";
        {$wallregi_giftcard_img_gallery_item_pseudo_shadow_css}
        transform: translateY(-2px);
    }
    .wallregi_images__gallery .wallregi_item:hover{
        {$wallregi_giftcard_img_gallery_item_pseudo_shadow_css}
        border-style: " . esc_attr($wallregi_giftcard_img_gallery_item_pseudo_group['giftcard_img_gallery_item_pseudo_border_styles'] ?? 'solid') . ";
        border-color: " . esc_attr($wallregi_giftcard_img_gallery_item_pseudo_group['giftcard_img_gallery_item_pseudo_border_color'] ?? '#333333') . ";
        transform: translateY(-2px);
    }


    /* Apply Giftcard Accordion Styling */

    .wallregi_apply_coupon_sec .wallregi_coupon_container{
        {$wallregi_apply_giftcard_container_border_css}
        {$wallregi_apply_giftcard_container_radius_css}
    }
    .wallregi_apply_coupon_sec .wallregi_cart_accordion_heading{
        color: " . esc_attr($wallregi_apply_giftcard_container_header_group['apply_giftcard_container_header_text_color'] ?? '#333333') . ";
        background-color: " . esc_attr($wallregi_apply_giftcard_container_header_group['apply_giftcard_container_header_bg_color'] ?? '#f3f3f3') . ";
        font-size: " . intval($wallregi_apply_giftcard_container_header_group['apply_giftcard_container_header_font_size'] ?? 16) . "px;
        font-weight: " . esc_attr($wallregi_apply_giftcard_container_header_group['apply_giftcard_container_header_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_apply_giftcard_container_header_group['apply_giftcard_container_header_text_align'] ?? 'left') . ";
        text-transform: " . esc_attr($wallregi_apply_giftcard_container_header_group['apply_giftcard_container_header_text_transform'] ?? 'none') . ";
        {$wallregi_apply_giftcard_container_header_padding_css}
    }

    .wallregi_coupon_container .wallregi_usage_coupon_list {
        {$wallregi_apply_giftcard_coupon_code_box_padding_css}
    } 
    .wallregi_usage_coupon_list .wallregi_coupon_item {
        color: " . esc_attr($wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_font_size'] ?? 14) . "px;
        font-weight: " . esc_attr($wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_text_align'] ?? 'left') . ";
        {$wallregi_apply_giftcard_coupon_code_padding_css}
        {$wallregi_apply_giftcard_coupon_code_margin_css}
        {$wallregi_apply_giftcard_coupon_code_border_css}
        {$wallregi_apply_giftcard_coupon_code_radius_css}
    } 

    .wallregi_apply_coupon_sec .wallregi_icon::before,
    .wallregi_apply_coupon_sec .wallregi_icon::after{
        background-color: " . esc_attr($wallregi_apply_giftcard_container_header_group['apply_giftcard_container_header_text_color'] ?? '#333333') . ";
    }
    .wallregi_usage_coupon_list .remove_coupon_code {
        background-color: " . esc_attr($wallregi_apply_giftcard_container_header_group['apply_giftcard_container_header_bg_color'] ?? '#f3f3f3') . ";
        font-size: " . intval($wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_font_size'] ?? 14) . "px;
    }


    /* Edit Giftcard Popup Modal Styling */
    .wallregi_edit_cart_modal{
        background-color: #f2f2f2;
        {$wallregi_background_css}
        {$wallregi_giftcard_body_border_css}
        {$wallregi_giftcard_body_radius_css}
        {$wallregi_giftcard_body_padding_css}
        padding-bottom: var(--wallregi-spacing-3xl);
    }

";