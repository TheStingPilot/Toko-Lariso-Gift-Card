<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Ensure all CSS variables are defined (fallback to empty strings/arrays if not set)
$wallregi_pdf_template_container_border_css = $wallregi_pdf_template_container_border_css ?? '';
$wallregi_pdf_template_container_radius_css = $wallregi_pdf_template_container_radius_css ?? '';
$wallregi_pdf_template_container_margin_css = $wallregi_pdf_template_container_margin_css ?? '';
$wallregi_pdf_header_style_border_css = $wallregi_pdf_header_style_border_css ?? '';
$wallregi_pdf_header_style_padding_css = $wallregi_pdf_header_style_padding_css ?? '';
$wallregi_pdf_header_style_margin_css = $wallregi_pdf_header_style_margin_css ?? '';
$wallregi_pdf_header_box_shadow_css = $wallregi_pdf_header_box_shadow_css ?? '';
$wallregi_pdf_content_style_border_css = $wallregi_pdf_content_style_border_css ?? '';
$wallregi_pdf_content_style_padding_css = $wallregi_pdf_content_style_padding_css ?? '';
$wallregi_pdf_content_style_margin_css = $wallregi_pdf_content_style_margin_css ?? '';
$wallregi_pdf_title_text_style_group = $wallregi_pdf_title_text_style_group ?? [];
$wallregi_pdf_title_text_style_margin_css = $wallregi_pdf_title_text_style_margin_css ?? '';
$wallregi_pdf_giftcard_price_style_group = $wallregi_pdf_giftcard_price_style_group ?? [];
$wallregi_pdf_giftcard_price_style_border_css = $wallregi_pdf_giftcard_price_style_border_css ?? '';
$wallregi_pdf_giftcard_price_style_padding_css = $wallregi_pdf_giftcard_price_style_padding_css ?? '';
$wallregi_pdf_giftcard_price_style_margin_css = $wallregi_pdf_giftcard_price_style_margin_css ?? '';
$wallregi_pdf_preview_mgs_style_group = $wallregi_pdf_preview_mgs_style_group ?? [];
$wallregi_pdf_preview_mgs_style_border_css = $wallregi_pdf_preview_mgs_style_border_css ?? '';
$wallregi_pdf_preview_mgs_style_padding_css = $wallregi_pdf_preview_mgs_style_padding_css ?? '';
$wallregi_pdf_preview_mgs_style_margin_css = $wallregi_pdf_preview_mgs_style_margin_css ?? '';
$wallregi_pdf_footer_styles_group = $wallregi_pdf_footer_styles_group ?? [];
$wallregi_pdf_footer_border_css = $wallregi_pdf_footer_border_css ?? '';
$wallregi_pdf_footer_padding_css = $wallregi_pdf_footer_padding_css ?? '';
$wallregi_pdf_footer_margin_css = $wallregi_pdf_footer_margin_css ?? '';

return "

    /* Giftcard PDF Template Styles */
    
    .wallregi_giftcard__card{
        {$wallregi_pdf_template_container_border_css};
        {$wallregi_pdf_template_container_radius_css};
        {$wallregi_pdf_template_container_margin_css};
    }
    .wallregi_giftcard__card .wallregi_card__header {
        {$wallregi_pdf_header_style_border_css};
        {$wallregi_pdf_header_style_padding_css};
        {$wallregi_pdf_header_style_margin_css};
        {$wallregi_pdf_header_box_shadow_css};
    }

    .wallregi_giftcard__card .wallregi_card__body {
        {$wallregi_pdf_content_style_border_css};
        {$wallregi_pdf_content_style_padding_css};
        {$wallregi_pdf_content_style_margin_css};

    }


    .wallregi_giftcard__card .wallregi_title {
        color: " . esc_attr($wallregi_pdf_title_text_style_group['pdf_title_text_style_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_pdf_title_text_style_group['pdf_title_text_style_font_size'] ?? 24) . "px;
        font-weight: " . esc_attr($wallregi_pdf_title_text_style_group['pdf_title_text_style_font_weight'] ?? 'bold') . ";
        text-align: " . esc_attr($wallregi_pdf_title_text_style_group['pdf_title_text_style_text_align'] ?? 'center') . ";
        text-transform: " . esc_attr($wallregi_pdf_title_text_style_group['pdf_title_text_style_text_transform'] ?? 'none') . ";
        {$wallregi_pdf_title_text_style_margin_css}
    }

    .wallregi_card__body .wallregi_price {
        color: " . esc_attr($wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_font_size'] ?? 20) . "px;
        font-weight: " . esc_attr($wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_font_weight'] ?? 'bold') . ";
        text-align: " . esc_attr($wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_text_align'] ?? 'center') . ";
        {$wallregi_pdf_giftcard_price_style_border_css};
        {$wallregi_pdf_giftcard_price_style_padding_css};
        {$wallregi_pdf_giftcard_price_style_margin_css};
        
    }
    .wallregi_card__body .wallregi-preview-scannable {
        text-align: center;
        margin: 10px 0 8px;
    }
    .wallregi_card__body .wallregi-preview-scannable--barcode img {
        display: block;
        margin-left: auto;
        margin-right: auto;
        max-width: 250px;
        width: auto;
        max-height: 50px;
        height: 48px;
        object-fit: contain;
    }
    .wallregi_card__body .wallregi-preview-scannable--qr img {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 120px;
        height: 120px;
        max-width: 120px;
        max-height: 120px;
        object-fit: contain;
    }
    .wallregi_card__body .wallregi-preview-scannable--pdf417 img {
        display: block;
        margin-left: auto;
        margin-right: auto;
        max-width: 260px;
        width: auto;
        max-height: 88px;
        height: auto;
        object-fit: contain;
    }
    .wallregi_card__body .wallregi-preview-scannable--both {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 15px;
        flex-wrap: wrap;
    }

    .wallregi_card__body .wallregi_preview__mgs {
        color: " . esc_attr($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_font_size'] ?? 16) . "px;
        font-weight: " . esc_attr($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_text_align'] ?? 'center') . ";
        text-transform: " . esc_attr($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_text_transform'] ?? 'none') . ";
        word-break: " . esc_attr($wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_word_break'] ?? 'break-all') . ";
        {$wallregi_pdf_preview_mgs_style_border_css};
        {$wallregi_pdf_preview_mgs_style_padding_css};
        {$wallregi_pdf_preview_mgs_style_margin_css};

    }

    .wallregi_giftcard__card .wallregi_giftcard_footer {
        color: " . esc_attr($wallregi_pdf_footer_styles_group['pdf_footer_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_pdf_footer_styles_group['pdf_footer_font_size'] ?? 14) . "px;
        font-weight: " . esc_attr($wallregi_pdf_footer_styles_group['pdf_footer_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_pdf_footer_styles_group['pdf_footer_text_align'] ?? 'center') . ";
        text-transform: " . esc_attr($wallregi_pdf_footer_styles_group['pdf_footer_text_transform'] ?? 'none') . ";
        {$wallregi_pdf_footer_border_css};
        {$wallregi_pdf_footer_padding_css};
        {$wallregi_pdf_footer_margin_css};
    }

";