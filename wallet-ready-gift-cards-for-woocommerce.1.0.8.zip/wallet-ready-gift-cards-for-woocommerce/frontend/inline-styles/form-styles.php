<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Ensure all CSS variables are defined (fallback to empty strings/arrays if not set)
$wallregi_giftcard_form_items_heading_group = $wallregi_giftcard_form_items_heading_group ?? [];
$wallregi_giftcard_form_items_label_group = $wallregi_giftcard_form_items_label_group ?? [];
$wallregi_giftcard_form_items_styles_group = $wallregi_giftcard_form_items_styles_group ?? [];
$wallregi_giftcard_form_items_border_css = $wallregi_giftcard_form_items_border_css ?? '';
$wallregi_giftcard_form_items_radius_css = $wallregi_giftcard_form_items_radius_css ?? '';
$wallregi_giftcard_form_items_padding_css = $wallregi_giftcard_form_items_padding_css ?? '';
$wallregi_giftcard_form_items_placeholder_group = $wallregi_giftcard_form_items_placeholder_group ?? [];
$wallregi_giftcard_form_items_pseudo_group = $wallregi_giftcard_form_items_pseudo_group ?? [];
$wallregi_giftcard_form_submit_mgs_group = $wallregi_giftcard_form_submit_mgs_group ?? [];
$wallregi_giftcard_all_buttons_styles_group = $wallregi_giftcard_all_buttons_styles_group ?? [];
$wallregi_giftcard_all_buttons_border_group = $wallregi_giftcard_all_buttons_border_group ?? [];
$wallregi_giftcard_all_buttons_padding_css = $wallregi_giftcard_all_buttons_padding_css ?? '';
$wallregi_giftcard_all_buttons_border_css = $wallregi_giftcard_all_buttons_border_css ?? '';
$wallregi_giftcard_all_buttons_radius_css = $wallregi_giftcard_all_buttons_radius_css ?? '';
$wallregi_giftcard_all_buttons_pseudo_styles_group = $wallregi_giftcard_all_buttons_pseudo_styles_group ?? [];
$wallregi_edit_giftcard_label_style_group = $wallregi_edit_giftcard_label_style_group ?? [];
$wallregi_edit_giftcard_label_style_margin_css = $wallregi_edit_giftcard_label_style_margin_css ?? '';

return "

    /* Form heading styles */
    .wallregi_form_wrap .wallregi_heading {
        color: " . esc_attr($wallregi_giftcard_form_items_heading_group['giftcard_form_items_heading_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_giftcard_form_items_heading_group['giftcard_form_items_heading_font_size'] ?? 16) . "px;
        font-weight: " . esc_attr($wallregi_giftcard_form_items_heading_group['giftcard_form_items_heading_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_giftcard_form_items_heading_group['giftcard_form_items_heading_text_align'] ?? 'left') . ";
        text-transform: " . esc_attr($wallregi_giftcard_form_items_heading_group['giftcard_form_items_heading_text_transform'] ?? 'none') . ";
    }

    /* Input label styles */
    .wallregi_form_wrap .wallregi_placeholder__text{
        color: " . esc_attr($wallregi_giftcard_form_items_label_group['giftcard_form_items_label_text_color'] ?? '#7e7c7c') . ";
        font-size: " . intval($wallregi_giftcard_form_items_label_group['giftcard_form_items_label_font_size'] ?? 14) . "px;
        font-weight: " . esc_attr($wallregi_giftcard_form_items_label_group['giftcard_form_items_label_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_giftcard_form_items_label_group['giftcard_form_items_label_text_align'] ?? 'left') . ";
        text-transform: " . esc_attr($wallregi_giftcard_form_items_label_group['giftcard_form_items_label_text_transform'] ?? 'capitalize') . ";
    }

    /* Normal input, textarea, datetime styles */
    .wallregi_custom_price_wraper .wallregi_cprice_input_field,
    .wallregi_edit_cart_modal .edit_giftcard_heading_input,
    .wallregi_modal_form_contents .wallregi_edit_input,
    .wallregi_modal_form_contents .wallregi_edit_textarea,
    .wallregi_coupon_form .wallregi_input_group .input-text,
    .wallregi_form_items .wallregi_input__field,
    .wallregi_form_items .wallregi_datetime__field,
    .wallregi_form_items .wallregi_textarea__field {
        color: " . esc_attr($wallregi_giftcard_form_items_styles_group['giftcard_form_items_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_giftcard_form_items_styles_group['giftcard_form_items_font_size'] ?? 14) . "px;
        background-color: " . esc_attr($wallregi_giftcard_form_items_styles_group['giftcard_form_items_bg_color'] ?? '#f3f3f3') . ";
        {$wallregi_giftcard_form_items_border_css};
        {$wallregi_giftcard_form_items_radius_css};
        {$wallregi_giftcard_form_items_padding_css};
    }

    /* Placeholder Text */
    .wallregi_custom_price_wraper .wallregi_cprice_input_field::placeholder,
    .wallregi_edit_cart_modal .edit_giftcard_heading_input::placeholder,
    .wallregi_modal_form_contents .wallregi_edit_input::placeholder,
    .wallregi_modal_form_contents .wallregi_edit_textarea::placeholder,
    .wallregi_form_items .wallregi_input__field::placeholder,
    .wallregi_form_items .wallregi_datetime__field::placeholder,
    .wallregi_form_items .wallregi_textarea__field::placeholder,
    .wallregi_custom_price_wraper .wallregi_cprice_input_field::placeholder {
        color: " . esc_attr($wallregi_giftcard_form_items_placeholder_group['giftcard_form_items_placeholder_text_color'] ?? '#999999') . ";
        font-size: " . intval($wallregi_giftcard_form_items_placeholder_group['giftcard_form_items_placeholder_font_size'] ?? 14) . "px;
        font-weight: " . esc_attr($wallregi_giftcard_form_items_placeholder_group['giftcard_form_items_placeholder_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_giftcard_form_items_placeholder_group['giftcard_form_items_placeholder_text_align'] ?? 'left') . ";
        text-transform: " . esc_attr($wallregi_giftcard_form_items_placeholder_group['giftcard_form_items_placeholder_text_transform'] ?? 'none') . ";
    }

    /* Focus Styles */
    .wallregi_form_items input:focus,
    .wallregi_form_items textarea:focus,
    .wallregi_custom_price_wraper .wallregi_cprice_input_field.wallregi_active:focus {
        color: " . esc_attr($wallregi_giftcard_form_items_pseudo_group['giftcard_form_items_pseudo_text_color'] ?? '#333333') . ";
        background-color: " . esc_attr($wallregi_giftcard_form_items_pseudo_group['giftcard_form_items_pseudo_bg_color'] ?? '#ffffff') . " !important;
        border-color: " . esc_attr($wallregi_giftcard_form_items_pseudo_group['giftcard_form_items_pseudo_border_color'] ?? '#7f54b3') . ";
        border-style: " . esc_attr($wallregi_giftcard_form_items_pseudo_group['giftcard_form_items_pseudo_border_styles'] ?? 'solid') . ";
        outline: none;
    }

    .showErrorMgs .wallregi_error_mgs {
        font-size: " . intval($wallregi_giftcard_form_submit_mgs_group['giftcard_form_submit_mgs_font_size'] ?? 14) . "px;
        font-weight: " . esc_attr($wallregi_giftcard_form_submit_mgs_group['giftcard_form_submit_mgs_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_giftcard_form_submit_mgs_group['giftcard_form_submit_mgs_text_align'] ?? 'left') . ";
        text-transform: " . esc_attr($wallregi_giftcard_form_submit_mgs_group['giftcard_form_submit_mgs_text_transform'] ?? 'none') . ";
    }


    /* Giftcard Layout Button Group Styling */
    .giftcard_pdf_download,
    .wallregi_custom_price_options .wallregi_item > .price_btn,
    .wallregi_edit_cart_modal .wallregi_title .button,
    .wallregi_edit_cart_modal .wallregi_form_button_items .button,
    .wodg_edit_cart_item_button_box .wodg_cart_item_edit_button,
    .wallregi_coupon_form .wallregi_input_group .apply_coupon_btn,
    .wallregi_giftcard_section .wallregi_button__items .button{
        color: " . esc_attr($wallregi_giftcard_all_buttons_styles_group['giftcard_all_buttons_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_giftcard_all_buttons_styles_group['giftcard_all_buttons_font_size'] ?? 14) . "px;
        font-weight: " . esc_attr($wallregi_giftcard_all_buttons_styles_group['giftcard_all_buttons_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_giftcard_all_buttons_styles_group['giftcard_all_buttons_text_align'] ?? 'center') . ";
        text-transform: " . esc_attr($wallregi_giftcard_all_buttons_styles_group['giftcard_all_buttons_text_transform'] ?? 'none') . ";

        background-color: " . esc_attr($wallregi_giftcard_all_buttons_border_group['giftcard_all_buttons_bg_color'] ?? '#7f54b3') . ";
        padding: 7px;
        {$wallregi_giftcard_all_buttons_padding_css}
        {$wallregi_giftcard_all_buttons_border_css}
        {$wallregi_giftcard_all_buttons_radius_css}
    }

    /* Giftcard Layout Button Group Pseudo Styling */
    .giftcard_pdf_download:hover,
    .wallregi_custom_price_options .wallregi_item > .price_btn:hover,
    .wallregi_edit_cart_modal .wallregi_title .button:hover,
    .wallregi_edit_cart_modal .wallregi_form_button_items .button:hover,
    .wodg_edit_cart_item_button_box .wodg_cart_item_edit_button:hover,
    .wallregi_coupon_form .wallregi_input_group .apply_coupon_btn:hover,
    .wallregi_giftcard_section .wallregi_button__items .button:hover{
        color: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_text_color'] ?? '#ffffff') . ";
        background-color: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_bg_color'] ?? '#be88eb') . ";
        border-color: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_border_color'] ?? '#be88eb') . ";
        border-style: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_border_styles'] ?? 'solid') . ";
    }

    .wallregi_giftcard_section .wallregi_button__items .button:hover .wallregi_icon::before,
    .wallregi_giftcard_section .wallregi_button__items .button:hover .wallregi_icon::after{
        background-color: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_text_color'] ?? '#ffffff') . ";
    }

    .wallregi_custom_price_options .wallregi_item.wallregi_active > .price_btn{
        color: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_text_color'] ?? '#ffffff') . ";
        background-color: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_bg_color'] ?? '#be88eb') . ";
        border-color: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_border_color'] ?? '#be88eb') . ";
        border-style: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_border_styles'] ?? 'solid') . ";
    }
    .wallregi_custom_price_options .wallregi_item.wallregi_selected > .price_btn{
        color: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_text_color'] ?? '#ffffff') . ";
        background-color: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_bg_color'] ?? '#be88eb') . ";
        border-color: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_border_color'] ?? '#be88eb') . ";
        border-style: " . esc_attr($wallregi_giftcard_all_buttons_pseudo_styles_group['giftcard_all_buttons_pseudo_border_styles'] ?? 'solid') . ";
    }

    .wallregi_edit_cart_modal label {
        color: " . esc_attr($wallregi_edit_giftcard_label_style_group['edit_giftcard_label_style_text_color'] ?? '#333333') . ";
        font-size: " . intval($wallregi_edit_giftcard_label_style_group['edit_giftcard_label_style_font_size'] ?? 14) . "px;
        font-weight: " . esc_attr($wallregi_edit_giftcard_label_style_group['edit_giftcard_label_style_font_weight'] ?? 'normal') . ";
        text-align: " . esc_attr($wallregi_edit_giftcard_label_style_group['edit_giftcard_label_style_text_align'] ?? 'left') . ";
        text-transform: " . esc_attr($wallregi_edit_giftcard_label_style_group['edit_giftcard_label_style_text_transform'] ?? 'none') . ";
        {$wallregi_edit_giftcard_label_style_margin_css}
    }

";