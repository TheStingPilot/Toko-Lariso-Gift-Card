<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}



/**
 * Utility functions for spacing, border radius, and box-shadow.
 */

// Generate spacings css (padding, margin, border)
function wallregi_generate_spacing_css($width, $position = 'none', $property = 'padding', $style = 'solid', $color = '#333333') {

    // Handle 'none' case based on property type
    if ($position === 'none' || $style === 'none') {
        return ($property === 'border') ? "{$property}: none;" : "{$property}: 0;";
    }

    // Special handling for border: add style and colo
    $wallregi_value = ($property === 'border')
        ? intval($width) . "px {$style} {$color}"
        : intval($width) . 'px';

    return match ($position) {
        'top'        => "{$property}-top: {$wallregi_value};",
        'right'      => "{$property}-right: {$wallregi_value};",
        'bottom'     => "{$property}-bottom: {$wallregi_value};",
        'left'       => "{$property}-left: {$wallregi_value};",
        'top_bottom' => "{$property}-top: {$wallregi_value}; {$property}-bottom: {$wallregi_value};",
        'left_right' => "{$property}-left: {$wallregi_value}; {$property}-right: {$wallregi_value};",
        'all'        => "{$property}: {$wallregi_value};",
        default      => '',
    };
}

// Generate border-radius CSS 
function wallregi_generate_radius_css($width, $position = 'all') {
    $width = intval($width) . 'px';

    return match ($position) {
        'top_left'     => "border-top-left-radius: {$width};",
        'top_right'    => "border-top-right-radius: {$width};",
        'bottom_left'  => "border-bottom-left-radius: {$width};",
        'bottom_right' => "border-bottom-right-radius: {$width};",
        'top'          => "border-top-left-radius: {$width}; border-top-right-radius: {$width};",
        'bottom'       => "border-bottom-left-radius: {$width}; border-bottom-right-radius: {$width};",
        'left'         => "border-top-left-radius: {$width}; border-bottom-left-radius: {$width};",
        'right'        => "border-top-right-radius: {$width}; border-bottom-right-radius: {$width};",
        'none'         => "border-radius: 0;",
        default        => "border-radius: {$width};",
    };
}

// Generate box shadow CSS
function wallregi_generate_box_shadow_css(
    $type = 'outer', 
    $horizontal = 0, 
    $vertical = 4, 
    $blur = 10, 
    $spread = 0, 
    $color = 'rgba(234, 239, 243, 0.8)'
    ) {
        
    // If type is 'none', return no shadow
    if ($type === 'none') {
        return 'box-shadow: none;';
    }

    // Determine if shadow is inset
    $inset = ($type === 'inset') ? 'inset ' : '';

    // Return box-shadow CSS
    return sprintf(
        'box-shadow: %s%dpx %dpx %dpx %dpx %s;',
        $inset,
        intval($horizontal),
        intval($vertical),
        intval($blur),
        intval($spread),
        esc_attr($color)
    );
}