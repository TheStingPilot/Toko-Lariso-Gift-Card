<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Initialize all CSS variables to prevent undefined variable warnings
$wallregi_giftcard_header_border_css = '';
$wallregi_giftcard_header_padding_css = '';
$wallregi_giftcard_header_radius_css = '';
$wallregi_giftcard_active_header_border_css = '';
$wallregi_giftcard_active_header_padding_css = '';
$wallregi_giftcard_active_header_radius_css = '';
$wallregi_giftcard_body_border_css = '';
$wallregi_giftcard_body_padding_css = '';
$wallregi_giftcard_body_radius_css = '';
$wallregi_giftcard_right_side_contents_border_css = '';
$wallregi_giftcard_right_side_contents_padding_css = '';
$wallregi_giftcard_right_side_contents_margin_css = '';
$wallregi_giftcard_right_side_contents_radius_css = '';
$wallregi_giftcard_custom_price_box_border_css = '';
$wallregi_giftcard_custom_price_box_padding_css = '';
$wallregi_giftcard_custom_price_box_margin_css = '';
$wallregi_giftcard_custom_price_box_radius_css = '';
$wallregi_giftcard_custom_price_heading_margin_css = '';
$wallregi_giftcard_price_button_border_css = '';
$wallregi_giftcard_price_button_padding_css = '';
$wallregi_giftcard_price_button_margin_css = '';
$wallregi_giftcard_price_button_radius_css = '';
$wallregi_giftcard_img_gallery_box_border_css = '';
$wallregi_giftcard_img_gallery_box_padding_css = '';
$wallregi_giftcard_img_gallery_box_margin_css = '';
$wallregi_giftcard_img_gallery_box_radius_css = '';
$wallregi_giftcard_img_gallery_heading_margin_css = '';
$wallregi_giftcard_img_gallery_item_border_css = '';
$wallregi_giftcard_img_gallery_item_radius_css = '';
$wallregi_giftcard_img_gallery_item_pseudo_shadow_css = '';
$wallregi_giftcard_all_buttons_border_css = '';
$wallregi_giftcard_all_buttons_padding_css = '';
$wallregi_giftcard_all_buttons_radius_css = '';
$wallregi_giftcard_form_items_border_css = '';
$wallregi_giftcard_form_items_padding_css = '';
$wallregi_giftcard_form_items_radius_css = '';
$wallregi_edit_giftcard_label_style_margin_css = '';
$wallregi_pdf_template_container_border_css = '';
$wallregi_pdf_template_container_margin_css = '';
$wallregi_pdf_template_container_radius_css = '';
$wallregi_pdf_header_style_border_css = '';
$wallregi_pdf_header_style_padding_css = '';
$wallregi_pdf_header_style_margin_css = '';
$wallregi_pdf_header_box_shadow_css = '';
$wallregi_pdf_content_style_border_css = '';
$wallregi_pdf_content_style_padding_css = '';
$wallregi_pdf_content_style_margin_css = '';
$wallregi_pdf_title_text_style_margin_css = '';
$wallregi_pdf_giftcard_price_style_border_css = '';
$wallregi_pdf_giftcard_price_style_padding_css = '';
$wallregi_pdf_giftcard_price_style_margin_css = '';
$wallregi_pdf_preview_mgs_style_border_css = '';
$wallregi_pdf_preview_mgs_style_padding_css = '';
$wallregi_pdf_preview_mgs_style_margin_css = '';
$wallregi_pdf_footer_border_css = '';
$wallregi_pdf_footer_padding_css = '';
$wallregi_pdf_footer_margin_css = '';
$wallregi_apply_giftcard_container_border_css = '';
$wallregi_apply_giftcard_container_radius_css = '';
$wallregi_apply_giftcard_container_header_padding_css = '';
$wallregi_apply_giftcard_coupon_code_box_padding_css = '';
$wallregi_apply_giftcard_coupon_code_padding_css = '';
$wallregi_apply_giftcard_coupon_code_margin_css = '';
$wallregi_apply_giftcard_coupon_code_border_css = '';
$wallregi_apply_giftcard_coupon_code_radius_css = '';

/*=========================
* GIFTCARD LAYOUT BOX MODEL START
*==================================== */

// Header default title spacing
$wallregi_giftcard_header_border_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_header_border_group['giftcard_header_border_width'] ?? 0,
    $wallregi_giftcard_header_border_group['giftcard_header_border_position'] ?? 'none',
    'border',
    $wallregi_giftcard_header_border_group['giftcard_header_border_styles'] ?? 'solid',
    $wallregi_giftcard_header_border_group['giftcard_header_border_color'] ?? '#333333'
);

$wallregi_giftcard_header_padding_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_header_box_model_group['giftcard_header_padding_width'] ?? 0,
    $wallregi_giftcard_header_box_model_group['giftcard_header_padding_position'] ?? 'none',
    'padding'
);

$wallregi_giftcard_header_radius_css = wallregi_generate_radius_css(
    $wallregi_giftcard_header_box_model_group['giftcard_header_radius_width'] ?? 0,
    $wallregi_giftcard_header_box_model_group['giftcard_header_radius_position'] ?? 'none'
);

// Header active title spacing
$wallregi_giftcard_active_header_border_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_active_header_border_group['giftcard_active_header_border_width'] ?? 0,
    $wallregi_giftcard_active_header_border_group['giftcard_active_header_border_position'] ?? 'none',
    'border',
    $wallregi_giftcard_active_header_border_group['giftcard_active_header_border_styles'] ?? 'solid',
    $wallregi_giftcard_active_header_border_group['giftcard_active_header_border_color'] ?? '#333333'
);

$wallregi_giftcard_active_header_padding_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_active_header_box_model_group['giftcard_active_header_padding_width'] ?? 0,
    $wallregi_giftcard_active_header_box_model_group['giftcard_active_header_padding_position'] ?? 'none',
    'padding'
);

$wallregi_giftcard_active_header_radius_css = wallregi_generate_radius_css(
    $wallregi_giftcard_active_header_box_model_group['giftcard_active_header_radius_width'] ?? 0,
    $wallregi_giftcard_active_header_box_model_group['giftcard_active_header_radius_position'] ?? 'none'
);

// Contents body spacing
$wallregi_giftcard_body_border_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_body_fields_group['giftcard_body_border_width'] ?? 0,
    $wallregi_giftcard_body_fields_group['giftcard_body_border_position'] ?? 'none',
    'border',
    $wallregi_giftcard_body_fields_group['giftcard_body_border_styles'] ?? 'solid',
    $wallregi_giftcard_body_fields_group['giftcard_body_border_color'] ?? '#333333'
);

$wallregi_giftcard_body_padding_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_body_fields_group['giftcard_body_padding_width'] ?? 0,
    $wallregi_giftcard_body_fields_group['giftcard_body_padding_position'] ?? 'none',
    'padding'
);

$wallregi_giftcard_body_radius_css = wallregi_generate_radius_css(
    $wallregi_giftcard_body_fields_group['giftcard_body_radius_width'] ?? 0,
    $wallregi_giftcard_body_fields_group['giftcard_body_radius_position'] ?? 'none'
);

// Giftcard Right Side Summary Contents Paragraph Spacing
// Border Spacing 
 $wallregi_giftcard_right_side_contents_border_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_border_width'] ?? 0,
    $wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_border_position'] ?? 'none',
    'border',
    $wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_border_styles'] ?? 'solid',
    $wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_border_color'] ?? '#333333'
);
// Padding Spacing 
$wallregi_giftcard_right_side_contents_padding_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_padding_width'] ?? 0,
    $wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_padding_position'] ?? 'none',
    'padding'
);
// Margin Spacing 
$wallregi_giftcard_right_side_contents_margin_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_margin_width'] ?? 0,
    $wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_margin_position'] ?? 'none',
    'margin'
);
// Border Radius Spacing 
$wallregi_giftcard_right_side_contents_radius_css = wallregi_generate_radius_css(
    $wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_radius_width'] ?? 0,
    $wallregi_giftcard_right_side_contents_group['giftcard_right_side_contents_radius_position'] ?? 'none'
);

// Giftcard Right Side Custom Price Box Model Spacing
// Border Spacing 
 $wallregi_giftcard_custom_price_box_border_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_custom_price_box_group['giftcard_custom_price_box_border_width'] ?? 0,
    $wallregi_giftcard_custom_price_box_group['giftcard_custom_price_box_border_position'] ?? 'none',
    'border',
    $wallregi_giftcard_custom_price_box_group['giftcard_custom_price_box_border_styles'] ?? 'solid',
    $wallregi_giftcard_custom_price_box_group['giftcard_custom_price_box_border_color'] ?? '#333333'
);
// Padding Spacing 
$wallregi_giftcard_custom_price_box_padding_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_custom_price_box_group['giftcard_custom_price_box_padding_width'] ?? 0,
    $wallregi_giftcard_custom_price_box_group['giftcard_custom_price_box_padding_position'] ?? 'none',
    'padding'
);
// Margin Spacing 
$wallregi_giftcard_custom_price_box_margin_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_custom_price_box_group['giftcard_custom_price_box_margin_width'] ?? 0,
    $wallregi_giftcard_custom_price_box_group['giftcard_custom_price_box_margin_position'] ?? 'none',
    'margin'
);
// Border Radius Spacing 
$wallregi_giftcard_custom_price_box_radius_css = wallregi_generate_radius_css(
    $wallregi_giftcard_custom_price_box_group['giftcard_custom_price_box_radius_width'] ?? 0,
    $wallregi_giftcard_custom_price_box_group['giftcard_custom_price_box_radius_position'] ?? 'none'
);

// Giftcard Custom Price Heading Spacing
// Margin Spacing 
$wallregi_giftcard_custom_price_heading_margin_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_custom_price_heading_group['giftcard_custom_price_heading_margin_width'] ?? 0,
    $wallregi_giftcard_custom_price_heading_group['giftcard_custom_price_heading_margin_position'] ?? 'none',
    'margin'
);


// Giftcard Right Side Custom Prices Button Group Spacing
// Border Spacing 
 $wallregi_giftcard_price_button_border_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_price_button_group['giftcard_price_button_border_width'] ?? 0,
    $wallregi_giftcard_price_button_group['giftcard_price_button_border_position'] ?? 'none',
    'border',
    $wallregi_giftcard_price_button_group['giftcard_price_button_border_styles'] ?? 'solid',
    $wallregi_giftcard_price_button_group['giftcard_price_button_border_color'] ?? '#333333'
);
// Padding Spacing 
$wallregi_giftcard_price_button_padding_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_price_button_group['giftcard_price_button_padding_width'] ?? 0,
    $wallregi_giftcard_price_button_group['giftcard_price_button_padding_position'] ?? 'none',
    'padding'
);
// Margin Spacing 
$wallregi_giftcard_price_button_margin_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_price_button_group['giftcard_price_button_margin_width'] ?? 0,
    $wallregi_giftcard_price_button_group['giftcard_price_button_margin_position'] ?? 'none',
    'margin'
);
// Border Radius Spacing 
$wallregi_giftcard_price_button_radius_css = wallregi_generate_radius_css(
    $wallregi_giftcard_price_button_group['giftcard_price_button_radius_width'] ?? 0,
    $wallregi_giftcard_price_button_group['giftcard_price_button_radius_position'] ?? 'none'
);


// Giftcard Right Side Images Gallery Box Model Spacing
// Border Spacing 
 $wallregi_giftcard_img_gallery_box_border_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_img_gallery_box_group['giftcard_img_gallery_box_border_width'] ?? 0,
    $wallregi_giftcard_img_gallery_box_group['giftcard_img_gallery_box_border_position'] ?? 'none',
    'border',
    $wallregi_giftcard_img_gallery_box_group['giftcard_img_gallery_box_border_styles'] ?? 'solid',
    $wallregi_giftcard_img_gallery_box_group['giftcard_img_gallery_box_border_color'] ?? '#333333'
);
// Padding Spacing 
$wallregi_giftcard_img_gallery_box_padding_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_img_gallery_box_group['giftcard_img_gallery_box_padding_width'] ?? 0,
    $wallregi_giftcard_img_gallery_box_group['giftcard_img_gallery_box_padding_position'] ?? 'none',
    'padding'
);
// Margin Spacing 
$wallregi_giftcard_img_gallery_box_margin_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_img_gallery_box_group['giftcard_img_gallery_box_margin_width'] ?? 0,
    $wallregi_giftcard_img_gallery_box_group['giftcard_img_gallery_box_margin_position'] ?? 'none',
    'margin'
);
// Border Radius Spacing 
$wallregi_giftcard_img_gallery_box_radius_css = wallregi_generate_radius_css(
    $wallregi_giftcard_img_gallery_box_group['giftcard_img_gallery_box_radius_width'] ?? 0,
    $wallregi_giftcard_img_gallery_box_group['giftcard_img_gallery_box_radius_position'] ?? 'none'
);

// Giftcard Images Gallery Heading Spacing
// Margin Spacing 
$wallregi_giftcard_img_gallery_heading_margin_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_img_gallery_heading_group['giftcard_img_gallery_heading_margin_width'] ?? 0,
    $wallregi_giftcard_img_gallery_heading_group['giftcard_img_gallery_heading_margin_position'] ?? 'none',
    'margin'
);


// Giftcard Right Side Images Gallery Item Spacing
// Border Spacing 
 $wallregi_giftcard_img_gallery_item_border_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_img_gallery_item_group['giftcard_img_gallery_item_border_width'] ?? 0,
    $wallregi_giftcard_img_gallery_item_group['giftcard_img_gallery_item_border_position'] ?? 'none',
    'border',
    $wallregi_giftcard_img_gallery_item_group['giftcard_img_gallery_item_border_styles'] ?? 'solid',
    $wallregi_giftcard_img_gallery_item_group['giftcard_img_gallery_item_border_color'] ?? '#333333'
);

// Border Radius Spacing 
$wallregi_giftcard_img_gallery_item_radius_css = wallregi_generate_radius_css(
    $wallregi_giftcard_img_gallery_item_group['giftcard_img_gallery_item_radius_width'] ?? 0,
    $wallregi_giftcard_img_gallery_item_group['giftcard_img_gallery_item_radius_position'] ?? 'none'
);

// Giftcard Right Side Images Gallery Item Pseudo Spacing
// Box Shadow 
$wallregi_giftcard_img_gallery_item_pseudo_shadow_css = wallregi_generate_box_shadow_css(
    $wallregi_giftcard_img_gallery_item_pseudo_group['giftcard_img_gallery_item_pseudo_shadow_type'] ?? 'none',
    $wallregi_giftcard_img_gallery_item_pseudo_group['giftcard_img_gallery_item_pseudo_shadow_horizontal'] ?? 0,
    $wallregi_giftcard_img_gallery_item_pseudo_group['giftcard_img_gallery_item_pseudo_shadow_vertical'] ?? 4,
    $wallregi_giftcard_img_gallery_item_pseudo_group['giftcard_img_gallery_item_pseudo_shadow_blur'] ?? 10,
    $wallregi_giftcard_img_gallery_item_pseudo_group['giftcard_img_gallery_item_pseudo_shadow_spread'] ?? 0,
    $wallregi_giftcard_img_gallery_item_pseudo_group['giftcard_img_gallery_item_pseudo_shadow_color'] ?? 'rgba(234, 239, 243, 0.8)',
);


/*=========================
* GIFTCARD LAYOUT BOX MODEL END
*================================== */

/*=================================
* GIFTCARD ALL BUTTON GROUPS BOX MODEL START
*============================================= */

// Giftcard all button group spacing
$wallregi_giftcard_all_buttons_border_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_all_buttons_border_group['giftcard_all_buttons_border_width'] ?? 0,
    $wallregi_giftcard_all_buttons_border_group['giftcard_all_buttons_border_position'] ?? 'none',
    'border',
    $wallregi_giftcard_all_buttons_border_group['giftcard_all_buttons_border_styles'] ?? 'solid',
    $wallregi_giftcard_all_buttons_border_group['giftcard_all_buttons_border_color'] ?? '#333333'
);

$wallregi_giftcard_all_buttons_padding_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_all_buttons_box_model_group['giftcard_all_buttons_padding_width'] ?? 0,
    $wallregi_giftcard_all_buttons_box_model_group['giftcard_all_buttons_padding_position'] ?? 'none',
    'padding'
);

$wallregi_giftcard_all_buttons_radius_css = wallregi_generate_radius_css(
    $wallregi_giftcard_all_buttons_box_model_group['giftcard_all_buttons_radius_width'] ?? 0,
    $wallregi_giftcard_all_buttons_box_model_group['giftcard_all_buttons_radius_position'] ?? 'none'
);

/*==================================
* GIFTCARD ALL BUTTON GROUPS BOX MODEL END
*============================================ */

/*=========================
* GIFTCARD FORM BOX MODEL START
*=============================== */

// Form spacing
$wallregi_giftcard_form_items_border_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_form_items_box_model_group['giftcard_form_items_border_width'] ?? 0,
    $wallregi_giftcard_form_items_box_model_group['giftcard_form_items_border_position'] ?? 'none',
    'border',
    $wallregi_giftcard_form_items_box_model_group['giftcard_form_items_border_styles'] ?? 'solid',
    $wallregi_giftcard_form_items_box_model_group['giftcard_form_items_border_color'] ?? '#333333'
);

$wallregi_giftcard_form_items_padding_css = wallregi_generate_spacing_css(
    $wallregi_giftcard_form_items_box_model_group['giftcard_form_items_padding_width'] ?? 0,
    $wallregi_giftcard_form_items_box_model_group['giftcard_form_items_padding_position'] ?? 'none',
    'padding'
);

$wallregi_giftcard_form_items_radius_css = wallregi_generate_radius_css(
    $wallregi_giftcard_form_items_box_model_group['giftcard_form_items_radius_width'] ?? 0,
    $wallregi_giftcard_form_items_box_model_group['giftcard_form_items_radius_position'] ?? 'none'
);

// For Edit GiftCard Form Label Spacing
$wallregi_edit_giftcard_label_style_margin_css = wallregi_generate_spacing_css(
    $wallregi_edit_giftcard_label_style_group['edit_giftcard_label_style_margin_width'] ?? 0,
    $wallregi_edit_giftcard_label_style_group['edit_giftcard_label_style_margin_position'] ?? 'none',
    'margin'
);

/*=========================
* GIFTCARD FORM BOX MODEL END
*=============================== */

/*===========================
* GIFTCARD PDF TEMPLATE BOX MODEL START
*======================================== */

// For Giftcard PDF Template Box Model Spacing:
$wallregi_pdf_template_container_border_css = wallregi_generate_spacing_css(
    $wallregi_pdf_template_container_group['pdf_template_container_border_width'] ?? 0,
    $wallregi_pdf_template_container_group['pdf_template_container_border_position'] ?? 'none',
    'border',
    $wallregi_pdf_template_container_group['pdf_template_container_border_styles'] ?? 'solid',
    $wallregi_pdf_template_container_group['pdf_template_container_border_color'] ?? '#333333',
);

$wallregi_pdf_template_container_margin_css = wallregi_generate_spacing_css(
    $wallregi_pdf_template_container_group['pdf_template_container_margin_width'] ?? 0,
    $wallregi_pdf_template_container_group['pdf_template_container_margin_position'] ?? 'none',
    'margin',
);

$wallregi_pdf_template_container_radius_css = wallregi_generate_radius_css(
    $wallregi_pdf_template_container_group['pdf_template_container_radius_width'] ?? 0,
    $wallregi_pdf_template_container_group['pdf_template_container_radius_position'] ?? 'none',

);

// For Giftcard PDF Layout Header Box Model (Padding, Margin, Border & Box Shadow):
$wallregi_pdf_header_style_border_css = wallregi_generate_spacing_css(
    $wallregi_pdf_header_style_group['pdf_header_style_border_width'] ?? 0,
    $wallregi_pdf_header_style_group['pdf_header_style_border_position'] ?? 'none',
    'border',
    $wallregi_pdf_header_style_group['pdf_header_style_border_styles'] ?? 'solid',
    $wallregi_pdf_header_style_group['pdf_header_style_border_color'] ?? '#333333',
);

$wallregi_pdf_header_style_padding_css = wallregi_generate_spacing_css(
    $wallregi_pdf_header_style_group['pdf_header_style_padding_width'] ?? 0,
    $wallregi_pdf_header_style_group['pdf_header_style_padding_position'] ?? 'none',
    'padding',
);

$wallregi_pdf_header_style_margin_css = wallregi_generate_spacing_css(
    $wallregi_pdf_header_style_group['pdf_header_style_margin_width'] ?? 0,
    $wallregi_pdf_header_style_group['pdf_header_style_margin_position'] ?? 'none',
    'margin',
);

// For Giftcard PDF Template Layout Header Box Shadow:
$wallregi_pdf_header_box_shadow_css = wallregi_generate_box_shadow_css(
    $wallregi_pdf_header_box_shadow_group['pdf_header_shadow_type'] ?? 'none',
    $wallregi_pdf_header_box_shadow_group['pdf_header_shadow_horizontal'] ?? 0,
    $wallregi_pdf_header_box_shadow_group['pdf_header_shadow_vertical'] ?? 4,
    $wallregi_pdf_header_box_shadow_group['pdf_header_shadow_blur'] ?? 10,
    $wallregi_pdf_header_box_shadow_group['pdf_header_shadow_spread'] ?? 0,
    $wallregi_pdf_header_box_shadow_group['pdf_header_shadow_color'] ?? 'rgba(234, 239, 243, 0.8)',
);


// For Giftcard PDF Layout Content Body Box Model (Padding, Margin & Border):
$wallregi_pdf_content_style_border_css = wallregi_generate_spacing_css(
    $wallregi_pdf_content_style_group['pdf_content_style_border_width'] ?? 0,
    $wallregi_pdf_content_style_group['pdf_content_style_border_position'] ?? 'none',
    'border',
    $wallregi_pdf_content_style_group['pdf_content_style_border_styles'] ?? 'solid',
    $wallregi_pdf_content_style_group['pdf_content_style_border_color'] ?? '#333333',
);

$wallregi_pdf_content_style_padding_css = wallregi_generate_spacing_css(
    $wallregi_pdf_content_style_group['pdf_content_style_padding_width'] ?? 0,
    $wallregi_pdf_content_style_group['pdf_content_style_padding_position'] ?? 'none',
    'padding',
);

$wallregi_pdf_content_style_margin_css = wallregi_generate_spacing_css(
    $wallregi_pdf_content_style_group['pdf_content_style_margin_width'] ?? 0,
    $wallregi_pdf_content_style_group['pdf_content_style_margin_position'] ?? 'none',
    'margin',
);



// For Giftcard PDF Title Box Model (Padding & Margin):
// $pdf_title_text_style_padding_css = wallregi_generate_spacing_css(
//     $wallregi_pdf_title_text_style_group['pdf_title_text_style_padding_width'],
//     $wallregi_pdf_title_text_style_group['pdf_title_text_style_padding_position'],
//     'padding'
// );

$wallregi_pdf_title_text_style_margin_css = wallregi_generate_spacing_css(
    $wallregi_pdf_title_text_style_group['pdf_title_text_style_margin_width'] ?? 0,
    $wallregi_pdf_title_text_style_group['pdf_title_text_style_margin_position'] ?? 'none',
    'margin'
);

// For Giftcard PDF Price Section Box Model (Padding, Margin & Border):
$wallregi_pdf_giftcard_price_style_border_css = wallregi_generate_spacing_css(
    $wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_border_width'] ?? 0,
    $wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_border_position'] ?? 'none',
    'border',
    $wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_border_styles'] ?? 'solid',
    $wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_border_color'] ?? '#333333',
);

$wallregi_pdf_giftcard_price_style_padding_css = wallregi_generate_spacing_css(
    $wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_padding_width'] ?? 0,
    $wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_padding_position'] ?? 'none',
    'padding'
);

$wallregi_pdf_giftcard_price_style_margin_css = wallregi_generate_spacing_css(
    $wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_margin_width'] ?? 0,
    $wallregi_pdf_giftcard_price_style_group['pdf_giftcard_price_style_margin_position'] ?? 'none',
    'margin'
);

// For Giftcard PDF Preview Message Box Model (Padding, Margin & Border):
$wallregi_pdf_preview_mgs_style_border_css = wallregi_generate_spacing_css(
    $wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_border_width'] ?? 0,
    $wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_border_position'] ?? 'none',
    'border',
    $wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_border_styles'] ?? 'solid',
    $wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_border_color'] ?? '#333333',
);

$wallregi_pdf_preview_mgs_style_padding_css = wallregi_generate_spacing_css(
    $wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_padding_width'] ?? 0,
    $wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_padding_position'] ?? 'none',
    'padding'
);

$wallregi_pdf_preview_mgs_style_margin_css = wallregi_generate_spacing_css(
    $wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_margin_width'] ?? 0,
    $wallregi_pdf_preview_mgs_style_group['pdf_preview_mgs_style_margin_position'] ?? 'none',
    'margin'
);

// For Giftcard PDF Layout Footer Box Model (Padding, Margin & Border):
$wallregi_pdf_footer_border_css = wallregi_generate_spacing_css(
    $wallregi_pdf_footer_border_group['pdf_footer_border_width'] ?? 0,
    $wallregi_pdf_footer_border_group['pdf_footer_border_position'] ?? 'none',
    'border',
    $wallregi_pdf_footer_border_group['pdf_footer_border_styles'] ?? 'solid',
    $wallregi_pdf_footer_border_group['pdf_footer_border_color'] ?? '#333333',
);


$wallregi_pdf_footer_padding_css = wallregi_generate_spacing_css(
    $wallregi_pdf_footer_box_model_group['pdf_footer_padding_width'] ?? 0,
    $wallregi_pdf_footer_box_model_group['pdf_footer_padding_position'] ?? 'none',
    'padding',
);


$wallregi_pdf_footer_margin_css = wallregi_generate_spacing_css(
    $wallregi_pdf_footer_box_model_group['pdf_footer_margin_width'] ?? 0,
    $wallregi_pdf_footer_box_model_group['pdf_footer_margin_position'] ?? 'none',
    'margin',
);

/*===========================
* GIFTCARD PDF TEMPLATE BOX MODEL END
*======================================== */

/*========================
* APPLY GIFTCARD BOX MODEL START
*================================ */

$wallregi_apply_giftcard_container_border_css = wallregi_generate_spacing_css(
    $wallregi_apply_giftcard_container_group['apply_giftcard_container_border_width'] ?? 0,
    $wallregi_apply_giftcard_container_group['apply_giftcard_container_border_position'] ?? 'none',
    'border',
    $wallregi_apply_giftcard_container_group['apply_giftcard_container_border_styles'] ?? 'solid',
    $wallregi_apply_giftcard_container_group['apply_giftcard_container_border_color'] ?? '#333333',
);


$wallregi_apply_giftcard_container_radius_css = wallregi_generate_radius_css(
    $wallregi_apply_giftcard_container_group['apply_giftcard_container_radius_width'] ?? 0,
    $wallregi_apply_giftcard_container_group['apply_giftcard_container_radius_position'] ?? 'none',
);

// Apply Giftcard Header Padding 
$wallregi_apply_giftcard_container_header_padding_css = wallregi_generate_spacing_css(
    $wallregi_apply_giftcard_container_header_group['apply_giftcard_container_header_padding_width'] ?? 0,
    $wallregi_apply_giftcard_container_header_group['apply_giftcard_container_header_padding_position'] ?? 'none',
    'padding'
);

// Apply Giftcard Coupon Code Container Padding 
$wallregi_apply_giftcard_coupon_code_box_padding_css = wallregi_generate_spacing_css(
    $wallregi_apply_giftcard_coupon_code_box_group['apply_giftcard_coupon_code_box_padding_width'] ?? 0,
    $wallregi_apply_giftcard_coupon_code_box_group['apply_giftcard_coupon_code_box_padding_position'] ?? 'none',
    'padding'
);

// Apply Giftcard Coupon Code List Item Spacing (Padding, Margin, Border, Radius)
$wallregi_apply_giftcard_coupon_code_padding_css = wallregi_generate_spacing_css(
    $wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_padding_width'] ?? 0,
    $wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_padding_position'] ?? 'none',
    'padding'
);

$wallregi_apply_giftcard_coupon_code_margin_css = wallregi_generate_spacing_css(
    $wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_margin_width'] ?? 0,
    $wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_margin_position'] ?? 'none',
    'margin'
);
$wallregi_apply_giftcard_coupon_code_border_css = wallregi_generate_spacing_css(
    $wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_border_width'] ?? 0,
    $wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_border_position'] ?? 'none',
    'border'
);

$wallregi_apply_giftcard_coupon_code_radius_css = wallregi_generate_radius_css(
    $wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_radius_width'] ?? 0,
    $wallregi_apply_giftcard_coupon_code_group['apply_giftcard_coupon_code_radius_position'] ?? 'none',
);

/*=======================
* APPLY GIFTCARD BOX MODEL END
*============================== */