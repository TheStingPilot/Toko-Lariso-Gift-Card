<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}



/**
 * Generate dynamic background and text color styles and extract settings groups.
 */

// White‐shade detection
$wallregi_white_shades   = [ '#ffffff', '#fff5ee', '#e2dfd2', '#fcf5e5', '#faf9f6', '#f8fafb', '#fefefe', '#fffff0', '#f0ead6', 'f9f6ee', 'f5f5dc', '#edeade' ];
$wallregi_background_css = '';
$wallregi_text_css       = '';
$wallregi_para_color     = esc_attr( $wallregi_settings['para_color'] ?? ( $wallregi_defaults['para_color'] ?? '#9d9d9d' ) );

// Build background and text styles
if ( $wallregi_settings['background_style'] === 'solid' ) {
    $wallregi_bg_color       = strtolower( $wallregi_settings['solid_color'] );
    $wallregi_background_css = 'background: ' . esc_attr( $wallregi_bg_color ) . ';';

    $wallregi_text_css = in_array( $wallregi_bg_color, $wallregi_white_shades, true ) ? 'rgba(51,51,51,1)' : $wallregi_para_color;

} elseif ( $wallregi_settings['background_style'] === 'gradient' ) {
    $wallregi_start  = strtolower( $wallregi_settings['gradient_start'] );
    $wallregi_middle = strtolower( $wallregi_settings['gradient_middle'] );
    $wallregi_end    = strtolower( $wallregi_settings['gradient_end'] );

    $wallregi_background_css = sprintf(
        'background: linear-gradient(to right, %1$s, %2$s, %3$s);',
        esc_attr( $wallregi_start ),
        esc_attr( $wallregi_middle ),
        esc_attr( $wallregi_end )
    );

    $wallregi_text_css = ( in_array( $wallregi_start, $wallregi_white_shades, true ) || in_array( $wallregi_middle, $wallregi_white_shades, true ) || in_array( $wallregi_end, $wallregi_white_shades, true ) )
        ? 'rgba(51,51,51,1)'
        : $wallregi_para_color;

} elseif ( $wallregi_settings['background_style'] === 'image' ) {
    $wallregi_bg_url = ! empty( $wallregi_settings['bg_image_url'] ) ? $wallregi_settings['bg_image_url'] : ( $wallregi_defaults['bg_image_url'] ?? '' );
    $wallregi_background_css = 'background-image: url(' . esc_url( $wallregi_bg_url ) . ');';
    $wallregi_text_css = $wallregi_para_color;

} else {
    $wallregi_text_css = $wallregi_para_color;
}

$wallregi_background_css .= 'background-repeat: no-repeat;';
$wallregi_background_css .= 'background-size: cover;';
$wallregi_background_css .= 'background-position: center;';
$wallregi_background_css .= 'background-attachment: fixed;';

// Accordion background for Apply Coupon section
$wallregi_accordion_background = ($wallregi_settings['background_style'] === 'image') ? '' : $wallregi_background_css;

/* =========================================
* EXTRACT GIFTCARD LAYOUT VARIABLES GROUP START
*================================================== */
// Giftcard Header 
$wallregi_giftcard_header_title_styles_group     = $wallregi_settings['giftcard_header_title_styles_group'] ?? [];
$wallregi_giftcard_header_border_group           = $wallregi_settings['giftcard_header_border_group'] ?? [];
$wallregi_giftcard_header_box_model_group        = $wallregi_settings['giftcard_header_box_model_group'] ?? [];
$wallregi_giftcard_header_pseudo_styles_group    = $wallregi_settings['giftcard_header_pseudo_styles_group'] ?? [];

// Giftcard Active Header 
$wallregi_giftcard_active_header_title_styles_group   = $wallregi_settings['giftcard_active_header_title_styles_group'] ?? [];
$wallregi_giftcard_active_header_border_group         = $wallregi_settings['giftcard_active_header_border_group'] ?? [];
$wallregi_giftcard_active_header_box_model_group      = $wallregi_settings['giftcard_active_header_box_model_group'] ?? [];
$wallregi_giftcard_active_header_pseudo_styles_group  = $wallregi_settings['giftcard_active_header_pseudo_styles_group'] ?? [];

// Giftcard Contents Body 
$wallregi_giftcard_body_fields_group             = $wallregi_settings['giftcard_body_fields_group'] ?? [];

// Giftcard Right Side Summary Contents Variables 
$wallregi_giftcard_right_side_contents_group     = $wallregi_settings['giftcard_right_side_contents_group'] ?? [];

// Giftcard Right Side Custom Price Variables 
$wallregi_giftcard_custom_price_box_group        = $wallregi_settings['giftcard_custom_price_box_group'] ?? [];
$wallregi_giftcard_custom_price_heading_group    = $wallregi_settings['giftcard_custom_price_heading_group'] ?? [];
$wallregi_giftcard_price_button_group            = $wallregi_settings['giftcard_price_button_group'] ?? [];

// Giftcard Right Side Images Gallery Variables 
$wallregi_giftcard_img_gallery_box_group         = $wallregi_settings['giftcard_img_gallery_box_group'] ?? [];
$wallregi_giftcard_img_gallery_heading_group     = $wallregi_settings['giftcard_img_gallery_heading_group'] ?? [];
$wallregi_giftcard_img_gallery_item_group        = $wallregi_settings['giftcard_img_gallery_item_group'] ?? [];
$wallregi_giftcard_img_gallery_item_pseudo_group = $wallregi_settings['giftcard_img_gallery_item_pseudo_group'] ?? [];




/* =========================================
* EXTRACT GIFTCARD LAYOUT VARIABLES GROUP END
*================================================== */

/* =========================================
* EXTRACT GIFTCARD ALL BUTTON VARIABLES GROUP START
*================================================== */

// Giftcard All Button Groups 
$wallregi_giftcard_all_buttons_styles_group          = $wallregi_settings['giftcard_all_buttons_styles_group'] ?? [];
$wallregi_giftcard_all_buttons_border_group          = $wallregi_settings['giftcard_all_buttons_border_group'] ?? [];
$wallregi_giftcard_all_buttons_box_model_group       = $wallregi_settings['giftcard_all_buttons_box_model_group'] ?? [];
$wallregi_giftcard_all_buttons_pseudo_styles_group   = $wallregi_settings['giftcard_all_buttons_pseudo_styles_group'] ?? [];

/* =========================================
* EXTRACT GIFTCARD ALL BUTTON VARIABLES GROUP END
*================================================== */



/* ====================================
* EXTRACT GIFTCARD FORM VARIABLES GROUP START
*================================================= */

$wallregi_giftcard_form_items_heading_group                  = $wallregi_settings['giftcard_form_items_heading_group'] ?? [];
$wallregi_giftcard_form_items_label_group                    = $wallregi_settings['giftcard_form_items_label_group'] ?? [];
$wallregi_giftcard_form_items_box_model_group                = $wallregi_settings['giftcard_form_items_box_model_group'] ?? [];
$wallregi_giftcard_form_items_styles_group                   = $wallregi_settings['giftcard_form_items_styles_group'] ?? [];
$wallregi_giftcard_form_items_placeholder_group              = $wallregi_settings['giftcard_form_items_placeholder_group'] ?? [];
$wallregi_giftcard_form_items_pseudo_group                   = $wallregi_settings['giftcard_form_items_pseudo_group'] ?? [];
$wallregi_giftcard_form_submit_mgs_group                     = $wallregi_settings['giftcard_form_submit_mgs_group'] ?? [];
$wallregi_edit_giftcard_label_style_group                    = $wallregi_settings['edit_giftcard_label_style_group'] ?? [];

/* ====================================
* EXTRACT GIFTCARD FORM VARIABLES GROUP END
*================================================= */

/* =========================================
* EXTRACT GIFTCARD PDF TEMPLATE VARIABLES GROUP START
*======================================================== */

// Full PDF Container Variable
$wallregi_pdf_template_container_group      = $wallregi_settings['pdf_template_container_group'] ?? [];

// PDF Header Variables 
$wallregi_pdf_header_style_group            = $wallregi_settings['pdf_header_style_group'] ?? [];
$wallregi_pdf_header_box_shadow_group       = $wallregi_settings['pdf_header_box_shadow_group'] ?? [];

// PDF Content Variables
$wallregi_pdf_content_style_group           = $wallregi_settings['pdf_content_style_group'] ?? [];
$wallregi_pdf_title_text_style_group        = $wallregi_settings['pdf_title_text_style_group'] ?? [];
$wallregi_pdf_giftcard_price_style_group    = $wallregi_settings['pdf_giftcard_price_style_group'] ?? [];
$wallregi_pdf_preview_mgs_style_group       = $wallregi_settings['pdf_preview_mgs_style_group'] ?? [];


// PDF Template Footer Variables 
$wallregi_pdf_footer_styles_group           = $wallregi_settings['pdf_footer_styles_group'] ?? [];
$wallregi_pdf_footer_border_group           = $wallregi_settings['pdf_footer_border_group'] ?? [];
$wallregi_pdf_footer_box_model_group        = $wallregi_settings['pdf_footer_box_model_group'] ?? [];


/* =======================================
* EXTRACT GIFTCARD PDF TEMPLATE VARIABLES GROUP END
*====================================================== */


/* ============================
* APPLY GIFTCARD VARIABLES GROUP START
*====================================== */

$wallregi_apply_giftcard_container_group              = $wallregi_settings['apply_giftcard_container_group'] ?? [];
$wallregi_apply_giftcard_container_header_group       = $wallregi_settings['apply_giftcard_container_header_group'] ?? [];
$wallregi_apply_giftcard_coupon_code_box_group        = $wallregi_settings['apply_giftcard_coupon_code_box_group'] ?? [];
$wallregi_apply_giftcard_coupon_code_group            = $wallregi_settings['apply_giftcard_coupon_code_group'] ?? [];

/* =============================
* APPLY GIFTCARD VARIABLES GROUP END
*====================================== */