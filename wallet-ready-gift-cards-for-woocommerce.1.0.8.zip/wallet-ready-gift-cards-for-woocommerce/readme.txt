=== GiftRocket – Ultimate Gift Cards for WooCommerce ===
Contributors: wooxperto,hasan350,mahmudul47
Donate link: https://giftrocketwp.com/
Tags: gift cards, digital gift cards, gift certificates, store credit, woocommerce, ecommerce
Requires at least: 6.5
Tested up to: 7.0
Requires PHP: 8.1
Stable tag: 1.0.8
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Sell WooCommerce gift cards with PDF email, Apple and Google Wallet, scheduled delivery, and Blocks checkout.

== Description ==

**Maximize your store's revenue with GiftRocket — the ultimate WooCommerce gift card plugin.**

Easily create, manage, and deliver digital gift cards by email. Shoppers redeem them at cart and checkout. WooCommerce Blocks are supported.

Boost sales, attract new customers, and raise average order value with gift cards. Get paid upfront and watch your revenue grow.

[Live demo](https://demo.giftrocketwp.com) | [Documentation](https://giftrocketwp.com/docs/) | [Get Pro](https://www.webcartisan.com/products/gift-card-for-woocommerce/)

= Why store owners choose GiftRocket =

* **Sell gift cards in minutes** — Gift Card product type, preset or custom amounts, message, and recipient email
* **PDF gift cards in the free plugin** — downloadable or email PDF with custom design, barcode, PDF417, or QR
* **Apple Wallet & Google Wallet** — optional passes via [ePasscard](https://epasscard.com/) (your API key)
* **Schedule gift card delivery** — customers pick date and time for the recipient email
* **Redeem like store credit** — apply codes on cart and checkout; unused balance stays for later
* **WooCommerce Blocks ready** — redeem and cart editing on block Cart / Checkout
* **HPOS compatible** — works with WooCommerce High Performance Order Storage
* **Admin gift card dashboard** — search, filters, manual issuance, balance history, liability tools
* **Fraud & abuse safeguards** — rate limits and security audit log when enabled
* **Import / migrate CSV** — bulk import codes and balances (up to 500 rows free; more in Pro)
* **Translation-ready & RTL** — gettext text domain, locale stubs, RTL companion styles

Configure everything under **GiftRocket → Gift Cards**. Open General, Form, PDF/email design, delivery, and Wallet.

= Sell WooCommerce gift cards (free features) =

* Dedicated **Gift Card** product type (catalog, product page, cart, orders, PDFs)
* Preset amounts plus **enter-your-own** pricing with min/max limits
* Recipient name, email, sender name, greeting/message (custom labels and max length)
* Card design gallery (image backgrounds, solid/gradient layouts, borders, preview)
* **Schedule email delivery** with date and time
* **PDF gift card** with optional **barcode, PDF417, and QR**
* **Custom PDF design features** — customizable PDF layouts, styling, colors, and typography controls
* Optional **Google Wallet** and **Apple Wallet** passes (ePasscard)
* Apply / redeem gift card codes on **cart and checkout** (classic + Blocks)
* Edit gift card details from the **cart** when enabled (Cart block supported)
* Apply gift cards on **admin orders** when creating or editing orders
* Purchaser **My Account → Gift cards** (PDF download and wallet pass link)
* Per-product expiry options for issued cards
* Optional checkout recipient flow (billing/shipping instead of product-page fields)
* Multiple gift cards from one product page; quantity caps per add-to-cart
* Custom add-to-cart / shop loop button text
* **Import / migrate (CSV)** — GiftRocket → Import / migrate (CSV)
* Fraud rate limits and security log; system status and feature overview
* **RTL** styles and translation-ready strings (130+ locale stubs)

= GiftRocket Pro (optional licensed add-on) =

Install free GiftRocket and WooCommerce first. Then install **GiftRocket Pro**. Activate the license under **GiftRocket → Pro license**. Pro features stay off until the license is valid.

* **Gift card balance top-up** — allow customers to recharge existing gift cards via dedicated top-up products or the `[wallregi_topup]` shortcode
* Edit gift card details at **checkout** (shortcode + Checkout block)
* Buyer-uploaded custom images on the card (with auto-cleanup and optional ClamAV scan)
* Greeting message presets / quick-pick chips
* **Partial redemption** — choose how much balance to apply
* Order rules: max gift cards per order; min/max combined redemption
* CSV import up to **5,000** rows per file
* **Outstanding balance / liability CSV export** for accounting and reporting
* Expiry reminder emails (custom schedule, email templates, log, unsubscribe)
* WooCommerce **REST API** gift card lookup and transactions (`wc/v3/wallregi-giftcards/...`)
* **AI writing assistant** (your API key): OpenAI, OpenRouter, Google Gemini, or Anthropic for staff copy and customer greetings

[Pro details](https://www.webcartisan.com/products/gift-card-for-woocommerce/)

= Compatibility =

* Requires **WooCommerce**
* Tested with **WordPress 7.0**
* Compatible with **High Performance Order Storage (HPOS)**
* Works with **WooCommerce Cart and Checkout Blocks** and classic shortcodes
* Guest-friendly redemption. Cards are not locked to one customer account.
* PHP 8.1+

= External services =

* **dompdf** (bundled) — generates PDFs on your server; see [dompdf on GitHub](https://github.com/dompdf/dompdf)
* **ePasscard** (optional) — Apple/Google Wallet passes with your API key; [epasscard.com](https://epasscard.com/)
* **AI providers** (Pro, optional) — OpenAI, OpenRouter, Google Gemini, or Anthropic with your own key

== Installation ==

1. Upload the plugin folder to /wp-content/plugins/ or install via Plugins → Add New.
2. Activate **Wallet Ready Gift Cards for WooCommerce** (GiftRocket).
3. Install and activate **WooCommerce** if it is not already active.
4. Open **GiftRocket → Gift Cards** and review Settings (General, Form, PDF/email, delivery, Wallet).
5. Create a product: **Products → Add new → Product data → Gift Card**.
6. Optional: install **GiftRocket Pro**, then activate the license under **GiftRocket → Pro license**.

== Frequently Asked Questions ==

= Does this plugin require WooCommerce? =

Yes. GiftRocket is a WooCommerce gift cards plugin. It shows an admin notice if WooCommerce is missing.

= Can I sell digital gift cards, gift certificates, or gift vouchers? =

Yes. Create Gift Card products with fixed or custom amounts. Recipients get email delivery. PDF and Wallet are included when enabled. They redeem the balance as store credit on your shop.

= Do customers get a PDF gift card? =

Yes. PDF generation is included in the free plugin. You can style the card. You can also add barcode, PDF417, or QR codes on the PDF.

= What about Apple Wallet and Google Wallet? =

Optional. Enable Wallet integration and connect your ePasscard API key. Passes can ship with orders and emails. They also appear in My Account when a pass exists.

= Can shoppers schedule gift card delivery? =

Yes. When scheduling is enabled on the product, buyers pick a future date and time. The recipient email sends then.

= How do customers redeem a gift card? =

They enter the gift card code on cart or checkout (classic or Blocks). The balance applies like store credit. Leftover balance stays on the card for later purchases. Expiry and your settings still apply.

= Does GiftRocket work with WooCommerce Blocks? =

Yes. Apply and redeem work on block cart and checkout. Cart line editing is free when enabled. Checkout line editing needs Pro with a valid license.

= Is GiftRocket compatible with HPOS? =

Yes. GiftRocket works with WooCommerce **High Performance Order Storage (HPOS)** and custom order tables.

= Can I import existing gift card codes? =

Yes. Use **GiftRocket → Import / migrate (CSV)**. Free allows up to 500 rows. Licensed Pro allows up to 5,000. See the migration docs in the plugin package.

= Can I create or adjust gift cards in admin? =

Yes. Use the GiftRocket gift cards dashboard. Search, edit, issue cards manually, and download PDFs. Wallet tools appear when configured.

= Can buyers edit gift card details after adding to cart? =

Cart editing is available in the free plugin when enabled. Editing on the checkout page requires GiftRocket Pro.

= Is there an AI feature? =

AI message and template helpers are part of **GiftRocket Pro**. Bring your own API key. Storefront AI is off by default.

= How is this different from a WooCommerce coupon? =

Gift cards use GiftRocket’s wallet and balance flow. That includes partial spend, remaining balance, and history. Standard coupons are separate. Test both together on staging if you use other discount plugins.

= Is the plugin translation-ready? =

Yes. Text domain: `wallet-ready-gift-cards-for-woocommerce`. RTL companion CSS loads for RTL site languages. See **Translations** below.

== Translations ==

GiftRocket uses gettext. The Pro add-on uses `wallet-ready-gift-cards-for-woocommerce-pro`.

= For site owners =

1. Set **Settings → General → Site Language**.
2. Translate with [Loco Translate](https://wordpress.org/plugins/loco-translate/) or Poedit, or use files in `languages/`.
3. Sample locales include Bengali (`bn_BD`) and Spanish (`es_ES`). Stubs ship for 130+ locales.

= WordPress.org language packs =

When listed on WordPress.org, community translations can ship via [translate.wordpress.org](https://translate.wordpress.org/). Until packs exist for your locale, use Loco Translate or the bundled `.po` files.

== Screenshots ==

1. GiftRocket gift card settings
2. General settings
3. General options
4. Email settings
5. Email body template
6. Free, Pro, and feature overview
7. Support section
8. Gift Card product type
9. Gift card template example
10. Gift card template example
11. Gift card template example
12. Gift card template example
13. Gift card on checkout
14. Gift card on cart
15. Gift card on cart (alternate)
16. Gift card on thank you page

== Changelog ==

= 1.0.8 (September 11, 2026) =

* New: Added custom PDF design features and template placeholder tags.
* New: Email and SMS shortcodes for gift card message and wallet pass link.
* Fix: Gift card redemption deducted from cart total without affecting tax.
* Fix: Translation/localization support for error messages, order meta, and Add to Cart button.
* Fix: Scheduled Deliveries table styling and action layout.
* Fix: PDF rendering, scheduling time picker, and currency display bugs.
* Update: Dynamic WooCommerce country code support for recipient phone field.
* Update: General UI improvements and bug fixes.

= 1.0.7 (August 20, 2026) =

* Fix: backend critical bug Solve.
* Update: Frontend UI updated.
* Update: welcome page updated.

= 1.0.6 (August 11, 2026) =

* New: new hooks for Gift Card single page fields to improve customization.
* Fix: Resolved character limit handling for greeting messages on Cart & Checkout pages.
* Update: Improved GiftRocket admin notice formatting for better clarity.
* Fix: Fixed word wrapping in Gift Card single page message field to ensure proper display.
* New: Free Setup notice for new users.


= 1.0.5 (August 7, 2026) =

* Fix: WooCommerce wc_enqueue_js deprecation issue resolved.
* Fix: Database creation bugs fixed.
* Change: Barcode and QR settings moved to a separate menu.
* Change: Gift Card Preview area settings moved to a separate menu.
* New: Option to display both Barcode and QR code features.
* New: Gift Card Preview area Logo option added.
* New: Gift Card Preview area Date option added.


= 1.0.4 (August 4, 2026) =

* Fix: Improved Gift Card PDF and email card design.
* Fix: Resolved Wallet integration display and configuration issues.
* Fix: Improved multi-digit number input field display and usability.

= 1.0.3 (July 21, 2026) =

* Fix: Gift card claim button not working on thank you page.
* Update: Minor improvements and bug fixes.

= 1.0.2 (July 1, 2026) =

* Fix: WooCommerce dependency fatal error and added an admin notice.
* Fix: Plugin menu visibility when WooCommerce is inactive.
* Update: Minor improvements and bug fixes.

= 1.0.1 (June 26, 2026) =

* Fix: Gift card claim case-sensitivity issue.

= 1.0.0 (May 16, 2026) =

* New: Initial release of GiftRocket (Wallet Ready Gift Cards for WooCommerce).
* New: Gift Card product type with PDF/email delivery, scheduling, and cart/checkout redeem.
* New: Fraud safeguards, ePasscard Wallet integration, and WooCommerce Blocks support.
* New: GiftRocket admin hub with dashboard, settings, security log, and feature overview.
* New: Optional billing/shipping recipient support during checkout.
* New: RTL support and translation locale stubs.
* New: Pro add-on with checkout edit, buyer images, presets, and partial redeem.
* New: Pro features including order limits, bulk CSV export, expiry reminders, balance exports, REST lookup, and multi-provider AI.
 
