# Toko Lariso Giftcards

Custom WooCommerce giftcard plugin for Toko Lariso.

The plugin treats giftcards as multi-purpose voucher store credit. A redeemed giftcard is applied to the payable order total after products, shipping, and VAT have been calculated. It is not implemented as a WooCommerce coupon.

Base language: English.

Text domain: `toko-lariso-giftcards`.

## Requirements

- WordPress 6.4+
- WooCommerce 8.5+; tested target up to WooCommerce 11.1
- PHP 8.0+
- WooCommerce Cart and Checkout Blocks for the native block redemption UI
- Optional: WPML + WPML String Translation for translated giftcard email template settings

## Installation

1. Upload `toko-lariso-giftcards-0.1.7.zip` in WordPress admin under Plugins > Add New > Upload Plugin.
2. Activate `Toko Lariso Giftcards`.
3. Go to WooCommerce > Toko Lariso Giftcards > Settings.
4. Configure fixed amounts, custom amount support, default validity, multiple giftcards, email text, refund behavior, and uninstall behavior.

## Creating a Giftcard Product

1. Create a WooCommerce product.
2. Set product type to `Toko Lariso giftcard`.
3. Add the giftcard image as the product image.
4. Add extra selectable designs as product gallery images.
5. Publish the product.

Do not enter the giftcard amount as the regular WooCommerce product price. The product can be left without a fixed catalog price. Customers choose the amount on the product page from the configured fixed presets, or from the custom amount field when that setting is enabled. The selected amount becomes the cart item price when the giftcard is added to the cart.

Giftcard products are intentionally treated as real, non-virtual WooCommerce products instead of virtual products. This keeps the giftcard as a normal order line for admin/order connectors, while the plugin prevents the giftcard from triggering paid shipping-rate lookups.

The plugin keeps giftcard delivery free and Blocks-safe:

- Giftcard products remain non-virtual order line items.
- Giftcards are excluded from shipping-rate requests so WooCommerce Cart/Checkout Blocks do not wait for giftcard delivery rates.
- Giftcard-only carts do not require a shipping charge or shipping address.
- Mixed carts keep normal shipping for the physical products, while the giftcard line stays in the order for admin/order integrations.
- A fallback `Giftcard delivery` method remains available as a safety net when a giftcard-only package is created by another integration.

## SendCloud Compatibility

The plugin includes a defensive compatibility layer for SendCloud's WooCommerce Blocks checkout handlers. SendCloud expects the WooCommerce session key `chosen_shipping_methods` to be a non-empty array during Store API checkout. Giftcard-only carts intentionally do not need shipping, so WooCommerce may leave that value unset. For giftcard-only orders without shipping line items, the plugin sets a non-SendCloud placeholder method id before SendCloud validates service-point data. This prevents SendCloud's service-point handler from throwing a PHP fatal while keeping the giftcard as a non-virtual order line item.

Customers can then select:

- Fixed amount
- Optional custom amount when enabled
- Recipient name
- Recipient email
- Personal message
- Optional delivery date
- Giftcard design from the product image/gallery

Each add-to-cart action creates one giftcard purchase line with its own recipient, message, delivery date, and design. To buy multiple giftcards, add the product multiple times with the right recipient details for each card.

## Redemption

Cart and Checkout Blocks display a Giftcard field below the coupon area. The Store API callback applies or removes giftcards from the WooCommerce session and recalculates the cart.

At checkout, the plugin redeems the session allocation against the giftcard balance with a database transaction and row lock. Public Store API responses expose only masked codes, not full codes.

## Admin Management

Open WooCommerce > Toko Lariso Giftcards to:

- Search by exact code, masked code, recipient, or purchase order id
- View initial balance, current balance, status, expiry, purchase order, redemption orders, and ledger
- Change status and expiry
- Apply a manual balance correction with a required reason
- Resend the giftcard email

## WPML Support

The plugin source strings use English as the base language and the `toko-lariso-giftcards` text domain.

WPML support includes:

- `wpml-config.xml` registration for option-backed email template fields.
- Runtime registration through `wpml_register_single_string`.
- Runtime translation through `wpml_translate_single_string`.
- Translatable email subject, heading, intro, button label, and shop URL.

After changing email template settings, open WPML > String Translation and translate strings in the `toko-lariso-giftcards` context.

## Refunds

Refund behavior is configurable:

- Manual review only: no balance is restored automatically; the order receives an admin note.
- Restore on full order refund: redeemed giftcard credit is restored once when the order reaches refunded status.

Partial refunds are intentionally not automatically restored because the correct behavior depends on whether the refunded amount relates to cash paid, giftcard credit, product value, shipping, or a mixed allocation.

## Data Retention

Deactivation never deletes giftcard data. Uninstall deletes tables and settings only when the explicit `Delete giftcard tables and settings when the plugin is uninstalled` setting is enabled.

## Local Syntax Testing

Run a single-file lint:

```sh
php -l toko-lariso-giftcards.php
```

Run all plugin PHP lint checks:

```sh
php tests/lint-all.php
```

PowerShell alternative:

```powershell
Get-ChildItem -Recurse -Filter *.php | ForEach-Object { php -l $_.FullName }
```

## Troubleshooting Cart Blocks

If the WooCommerce Cart Block stays on grey loading placeholders even with only a normal product in the cart, inspect the browser console and Network tab first. This usually means a global frontend script or Store API request is failing before the cart block can finish rendering. Known indicators are uncaught JavaScript errors from theme scripts, consent/cookie plugins, cache/minify tools, or shipping/VAT extensions. Test once with optimization/cache disabled and with unrelated frontend scripts temporarily disabled.

## References

- WooCommerce Store API extensibility: https://github.com/woocommerce/woocommerce/blob/trunk/docs/apis/store-api/extending-store-api/README.md
- Updating the cart through `extensionCartUpdate`: https://github.com/woocommerce/woocommerce/blob/trunk/docs/apis/store-api/extending-store-api/extend-store-api-update-cart.md
- Cart and Checkout Blocks integration interface: https://github.com/woocommerce/woocommerce/blob/trunk/docs/block-development/reference/integration-interface.md
