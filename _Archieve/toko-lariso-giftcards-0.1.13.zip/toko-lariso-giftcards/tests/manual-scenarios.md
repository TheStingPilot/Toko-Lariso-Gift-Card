# Manual Test Scenarios

Run these on a staging store with WooCommerce Blocks cart and checkout pages.

## 0. Baseline Cart Block

1. Temporarily empty the cart.
2. Add one regular, non-giftcard WooCommerce product.
3. Open the Cart Block page.
4. Inspect the browser console and Store API network request.

Expected:

- The normal product cart renders without grey loading placeholders.
- There are no uncaught frontend JavaScript errors.
- WooCommerce Store API cart requests return successful JSON responses.
- If this baseline fails, fix the theme/plugin/frontend error before testing giftcard behavior.

## 1. Buy a Giftcard

1. Create a `Toko Lariso giftcard` product.
2. Add a product image and at least two gallery images.
3. Open the product page.
4. Confirm the product page shows fixed amount presets, recipient fields, design selection, and an add-to-cart button.
5. Select EUR 25, enter recipient name/email/message, choose a design, add the giftcard to the cart, and place the order.
6. Pay with a normal payment method.

Expected:

- Product is non-virtual and non-taxable.
- The regular WooCommerce product price can be empty; the selected preset becomes the cart line price.
- Giftcard-only Cart and Checkout Blocks load without waiting for shipping rates.
- Giftcard-only shipping cost is EUR 0 because no paid shipping method is required.
- Order status becomes processing/completed.
- One giftcard row is created.
- Ledger contains `issued`.
- Recipient receives an email with the full code and selected image.
- Order item stores masked code and giftcard id.

## 2. Fully Use a Giftcard

1. Create a cart where total including VAT and shipping is less than or equal to the giftcard balance.
2. Apply the code in Checkout Block.
3. Place the order.

Expected:

- Giftcard appears as store credit, not as coupon.
- Order payable total becomes zero if balance covers the full total.
- Giftcard status becomes `used`.
- Ledger contains `redeemed`.

## 3. Partially Use a Giftcard

1. Create a cart totaling EUR 41.90 including VAT and shipping.
2. Apply a EUR 15 giftcard.

Expected:

- Remaining total is EUR 26.90.
- Product and shipping tax lines are unchanged by the giftcard credit.
- Giftcard current balance is reduced by EUR 15.
- Ledger contains one `redeemed` entry with amount `-15`.

## 3a. Giftcard Credit Must Stay Exact

1. Create a cart totaling more than EUR 50 including VAT and shipping.
2. Apply a EUR 50 giftcard.
3. Repeat with goods totaling EUR 44.45 including VAT and shipping of EUR 6.95 including VAT.

Expected:

- The giftcard summary shows exactly `EUR 50.00`.
- The WooCommerce totals area must not show a capped ex-VAT giftcard line such as `-EUR 43.49`.
- The giftcard is not shown as a VAT-adjusted discount such as `-EUR 50.87`.
- VAT lines for products and shipping remain based on the original product/shipping taxable amounts.
- Remaining payable total equals cart total including VAT and shipping minus EUR 50.00.
- In the EUR 44.45 + EUR 6.95 example, the remaining payable total is EUR 1.40.
- The giftcard widget shows plain text amounts such as `EUR 50.00`, without raw HTML entities.

## 4. Mixed 9 Percent, 21 Percent, and Shipping

1. Add one product taxed at 9 percent.
2. Add one product taxed at 21 percent.
3. Add taxable shipping.
4. Apply giftcard credit.

Expected:

- VAT lines remain based on product/shipping taxable amounts.
- Giftcard credit is applied as post-tax store credit through the final payable total, not as a coupon or taxable discount.
- Final payable total equals WooCommerce total including VAT/shipping minus giftcard credit.

## 5. Virtual and Physical Product

1. Add a regular virtual product and a regular physical product.
2. Select a shipping method.
3. Apply giftcard credit in Cart Block.

Expected:

- Shipping remains required because the physical product is in cart.
- Giftcard credit can apply to the final cart total including shipping.

## 6. Giftcard Product Shipping

Giftcard-only cart:

1. Add only a `Toko Lariso giftcard` product to the cart.
2. Open Cart Block or Checkout Block.

Expected:

- The product remains non-virtual in WooCommerce.
- Cart and Checkout Blocks load normally.
- No shipping charge or shipping address is required for the giftcard-only cart.
- If another integration creates a giftcard-only shipping package, its rates are forced to EUR 0.

Mixed cart:

1. Add a `Toko Lariso giftcard` product and a normal physical product.
2. Open checkout.

Expected:

- Cart and Checkout Blocks load normally.
- The mixed cart remains one shipping package.
- Normal physical products keep normal shipping.
- Giftcard value is excluded from the package contents cost used for shipping-rate calculations.

## 7. Cart Block

1. Open the Cart Block page.
2. Apply a valid giftcard.
3. Remove it.
4. Apply an invalid code.

Expected:

- Valid code updates totals through Store API.
- Remove updates totals through Store API.
- Invalid code shows an error and does not reveal whether a specific code exists.

## 8. Checkout Block

1. Open Checkout Block with a valid cart.
2. Apply a giftcard.
3. Place the order.

Expected:

- The order is created with the giftcard fee.
- The ledger redemption links to the order.
- Full code is not exposed in Store API responses.

## 8a. Repeated Apply Clicks During Checkout Updates

1. Open Checkout Block with a valid cart.
2. Enter a valid giftcard code.
3. Click Apply repeatedly while the checkout totals are updating.

Expected:

- Only one giftcard Store API update is sent while the first request is in flight.
- The input and Apply button are disabled during the update.
- The giftcard is not applied twice.
- With `wc-postcode-checker` 3.7.2 active, clicking the giftcard Apply button is not intercepted by the plugin's broad `.wc-block-components-button` document click handler.
- Console messages from external shipping observers, such as `Observer for shipping is already active.`, do not indicate duplicate giftcard redemption when they are triggered by real address/shipping actions.

## 9. Refund Scenario

Manual mode:

1. Place an order using giftcard credit.
2. Refund the order.

Expected:

- Giftcard balance is not restored automatically.
- Order receives an admin note to review manually.

Full-refund restore mode:

1. Set refund behavior to `Restore giftcard credit on full order refund`.
2. Place an order using giftcard credit.
3. Fully refund the order.

Expected:

- Giftcard credit is restored once.
- Ledger contains `refunded`.
- Repeating the refund/status action does not restore twice.

## 10. SendCloud Giftcard-only Checkout

1. Activate SendCloud Shipping with service points enabled.
2. Add only a `Toko Lariso giftcard` product to the cart.
3. Open Checkout Block.
4. Select a normal payment method.
5. Place the order.

Expected:

- Store API checkout does not return HTTP 500.
- No fatal is logged from SendCloud's `wc_blocks_validate_service_point_selection()`.
- The order is created without a shipping line item.
- The giftcard remains a non-virtual order line item.
- Giftcard issuance runs after successful payment/status transition.

## 11. Admin Full Code Access

1. Buy a giftcard in a staging store where outbound email is disabled.
2. Open WooCommerce > Toko Lariso Giftcards.
3. Open the generated giftcard detail page.

Expected:

- The giftcard list still shows the masked code only.
- The detail screen shows a readonly `Full code` field.
- The full code can be selected/copied by an admin with `manage_woocommerce`.
- Store API responses and customer-facing totals still expose only masked codes.
