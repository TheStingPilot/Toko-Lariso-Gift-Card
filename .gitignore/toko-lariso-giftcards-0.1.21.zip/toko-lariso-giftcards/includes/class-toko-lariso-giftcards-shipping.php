<?php
/**
 * Giftcard shipping behavior.
 *
 * @package TokoLarisoGiftcards
 */

defined( 'ABSPATH' ) || exit;

/**
 * Keeps giftcard products non-virtual while preventing giftcards from triggering shipping-rate waits.
 */
class Toko_Lariso_Giftcards_Shipping {
	/**
	 * Free shipping method id for giftcard-only packages.
	 */
	public const METHOD_ID = 'tokolariso_giftcard_delivery';

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public function init(): void {
		add_action( 'woocommerce_shipping_init', array( $this, 'define_shipping_method' ) );
		add_filter( 'woocommerce_shipping_methods', array( $this, 'register_shipping_method' ) );
		add_filter( 'woocommerce_product_needs_shipping', array( $this, 'giftcard_product_needs_no_shipping_rate' ), 10, 2 );
		add_filter( 'woocommerce_cart_needs_shipping', array( $this, 'cart_needs_shipping' ), 10, 1 );
		add_filter( 'woocommerce_cart_needs_shipping_address', array( $this, 'cart_needs_shipping_address' ), 10, 1 );
		add_filter( 'woocommerce_cart_shipping_packages', array( $this, 'prepare_giftcard_shipping_packages' ), 100 );
		add_filter( 'woocommerce_package_rates', array( $this, 'zero_giftcard_package_rates' ), 100, 2 );
	}

	/**
	 * Defines the zero-cost shipping method.
	 *
	 * @return void
	 */
	public function define_shipping_method(): void {
		if ( ! class_exists( 'WC_Shipping_Method' ) || class_exists( 'WC_Shipping_Toko_Lariso_Giftcard_Delivery' ) ) {
			return;
		}

		require_once TOKO_LARISO_GIFTCARDS_PATH . 'includes/class-wc-shipping-toko-lariso-giftcard-delivery.php';
	}

	/**
	 * Registers the shipping method with WooCommerce.
	 *
	 * @param array<string,string> $methods Shipping methods.
	 * @return array<string,string>
	 */
	public function register_shipping_method( array $methods ): array {
		$methods[ self::METHOD_ID ] = 'WC_Shipping_Toko_Lariso_Giftcard_Delivery';
		return $methods;
	}

	/**
	 * Keeps giftcards as non-virtual products while excluding them from shipping-rate calculation.
	 *
	 * @param bool       $needs_shipping Existing shipping need.
	 * @param WC_Product $product Product.
	 * @return bool
	 */
	public function giftcard_product_needs_no_shipping_rate( bool $needs_shipping, WC_Product $product ): bool {
		if ( self::product_is_giftcard( $product ) ) {
			return false;
		}

		return $needs_shipping;
	}

	/**
	 * Cart needs shipping only when it contains a non-giftcard shippable item.
	 *
	 * @param bool $needs_shipping Existing cart shipping need.
	 * @return bool
	 */
	public function cart_needs_shipping( bool $needs_shipping ): bool {
		if ( ! $needs_shipping ) {
			return false;
		}

		return $this->cart_has_regular_shippable_items();
	}

	/**
	 * Cart needs a shipping address only when a non-giftcard item requires shipping.
	 *
	 * @param bool $needs_address Existing address need.
	 * @return bool
	 */
	public function cart_needs_shipping_address( bool $needs_address ): bool {
		if ( ! $needs_address ) {
			return false;
		}

		return $this->cart_has_regular_shippable_items();
	}

	/**
	 * Marks giftcard-only packages and keeps mixed packages as one package for Store API stability.
	 *
	 * @param array<int,array<string,mixed>> $packages Packages.
	 * @return array<int,array<string,mixed>>
	 */
	public function prepare_giftcard_shipping_packages( array $packages ): array {
		$prepared_packages = array();

		foreach ( $packages as $package ) {
			$contents = isset( $package['contents'] ) && is_array( $package['contents'] ) ? $package['contents'] : array();
			if ( ! $contents ) {
				$prepared_packages[] = $package;
				continue;
			}

			$giftcards       = array();
			$regular         = array();
			$has_giftcards   = false;
			$has_regular     = false;

			foreach ( $contents as $cart_item_key => $cart_item ) {
				if ( self::cart_item_is_giftcard( $cart_item ) ) {
					$giftcards[ $cart_item_key ] = $cart_item;
					$has_giftcards               = true;
				} else {
					$regular[ $cart_item_key ] = $cart_item;
					$has_regular               = true;
				}
			}

			if ( $has_giftcards && ! $has_regular ) {
				$package['tokolariso_giftcard_package'] = true;
				$package['package_name']                = __( 'Giftcards', 'toko-lariso-giftcards' );
				$prepared_packages[]                    = $package;
				continue;
			}

			if ( $has_giftcards && $has_regular ) {
				$package['contents_cost'] = $this->package_contents_cost( $regular );
			} else {
				$package['contents_cost'] = $this->package_contents_cost( $contents );
			}

			$prepared_packages[] = $package;
		}

		return $prepared_packages;
	}

	/**
	 * Sets all rates for giftcard-only packages to zero, including third-party rates.
	 *
	 * @param array<string,WC_Shipping_Rate> $rates Rates.
	 * @param array<string,mixed>            $package Package.
	 * @return array<string,WC_Shipping_Rate>
	 */
	public function zero_giftcard_package_rates( array $rates, array $package ): array {
		if ( ! self::package_is_giftcards_only( $package ) ) {
			return $rates;
		}

		if ( ! $rates && class_exists( 'WC_Shipping_Rate' ) ) {
			$rates[ self::METHOD_ID ] = new WC_Shipping_Rate(
				self::METHOD_ID,
				__( 'Giftcard delivery', 'toko-lariso-giftcards' ),
				0,
				array(),
				self::METHOD_ID
			);
		}

		foreach ( $rates as $rate ) {
			if ( is_callable( array( $rate, 'set_cost' ) ) ) {
				$rate->set_cost( 0 );
			} else {
				$rate->cost = 0;
			}

			$taxes = is_callable( array( $rate, 'get_taxes' ) ) ? $rate->get_taxes() : array();
			if ( is_array( $taxes ) ) {
				$zero_taxes = array();
				foreach ( $taxes as $tax_id => $tax_amount ) {
					$zero_taxes[ $tax_id ] = 0;
				}
				if ( is_callable( array( $rate, 'set_taxes' ) ) ) {
					$rate->set_taxes( $zero_taxes );
				} else {
					$rate->taxes = $zero_taxes;
				}
			}
		}

		return $rates;
	}

	/**
	 * Checks if a shipping package contains only giftcards.
	 *
	 * @param array<string,mixed> $package Package.
	 * @return bool
	 */
	public static function package_is_giftcards_only( array $package ): bool {
		$contents = isset( $package['contents'] ) && is_array( $package['contents'] ) ? $package['contents'] : array();
		if ( ! $contents ) {
			return false;
		}

		foreach ( $contents as $cart_item ) {
			if ( ! self::cart_item_is_giftcard( $cart_item ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Checks whether a cart item is a Toko Lariso giftcard product.
	 *
	 * @param mixed $cart_item Cart item.
	 * @return bool
	 */
	private static function cart_item_is_giftcard( mixed $cart_item ): bool {
		if ( ! is_array( $cart_item ) || empty( $cart_item['data'] ) || ! is_object( $cart_item['data'] ) ) {
			return false;
		}

		return self::product_is_giftcard( $cart_item['data'] );
	}

	/**
	 * Checks whether a product is a Toko Lariso giftcard.
	 *
	 * @param mixed $product Product.
	 * @return bool
	 */
	private static function product_is_giftcard( mixed $product ): bool {
		return Toko_Lariso_Giftcards_Product_Type::is_giftcard_product( $product );
	}

	/**
	 * Checks whether the current cart has shippable items other than giftcards.
	 *
	 * @return bool
	 */
	private function cart_has_regular_shippable_items(): bool {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return true;
		}

		foreach ( WC()->cart->get_cart() as $cart_item ) {
			if ( self::cart_item_is_giftcard( $cart_item ) ) {
				continue;
			}

			$product = isset( $cart_item['data'] ) && is_object( $cart_item['data'] ) ? $cart_item['data'] : null;
			if ( $product && is_callable( array( $product, 'needs_shipping' ) ) && $product->needs_shipping() ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Calculates package contents cost.
	 *
	 * @param array<string,array<string,mixed>> $contents Contents.
	 * @return float
	 */
	private function package_contents_cost( array $contents ): float {
		$cost = 0.0;
		foreach ( $contents as $cart_item ) {
			$cost += isset( $cart_item['line_total'] ) ? (float) $cart_item['line_total'] : 0.0;
		}

		return $cost;
	}
}
