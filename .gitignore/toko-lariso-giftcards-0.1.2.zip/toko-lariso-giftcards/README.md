# Toko Lariso Giftcards

Custom WooCommerce giftcard plugin for Toko Lariso.

The plugin treats giftcards as multi-purpose voucher store credit. A redeemed giftcard is applied to the payable order total after products, shipping, and VAT have been calculated. It is not implemented as a WooCommerce coupon.

Base language: English.

Text domain: `toko-lariso-giftcards`.

## Requirements

- WordPress 6.4+
- WooCommerce 8.5+; tested target up to WooCommerce 11.1
- PHP 8.0+
- WooCommerce Cart and Checkout Blocks for the native block redemption UI
- Optional: WPML + WPML String Translation for translated giftcard email template settings

## Installation

1. Upload `toko-lariso-giftcards-0.1.2.zip` in WordPress admin under Plugins > Add New > Upload Plugin.
2. Activate `Toko Lariso Giftcards`.
3. Go to WooCommerce > Toko Lariso Giftcards > Settings.
4. Configure fixed amounts, custom amount support, default validity, multiple giftcards, email text, refund behavior, and uninstall behavior.

## Creating a Giftcard Product

1. Create a WooCommerce product.
2. Set product type to `Toko Lariso giftcard`.
3. Add the giftcard image as the product image.
4. Add extra selectable designs as product gallery images.
5. Publish the product.

Giftcard products are intentionally treated as real, shippable WooCommerce products instead of virtual products. This keeps shipping/order connectors such as SendCloud in the normal order flow.

The plugin keeps giftcard delivery free:

- Giftcard-only carts/packages receive zero-cost shipping.
- Existing third-party shipping rates for giftcard-only packages are forced to EUR 0.
- If no shipping rate exists, the plugin adds a fallback `Giftcard delivery` rate at EUR 0.
- Mixed carts are split so giftcards do not add shipping cost to normal physical-product shipping.

Customers can then select:

- Fixed amount
- Optional custom amount when enabled
- Recipient name
- Recipient email
- Personal message
- Optional delivery date
- Giftcard design from the product image/gallery

## Redemption

Cart and Checkout Blocks display a Giftcard field below the coupon area. The Store API callback applies or removes giftcards from the WooCommerce session and recalculates the cart.

At checkout, the plugin redeems the session allocation against the giftcard balance with a database transaction and row lock. Public Store API responses expose only masked codes, not full codes.

## Admin Management

Open WooCommerce > Toko Lariso Giftcards to:

- Search by exact code, masked code, recipient, or purchase order id
- View initial balance, current balance, status, expiry, purchase order, redemption orders, and ledger
- Change status and expiry
- Apply a manual balance correction with a required reason
- Resend the giftcard email

## WPML Support

The plugin source strings use English as the base language and the `toko-lariso-giftcards` text domain.

WPML support includes:

- `wpml-config.xml` registration for option-backed email template fields.
- Runtime registration through `wpml_register_single_string`.
- Runtime translation through `wpml_translate_single_string`.
- Translatable email subject, heading, intro, button label, and shop URL.

After changing email template settings, open WPML > String Translation and translate strings in the `toko-lariso-giftcards` context.

## Refunds

Refund behavior is configurable:

- Manual review only: no balance is restored automatically; the order receives an admin note.
- Restore on full order refund: redeemed giftcard credit is restored once when the order reaches refunded status.

Partial refunds are intentionally not automatically restored because the correct behavior depends on whether the refunded amount relates to cash paid, giftcard credit, product value, shipping, or a mixed allocation.

## Data Retention

Deactivation never deletes giftcard data. Uninstall deletes tables and settings only when the explicit `Delete giftcard tables and settings when the plugin is uninstalled` setting is enabled.

## Local Syntax Testing

Run a single-file lint:

```sh
php -l toko-lariso-giftcards.php
```

Run all plugin PHP lint checks:

```sh
php tests/lint-all.php
```

PowerShell alternative:

```powershell
Get-ChildItem -Recurse -Filter *.php | ForEach-Object { php -l $_.FullName }
```

## References

- WooCommerce Store API extensibility: https://github.com/woocommerce/woocommerce/blob/trunk/docs/apis/store-api/extending-store-api/README.md
- Updating the cart through `extensionCartUpdate`: https://github.com/woocommerce/woocommerce/blob/trunk/docs/apis/store-api/extending-store-api/extend-store-api-update-cart.md
- Cart and Checkout Blocks integration interface: https://github.com/woocommerce/woocommerce/blob/trunk/docs/block-development/reference/integration-interface.md
