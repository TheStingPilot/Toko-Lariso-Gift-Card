<?php
/**
 * Order redemption, issuance, and refund handling.
 *
 * @package TokoLarisoGiftcards
 */

defined( 'ABSPATH' ) || exit;

/**
 * Handles order lifecycle.
 */
class Toko_Lariso_Giftcards_Order {
	private const ORDER_APPLICATIONS_META = '_tokolariso_giftcard_applications';
	private const ORDER_REDEEMED_META     = '_tokolariso_giftcards_redeemed';
	private const ORDER_REFUNDED_META     = '_tokolariso_giftcards_refunded';
	private const ORDER_ORIGINAL_TOTAL_META    = '_tokolariso_order_total_before_giftcards';
	private const ORDER_GIFTCARD_PAYMENT_META = '_tokolariso_giftcard_payment_total';
	private const ORDER_PAYMENT_DUE_META       = '_tokolariso_payment_due_after_giftcards';

	/**
	 * Settings.
	 *
	 * @var Toko_Lariso_Giftcards_Settings
	 */
	private Toko_Lariso_Giftcards_Settings $settings;

	/**
	 * Repository.
	 *
	 * @var Toko_Lariso_Giftcards_Repository
	 */
	private Toko_Lariso_Giftcards_Repository $repository;

	/**
	 * Email service.
	 *
	 * @var Toko_Lariso_Giftcards_Email
	 */
	private Toko_Lariso_Giftcards_Email $email;

	/**
	 * Cart service.
	 *
	 * @var Toko_Lariso_Giftcards_Cart
	 */
	private Toko_Lariso_Giftcards_Cart $cart;

	/**
	 * Constructor.
	 *
	 * @param Toko_Lariso_Giftcards_Settings   $settings Settings.
	 * @param Toko_Lariso_Giftcards_Repository $repository Repository.
	 * @param Toko_Lariso_Giftcards_Email      $email Email.
	 * @param Toko_Lariso_Giftcards_Cart       $cart Cart.
	 */
	public function __construct( Toko_Lariso_Giftcards_Settings $settings, Toko_Lariso_Giftcards_Repository $repository, Toko_Lariso_Giftcards_Email $email, Toko_Lariso_Giftcards_Cart $cart ) {
		$this->settings   = $settings;
		$this->repository = $repository;
		$this->email      = $email;
		$this->cart       = $cart;
	}

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public function init(): void {
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'redeem_for_store_api_order' ), 10, 1 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'redeem_for_classic_order' ), 10, 3 );

		add_action( 'woocommerce_payment_complete', array( $this, 'maybe_issue_purchased_giftcards' ), 10, 1 );
		add_action( 'woocommerce_order_status_processing', array( $this, 'maybe_issue_purchased_giftcards' ), 10, 1 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'maybe_issue_purchased_giftcards' ), 10, 1 );

		add_action( 'woocommerce_order_status_refunded', array( $this, 'maybe_restore_on_full_refund' ), 10, 1 );
		add_action( 'woocommerce_order_refunded', array( $this, 'handle_partial_refund_note' ), 10, 2 );
	}

	/**
	 * Redeems giftcards during Store API checkout before payment is processed.
	 *
	 * @param WC_Order $order Order.
	 * @return void
	 */
	public function redeem_for_store_api_order( WC_Order $order ): void {
		$this->redeem_for_order( $order );
	}

	/**
	 * Redeems giftcards during classic checkout.
	 *
	 * @param int      $order_id Order id.
	 * @param array    $posted_data Posted data.
	 * @param WC_Order $order Order.
	 * @return void
	 */
	public function redeem_for_classic_order( int $order_id, array $posted_data, WC_Order $order ): void {
		$this->redeem_for_order( $order );
	}

	/**
	 * Issues giftcards purchased in a paid order.
	 *
	 * @param int|WC_Order $order_input Order id or object.
	 * @return void
	 */
	public function maybe_issue_purchased_giftcards( int|WC_Order $order_input ): void {
		$order = $order_input instanceof WC_Order ? $order_input : wc_get_order( $order_input );
		if ( ! $order ) {
			return;
		}

		if ( ! in_array( $order->get_status(), array( 'processing', 'completed' ), true ) ) {
			return;
		}

		$changed = false;
		foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
			if ( 'yes' !== $item->get_meta( '_tokolariso_is_giftcard', true ) ) {
				continue;
			}
			if ( $item->get_meta( '_tokolariso_giftcard_id', true ) ) {
				continue;
			}

			$amount = (float) $item->get_meta( '_tokolariso_giftcard_amount', true );
			if ( $amount <= 0 ) {
				$amount = (float) $item->get_total() + (float) $item->get_total_tax();
			}

			$expires_at = gmdate( 'Y-m-d H:i:s', time() + ( DAY_IN_SECONDS * absint( $this->settings->get( 'expiry_days', 730 ) ) ) );
			$card       = $this->repository->create_giftcard(
				array(
					'amount'                  => $amount,
					'currency'                => $order->get_currency(),
					'expires_at'              => $expires_at,
					'purchased_order_id'      => $order->get_id(),
					'purchased_order_item_id' => $item_id,
					'recipient_name'          => (string) $item->get_meta( '_tokolariso_giftcard_recipient_name', true ),
					'recipient_email'         => (string) $item->get_meta( '_tokolariso_giftcard_recipient_email', true ),
					'message'                 => (string) $item->get_meta( '_tokolariso_giftcard_message', true ),
					'image_id'                => (int) $item->get_meta( '_tokolariso_giftcard_image_id', true ),
					'image_url'               => (string) $item->get_meta( '_tokolariso_giftcard_image_url', true ),
				)
			);

			$item->add_meta_data( '_tokolariso_giftcard_id', (int) $card['id'], true );
			$item->add_meta_data( '_tokolariso_giftcard_code_mask', (string) $card['code_mask'], true );
			$item->save();

			$delivery_date = (string) $item->get_meta( '_tokolariso_giftcard_delivery_date', true );
			$this->email->send_or_schedule( $card, $delivery_date );

			$order->add_order_note(
				sprintf(
					/* translators: 1: masked code, 2: recipient email */
					__( 'Giftcard %1$s issued and queued/sent to %2$s.', 'toko-lariso-giftcards' ),
					(string) $card['code_mask'],
					(string) $card['recipient_email']
				)
			);
			$changed = true;
		}

		if ( $changed ) {
			$order->save();
		}
	}

	/**
	 * Restores giftcard credit when full-refund behavior is enabled and the order is refunded.
	 *
	 * @param int $order_id Order id.
	 * @return void
	 */
	public function maybe_restore_on_full_refund( int $order_id ): void {
		if ( 'restore_full_refund' !== $this->settings->get( 'refund_behavior', 'manual' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order || 'yes' === $order->get_meta( self::ORDER_REFUNDED_META, true ) ) {
			return;
		}

		$applications = $this->get_order_applications( $order );
		if ( ! $applications ) {
			return;
		}

		foreach ( $applications as $application ) {
			$this->repository->credit(
				(int) $application['id'],
				(float) $application['amount'],
				'refunded',
				$order->get_id(),
				__( 'Giftcard credit restored after full order refund.', 'toko-lariso-giftcards' )
			);
		}

		$order->update_meta_data( self::ORDER_REFUNDED_META, 'yes' );
		$order->add_order_note( __( 'Giftcard credit was restored because the order was fully refunded.', 'toko-lariso-giftcards' ) );
		$order->save();
	}

	/**
	 * Adds a note on partial refunds when automatic restoration is not safe.
	 *
	 * @param int $order_id Order id.
	 * @param int $refund_id Refund id.
	 * @return void
	 */
	public function handle_partial_refund_note( int $order_id, int $refund_id ): void {
		$order = wc_get_order( $order_id );
		if ( ! $order || ! $this->get_order_applications( $order ) ) {
			return;
		}

		if ( 'restore_full_refund' === $this->settings->get( 'refund_behavior', 'manual' ) && $order->has_status( 'refunded' ) ) {
			return;
		}

		$order->add_order_note( __( 'This order used giftcard credit. Review the refund and restore giftcard balance manually if appropriate.', 'toko-lariso-giftcards' ) );
		$order->save();
	}

	/**
	 * Gets order giftcard applications.
	 *
	 * @param WC_Order $order Order.
	 * @return array<int,array<string,mixed>>
	 */
	public function get_order_applications( WC_Order $order ): array {
		$applications = $order->get_meta( self::ORDER_APPLICATIONS_META, true );
		return is_array( $applications ) ? $applications : array();
	}

	/**
	 * Redeems current session allocations for the order.
	 *
	 * @param WC_Order $order Order.
	 * @return void
	 */
	private function redeem_for_order( WC_Order $order ): void {
		if ( 'yes' === $order->get_meta( self::ORDER_REDEEMED_META, true ) ) {
			return;
		}

		$allocations = $this->cart->get_allocations();
		if ( ! $allocations ) {
			return;
		}

		$applications = array();
		foreach ( $allocations as $allocation ) {
			$giftcard_id = (int) ( $allocation['id'] ?? 0 );
			$amount      = (float) ( $allocation['amount'] ?? 0 );
			if ( $giftcard_id <= 0 || $amount <= 0 ) {
				continue;
			}

			$card = $this->repository->redeem(
				$giftcard_id,
				$amount,
				$order->get_id(),
				sprintf(
					/* translators: %d: order id */
					__( 'Redeemed for order #%d.', 'toko-lariso-giftcards' ),
					$order->get_id()
				)
			);

			$applications[] = array(
				'id'        => $giftcard_id,
				'code_mask' => (string) ( $allocation['code_mask'] ?? $card['code_mask'] ),
				'amount'    => $amount,
				'ledger_id' => (int) ( $card['ledger_id'] ?? 0 ),
			);
		}

		if ( ! $applications ) {
			return;
		}

		$original_total   = $this->order_total_before_giftcards( $order );
		$giftcard_payment = min( $original_total, $this->applications_total( $applications ) );
		$payment_due      = $this->repository->normalize_amount( max( 0.0, $original_total - $giftcard_payment ) );

		$order->set_total( $payment_due );
		$order->update_meta_data( self::ORDER_REDEEMED_META, 'yes' );
		$order->update_meta_data( self::ORDER_APPLICATIONS_META, $applications );
		$order->update_meta_data( self::ORDER_ORIGINAL_TOTAL_META, $original_total );
		$order->update_meta_data( self::ORDER_GIFTCARD_PAYMENT_META, $giftcard_payment );
		$order->update_meta_data( self::ORDER_PAYMENT_DUE_META, $payment_due );
		$order->add_order_note( $this->format_order_note( $applications, $original_total, $payment_due ) );
		$order->save();

		$this->cart->clear_session();
	}

	/**
	 * Calculates the order amount including VAT and shipping before giftcard payment.
	 *
	 * @param WC_Order $order Order.
	 * @return float
	 */
	private function order_total_before_giftcards( WC_Order $order ): float {
		$total = 0.0;

		foreach ( $order->get_items( 'line_item' ) as $item ) {
			$total += (float) $item->get_total() + (float) $item->get_total_tax();
		}

		foreach ( $order->get_items( 'shipping' ) as $item ) {
			$total += (float) $item->get_total() + (float) $item->get_total_tax();
		}

		foreach ( $order->get_items( 'fee' ) as $item ) {
			$total += (float) $item->get_total() + (float) $item->get_total_tax();
		}

		return $this->repository->normalize_amount( max( 0.0, $total ) );
	}

	/**
	 * Totals redeemed giftcard applications.
	 *
	 * @param array<int,array<string,mixed>> $applications Applications.
	 * @return float
	 */
	private function applications_total( array $applications ): float {
		$total = 0.0;

		foreach ( $applications as $application ) {
			$total += (float) ( $application['amount'] ?? 0 );
		}

		return $this->repository->normalize_amount( $total );
	}

	/**
	 * Formats order note for redemptions.
	 *
	 * @param array<int,array<string,mixed>> $applications Applications.
	 * @param float                          $original_total Original order total.
	 * @param float                          $payment_due Remaining payment-method amount.
	 * @return string
	 */
	private function format_order_note( array $applications, float $original_total, float $payment_due ): string {
		$parts = array();
		foreach ( $applications as $application ) {
			$parts[] = sprintf(
				'%s: %s',
				(string) $application['code_mask'],
				wp_strip_all_tags( wc_price( (float) $application['amount'] ) )
			);
		}

		return sprintf(
			/* translators: 1: comma-separated giftcard applications, 2: original total, 3: remaining payment due */
			__( 'Giftcard partial payment applied: %1$s. Order total before giftcard payment: %2$s. Remaining amount charged by payment method: %3$s.', 'toko-lariso-giftcards' ),
			implode( ', ', $parts ),
			wp_strip_all_tags( wc_price( $original_total ) ),
			wp_strip_all_tags( wc_price( $payment_due ) )
		);
	}
}
