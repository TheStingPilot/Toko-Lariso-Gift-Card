( function ( wp, wc ) {
	'use strict';

	if ( ! wp || ! wc || ! wc.blocksCheckout || ! wc.wcBlocksData ) {
		return;
	}

	var createElement = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var useState = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var useSelect = wp.data.useSelect;
	var __ = wp.i18n.__;
	var registerPlugin = wp.plugins.registerPlugin;
	var ExperimentalDiscountsMeta = wc.blocksCheckout.ExperimentalDiscountsMeta;
	var ExperimentalOrderMeta = wc.blocksCheckout.ExperimentalOrderMeta;
	var extensionCartUpdate = wc.blocksCheckout.extensionCartUpdate;
	var registerCheckoutFilters = wc.blocksCheckout.registerCheckoutFilters || wc.blocksCheckout.__experimentalRegisterCheckoutFilters;
	var processErrorResponse = wc.wcBlocksData.processErrorResponse;
	var cartStore = wc.wcBlocksData.cartStore;

	if ( ! ExperimentalDiscountsMeta || ! extensionCartUpdate || ! cartStore ) {
		return;
	}

	var namespace = 'tokolariso-giftcards';
	var pendingUpdate = false;
	var pendingListeners = [];

	function setPendingUpdate( value ) {
		pendingUpdate = value;
		pendingListeners.forEach( function ( listener ) {
			listener( value );
		} );
	}

	function subscribePendingUpdate( listener ) {
		pendingListeners.push( listener );

		return function () {
			pendingListeners = pendingListeners.filter( function ( current ) {
				return current !== listener;
			} );
		};
	}

	function getExtensionData( cartData ) {
		if ( ! cartData || ! cartData.extensions ) {
			return {};
		}
		return cartData.extensions[ namespace ] || {};
	}

	function useGiftcardExtensionData() {
		return getExtensionData(
			useSelect(
				function ( select ) {
					return select( cartStore ).getCartData();
				},
				[]
			)
		);
	}

	function useBusyState() {
		var busyState = useState( pendingUpdate );
		var busy = busyState[ 0 ];
		var setBusy = busyState[ 1 ];

		useEffect(
			function () {
				return subscribePendingUpdate( setBusy );
			},
			[]
		);

		return busy;
	}

	function runGiftcardUpdate( data, successMessage, setMessage, onSuccess ) {
		if ( pendingUpdate ) {
			return;
		}

		setPendingUpdate( true );
		setMessage( '' );
		extensionCartUpdate( {
			namespace: namespace,
			data: data,
		} )
			.then( function () {
				if ( onSuccess ) {
					onSuccess();
				}
				setMessage( successMessage || '' );
			} )
			.catch( function ( error ) {
				if ( processErrorResponse ) {
					processErrorResponse( error );
				}
				setMessage( __( 'The giftcard could not be applied. Please check the code and try again.', 'toko-lariso-giftcards' ) );
			} )
			.finally( function () {
				setPendingUpdate( false );
			} );
	}

	function GiftcardPanel() {
		var extensionData = useGiftcardExtensionData();
		var applied = Array.isArray( extensionData.applied ) ? extensionData.applied : [];
		var allowMultiple = extensionData.allow_multiple !== false;
		var renderAppliedInPanel = ! ExperimentalOrderMeta;
		var state = useState( '' );
		var code = state[ 0 ];
		var setCode = state[ 1 ];
		var busy = useBusyState();
		var messageState = useState( '' );
		var message = messageState[ 0 ];
		var setMessage = messageState[ 1 ];

		function onApply( event ) {
			event.preventDefault();
			if ( busy || pendingUpdate ) {
				return;
			}
			if ( ! code.trim() ) {
				setMessage( __( 'Please enter a giftcard code.', 'toko-lariso-giftcards' ) );
				return;
			}
			runGiftcardUpdate(
				{
					action: 'apply',
					code: code.trim(),
				},
				__( 'Giftcard applied.', 'toko-lariso-giftcards' ),
				setMessage,
				function () {
					setCode( '' );
				}
			);
		}

		function onRemove( id ) {
			if ( busy || pendingUpdate ) {
				return;
			}

			runGiftcardUpdate(
				{
					action: 'remove',
					id: id,
				},
				__( 'Giftcard removed.', 'toko-lariso-giftcards' ),
				setMessage
			);
		}

		if ( ! allowMultiple && applied.length > 0 ) {
			if ( ExperimentalOrderMeta ) {
				return null;
			}

			return createElement(
				'div',
				{ className: 'wc-block-components-totals-wrapper tokolariso-giftcard-block' },
				renderApplied( applied, onRemove, busy, extensionData ),
				message ? createElement( 'p', { className: 'tokolariso-giftcard-message' }, message ) : null
			);
		}

		return createElement(
			'div',
			{ className: 'wc-block-components-totals-wrapper tokolariso-giftcard-block' },
			createElement( 'strong', { className: 'tokolariso-giftcard-title' }, __( 'Giftcard', 'toko-lariso-giftcards' ) ),
			createElement(
				'form',
				{ className: 'tokolariso-giftcard-form', onSubmit: onApply },
				createElement( 'input', {
					type: 'text',
					value: code,
					onChange: function ( event ) {
						setCode( event.target.value );
					},
					placeholder: __( 'Enter giftcard code', 'toko-lariso-giftcards' ),
					disabled: busy || pendingUpdate,
					autoComplete: 'off',
				} ),
				createElement(
					'button',
					{
						type: 'submit',
						disabled: busy || pendingUpdate,
						className: 'tokolariso-giftcard-apply wp-element-button',
						onClick: function ( event ) {
							event.stopPropagation();
						},
					},
					busy ? __( 'Applying...', 'toko-lariso-giftcards' ) : __( 'Apply', 'toko-lariso-giftcards' )
				)
			),
			renderAppliedInPanel ? renderApplied( applied, onRemove, busy, extensionData ) : null,
			message ? createElement( 'p', { className: 'tokolariso-giftcard-message' }, message ) : null
		);
	}

	function GiftcardOrderSummary() {
		var extensionData = useGiftcardExtensionData();
		var applied = Array.isArray( extensionData.applied ) ? extensionData.applied : [];
		var busy = useBusyState();
		var messageState = useState( '' );
		var message = messageState[ 0 ];
		var setMessage = messageState[ 1 ];

		function onRemove( id ) {
			if ( busy || pendingUpdate ) {
				return;
			}

			runGiftcardUpdate(
				{
					action: 'remove',
					id: id,
				},
				__( 'Giftcard removed.', 'toko-lariso-giftcards' ),
				setMessage
			);
		}

		if ( ! applied.length ) {
			return null;
		}

		return createElement(
			'div',
			{ className: 'wc-block-components-totals-wrapper tokolariso-giftcard-summary' },
			renderApplied( applied, onRemove, busy, extensionData ),
			message ? createElement( 'p', { className: 'tokolariso-giftcard-message' }, message ) : null
		);
	}

	function renderApplied( applied, onRemove, busy, extensionData ) {
		if ( ! applied.length ) {
			return null;
		}

		return createElement(
			'div',
			{ className: 'tokolariso-giftcard-applied' },
			createElement( 'div', { className: 'tokolariso-giftcard-applied-heading' }, __( 'Giftcard partial payment', 'toko-lariso-giftcards' ) ),
			applied.map( function ( card ) {
				return createElement(
					'div',
					{ className: 'tokolariso-giftcard-applied-row', key: card.id },
					createElement(
						'span',
						null,
						card.code,
						' ',
						createElement( 'strong', null, card.amount_formatted ),
						card.remaining_balance_formatted
							? createElement(
									'small',
									{ className: 'tokolariso-giftcard-remaining' },
									' ' + __( 'Remaining:', 'toko-lariso-giftcards' ) + ' ' + card.remaining_balance_formatted
							  )
							: null
					),
					createElement(
						'button',
						{
							type: 'button',
							disabled: busy || pendingUpdate,
							onClick: function () {
								onRemove( card.id );
							},
						},
						__( 'Remove', 'toko-lariso-giftcards' )
					)
				);
			} ),
			extensionData.total_applied_formatted
				? createElement(
						'p',
						{ className: 'tokolariso-giftcard-total' },
						__( 'Paid with giftcard:', 'toko-lariso-giftcards' ) + ' ' + extensionData.total_applied_formatted
				  )
				: null,
			extensionData.remaining_total_formatted
				? createElement(
						'p',
						{ className: 'tokolariso-giftcard-due' },
						__( 'Amount to pay with selected payment method:', 'toko-lariso-giftcards' ) + ' ' + extensionData.remaining_total_formatted
				  )
				: null
		);
	}

	registerPlugin( 'tokolariso-giftcards', {
		render: function () {
			return createElement(
				Fragment,
				null,
				createElement( ExperimentalDiscountsMeta, null, createElement( GiftcardPanel ) ),
				ExperimentalOrderMeta ? createElement( ExperimentalOrderMeta, null, createElement( GiftcardOrderSummary ) ) : null
			);
		},
		scope: 'woocommerce-checkout',
	} );

	if ( registerCheckoutFilters ) {
		registerCheckoutFilters( namespace, {
			placeOrderButtonLabel: function ( defaultValue, extensions ) {
				var data = extensions && extensions[ namespace ];
				if ( data && data.total_applied > 0 && data.remaining_total_formatted ) {
					return __( 'Place order and pay', 'toko-lariso-giftcards' ) + ' · ' + data.remaining_total_formatted;
				}
				return defaultValue;
			},
		} );
	}
} )( window.wp, window.wc );
