# Manual Test Scenarios

Run these on a staging store with WooCommerce Blocks cart and checkout pages.

## 1. Buy a Giftcard

1. Create a `Toko Lariso giftcard` product.
2. Add a product image and at least two gallery images.
3. Open the product page.
4. Select EUR 25, enter recipient name/email/message, choose a design, and place the order.
5. Pay with a normal payment method.

Expected:

- Product is virtual and non-taxable.
- Order status becomes processing/completed.
- One giftcard row is created.
- Ledger contains `issued`.
- Recipient receives an email with the full code and selected image.
- Order item stores masked code and giftcard id.

## 2. Fully Use a Giftcard

1. Create a cart where total including VAT and shipping is less than or equal to the giftcard balance.
2. Apply the code in Checkout Block.
3. Place the order.

Expected:

- Giftcard appears as store credit, not as coupon.
- Order payable total becomes zero if balance covers the full total.
- Giftcard status becomes `used`.
- Ledger contains `redeemed`.

## 3. Partially Use a Giftcard

1. Create a cart totaling EUR 41.90 including VAT and shipping.
2. Apply a EUR 15 giftcard.

Expected:

- Remaining total is EUR 26.90.
- Product and shipping tax lines are unchanged by the giftcard credit.
- Giftcard current balance is reduced by EUR 15.
- Ledger contains one `redeemed` entry with amount `-15`.

## 4. Mixed 9 Percent, 21 Percent, and Shipping

1. Add one product taxed at 9 percent.
2. Add one product taxed at 21 percent.
3. Add taxable shipping.
4. Apply giftcard credit.

Expected:

- VAT lines remain based on product/shipping taxable amounts.
- Giftcard credit is a non-taxable negative fee.
- Final payable total equals WooCommerce total including VAT/shipping minus giftcard credit.

## 5. Virtual and Physical Product

1. Add a virtual product and a physical product.
2. Select a shipping method.
3. Apply giftcard credit in Cart Block.

Expected:

- Shipping remains required because the physical product is in cart.
- Giftcard credit can apply to the final cart total including shipping.

## 6. Cart Block

1. Open the Cart Block page.
2. Apply a valid giftcard.
3. Remove it.
4. Apply an invalid code.

Expected:

- Valid code updates totals through Store API.
- Remove updates totals through Store API.
- Invalid code shows an error and does not reveal whether a specific code exists.

## 7. Checkout Block

1. Open Checkout Block with a valid cart.
2. Apply a giftcard.
3. Place the order.

Expected:

- The order is created with the giftcard fee.
- The ledger redemption links to the order.
- Full code is not exposed in Store API responses.

## 8. Refund Scenario

Manual mode:

1. Place an order using giftcard credit.
2. Refund the order.

Expected:

- Giftcard balance is not restored automatically.
- Order receives an admin note to review manually.

Full-refund restore mode:

1. Set refund behavior to `Restore giftcard credit on full order refund`.
2. Place an order using giftcard credit.
3. Fully refund the order.

Expected:

- Giftcard credit is restored once.
- Ledger contains `refunded`.
- Repeating the refund/status action does not restore twice.
