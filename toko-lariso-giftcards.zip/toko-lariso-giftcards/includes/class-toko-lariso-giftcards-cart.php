<?php
/**
 * Cart and checkout behavior.
 *
 * @package TokoLarisoGiftcards
 */

defined( 'ABSPATH' ) || exit;

/**
 * Handles giftcard sales and cart credit application.
 */
class Toko_Lariso_Giftcards_Cart {
	public const SESSION_APPLIED     = 'tokolariso_giftcards_applied';
	public const SESSION_ALLOCATIONS = 'tokolariso_giftcards_allocations';

	/**
	 * Settings.
	 *
	 * @var Toko_Lariso_Giftcards_Settings
	 */
	private Toko_Lariso_Giftcards_Settings $settings;

	/**
	 * Repository.
	 *
	 * @var Toko_Lariso_Giftcards_Repository
	 */
	private Toko_Lariso_Giftcards_Repository $repository;

	/**
	 * Constructor.
	 *
	 * @param Toko_Lariso_Giftcards_Settings   $settings Settings.
	 * @param Toko_Lariso_Giftcards_Repository $repository Repository.
	 */
	public function __construct( Toko_Lariso_Giftcards_Settings $settings, Toko_Lariso_Giftcards_Repository $repository ) {
		$this->settings   = $settings;
		$this->repository = $repository;
	}

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public function init(): void {
		add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'validate_giftcard_add_to_cart' ), 10, 3 );
		add_filter( 'woocommerce_add_cart_item_data', array( $this, 'add_cart_item_data' ), 10, 3 );
		add_filter( 'woocommerce_get_item_data', array( $this, 'display_cart_item_data' ), 10, 2 );
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'set_giftcard_cart_prices' ), 20 );
		add_action( 'woocommerce_cart_calculate_fees', array( $this, 'apply_store_credit_fee' ), 9999 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'add_order_item_meta' ), 10, 4 );
	}

	/**
	 * Applies a giftcard code to the session.
	 *
	 * @param string $code Code entered by shopper.
	 * @return array<string,mixed>
	 */
	public function apply_code_to_session( string $code ): array {
		$card = $this->repository->get_by_code( $code );
		if ( ! $card ) {
			throw new InvalidArgumentException( __( 'Giftcard code was not found or cannot be used.', 'toko-lariso-giftcards' ) );
		}

		if ( $this->repository->is_expired_by_date( $card ) ) {
			$this->repository->expire( (int) $card['id'] );
			throw new InvalidArgumentException( __( 'Giftcard code was not found or cannot be used.', 'toko-lariso-giftcards' ) );
		}

		if ( 'active' !== $card['status'] || (float) $card['current_balance'] <= 0 ) {
			throw new InvalidArgumentException( __( 'Giftcard code was not found or cannot be used.', 'toko-lariso-giftcards' ) );
		}

		$applied = $this->get_applied_cards();
		if ( ! $this->settings->multiple_giftcards_enabled() ) {
			$applied = array();
		}

		foreach ( $applied as $existing ) {
			if ( (int) $existing['id'] === (int) $card['id'] ) {
				return $card;
			}
		}

		$applied[] = array(
			'id'        => (int) $card['id'],
			'code_mask' => (string) $card['code_mask'],
		);

		$this->set_applied_cards( $applied );
		$this->recalculate_cart();

		return $card;
	}

	/**
	 * Removes a card from session.
	 *
	 * @param int $giftcard_id Giftcard id.
	 * @return void
	 */
	public function remove_card_from_session( int $giftcard_id ): void {
		$applied = array_values(
			array_filter(
				$this->get_applied_cards(),
				static fn( array $card ): bool => (int) $card['id'] !== $giftcard_id
			)
		);

		$this->set_applied_cards( $applied );
		$this->recalculate_cart();
	}

	/**
	 * Clears session giftcards.
	 *
	 * @return void
	 */
	public function clear_session(): void {
		if ( WC()->session ) {
			WC()->session->__unset( self::SESSION_APPLIED );
			WC()->session->__unset( self::SESSION_ALLOCATIONS );
		}
	}

	/**
	 * Gets applied cards from session.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function get_applied_cards(): array {
		if ( ! WC()->session ) {
			return array();
		}

		$applied = WC()->session->get( self::SESSION_APPLIED, array() );
		return is_array( $applied ) ? $applied : array();
	}

	/**
	 * Gets current cart allocations.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function get_allocations(): array {
		if ( ! WC()->session ) {
			return array();
		}

		$allocations = WC()->session->get( self::SESSION_ALLOCATIONS, array() );
		return is_array( $allocations ) ? $allocations : array();
	}

	/**
	 * Gets summary data safe for public Store API responses.
	 *
	 * @return array<string,mixed>
	 */
	public function get_public_summary(): array {
		$allocations = $this->get_allocations();
		$total       = 0.0;
		$items       = array();

		foreach ( $allocations as $allocation ) {
			$amount = (float) ( $allocation['amount'] ?? 0 );
			$total += $amount;
			$items[] = array(
				'id'                          => (int) ( $allocation['id'] ?? 0 ),
				'code'                        => (string) ( $allocation['code_mask'] ?? '' ),
				'amount'                      => $amount,
				'amount_formatted'            => wp_strip_all_tags( wc_price( $amount ) ),
				'balance'                     => (float) ( $allocation['balance'] ?? 0 ),
				'balance_formatted'           => wp_strip_all_tags( wc_price( (float) ( $allocation['balance'] ?? 0 ) ) ),
				'remaining_balance'           => (float) ( $allocation['remaining_balance'] ?? 0 ),
				'remaining_balance_formatted' => wp_strip_all_tags( wc_price( (float) ( $allocation['remaining_balance'] ?? 0 ) ) ),
			);
		}

		return array(
			'applied'                 => $items,
			'total_applied'           => $this->repository->normalize_amount( $total ),
			'total_applied_formatted' => wp_strip_all_tags( wc_price( $total ) ),
			'allow_multiple'          => $this->settings->multiple_giftcards_enabled(),
		);
	}

	/**
	 * Validates add-to-cart for giftcard products.
	 *
	 * @param bool $passed Existing pass status.
	 * @param int  $product_id Product id.
	 * @param int  $quantity Quantity.
	 * @return bool
	 */
	public function validate_giftcard_add_to_cart( bool $passed, int $product_id, int $quantity ): bool {
		$product = wc_get_product( $product_id );
		if ( ! $product || Toko_Lariso_Giftcards_Product_Type::TYPE !== $product->get_type() ) {
			return $passed;
		}

		$nonce = isset( $_POST['tokolariso_giftcard_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['tokolariso_giftcard_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'tokolariso_giftcard_add_to_cart' ) ) {
			wc_add_notice( __( 'Giftcard form security check failed. Please try again.', 'toko-lariso-giftcards' ), 'error' );
			return false;
		}

		$amount = $this->read_purchase_amount();
		if ( $amount <= 0 ) {
			wc_add_notice( __( 'Please choose a valid giftcard amount.', 'toko-lariso-giftcards' ), 'error' );
			return false;
		}

		$name  = isset( $_POST['tokolariso_giftcard_recipient_name'] ) ? sanitize_text_field( wp_unslash( $_POST['tokolariso_giftcard_recipient_name'] ) ) : '';
		$email = isset( $_POST['tokolariso_giftcard_recipient_email'] ) ? sanitize_email( wp_unslash( $_POST['tokolariso_giftcard_recipient_email'] ) ) : '';
		if ( '' === $name || ! is_email( $email ) ) {
			wc_add_notice( __( 'Please enter a recipient name and a valid recipient email address.', 'toko-lariso-giftcards' ), 'error' );
			return false;
		}

		$date = isset( $_POST['tokolariso_giftcard_delivery_date'] ) ? sanitize_text_field( wp_unslash( $_POST['tokolariso_giftcard_delivery_date'] ) ) : '';
		if ( $date && strtotime( $date ) < strtotime( gmdate( 'Y-m-d' ) ) ) {
			wc_add_notice( __( 'Delivery date cannot be in the past.', 'toko-lariso-giftcards' ), 'error' );
			return false;
		}

		return $passed;
	}

	/**
	 * Adds giftcard purchase data to cart item.
	 *
	 * @param array<string,mixed> $cart_item_data Cart data.
	 * @param int                 $product_id Product id.
	 * @param int                 $variation_id Variation id.
	 * @return array<string,mixed>
	 */
	public function add_cart_item_data( array $cart_item_data, int $product_id, int $variation_id ): array {
		$product = wc_get_product( $product_id );
		if ( ! $product || Toko_Lariso_Giftcards_Product_Type::TYPE !== $product->get_type() ) {
			return $cart_item_data;
		}

		$image_id = isset( $_POST['tokolariso_giftcard_image_id'] ) ? absint( $_POST['tokolariso_giftcard_image_id'] ) : 0;
		$message  = isset( $_POST['tokolariso_giftcard_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['tokolariso_giftcard_message'] ) ) : '';
		$date     = isset( $_POST['tokolariso_giftcard_delivery_date'] ) ? sanitize_text_field( wp_unslash( $_POST['tokolariso_giftcard_delivery_date'] ) ) : '';

		$cart_item_data['tokolariso_giftcard'] = array(
			'amount'          => $this->read_purchase_amount(),
			'recipient_name'  => isset( $_POST['tokolariso_giftcard_recipient_name'] ) ? sanitize_text_field( wp_unslash( $_POST['tokolariso_giftcard_recipient_name'] ) ) : '',
			'recipient_email' => isset( $_POST['tokolariso_giftcard_recipient_email'] ) ? sanitize_email( wp_unslash( $_POST['tokolariso_giftcard_recipient_email'] ) ) : '',
			'message'         => $message,
			'delivery_date'   => $date,
			'image_id'        => $image_id,
			'image_url'       => $image_id ? wp_get_attachment_image_url( $image_id, 'large' ) : '',
			'unique_key'      => wp_generate_uuid4(),
		);

		return $cart_item_data;
	}

	/**
	 * Displays giftcard item data in cart and checkout.
	 *
	 * @param array<int,array<string,string>> $item_data Item data.
	 * @param array<string,mixed>             $cart_item Cart item.
	 * @return array<int,array<string,string>>
	 */
	public function display_cart_item_data( array $item_data, array $cart_item ): array {
		if ( empty( $cart_item['tokolariso_giftcard'] ) || ! is_array( $cart_item['tokolariso_giftcard'] ) ) {
			return $item_data;
		}

		$data = $cart_item['tokolariso_giftcard'];
		$item_data[] = array(
			'key'   => __( 'Giftcard amount', 'toko-lariso-giftcards' ),
			'value' => wp_strip_all_tags( wc_price( (float) $data['amount'] ) ),
		);
		$item_data[] = array(
			'key'   => __( 'Recipient', 'toko-lariso-giftcards' ),
			'value' => esc_html( (string) $data['recipient_name'] ) . ' &lt;' . esc_html( (string) $data['recipient_email'] ) . '&gt;',
		);
		if ( ! empty( $data['delivery_date'] ) ) {
			$item_data[] = array(
				'key'   => __( 'Delivery date', 'toko-lariso-giftcards' ),
				'value' => esc_html( (string) $data['delivery_date'] ),
			);
		}

		return $item_data;
	}

	/**
	 * Sets dynamic cart item prices for giftcards.
	 *
	 * @param WC_Cart $cart Cart.
	 * @return void
	 */
	public function set_giftcard_cart_prices( WC_Cart $cart ): void {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}

		foreach ( $cart->get_cart() as $cart_item ) {
			if ( empty( $cart_item['tokolariso_giftcard']['amount'] ) || empty( $cart_item['data'] ) ) {
				continue;
			}

			$cart_item['data']->set_price( (float) $cart_item['tokolariso_giftcard']['amount'] );
			$cart_item['data']->set_tax_status( 'none' );
			$cart_item['data']->set_virtual( true );
		}
	}

	/**
	 * Applies giftcards as non-taxable negative fees after taxes/shipping are known.
	 *
	 * @param WC_Cart $cart Cart.
	 * @return void
	 */
	public function apply_store_credit_fee( WC_Cart $cart ): void {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}

		$applied = $this->get_applied_cards();
		if ( ! $applied ) {
			$this->set_allocations( array() );
			return;
		}

		if ( ! $this->settings->multiple_giftcards_enabled() ) {
			$applied = array_slice( $applied, 0, 1 );
		}

		$remaining   = $this->cart_total_before_giftcards( $cart );
		$allocations = array();

		foreach ( $applied as $session_card ) {
			if ( $remaining <= 0 ) {
				break;
			}

			$card = $this->repository->get_by_id( (int) ( $session_card['id'] ?? 0 ) );
			if ( ! $card ) {
				continue;
			}

			if ( $this->repository->is_expired_by_date( $card ) ) {
				$this->repository->expire( (int) $card['id'] );
				continue;
			}

			if ( 'active' !== $card['status'] || (float) $card['current_balance'] <= 0 ) {
				continue;
			}

			$amount = min( (float) $card['current_balance'], $remaining );
			$amount = $this->repository->normalize_amount( $amount );
			if ( $amount <= 0 ) {
				continue;
			}

			$cart->add_fee(
				sprintf(
					/* translators: %s: masked giftcard code */
					__( 'Giftcard %s', 'toko-lariso-giftcards' ),
					(string) $card['code_mask']
				),
				-1 * $amount,
				false
			);

			$allocations[] = array(
				'id'        => (int) $card['id'],
				'code_mask' => (string) $card['code_mask'],
				'amount'    => $amount,
				'balance'   => (float) $card['current_balance'],
				'remaining_balance' => max( 0.0, (float) $card['current_balance'] - $amount ),
			);
			$remaining -= $amount;
		}

		$this->set_applied_cards(
			array_map(
				static fn( array $allocation ): array => array(
					'id'        => (int) $allocation['id'],
					'code_mask' => (string) $allocation['code_mask'],
				),
				$allocations
			)
		);
		$this->set_allocations( $allocations );
	}

	/**
	 * Adds giftcard sale metadata to order line items.
	 *
	 * @param WC_Order_Item_Product $item Order item.
	 * @param string                $cart_item_key Cart item key.
	 * @param array<string,mixed>   $values Cart item values.
	 * @param WC_Order              $order Order.
	 * @return void
	 */
	public function add_order_item_meta( WC_Order_Item_Product $item, string $cart_item_key, array $values, WC_Order $order ): void {
		if ( empty( $values['tokolariso_giftcard'] ) || ! is_array( $values['tokolariso_giftcard'] ) ) {
			return;
		}

		$data = $values['tokolariso_giftcard'];
		$item->add_meta_data( '_tokolariso_is_giftcard', 'yes', true );
		$item->add_meta_data( '_tokolariso_giftcard_amount', (float) $data['amount'], true );
		$item->add_meta_data( '_tokolariso_giftcard_recipient_name', (string) $data['recipient_name'], true );
		$item->add_meta_data( '_tokolariso_giftcard_recipient_email', (string) $data['recipient_email'], true );
		$item->add_meta_data( '_tokolariso_giftcard_message', (string) $data['message'], true );
		$item->add_meta_data( '_tokolariso_giftcard_delivery_date', (string) $data['delivery_date'], true );
		$item->add_meta_data( '_tokolariso_giftcard_image_id', (int) $data['image_id'], true );
		$item->add_meta_data( '_tokolariso_giftcard_image_url', (string) $data['image_url'], true );

		$item->add_meta_data( __( 'Giftcard amount', 'toko-lariso-giftcards' ), wp_strip_all_tags( wc_price( (float) $data['amount'] ) ), true );
		$item->add_meta_data( __( 'Recipient', 'toko-lariso-giftcards' ), sanitize_text_field( (string) $data['recipient_name'] ) . ' <' . sanitize_email( (string) $data['recipient_email'] ) . '>', true );
	}

	/**
	 * Reads selected purchase amount from POST.
	 *
	 * @return float
	 */
	private function read_purchase_amount(): float {
		$choice = isset( $_POST['tokolariso_giftcard_amount_choice'] ) ? sanitize_text_field( wp_unslash( $_POST['tokolariso_giftcard_amount_choice'] ) ) : '';

		if ( 'custom' === $choice && $this->settings->custom_amount_enabled() ) {
			$amount = isset( $_POST['tokolariso_giftcard_custom_amount'] ) ? wc_clean( wp_unslash( $_POST['tokolariso_giftcard_custom_amount'] ) ) : 0;
			return $this->repository->normalize_amount( $amount );
		}

		$amount = str_starts_with( $choice, 'fixed:' ) ? substr( $choice, 6 ) : 0;
		$amount = $this->repository->normalize_amount( $amount );

		foreach ( $this->settings->fixed_amounts() as $fixed ) {
			if ( abs( $amount - (float) $fixed ) < 0.0001 ) {
				return $amount;
			}
		}

		return 0.0;
	}

	/**
	 * Computes the maximum creditable cart total before giftcard credits.
	 *
	 * @param WC_Cart $cart Cart.
	 * @return float
	 */
	private function cart_total_before_giftcards( WC_Cart $cart ): float {
		$total = (float) $cart->get_cart_contents_total()
			+ (float) $cart->get_cart_contents_tax()
			+ (float) $cart->get_shipping_total()
			+ (float) $cart->get_shipping_tax();

		foreach ( $cart->get_fees() as $fee ) {
			$amount = (float) $fee->amount;
			if ( $amount > 0 ) {
				$total += $amount;
			}
		}

		return max( 0.0, $this->repository->normalize_amount( $total ) );
	}

	/**
	 * Stores applied card references in session.
	 *
	 * @param array<int,array<string,mixed>> $cards Applied cards.
	 * @return void
	 */
	private function set_applied_cards( array $cards ): void {
		if ( WC()->session ) {
			WC()->session->set( self::SESSION_APPLIED, $cards );
		}
	}

	/**
	 * Stores current allocations in session.
	 *
	 * @param array<int,array<string,mixed>> $allocations Allocations.
	 * @return void
	 */
	private function set_allocations( array $allocations ): void {
		if ( WC()->session ) {
			WC()->session->set( self::SESSION_ALLOCATIONS, $allocations );
		}
	}

	/**
	 * Recalculates cart totals when possible.
	 *
	 * @return void
	 */
	private function recalculate_cart(): void {
		if ( WC()->cart ) {
			WC()->cart->calculate_totals();
		}
	}
}
