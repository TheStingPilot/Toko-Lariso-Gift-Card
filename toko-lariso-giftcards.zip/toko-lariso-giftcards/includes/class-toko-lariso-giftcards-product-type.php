<?php
/**
 * WooCommerce giftcard product type.
 *
 * @package TokoLarisoGiftcards
 */

defined( 'ABSPATH' ) || exit;

/**
 * Product type and product-page fields.
 */
class Toko_Lariso_Giftcards_Product_Type {
	/**
	 * Product type slug.
	 */
	public const TYPE = 'tokolarisogiftcard';

	/**
	 * Settings.
	 *
	 * @var Toko_Lariso_Giftcards_Settings
	 */
	private Toko_Lariso_Giftcards_Settings $settings;

	/**
	 * Constructor.
	 *
	 * @param Toko_Lariso_Giftcards_Settings $settings Settings.
	 */
	public function __construct( Toko_Lariso_Giftcards_Settings $settings ) {
		$this->settings = $settings;
	}

	/**
	 * Hooks.
	 *
	 * @return void
	 */
	public function init(): void {
		add_filter( 'product_type_selector', array( $this, 'add_product_type' ) );
		add_filter( 'woocommerce_product_class', array( $this, 'product_class' ), 10, 2 );
		add_filter( 'woocommerce_product_data_tabs', array( $this, 'hide_irrelevant_tabs' ), 20 );
		add_action( 'woocommerce_product_options_general_product_data', array( $this, 'admin_notice' ) );
		add_action( 'woocommerce_process_product_meta_' . self::TYPE, array( $this, 'save_product' ) );
		add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'render_purchase_fields' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Adds product type to selector.
	 *
	 * @param array<string,string> $types Existing types.
	 * @return array<string,string>
	 */
	public function add_product_type( array $types ): array {
		$types[ self::TYPE ] = __( 'Toko Lariso giftcard', 'toko-lariso-giftcards' );
		return $types;
	}

	/**
	 * Maps product type to class.
	 *
	 * @param string $class_name Product class.
	 * @param string $product_type Product type.
	 * @return string
	 */
	public function product_class( string $class_name, string $product_type ): string {
		if ( self::TYPE === $product_type ) {
			return 'WC_Product_Toko_Lariso_Giftcard';
		}
		return $class_name;
	}

	/**
	 * Hides stock/shipping tabs for the virtual product type.
	 *
	 * @param array<string,array<string,mixed>> $tabs Product tabs.
	 * @return array<string,array<string,mixed>>
	 */
	public function hide_irrelevant_tabs( array $tabs ): array {
		if ( isset( $tabs['shipping'] ) ) {
			$tabs['shipping']['class'][] = 'hide_if_' . self::TYPE;
		}
		if ( isset( $tabs['inventory'] ) ) {
			$tabs['inventory']['class'][] = 'show_if_' . self::TYPE;
		}
		return $tabs;
	}

	/**
	 * Shows admin guidance.
	 *
	 * @return void
	 */
	public function admin_notice(): void {
		global $product_object;

		if ( ! $product_object || self::TYPE !== $product_object->get_type() ) {
			return;
		}

		echo '<div class="options_group show_if_' . esc_attr( self::TYPE ) . '">';
		echo '<p class="form-field"><span class="description">';
		echo esc_html__( 'Giftcard amounts are configured in WooCommerce > Toko Lariso Giftcards. This product is sold as a virtual, non-taxable multi-purpose voucher.', 'toko-lariso-giftcards' );
		echo '</span></p>';
		echo '</div>';
	}

	/**
	 * Saves type-specific product settings.
	 *
	 * @param int $post_id Product id.
	 * @return void
	 */
	public function save_product( int $post_id ): void {
		$product = wc_get_product( $post_id );
		if ( ! $product ) {
			return;
		}

		$product->set_virtual( true );
		$product->set_tax_status( 'none' );
		$product->set_sold_individually( false );
		$product->save();
	}

	/**
	 * Enqueues product page styles.
	 *
	 * @return void
	 */
	public function enqueue_assets(): void {
		if ( function_exists( 'is_product' ) && is_product() ) {
			wp_enqueue_style( 'tokolariso-giftcards-product', TOKO_LARISO_GIFTCARDS_URL . 'assets/css/product.css', array(), TOKO_LARISO_GIFTCARDS_VERSION );
		}
	}

	/**
	 * Renders giftcard purchase fields on product pages.
	 *
	 * @return void
	 */
	public function render_purchase_fields(): void {
		global $product;

		if ( ! $product || self::TYPE !== $product->get_type() ) {
			return;
		}

		$amounts   = $this->settings->fixed_amounts();
		$image_ids = array_values(
			array_unique(
				array_filter(
					array_merge(
						array( (int) $product->get_image_id() ),
						array_map( 'absint', $product->get_gallery_image_ids() )
					)
				)
			)
		);

		wp_nonce_field( 'tokolariso_giftcard_add_to_cart', 'tokolariso_giftcard_nonce' );
		?>
		<div class="tokolariso-giftcard-fields">
			<fieldset>
				<legend><?php esc_html_e( 'Giftcard amount', 'toko-lariso-giftcards' ); ?></legend>
				<?php foreach ( $amounts as $index => $amount ) : ?>
					<label>
						<input type="radio" name="tokolariso_giftcard_amount_choice" value="fixed:<?php echo esc_attr( wc_format_decimal( $amount ) ); ?>" <?php checked( 0, $index ); ?> />
						<?php echo wp_kses_post( wc_price( $amount ) ); ?>
					</label>
				<?php endforeach; ?>
				<?php if ( $this->settings->custom_amount_enabled() ) : ?>
					<label class="tokolariso-giftcard-custom-amount">
						<input type="radio" name="tokolariso_giftcard_amount_choice" value="custom" />
						<?php esc_html_e( 'Custom amount', 'toko-lariso-giftcards' ); ?>
						<input type="number" name="tokolariso_giftcard_custom_amount" min="1" step="0.01" inputmode="decimal" />
					</label>
				<?php endif; ?>
			</fieldset>

			<p>
				<label for="tokolariso_giftcard_recipient_name"><?php esc_html_e( 'Recipient name', 'toko-lariso-giftcards' ); ?></label>
				<input type="text" id="tokolariso_giftcard_recipient_name" name="tokolariso_giftcard_recipient_name" required />
			</p>
			<p>
				<label for="tokolariso_giftcard_recipient_email"><?php esc_html_e( 'Recipient email', 'toko-lariso-giftcards' ); ?></label>
				<input type="email" id="tokolariso_giftcard_recipient_email" name="tokolariso_giftcard_recipient_email" required />
			</p>
			<p>
				<label for="tokolariso_giftcard_message"><?php esc_html_e( 'Personal message', 'toko-lariso-giftcards' ); ?></label>
				<textarea id="tokolariso_giftcard_message" name="tokolariso_giftcard_message" rows="4"></textarea>
			</p>
			<p>
				<label for="tokolariso_giftcard_delivery_date"><?php esc_html_e( 'Delivery date', 'toko-lariso-giftcards' ); ?></label>
				<input type="date" id="tokolariso_giftcard_delivery_date" name="tokolariso_giftcard_delivery_date" min="<?php echo esc_attr( gmdate( 'Y-m-d' ) ); ?>" />
			</p>

			<?php if ( $image_ids ) : ?>
				<fieldset class="tokolariso-giftcard-designs">
					<legend><?php esc_html_e( 'Choose a design', 'toko-lariso-giftcards' ); ?></legend>
					<?php foreach ( $image_ids as $index => $image_id ) : ?>
						<label>
							<input type="radio" name="tokolariso_giftcard_image_id" value="<?php echo esc_attr( $image_id ); ?>" <?php checked( 0, $index ); ?> />
							<?php echo wp_kses_post( wp_get_attachment_image( $image_id, 'thumbnail' ) ); ?>
						</label>
					<?php endforeach; ?>
				</fieldset>
			<?php endif; ?>
		</div>
		<?php
	}
}

/**
 * Defines the product class once WooCommerce product classes are available.
 *
 * @return void
 */
function tokolariso_giftcards_register_product_class(): void {
	if ( ! class_exists( 'WC_Product_Simple' ) || class_exists( 'WC_Product_Toko_Lariso_Giftcard' ) ) {
		return;
	}

	/**
	 * Giftcard product object.
	 */
	class WC_Product_Toko_Lariso_Giftcard extends WC_Product_Simple {
		/**
		 * Gets product type.
		 *
		 * @return string
		 */
		public function get_type(): string {
			return Toko_Lariso_Giftcards_Product_Type::TYPE;
		}

		/**
		 * Giftcards are virtual.
		 *
		 * @return bool
		 */
		public function is_virtual(): bool {
			return true;
		}

		/**
		 * Giftcard voucher sales are treated as non-taxable.
		 *
		 * @param string $context Context.
		 * @return string
		 */
		public function get_tax_status( $context = 'view' ): string {
			return 'none';
		}
	}
}

tokolariso_giftcards_register_product_class();
add_action( 'woocommerce_loaded', 'tokolariso_giftcards_register_product_class' );
