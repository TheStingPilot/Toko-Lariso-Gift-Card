# Technical Notes

## Architecture

The plugin is a conventional WordPress/WooCommerce plugin with small service classes:

- `Toko_Lariso_Giftcards_Settings`: option defaults, sanitization, and settings access.
- `Toko_Lariso_Giftcards_WPML`: WPML string registration and translation for option-backed email template settings.
- `Toko_Lariso_Giftcards_Repository`: database access, code hashing/encryption, balance mutation, and ledger logging.
- `Toko_Lariso_Giftcards_Product_Type`: custom WooCommerce product type `tokolarisogiftcard`, dynamic amount price label, and product-page add-to-cart form with purchase fields.
- `Toko_Lariso_Giftcards_Shipping`: giftcard shipping exclusion for rate calculations and zero-cost giftcard-only fallback package rates.
- `Toko_Lariso_Giftcards_Sendcloud_Compatibility`: defensive session normalization before SendCloud's Store API checkout validation runs.
- `Toko_Lariso_Giftcards_Cart`: cart item metadata, dynamic giftcard sale pricing, Store Credit fee application, and session allocations.
- `Toko_Lariso_Giftcards_Store_API`: WooCommerce Store API extension data and `cart/extensions` update callback.
- `Toko_Lariso_Giftcards_Blocks_Integration`: Cart/Checkout Blocks asset registration via WooCommerce Blocks `IntegrationInterface`, with current `wc-blocks-data-store` dependency detection and fallback for older Blocks builds.
- `Toko_Lariso_Giftcards_Order`: checkout redemption, giftcard issuance after successful payment, and refund handling.
- `Toko_Lariso_Giftcards_Admin`: WooCommerce submenu for giftcard management.
- `Toko_Lariso_Giftcards_Email`: WooCommerce mailer integration for recipient emails.

## Language and WPML

The base language is English. The plugin text domain is `toko-lariso-giftcards`.

Static UI strings are wrapped in WordPress i18n functions using that text domain. Option-backed email template fields are not static source strings, so the plugin supports WPML in two ways:

- `wpml-config.xml` declares the `tokolariso_giftcards_settings` option keys for WPML String Translation.
- `Toko_Lariso_Giftcards_WPML` registers and translates these fields at runtime:
  - `email_subject`
  - `email_heading`
  - `email_intro`
  - `email_button_label`
  - `email_shop_url`

The WPML string context is `toko-lariso-giftcards`.

## VAT and Fiscal Treatment

This implementation treats giftcards as multi-purpose vouchers / store credit. On sale, the `tokolarisogiftcard` product is forced to non-taxable but not virtual. It remains a normal order line item, while the shipping compatibility layer prevents giftcard-only carts from triggering paid shipping-rate lookups. On redemption, the giftcard reduces the remaining payable amount after WooCommerce has calculated product totals, shipping totals, and VAT.

Example:

- Products: EUR 34.95 including VAT
- Shipping: EUR 6.95 including VAT
- WooCommerce total before giftcard: EUR 41.90
- Giftcard credit: EUR 15.00
- Payable remainder: EUR 26.90

The credit is implemented as a non-taxable negative fee because WooCommerce totals and Blocks need a server-side cart total line that survives Store API checkout. WooCommerce intentionally treats negative fees like taxable discounts by allocating tax to them during cart-total calculation. To keep giftcards as exact post-tax store credit, this plugin creates giftcard fees with ids prefixed by `tokolariso_giftcard_` and uses `woocommerce_cart_totals_get_fees_from_cart_taxes` to clear taxes only for those fees. The fee reduces the final payable total by the exact redeemed amount but does not reduce product or shipping VAT bases and is not a WooCommerce coupon.

Fiscal assumptions must be reviewed by the merchant's accountant/bookkeeper. This code is a technical implementation of the requested treatment, not tax advice.

## Shipping Treatment

Giftcard products are non-virtual order line items. This is deliberate for compatibility with order integrations that ignore virtual-only orders. They are still excluded from shipping-rate requests so giftcard-only carts do not require a paid shipping method.

The shipping behavior is:

- Giftcard products remain non-virtual and appear as normal order line items.
- `woocommerce_product_needs_shipping` returns `false` for giftcard products so they do not participate in shipping-rate requests.
- `woocommerce_cart_needs_shipping` and `woocommerce_cart_needs_shipping_address` remain `true` only when the cart contains a non-giftcard shippable item.
- `woocommerce_cart_shipping_packages` keeps mixed carts as one package for Store API/Blocks stability and excludes giftcard value from `contents_cost`.
- `woocommerce_package_rates` still sets any giftcard-only fallback package rates to zero, including third-party rates such as SendCloud rates.
- If another integration creates a giftcard-only package with no rates, the plugin injects a fallback `Giftcard delivery` shipping rate at zero cost.

This means a cart containing only a giftcard does not need a shipping-rate lookup or a paid shipping method, while a cart with physical products still pays the normal shipping charge for those physical products without creating multiple Store API shipping packages.

## SendCloud Blocks Compatibility

SendCloud's WooCommerce Blocks service-point checkout handler reads `WC()->session->get( 'chosen_shipping_methods', '' )` and immediately calls `reset()` on the result. In a giftcard-only checkout, WooCommerce may have no shipping method selection because the cart intentionally does not need shipping. In that state the session fallback can be a string, which causes a PHP fatal in SendCloud:

```text
reset(): Argument #1 ($array) must be of type array, string given
```

The compatibility layer hooks `woocommerce_store_api_checkout_order_processed` at priority `1`, before SendCloud's default priority `10` handler. For orders that contain only Toko Lariso giftcards and no shipping line items, it normalizes the session value to a non-empty array containing the non-SendCloud method id `tokolariso_giftcard_delivery`. SendCloud then sees that the selected method is not `sc_service_point` and returns without service-point validation.

The workaround is intentionally limited to giftcard-only orders without shipping items. It does not alter normal physical-product shipping, selected SendCloud rates, or service-point orders.

## Giftcard Product Pricing and Add to Cart

The giftcard product does not use the regular WooCommerce product price as the voucher amount. The product can be saved without a fixed regular price. The product page renders a custom `tokolarisogiftcard` add-to-cart form where shoppers choose one configured fixed amount, or a custom amount when enabled.

The selected amount is stored in cart item data and assigned as the cart line price during `woocommerce_before_calculate_totals`. Each add-to-cart action is limited to quantity `1` so each giftcard purchase has exactly one recipient, message, delivery date, design, and generated code. Buying multiple giftcards is supported by adding the product multiple times.

## Database Tables

Tables are created with `dbDelta()` on activation.

### `{prefix}tokolariso_giftcards`

- `id`
- `code_hash`: HMAC-SHA256 of the normalized code.
- `code_encrypted`: encrypted full code for admin detail/resend flows only.
- `code_mask`: masked public/admin display code.
- `initial_amount`
- `current_balance`
- `currency`
- `status`: `active`, `used`, `expired`, `blocked`
- `expires_at`
- `issued_at`
- `purchased_order_id`
- `purchased_order_item_id`
- `recipient_name`
- `recipient_email`
- `message`
- `image_id`
- `image_url`
- `created_at`
- `updated_at`

### `{prefix}tokolariso_giftcard_ledger`

- `id`
- `giftcard_id`
- `mutation_type`: `issued`, `redeemed`, `refunded`, `adjusted`, `expired`
- `amount`: signed amount; redemptions/expirations are negative.
- `balance_before`
- `balance_after`
- `order_id`
- `user_id`
- `reason`
- `created_at`

## Balance Safety

Giftcard application in Cart/Checkout is tentative and stored in the WooCommerce session. The real balance mutation happens during order creation.

The repository uses:

- SQL transaction with `START TRANSACTION` / `COMMIT` / `ROLLBACK`
- `SELECT ... FOR UPDATE` against the giftcard row
- Balance check before update
- Order/giftcard ledger idempotency check for `redeemed`
- Order meta `_tokolariso_giftcards_redeemed` to avoid repeated order-level processing

This prevents two concurrent checkout requests from spending the same available balance twice.

## Hooks and Integration Points

### Product

- `product_type_selector`
- `woocommerce_product_class`
- `woocommerce_get_price_html`
- `woocommerce_product_data_tabs`
- `woocommerce_tokolarisogiftcard_add_to_cart`
- `woocommerce_before_add_to_cart_button`
- `woocommerce_product_needs_shipping`
- `woocommerce_cart_needs_shipping`
- `woocommerce_cart_needs_shipping_address`
- `woocommerce_store_api_checkout_order_processed` at priority `1` for SendCloud session normalization
- `woocommerce_add_to_cart_validation`
- `woocommerce_add_cart_item_data`
- `woocommerce_before_calculate_totals`
- `woocommerce_cart_calculate_fees`
- `woocommerce_cart_totals_get_fees_from_cart_taxes`
- `woocommerce_get_item_data`
- `woocommerce_checkout_create_order_line_item`

### Cart and Checkout Blocks

- `before_woocommerce_init`: declares `cart_checkout_blocks` and HPOS compatibility.
- `woocommerce_blocks_loaded`: registers Store API endpoint data and update callback.
- `woocommerce_blocks_cart_block_registration`
- `woocommerce_blocks_checkout_block_registration`
- `woocommerce_cart_shipping_packages`
- `woocommerce_package_rates`
- Store API endpoints extended:
  - `CartSchema::IDENTIFIER`
  - `CheckoutSchema::IDENTIFIER`
- Store API update callback namespace:
  - `tokolariso-giftcards`
- Frontend call:
  - `wc.blocksCheckout.extensionCartUpdate({ namespace, data })`
- The Blocks UI keeps a shared in-flight update guard around Apply/Remove, with listener synchronization across Checkout Blocks rerenders, so a rerendered checkout cannot submit duplicate giftcard updates before the previous Store API request finishes.
- UI slot:
  - `ExperimentalDiscountsMeta`
- Filter:
  - `totalLabel`, renamed to `Remaining total` when giftcard credit is applied.

### Orders

- `woocommerce_store_api_checkout_order_processed`
- `woocommerce_checkout_order_processed`
- `woocommerce_payment_complete`
- `woocommerce_order_status_processing`
- `woocommerce_order_status_completed`
- `woocommerce_order_status_refunded`
- `woocommerce_order_refunded`

## Public Endpoint Security

Public Store API data exposes:

- Giftcard database id
- Masked code only
- Applied amount
- Current card balance
- Formatted amounts
- Multiple-card setting

It does not expose full giftcard codes or encrypted code payloads.

## Admin Full Code Access

Giftcard codes are stored encrypted in the `code_encrypted` column and masked everywhere customer-facing. The WooCommerce admin giftcard detail screen shows the decrypted full code only to users who can access the plugin admin page with `manage_woocommerce`. This is intended for staging tests, stores with disabled outbound email, and manual recipient support.

The full code is not exposed in Cart/Checkout Blocks, Store API responses, order notes, or the admin list table.

## Local PHP Syntax Testing

The plugin includes `tests/lint-all.php`, which recursively runs `php -l` for every PHP file in the plugin folder.

Commands:

```sh
php -l toko-lariso-giftcards.php
php tests/lint-all.php
```

PowerShell:

```powershell
Get-ChildItem -Recurse -Filter *.php | ForEach-Object { php -l $_.FullName }
```

## Admin Security

Admin actions require:

- `manage_woocommerce`
- WordPress nonces
- Sanitized inputs
- Escaped output

Manual balance corrections require a reason and create `adjusted` ledger entries.

## Refund Assumption

The default refund behavior is manual review. Automatic restoration can be enabled only for full order refunds. Partial refunds are left manual because the plugin cannot reliably infer whether the refunded value should restore store credit, cash, shipping, or a mix.

## Uninstall and Deactivation

Deactivation:

- Clears scheduled giftcard email events only.
- Does not delete giftcards, ledger, or settings.

Uninstall:

- Deletes data only if the explicit setting is enabled.

## Official WooCommerce References Used

- Store API extensibility: https://github.com/woocommerce/woocommerce/blob/trunk/docs/apis/store-api/extending-store-api/README.md
- Store API endpoint data: https://github.com/woocommerce/woocommerce/blob/trunk/docs/apis/store-api/extending-store-api/extend-store-api-add-data.md
- Store API update callbacks: https://github.com/woocommerce/woocommerce/blob/trunk/docs/apis/store-api/extending-store-api/extend-store-api-update-cart.md
- Cart/Checkout Blocks extensibility: https://github.com/woocommerce/woocommerce/blob/trunk/docs/block-development/extensible-blocks/cart-and-checkout-blocks/README.md
- Blocks integration interface: https://github.com/woocommerce/woocommerce/blob/trunk/docs/block-development/reference/integration-interface.md
- Checkout processing hook notes: https://github.com/woocommerce/woocommerce/blob/trunk/docs/block-development/extensible-blocks/cart-and-checkout-blocks/how-checkout-processes-an-order.md
- Negative fee tax allocation and `woocommerce_cart_totals_get_fees_from_cart_taxes`: https://woocommerce.github.io/code-reference/files/woocommerce-includes-class-wc-cart-totals.html
- Cart fee ids through `WC_Cart_Fees::add_fee()`: https://woocommerce.github.io/code-reference/files/woocommerce-includes-class-wc-cart-fees.html

## Cart Block Troubleshooting

If a normal non-giftcard product also leaves the Cart Block on loading placeholders, the failure is likely outside the giftcard line-item logic. Check browser console errors and Store API network responses before testing giftcard redemption. Uncaught JavaScript errors from theme scripts, consent/cookie plugins, cache/minify plugins, or shipping/VAT extensions can prevent WooCommerce Blocks from completing frontend rendering.
